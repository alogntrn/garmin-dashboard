"""Browser smoke tests for the dashboard UI (development only).

Needs a running dashboard (default http://127.0.0.1:8050) with sample data, Playwright and Chrome:
    python3 tools/ui_smoke.py              # all tests
    python3 tools/ui_smoke.py test_today   # some tests
Each test runs in a fresh 390 x 844 page; any console error fails the test.
"""
import json
import re
import os
import sys
import traceback
import urllib.request

from playwright.sync_api import sync_playwright

BASE = os.environ.get("DASH_URL", "http://127.0.0.1:8050")
CHROME = os.environ.get("CHROME", "/usr/bin/google-chrome")
TESTS = {}


def smoke(fn=None, *, allow=()):
    """Register a test. `allow`: console-error substrings the test provokes on purpose (a stubbed 503, an aborted POST)."""
    def reg(f):
        f.allow = allow
        TESTS[f.__name__] = f
        return f
    return reg(fn) if fn else reg


def api(path, body=None, method=None):
    req = urllib.request.Request(BASE + path, data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Content-Type": "application/json"}, method=method or ("POST" if body is not None else "GET"))
    with urllib.request.urlopen(req) as r:
        return json.load(r)


def reload(page, settle=600):
    """A real reload: go() to the hash the page is already on is a same-document navigation and reloads nothing."""
    page.reload()
    page.wait_for_load_state("networkidle")
    page.wait_for_timeout(settle)


def go(page, hash_, wait=".loading", settle=600):
    page.goto(BASE + "/" + hash_)
    page.wait_for_load_state("networkidle")
    page.wait_for_timeout(settle)


# ------------------------------------------------------------------ tests
@smoke
def test_boot(page):
    go(page, "")
    assert page.locator("#app").inner_text().strip(), "app area is empty"


ROUTES = ["#/today", "#/activities", "#/progress/overview", "#/progress/run", "#/progress/ride",
          "#/progress/strength", "#/recovery", "#/settings", "#/plan"]
TAB_OF = {"#/today": "today", "#/activities": "activities", "#/recovery": "recovery", "#/plan": "today"}


@smoke
def test_shell_routes(page):
    for h in ROUTES:
        go(page, h)
        assert page.locator("#app").inner_text().strip(), f"{h}: empty page"
        links = page.locator("#tabbar a")
        assert links.count() == 4, f"{h}: tab bar has {links.count()} links"
        want = TAB_OF.get(h, "progress" if h.startswith("#/progress") else None)
        cur = page.locator("#tabbar a[aria-current=page]")
        if want:
            assert cur.count() == 1 and cur.get_attribute("data-tab") == want, f"{h}: wrong active tab"
    go(page, "#/overview")
    assert page.evaluate("location.hash") == "#/today", "old #/overview did not redirect"
    go(page, "#/progress/strength")
    href = page.locator(".g-rack a.g-day").first.get_attribute("href")
    assert href.startswith("#/progress/strength/"), f"rack link still points to {href}"


@smoke
def test_shell_routes_wide(page):
    go(page, "#/today")
    assert page.locator("#side").is_visible(), "sidebar hidden on a wide screen"
    assert not page.locator("#tabbar").is_visible(), "tab bar visible on a wide screen"


def today_iso():
    import datetime
    return datetime.date.today().isoformat()


def days_from_today(n):
    import datetime
    return (datetime.date.today() + datetime.timedelta(days=n)).isoformat()


def set_gym_day(code, start_offset=0):
    """Make today a given plan letter: block start `start_offset` days from today, explicit session for today."""
    api("/api/gym/settings", {"start": days_from_today(start_offset)})
    api("/api/gym/day", {"date": today_iso(), "session": code, "done": False})


@smoke
def test_today(page):
    set_gym_day("A")
    go(page, "#/today")
    call = page.locator(".td-call").inner_text().strip()
    assert call.startswith("Leg day.") or call.startswith("Recovery day."), f"headline: {call!r}"
    assert page.locator(".td-ready .td-rrow").count() == 4, "readiness rows"
    assert page.locator(".td-gym a.u-btn[href='#/workout']").count() == 1, "no Start button on a plan day"
    assert page.locator(".td-cardio a.u-row").count() == 2, "cardio rows"
    assert page.locator(".td-week .td-day").count() == 7, "week strip"


def clear_choice():
    """Today without a chosen workout and without sets (block started a week ago)."""
    t = today_iso()
    api("/api/gym/settings", {"start": days_from_today(-8)})
    for row in api("/api/gym")["sets"]:
        if row["date"] == t:
            api(f"/api/gym/set/{row['id']}", method="DELETE")
    api("/api/gym/day", {"date": t, "session": "", "done": False, "rpe": None, "pain": None, "note": ""})


@smoke
def test_today_choose_workout(page):
    clear_choice()
    go(page, "#/today")
    assert page.locator(".td-choice").count() == 4, "A, B, C and an empty session"
    assert page.locator(".td-choice .td-sug").count() == 1, "exactly one suggestion"
    call = page.locator(".td-call").inner_text().strip()
    assert not call.startswith(("Leg day.", "Upper-body day.", "Rest day.")), f"no gym line before choosing: {call!r}"
    assert not small_targets(page, ".td-gym button, .td-gym a"), "choice rows reach 44 px"
    name = page.locator(".td-choice[data-pick='B'] .rt b").inner_text()
    page.locator(".td-choice[data-pick='B']").click()
    page.wait_for_function("() => location.hash === '#/workout'")
    page.wait_for_function("n => document.querySelector('#wm .wo-tt b')?.textContent === n", arg=name)  # past the loading bar
    assert api("/api/gym")["days"][today_iso()]["session"] == "B"


@smoke
def test_today_change_workout(page):
    clear_choice()
    api("/api/gym/day", {"date": today_iso(), "session": "A"})
    go(page, "#/today")
    assert page.locator(".td-call").inner_text().strip().startswith(("Leg day.", "Recovery day."))
    page.locator(".td-gym [data-act='change']").click()
    page.wait_for_selector(".td-choice")
    assert api("/api/gym")["days"][today_iso()]["session"] is None


@smoke
def test_today_coach_stub(page):
    """Fresh install: no HRV numbers yet and no run suggestion. The row shows the coach's text, Today still renders."""
    set_gym_day("A")
    co = api("/api/coach")
    hrv = next(f for f in co["readiness"]["factors"] if f["name"] == "HRV")
    hrv.update(value=None, lo=None, hi=None, status="none", text="No HRV data yet.")
    for f in co["readiness"]["factors"]:                 # fixed numbers, so the test doesn't depend on last night's data
        if f["name"] == "Resting HR":
            f.update(value=50, lo=47, hi=53, unit="bpm", status="green")
        elif f["name"] == "Sleep":
            f.update(value=7.5, lo=6, hi=9, unit="h", status="green")
    co["run"] = None
    page.route("**/api/coach", lambda r: r.fulfill(status=200, content_type="application/json", body=json.dumps(co)))
    go(page, "#/today")
    rows = page.locator(".td-ready .td-rrow")
    assert rows.count() == 4, "readiness rows"
    assert page.locator(".td-ready .td-rtext", has_text="No HRV data yet.").count() == 1, "HRV text instead of a bar"
    assert page.locator(".td-ready .u-range").count() == 2, "bars for resting HR and sleep only"
    assert page.locator(".td-cardio a.u-row").count() == 1, "one cardio row when the run is missing"


@smoke(allow=("503",))
def test_today_without_coach(page):
    set_gym_day("A")
    page.route("**/api/coach", lambda r: r.fulfill(status=503, body="busy"))
    go(page, "#/today")
    assert page.locator(".td-call").inner_text().strip().startswith("Leg day."), "headline"
    assert "Coach data didn't load" in page.locator(".td-why").inner_text(), "says what failed"
    assert page.locator(".td-ready").count() == 0 and page.locator(".td-cardio").count() == 0
    assert page.locator(".td-gym a.u-btn[href='#/workout']").count() == 1, "gym card still there"


@smoke(allow=("503",))
def test_today_without_gym(page):
    """The gym log can't be read: Today still shows the call, recovery and cardio, just no gym card."""
    page.route("**/api/gym", lambda r: r.fulfill(status=503, body="busy"))
    go(page, "#/today")
    assert page.locator("#app .empty").count() == 0, "error page instead of Today"
    assert page.locator(".td-call").inner_text().strip(), "headline"
    assert page.locator(".td-ready").count() == 1 and page.locator(".td-cardio").count() == 1
    assert page.locator(".td-gym").count() == 0 and page.locator(".td-strip").count() == 0


def clear_today(code="A"):
    """Fresh session for today: plan letter `code`, no sets, not done, no effort/pain/note."""
    set_gym_day(code)
    t = today_iso()
    for row in api("/api/gym")["sets"]:
        if row["date"] == t:
            api(f"/api/gym/set/{row['id']}", method="DELETE")
    api("/api/gym/day", {"date": t, "done": False, "rpe": None, "pain": None, "note": ""})


def log_via_api(slot="bench", ex="bench", name="Barbell bench press", kg=50, reps=8):
    return api("/api/gym/set", {"date": today_iso(), "session": "A", "slot": slot, "ex": ex, "name": name, "kg": kg, "reps": reps})


def to_second_exercise(page):
    first = page.locator(".wo-name").inner_text()
    page.locator(".wo-next").click()
    page.wait_for_function("n => document.querySelector('.wo-name')?.textContent !== n", arg=first)


def ensure_value(page, field, value):
    box = page.locator(f".wo-step[data-f='{field}'] input")
    if not box.input_value():
        box.fill(str(value))
    return box


@smoke
def test_workout_log_set(page):
    clear_today()
    go(page, "#/workout")
    assert page.locator("#wm").is_visible(), "workout layer"
    to_second_exercise(page)
    kg = page.locator(".wo-step[data-f='kg'] input")
    before = float(kg.input_value() or 0)
    page.locator(".wo-step[data-f='kg'] button[data-d='1']").click()
    assert float(kg.input_value()) == before + 2.5, f"kg {kg.input_value()} after + from {before}"
    ensure_value(page, "reps", 8)
    assert "Log set 1" in page.locator(".wo-log").inner_text()
    with page.expect_response(lambda r: r.url.endswith("/api/gym/set") and r.request.method == "POST") as resp:
        page.locator(".wo-log").click()
    assert resp.value.status == 200, f"POST status {resp.value.status}"
    page.wait_for_selector(".wo-set")
    assert page.locator(".wo-set").count() == 1, "one logged set row"
    assert "Log set 2" in page.locator(".wo-log").inner_text(), page.locator(".wo-log").inner_text()


@smoke(allow=("Failed to load resource", "ERR_FAILED"))
def test_log_set_failure_keeps_values(page):
    clear_today()
    page.route("**/api/gym/set", lambda r: r.abort() if r.request.method == "POST" else r.continue_())
    go(page, "#/workout")
    to_second_exercise(page)
    page.locator(".wo-step[data-f='kg'] input").fill("55")
    page.locator(".wo-step[data-f='reps'] input").fill("9")
    page.locator(".wo-log").click()
    page.wait_for_selector(".wo-err")
    assert "Couldn't save" in page.locator(".wo-err").inner_text()
    assert page.locator(".wo-set").count() == 0, "nothing logged"
    assert page.locator(".wo-step[data-f='kg'] input").input_value() == "55"
    assert page.locator(".wo-step[data-f='reps'] input").input_value() == "9"
    assert page.locator(".wo-log").is_enabled(), "log button usable again"


@smoke
def test_overview_jump_and_reorder(page):
    clear_today()
    go(page, "#/workout")
    page.locator("button[aria-label='Session overview']").click()
    rows = page.locator(".wo-ov .wo-row")
    assert rows.count() >= 5, "overview rows"
    fourth = rows.nth(3).locator(".rt b").inner_text()
    rows.nth(3).locator(".rt").click()
    page.wait_for_function("n => document.querySelector('.wo-name')?.textContent === n", arg=fourth)
    assert page.locator("#sheet").is_hidden(), "overview closes after a jump"
    page.locator("button[aria-label='Session overview']").click()
    last = rows.nth(rows.count() - 1)
    moved = last.locator(".rt b").inner_text()
    last.locator(".wo-grip").drag_to(rows.nth(0), target_position={"x": 40, "y": 3})
    assert rows.nth(0).locator(".rt b").inner_text() == moved, "dragged row is first"
    reload(page)
    page.locator("button[aria-label='Session overview']").click()
    assert page.locator(".wo-ov .wo-row").nth(0).locator(".rt b").inner_text() == moved, "order survives a reload"
    assert page.locator(".wo-name").inner_text() == fourth, "still on the exercise picked before"


@smoke
def test_workout_choose_then_log(page):
    clear_choice()
    go(page, "#/workout")
    assert page.locator("#wm .wo-choice").count() == 4, "Workout mode asks which workout first"
    name = page.locator("#wm .wo-choice[data-pick='C'] .rt b").inner_text()
    page.locator("#wm .wo-choice[data-pick='C']").click()
    page.wait_for_selector("#wm .wo-log")
    assert page.locator("#wm .wo-tt b").inner_text() == name
    assert api("/api/gym")["days"][today_iso()]["session"] == "C"


@smoke
def test_switch_only_before_first_set(page):
    clear_choice()
    api("/api/gym/day", {"date": today_iso(), "session": "A"})
    go(page, "#/workout")
    page.locator("button[aria-label='Session overview']").click()
    page.locator("#sheet [data-act='switch']").click()
    name = page.locator("#sheet .wo-choice[data-pick='B'] .rt b").inner_text()
    page.locator("#sheet .wo-choice[data-pick='B']").click()
    page.wait_for_function("n => document.querySelector('#wm .wo-tt b')?.textContent === n", arg=name)
    assert page.locator("#sheet").is_hidden()
    api("/api/gym/set", {"date": today_iso(), "session": "B", "slot": "pd", "ex": "pd", "name": "Lat pulldown", "kg": 45, "reps": 10})
    reload(page)
    page.locator("button[aria-label='Session overview']").click()
    assert page.locator("#sheet [data-act='switch']").count() == 0, "no switching once a set is logged"


@smoke
def test_activities_weeks_and_gym(page):
    clear_today()
    log_via_api()
    go(page, "#/activities")
    assert page.locator(".ac-week").first.locator("h2").inner_text() == "This week"
    assert page.locator(".ac-week").first.locator(".ac-tot").inner_text().strip(), "week totals"
    assert page.locator(".ac-list a[href^='#/gym-session/']").count() >= 1, "gym sessions in the list"
    assert page.locator(".ac-list a[href^='#/activity/']").count() >= 1, "Garmin activities in the list"


@smoke
def test_activities_filter_gym(page):
    clear_today()
    log_via_api()
    go(page, "#/activities")
    page.locator(".ac-seg button", has_text="Gym").click()
    page.wait_for_function("() => !document.querySelector(\".ac-list a[href^='#/activity/']\")")
    assert page.locator(".ac-list a[href^='#/gym-session/']").count() >= 1
    page.locator(".ac-search input").fill("zzz-nothing")
    page.wait_for_selector(".ac-empty")
    page.locator(".ac-search input").fill("bench")
    page.wait_for_selector(".ac-list a[href^='#/gym-session/']")


@smoke
def test_activities_calendar(page):
    clear_today()
    log_via_api()
    go(page, "#/activities")
    page.locator("button[aria-label='Calendar']").click()
    page.wait_for_selector(".ac-cal .ac-cell")
    assert page.locator(".ac-cal .ac-cell").count() == 42
    title = page.locator(".ac-month").inner_text()
    assert page.locator(".ac-cell.today i.gym").count() == 1, "today's gym session shows as a dot"
    page.locator(".ac-cell.today").click()
    page.wait_for_selector("#sheet a[href^='#/gym-session/']")
    page.keyboard.press("Escape")
    page.locator("button[aria-label='Previous month']").click()
    page.wait_for_function("t => document.querySelector('.ac-month')?.textContent !== t", arg=title)


@smoke
def test_gym_session_page(page):
    clear_today()
    log_via_api()
    go(page, "#/activities")
    page.locator(f".ac-list a[href='#/gym-session/{today_iso()}']").click()
    page.wait_for_selector(".gs-ex")
    assert page.locator("#pagehead .ph-title").inner_text().strip(), "session name as the title"
    ex = page.locator(".gs-ex", has_text="Barbell bench press")
    assert ex.count() == 1 and "50 kg × 8" in ex.inner_text(), "logged sets listed"
    assert page.locator(".gs-check").count() == 1, "effort check"
    assert page.locator(f"a[href='#/progress/strength/{today_iso()}'], a[href='#/workout']").count() >= 1, "a way to edit"


@smoke
def test_gym_session_page_without_sets(page):
    clear_choice()
    api("/api/gym/day", {"date": today_iso(), "session": "B"})
    go(page, f"#/gym-session/{today_iso()}")
    page.wait_for_selector(".gs-none")
    assert page.locator(".gs-ex").count() == 0


@smoke
def test_activity_detail(page):
    go(page, "#/activities")
    page.locator(".ac-seg button", has_text="All").click()
    link = page.locator(".ac-list a[href^='#/activity/']").first
    aid = link.get_attribute("href").split("/")[-1]
    name = link.locator(".rt b").inner_text()
    link.click()
    page.wait_for_selector(".av-stats")
    assert page.locator("#pagehead .ph-title").inner_text().strip() == name, "activity name as the page title"
    assert page.locator(".av-stat").count() >= 4, "stat grid"
    a = api(f"/api/activity/{aid}")
    if a.get("hr_zones_s"):
        assert re.search(r"\d+ % in zone \d", page.locator(".av-zones").first.inner_text()), "zone headline"
    assert page.locator("#app .page-head h1").count() == 0, "old page title gone"


@smoke
def test_quick_taps_never_zoom(page):
    """Tapping + four times fast must not trigger the phone's double-tap zoom."""
    clear_today()
    go(page, "#/workout")
    looks = page.evaluate("""() => ['.wo-sc button', '.wo-log', '.wo-rirb button, .wo-next']
        .map((sel) => document.querySelector(sel)).filter(Boolean).map((el) => getComputedStyle(el).touchAction)""")
    assert looks and all(v == "manipulation" for v in looks), looks


SMALL_TARGETS_JS = """(scope) => {
  const need = 44, bad = [];
  const hits = (el, x, y) => { const h = document.elementFromPoint(x, y); return !!h && (h === el || el.contains(h)); };
  for (let el of document.querySelectorAll(scope)) {
    if (el.matches('label input')) el = el.closest('label');
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height) continue;
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    if (cy < 0 || cy > innerHeight || cx < 0 || cx > innerWidth || !hits(el, cx, cy)) continue;
    const tall = r.height >= need - .5 || (hits(el, cx, cy - need / 2 + 1) && hits(el, cx, cy + need / 2 - 1));
    const wide = el.closest('.fin-scale') || r.width >= need - .5 || (hits(el, cx - need / 2 + 1, cy) && hits(el, cx + need / 2 - 1, cy));
    if (!tall || !wide) bad.push(el.tagName.toLowerCase() + '.' + el.className + ' ' + Math.round(r.width) + 'x' + Math.round(r.height));
  }
  return bad;
}"""


def small_targets(page, scope):
    return page.evaluate(SMALL_TARGETS_JS, scope)


@smoke
def test_touch_targets(page):
    """Everything tappable on Today and in Workout mode is at least 44 px (0–10 scales: 44 px tall)."""
    clear_today()
    log_via_api()
    go(page, "#/today")
    bad = small_targets(page, "#pagehead a, #pagehead button, #app a, #app button, #tabbar a, #resume")
    go(page, "#/workout")
    sel = "#wm button, #wm a, #wm summary, #wm input"
    bad += small_targets(page, sel)
    page.locator(".wo-next").click()
    bad += small_targets(page, sel)
    for opener in ("button[aria-label='Session overview']", ".wo-set", ".wo-link", ".wo-finish"):
        page.locator(opener).first.click()
        bad += small_targets(page, "#sheet button, #sheet a, #sheet input, #sheet select")
        page.keyboard.press("Escape")
    assert not bad, sorted(set(bad))


@smoke
def test_finish_saves_day(page):
    clear_today()
    log_via_api()
    go(page, "#/workout")
    page.locator(".wo-finish").click()
    page.locator(".fin-eff button[data-v='6']").click()
    page.locator(".fin-pain button[data-v='1']").click()
    assert "hard" in page.locator(".fin-eff-l").inner_text(), "CR10 label for 6"
    page.locator(".fin-note").fill("Felt solid")
    with page.expect_response(lambda r: r.url.endswith("/api/gym/day") and r.request.method == "POST") as resp:
        page.locator(".fin-save").click()
    assert resp.value.status == 200
    day = api("/api/gym")["days"][today_iso()]
    assert day["done"] and day["rpe"] == 6 and day["pain"] == 1 and day["note"] == "Felt solid", day
    page.wait_for_function("() => location.hash === '#/today'")
    assert page.locator("#wm").is_hidden()


@smoke
def test_resume_bar_and_reload(page):
    clear_today()
    log_via_api()
    go(page, "#/workout")
    to_second_exercise(page)
    name = page.locator(".wo-name").inner_text()
    page.locator("button[aria-label='Minimise']").click()
    page.wait_for_function("() => location.hash === '#/today'")
    page.wait_for_selector("#resume:not([hidden])")
    assert "Exercise 2 of" in page.locator("#resume").inner_text(), page.locator("#resume").inner_text().replace("\n", " | ")
    go(page, "#/activities")
    assert page.locator("#resume").is_visible(), "resume bar on another tab"
    page.locator("#resume").click()
    page.wait_for_selector("#wm:not([hidden])")
    assert page.locator(".wo-name").inner_text() == name, "resume opens the remembered exercise"
    reload(page)
    assert page.locator(".wo-name").inner_text() == name, "reload keeps the exercise"


# ------------------------------------------------------------------ runner
def run(names):
    failed = []
    with sync_playwright() as p:
        br = p.chromium.launch(executable_path=CHROME, args=["--no-sandbox"])
        for name in names:
            width = 1280 if name.endswith("_wide") else 390
            ctx = br.new_context(viewport={"width": width, "height": 844}, is_mobile=width < 768, has_touch=width < 768)
            page = ctx.new_page()
            errors = []
            page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
            page.on("pageerror", lambda e: errors.append(str(e)))
            try:
                TESTS[name](page)
                errors = [e for e in errors if not any(a in e for a in TESTS[name].allow)]
                assert not errors, "console errors: " + " | ".join(errors[:3])
                print(f"PASS {name}")
            except Exception as e:  # noqa: BLE001
                failed.append(name)
                print(f"FAIL {name}: {e}")
                if os.environ.get("SMOKE_TRACE"):
                    traceback.print_exc()
            ctx.close()
        br.close()
    print(f"{len(names) - len(failed)}/{len(names)} passed")
    return not failed


if __name__ == "__main__":
    picked = sys.argv[1:] or list(TESTS)
    unknown = [n for n in picked if n not in TESTS]
    if unknown:
        sys.exit(f"unknown tests: {unknown}")
    sys.exit(0 if run(picked) else 1)
