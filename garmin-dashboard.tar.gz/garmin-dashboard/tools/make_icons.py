"""Renders the home-screen icons from the dashboard's pulse-line mark (dev only; needs Playwright and Chrome).

    python3 tools/make_icons.py

Writes garmin_dash/static/icons/: apple-touch-icon.png (180), icon-192.png, icon-512.png, icon-maskable-512.png.
Full-bleed squares: iOS and Android round the corners themselves.
"""
from pathlib import Path

from playwright.sync_api import sync_playwright

OUT = Path(__file__).resolve().parent.parent / "garmin_dash" / "static" / "icons"
# The dashboard's pulse mark (32-unit grid: x 5..27, y 11..25, centre (16, 18)) on white, coloured from blue through
# pink to orange (the run, gym and ride colours) with a soft coloured shadow, like Apple's white icons.
PULSE = "M5 19h5l3-8 5 14 3-9h6"


def svg(size: int, scale: float) -> str:
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="{size}" height="{size}">
<defs>
  <linearGradient id="bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFFFFF"/><stop offset="1" stop-color="#ECEEF4"/></linearGradient>
  <linearGradient id="st" gradientUnits="userSpaceOnUse" x1="5" y1="0" x2="27" y2="0">
    <stop offset="0" stop-color="#0A84FF"/><stop offset=".5" stop-color="#FF2D92"/><stop offset="1" stop-color="#FF9F0A"/></linearGradient>
  <filter id="sh" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="0" dy="24" stdDeviation="28" flood-color="#C2185B" flood-opacity=".26"/></filter>
</defs>
<rect width="1024" height="1024" fill="url(#bg)"/>
<g transform="translate(512 512) scale({scale}) translate(-16 -18)"><path d="{PULSE}" fill="none" stroke="url(#st)" stroke-width="3.3"
  stroke-linecap="round" stroke-linejoin="round" filter="url(#sh)"/></g></svg>"""


ICONS = [("apple-touch-icon.png", 180, 30.5), ("icon-192.png", 192, 30.5), ("icon-512.png", 512, 30.5),
         ("icon-maskable-512.png", 512, 26)]   # maskable: the mark stays well inside the 80 % safe circle

if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        br = p.chromium.launch()
        for name, size, scale in ICONS:
            pg = br.new_page(viewport={"width": size, "height": size}, device_scale_factor=1)
            pg.set_content(f'<html><body style="margin:0;background:#000">{svg(size, scale)}</body></html>')
            pg.screenshot(path=str(OUT / name), clip={"x": 0, "y": 0, "width": size, "height": size}, omit_background=False)
            print(OUT / name)
        br.close()
