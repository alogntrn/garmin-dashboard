"""Renders the home-screen icons from the dashboard's pulse-line mark (dev only; needs Playwright and Chrome).

    python3 tools/make_icons.py

Writes garmin_dash/static/icons/: apple-touch-icon.png (180), icon-192.png, icon-512.png, icon-maskable-512.png.
Full-bleed squares: iOS and Android round the corners themselves.
"""
from pathlib import Path

from playwright.sync_api import sync_playwright

OUT = Path(__file__).resolve().parent.parent / "garmin_dash" / "static" / "icons"
# The favicon's path (32-unit grid): x 5..27, y 11..25, so its centre is (16, 18).
MARK = '<path d="M5 19h5l3-8 5 14 3-9h6" fill="none" stroke="#fff" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"/>'


def svg(size: int, scale: float) -> str:
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="{size}" height="{size}">
<defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2C2C2E"/><stop offset="1" stop-color="#000"/></linearGradient></defs>
<rect width="1024" height="1024" fill="url(#g)"/>
<g transform="translate(512 512) scale({scale}) translate(-16 -18)">{MARK}</g></svg>"""


ICONS = [("apple-touch-icon.png", 180, 29), ("icon-192.png", 192, 29), ("icon-512.png", 512, 29),
         ("icon-maskable-512.png", 512, 22)]   # maskable: the mark stays inside the 80 % safe circle

if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        br = p.chromium.launch()
        for name, size, scale in ICONS:
            pg = br.new_page(viewport={"width": size, "height": size}, device_scale_factor=1)
            pg.set_content(f'<html><body style="margin:0;background:#000">{svg(size, scale)}</body></html>')
            pg.screenshot(path=str(OUT / name), clip={"x": 0, "y": 0, "width": size, "height": size}, omit_background=False)
            print(OUT / name)
        br.close()
