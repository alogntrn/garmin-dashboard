"""Fake Garmin Personal API with ~18 months of synthetic runs, rides and wellness data.
Development/testing only:  python tools/mock_garmin.py  (port 9099)
then: GARMIN_PERSONAL_API_BASE_URL=http://127.0.0.1:9099 GARMIN_PERSONAL_API_KEY=x ./garmin-dash sync
"""
from __future__ import annotations

import base64
import io
import json
import math
import random
import time
import zipfile
from datetime import date, datetime, timedelta

from flask import Flask, Response, jsonify, request

app = Flask(__name__)
rnd = random.Random(42)
TODAY = date.today()
START = TODAY - timedelta(days=540)
REST = 48
MAXHR = 196


def daterange(a, b):
    d = a
    while d <= b:
        yield d
        d += timedelta(days=1)


# ------------------------------------------------------------ activity plan
ACTS = []
aid = 15_000_000_000
for d in daterange(START, TODAY):
    prog = (d - START).days / 540  # fitness progression 0..1
    wd = d.weekday()
    plan = []
    if wd in (1, 3, 6):
        kind = {1: "easy", 3: "intervals", 6: "long"}[wd]
        plan.append(("running" if rnd.random() > 0.1 else "trail_running", kind))
    if wd == 5:
        plan.append(("road_biking", "climb"))
    if wd == 2:
        plan.append(("indoor_cycling" if d.month in (11, 12, 1, 2, 3) else "gravel_cycling", "tempo"))
    for tk, kind in plan:
        if rnd.random() < 0.18:
            continue
        aid += rnd.randint(1000, 90000)
        hour = 7 if kind != "long" else 9
        ACTS.append({"id": aid, "date": d, "type": tk, "kind": kind, "prog": prog,
                     "start": datetime(d.year, d.month, d.day, hour, rnd.randint(0, 59), 0),
                     "seed": rnd.randint(0, 10**9)})


def simulate(a):
    """Second-by-second simulation -> arrays (dt=1s)."""
    r = random.Random(a["seed"])
    p = a["prog"]
    ride = "cycl" in a["type"] or "bik" in a["type"]
    indoor = a["type"].startswith("indoor")
    ftp = 235 + 35 * p
    thr_pace = 4.35 - 0.25 * p  # min/km threshold
    secs = []
    if ride:
        if a["kind"] == "climb":
            # valley -> climb -> descent -> second climb -> home
            segs = [("flat", 900), ("climb", r.randint(1800, 3300)), ("descent", 1200), ("flat", 600),
                    ("climb", r.randint(900, 1800)), ("descent", 900), ("flat", 600)]
        else:
            segs = [("flat", 600)] + [("tempo", 900), ("flat", 300)] * 2 + [("flat", 600)]
    else:
        if a["kind"] == "intervals":
            segs = [("easy", 900)] + [("hard", int(1000 / (1000 / ((thr_pace - 0.25) * 60)))), ("jog", 120)] * 6 + [("easy", 600)]
        elif a["kind"] == "long":
            segs = [("easy", int(r.uniform(85, 115) * 60))]
        else:
            segs = [("easy", int(r.uniform(40, 60) * 60))]
    alt = 680.0
    lat, lon = 46.2333 + r.uniform(-0.02, 0.02), 7.3600 + r.uniform(-0.05, 0.05)
    heading = r.uniform(0, 2 * math.pi)
    dist, hr = 0.0, REST + 30.0
    for kind, n in segs:
        grade = {"climb": r.uniform(0.055, 0.085), "descent": -r.uniform(0.05, 0.08)}.get(kind, r.uniform(-0.005, 0.008))
        if indoor:
            grade = 0
        for _ in range(n):
            if ride:
                watts = {"flat": 0.68, "climb": 0.88, "descent": 0.12, "tempo": 0.86}[kind] * ftp
                watts = max(0, watts * r.uniform(0.85, 1.15))
                if kind == 'flat' and r.random() < 0.004:
                    watts = r.uniform(600, 950)
                if kind == "climb":
                    speed = max(2.5, watts / (75 * 9.81 * grade + 6))
                elif kind == "descent":
                    speed = r.uniform(11, 15)
                else:
                    speed = 7.5 + watts / 80 + r.uniform(-0.5, 0.5)
                intensity = watts / ftp
                cad = 88 + r.uniform(-6, 6) if watts > 20 else 0
            else:
                pace = {"easy": thr_pace * 1.25, "hard": thr_pace * 0.93, "jog": thr_pace * 1.55}[kind]
                speed = 1000 / (pace * 60) * r.uniform(0.96, 1.04)
                watts = None
                intensity = (1000 / (thr_pace * 60)) and speed / (1000 / (thr_pace * 60))
                cad = 172 + (speed - 3) * 8 + r.uniform(-3, 3)
            target = REST + (MAXHR - REST) * min(1.0, 0.05 + 0.7 * max(intensity, 0) ** 1.5) + len(secs) / 900
            hr += (target - hr) / 25
            dist += speed
            alt += speed * grade
            if not indoor:
                heading += r.uniform(-0.05, 0.05)
                lat += speed * math.cos(heading) / 111_000
                lon += speed * math.sin(heading) / (111_000 * math.cos(math.radians(46.2)))
            secs.append((hr + r.uniform(-2, 2), watts, speed, cad, alt, dist, None if indoor else lat, None if indoor else lon))
    return secs, ride, indoor


SUMMARY_CACHE = {}


def summary(a):
    if a["id"] in SUMMARY_CACHE:
        return SUMMARY_CACHE[a["id"]]
    secs, ride, indoor = simulate(a)
    n = len(secs)
    hrs = [s[0] for s in secs]
    pw = [s[1] for s in secs if s[1] is not None]
    gain = sum(max(0, secs[i][4] - secs[i - 1][4]) for i in range(1, n))
    loss = sum(max(0, secs[i - 1][4] - secs[i][4]) for i in range(1, n))
    has_power = ride and (a["id"] % 5 != 0)
    s = {
        "activityId": a["id"],
        "activityName": {"easy": "Easy run", "intervals": "6 x 1 km", "long": "Long run", "climb": "Col ride", "tempo": "Tempo ride"}[a["kind"]],
        "startTimeLocal": a["start"].strftime("%Y-%m-%d %H:%M:%S"),
        "startTimeGMT": (a["start"] - timedelta(hours=2)).strftime("%Y-%m-%d %H:%M:%S"),
        "activityType": {"typeId": 1, "typeKey": a["type"], "parentTypeId": 17},
        "eventType": {"typeKey": "uncategorized"},
        "distance": round(secs[-1][5], 1), "duration": float(n), "elapsedDuration": float(n), "movingDuration": float(n - 30),
        "elevationGain": round(gain, 1), "elevationLoss": round(loss, 1),
        "averageSpeed": secs[-1][5] / n, "maxSpeed": max(x[2] for x in secs),
        "averageHR": round(sum(hrs) / n), "maxHR": round(max(hrs)),
        "calories": round(n / 60 * (11 if ride else 13)),
        "aerobicTrainingEffect": round(min(5, 1.5 + n / 3600 * 1.5), 1),
        "anaerobicTrainingEffect": round(1.0 + (1.5 if a["kind"] == "intervals" else 0.2), 1),
        "activityTrainingLoad": round(n / 3600 * (95 if a["kind"] in ("intervals", "climb", "tempo") else 60) * random.Random(a["id"]).uniform(0.9, 1.1), 1),
        "locationName": None if indoor else rnd.choice(["Sion", "Brig", "Sierre", "Visp"]),
        "manufacturer": "GARMIN", "lapCount": 3, "hasPolyline": not indoor,
    }
    if has_power:
        s.update({"avgPower": round(sum(pw) / len(pw)), "maxPower": round(max(pw)), "normPower": round(sum(pw) / len(pw) * 1.05)})
        s["averageBikingCadenceInRevPerMinute"] = 87
    if not ride:
        s.update({"averageRunningCadenceInStepsPerMinute": 174.0, "avgStrideLength": 105.0 + 10 * a["prog"],
                  "avgGroundContactTime": 248 - 8 * a["prog"], "avgVerticalOscillation": 8.9,
                  "vO2MaxValue": round(50 + 4 * a["prog"])})
    else:
        s["vO2MaxValue"] = round(51 + 4 * a["prog"]) if has_power else None
    SUMMARY_CACHE[a["id"]] = s
    return s


def build_fit(a) -> bytes:
    from fit_tool.fit_file_builder import FitFileBuilder
    from fit_tool.profile.messages.file_id_message import FileIdMessage
    from fit_tool.profile.messages.lap_message import LapMessage
    from fit_tool.profile.messages.record_message import RecordMessage
    from fit_tool.profile.messages.session_message import SessionMessage
    from fit_tool.profile.profile_type import FileType, Manufacturer, Sport

    secs, ride, indoor = simulate(a)
    has_power = ride and (a["id"] % 5 != 0)
    b = FitFileBuilder(auto_define=True, min_string_size=50)
    ts0 = int((a["start"] - timedelta(hours=2)).timestamp() * 1000)
    m = FileIdMessage(); m.type = FileType.ACTIVITY; m.manufacturer = Manufacturer.GARMIN.value
    m.product = 0; m.serial_number = 1; m.time_created = ts0
    b.add(m)
    step = 1 if a["id"] % 2 else 2  # half the files use "smart recording"
    recs = []
    for i in range(0, len(secs), step):
        hr, w, sp, cad, alt, dist, lat, lon = secs[i]
        r = RecordMessage(); r.timestamp = ts0 + i * 1000
        r.heart_rate = int(hr); r.speed = sp; r.distance = dist; r.altitude = alt
        if lat is not None:
            r.position_lat = lat; r.position_long = lon
        if has_power and w is not None:
            r.power = int(w)
        if ride:
            r.cadence = int(cad)
        else:
            r.cadence = int(cad / 2)
        recs.append(r)
    b.add_all(recs)
    n = len(secs)
    third = n // 3
    for k in range(3):
        a0, a1 = k * third, (k + 1) * third if k < 2 else n
        lp = LapMessage(); lp.timestamp = ts0 + a1 * 1000; lp.start_time = ts0 + a0 * 1000
        lp.total_elapsed_time = a1 - a0; lp.total_timer_time = a1 - a0
        lp.total_distance = secs[a1 - 1][5] - (secs[a0 - 1][5] if a0 else 0)
        lp.avg_heart_rate = int(sum(s[0] for s in secs[a0:a1]) / (a1 - a0))
        lp.max_heart_rate = int(max(s[0] for s in secs[a0:a1]))
        lp.avg_speed = lp.total_distance / (a1 - a0)
        if has_power:
            lp.avg_power = int(sum(s[1] for s in secs[a0:a1]) / (a1 - a0))
        b.add(lp)
    se = SessionMessage(); se.timestamp = ts0 + n * 1000; se.start_time = ts0
    se.sport = Sport.CYCLING if ride else Sport.RUNNING; se.total_elapsed_time = n
    b.add(se)
    fit = b.build().to_bytes()
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr(f"{a['id']}_ACTIVITY.fit", fit)
    return buf.getvalue()


# ----------------------------------------------------------- wellness model
def load_on(d):
    return sum(summary(a)["activityTrainingLoad"] for a in ACTS if a["date"] == d)


WELL = {}
fatigue = 0.0
for d in daterange(START, TODAY):
    r = random.Random(d.toordinal())
    fatigue = fatigue * 0.8 + sum(60 if a["kind"] in ("easy",) else 110 for a in ACTS if a["date"] == d) * 0.2
    prog = (d - START).days / 540
    rhr = 52 - 4 * prog + fatigue / 25 + r.uniform(-1.5, 1.5)
    hrv = 58 + 8 * prog - fatigue / 6 + r.uniform(-6, 6)
    sleep = r.gauss(7.3 if d.weekday() >= 4 else 6.9, 0.6) * 3600
    WELL[d] = {"rhr": round(rhr), "hrv": round(hrv), "sleep": sleep, "steps": int(r.gauss(9500, 2500)),
               "stress": int(r.uniform(22, 38) + fatigue / 10), "bbh": int(min(100, r.uniform(70, 98) - fatigue / 8)),
               "score": int(min(98, max(40, 55 + (sleep / 3600 - 6) * 15 + r.uniform(-8, 8))))}


def days(a, b):
    a, b = date.fromisoformat(a), date.fromisoformat(b)
    return [d for d in daterange(a, min(b, TODAY)) if d >= START]


# ------------------------------------------------------------------ routes
@app.post("/personalapitoken-service/personal-api/personal-api-key/token")
def token():
    if not request.headers.get("Authorization", "").startswith("ApiKey "):
        return "", 401
    payload = base64.urlsafe_b64encode(json.dumps({"exp": int(time.time()) + 86400}).encode()).decode().rstrip("=")
    return f"eyJhbGciOiJub25lIn0.{payload}.sig"


def auth_ok():
    return request.headers.get("Authorization", "").startswith("Bearer ")


@app.get("/activitylist-service/activities/search/activities")
def search():
    if not auth_ok():
        return "", 401
    start, limit = int(request.args.get("start", 0)), int(request.args.get("limit", 20))
    if limit > 60:
        return "", 500
    acts = sorted(ACTS, key=lambda a: a["start"], reverse=True)
    if request.args.get("startDate"):
        acts = [a for a in acts if a["date"] >= date.fromisoformat(request.args["startDate"])]
    if request.args.get("endDate"):
        acts = [a for a in acts if a["date"] <= date.fromisoformat(request.args["endDate"])]
    return jsonify([summary(a) for a in acts[start:start + limit]])


FIT_CACHE = {}


@app.get("/download-service/files/activity/<int:aid>")
def download(aid):
    a = next((x for x in ACTS if x["id"] == aid), None)
    if not a:
        return "", 404
    if aid not in FIT_CACHE:
        FIT_CACHE[aid] = build_fit(a)
    return Response(FIT_CACHE[aid], mimetype="application/zip")


@app.get("/usersummary-service/v2/dailysummaries")
def dailysummaries():
    out = []
    for d in days(request.args["startDate"], request.args["endDate"]):
        w = WELL[d]
        out.append({"calendarDate": d.isoformat(), "source": "DEVICE",
                    "movement": {"steps": w["steps"], "distanceMeters": int(w["steps"] * 0.78)},
                    "heartRate": {"restingValue": w["rhr"], "minValue": w["rhr"] - 4, "maxValue": 150},
                    "stress": {"averageLevel": w["stress"], "maxLevel": 90},
                    "bodyBattery": {"highestValue": w["bbh"], "lowestValue": max(5, w["bbh"] - 65), "chargedValue": 60, "drainedValue": 64},
                    "calories": {"totalValue": 2500, "activeValue": 700},
                    "intensityMinutes": {"moderateValue": 20, "vigorousValue": 15}})
    return jsonify({"data": out})


@app.get("/sleep-service/sleep/dailySleepSummariesByDate")
def sleepsum():
    ds = days(request.args["startDate"], request.args["endDate"])
    if len(ds) > 28:
        return "", 400
    out = []
    for d in ds:
        s = WELL[d]["sleep"]
        out.append({"calendarDate": d.isoformat(), "sleepTimeSeconds": int(s), "deepSleepSeconds": int(s * 0.18),
                    "lightSleepSeconds": int(s * 0.55), "remSleepSeconds": int(s * 0.27), "awakeSleepSeconds": 1500,
                    "sleepScores": {"overall": {"value": WELL[d]["score"], "qualifierKey": "GOOD"}}})
    return jsonify(out)


@app.get("/sleep-service/sleep/dailySleep")
def sleepday():
    return jsonify({"dailySleepDTO": {"calendarDate": request.args["date"]}})


@app.get("/hrv-service/hrv/daily/<a>/<b>")
def hrv(a, b):
    out = [{"calendarDate": d.isoformat(), "weeklyAvg": WELL[d]["hrv"] + 1, "lastNightAvg": WELL[d]["hrv"],
            "baseline": {"lowUpper": 48, "balancedLow": 52, "balancedUpper": 68}, "status": "BALANCED"} for d in days(a, b)]
    return jsonify({"hrvSummaries": out})


@app.get("/wellness-service/wellness/bodyBattery/reports/daily")
def bb():
    out = []
    for d in days(request.args["startDate"], request.args["endDate"]):
        out.append({"date": d.isoformat(), "charged": 60, "drained": 62,
                    "bodyBatteryValuesArray": [[0, WELL[d]["bbh"]], [1, max(5, WELL[d]["bbh"] - 65)]]})
    return jsonify(out)


@app.get("/weight-service/weight/range/<a>/<b>")
def weight(a, b):
    return jsonify({"dailyWeightSummaries": [{"summaryDate": d.isoformat(), "weight": 72400.0 - (d - START).days * 3} for d in days(a, b) if d.day in (1, 15)]})


@app.get("/userprofile-service/userprofile/settings")
def profile():
    return jsonify({"userData": {"gender": "MALE", "weight": 72400.0, "height": 181.0, "lactateThresholdHeartRate": 174}})


@app.get("/biometric-service/heartRateZones/v2")
def zones():
    return jsonify([{"trainingMethod": "HR_MAX", "restingHeartRateUsed": 48, "lactateThresholdHeartRateUsed": 174,
                     "zone1Floor": 98, "zone2Floor": 118, "zone3Floor": 137, "zone4Floor": 157, "zone5Floor": 176,
                     "maxHeartRateUsed": 196, "sport": "DEFAULT"}])


if __name__ == "__main__":
    print(f"{len(ACTS)} synthetic activities")
    app.run(port=9099, threaded=True)
