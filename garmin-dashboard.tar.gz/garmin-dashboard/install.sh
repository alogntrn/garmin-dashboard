#!/usr/bin/env bash
# Installs the Garmin dashboard on a Raspberry Pi (or any Debian-based Linux).
# Run from the project folder:  ./install.sh
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
USER_NAME="$(id -un)"
cd "$DIR"

echo "==> Checking Python"
python3 - <<'EOF'
import sys
if sys.version_info < (3, 9):
    sys.exit(f"Python 3.9+ needed, found {sys.version.split()[0]}")
print("   Python", sys.version.split()[0])
EOF
if ! python3 -c "import venv, ensurepip" 2>/dev/null; then
  echo "==> Installing python3-venv"
  sudo apt-get update -qq && sudo apt-get install -y -qq python3-venv
fi

echo "==> Creating virtual environment and installing packages (takes a few minutes on a Pi)"
[ -d .venv ] || python3 -m venv .venv
.venv/bin/pip install -q --upgrade pip
.venv/bin/pip install -q -r requirements.txt

[ -f config.ini ] || { cp config.example.ini config.ini; echo "==> Created config.ini"; }
chmod +x garmin-dash

echo "==> Installing system services"
for f in systemd/*.service systemd/*.timer; do
  sed -e "s|__DIR__|$DIR|g" -e "s|__USER__|$USER_NAME|g" "$f" | sudo tee "/etc/systemd/system/$(basename "$f")" >/dev/null
done
sudo systemctl daemon-reload
sudo systemctl enable --now garmin-dashboard.service
sudo systemctl enable --now garmin-sync.timer

PORT=$(grep -E '^\s*port\s*=' config.ini | head -1 | sed 's/.*=\s*//' || true)
echo
echo "Done. The dashboard runs on this Pi at http://127.0.0.1:${PORT:-8050}"
if [ ! -f "$HOME/.config/garmin/connect-personal-api-key" ]; then
  echo
  echo "Next:  ./garmin-dash set-key        (paste your Garmin Personal API key)"
  echo "Then:  sudo systemctl start garmin-sync.service   (first full download, runs in the background)"
fi
echo "Remote access: ./setup-tailscale.sh"
