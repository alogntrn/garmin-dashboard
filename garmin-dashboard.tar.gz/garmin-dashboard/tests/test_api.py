"""Server-side checks for the redesign (dev only)."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from garmin_dash import web  # noqa: E402


def test_index_is_revalidated():
    r = web.app.test_client().get("/")
    assert r.status_code == 200
    assert r.headers.get("Cache-Control") == "no-cache"


def test_static_files_are_revalidated():
    r = web.app.test_client().get("/static/style.css")
    assert r.status_code == 200
    assert r.headers.get("Cache-Control") == "no-cache"


def test_readiness_factors_carry_numbers():
    import pytest
    from garmin_dash import coach
    hrv = next(f for f in coach.readiness()["factors"] if f["name"] == "HRV")
    if hrv["status"] == "none" or "Garmin HRV status" in hrv["text"]:
        pytest.skip("no HRV baseline in the sample data")
    assert hrv["unit"] == "ms" and hrv["value"] > 0 and hrv["lo"] < hrv["hi"]


def test_context_has_week_cap_and_max_hard():
    from garmin_dash import coach
    ctx = coach.suggestions()["context"]
    assert ctx["max_hard"] in (2, 3)
    assert "run_week_cap" in ctx


def test_a_gym_day_has_only_the_workout_you_chose(tmp_path, monkeypatch):
    from datetime import date
    from garmin_dash import gym
    monkeypatch.setattr(gym, "DB_PATH", tmp_path / "gym.sqlite")
    gym.save_day({"date": "2026-11-21", "session": "B"})
    assert gym.session_on(date(2026, 11, 21)) == "B"
    assert gym.session_on(date(2026, 11, 22)) is None, "no calendar letter for a day nobody chose"


def test_coach_keeps_cardio_easy_only_on_a_chosen_leg_day(monkeypatch):
    from datetime import date
    from garmin_dash import coach, gym
    picks = {date(2026, 11, 21): "A", date(2026, 11, 22): None, date(2026, 11, 23): "A"}
    monkeypatch.setattr(gym, "session_on", lambda d: picks.get(d))
    assert "legs" in coach._gym_conflict(date(2026, 11, 21))
    assert coach._gym_conflict(date(2026, 11, 22)) is None, "tomorrow isn't planned any more"


def test_activities_filter_by_date_range(monkeypatch):
    from garmin_dash import analytics as A
    rows = [{"id": i, "date": d, "sport": "run", "name": f"Run {i}", "location": None} for i, d in
            enumerate(["2026-10-30", "2026-11-01", "2026-11-15", "2026-11-30", "2026-12-01"])]
    monkeypatch.setattr(A, "activities", lambda: rows)
    monkeypatch.setattr(A, "ftp_now", lambda: (250, None))
    monkeypatch.setattr(A, "_public", lambda a, ftp: a)
    got = A.activity_list(start="2026-11-01", end="2026-11-30", limit=500)
    assert [a["date"] for a in got["items"]] == ["2026-11-30", "2026-11-15", "2026-11-01"]
    assert got["total"] == 3


def test_your_exercise_remembers_weight_per_arm(tmp_path, monkeypatch):
    from garmin_dash import gym
    monkeypatch.setattr(gym, "DB_PATH", tmp_path / "gym.sqlite")
    ex = gym.save_exercise({"name": "Arnold press", "kind": "kg", "cat": "Shoulders", "pair": True})
    assert ex["pair"] is True
    assert gym.save_exercise({"id": ex["id"], "name": "Arnold press", "kind": "kg", "pair": False})["pair"] is False
    assert gym.save_exercise({"name": "Plank row", "kind": "kg"})["pair"] is False


def test_status_says_when_a_sync_runs(tmp_path, monkeypatch):
    import fcntl
    from garmin_dash import analytics, config
    monkeypatch.setattr(config, "DATA_DIR", tmp_path)
    assert analytics.sync_running() is False, "no lock file yet"
    with open(tmp_path / "sync.lock", "w") as held:
        fcntl.flock(held, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert analytics.sync_running() is True
        assert web.app.test_client().get("/api/status").get_json()["syncing"] is True
        fcntl.flock(held, fcntl.LOCK_UN)
    assert analytics.sync_running() is False, "the lock file stays, but nobody holds it"


def test_home_screen_icon_and_manifest():
    import json
    import struct
    c = web.app.test_client()
    html = c.get("/").get_data(as_text=True)
    assert 'rel="apple-touch-icon"' in html and 'rel="manifest"' in html
    man = json.loads(c.get("/static/manifest.json").get_data(as_text=True))
    assert man["display"] == "standalone" and man["start_url"].startswith("/") and man["short_name"] == "Training"
    for icon in man["icons"] + [{"src": "/static/icons/apple-touch-icon.png", "sizes": "180x180"}]:
        r = c.get(icon["src"])
        assert r.status_code == 200 and r.data[:8] == b"\x89PNG\r\n\x1a\n", icon["src"]
        assert "%dx%d" % struct.unpack(">II", r.data[16:24]) == icon["sizes"], icon["src"]


def test_long_run_day_states_one_distance_limit():
    """On a long-run day the +5 % limit replaces the everyday 'keep this run ≤ longest' line instead of contradicting it."""
    import pytest
    from garmin_dash import coach
    st = coach.state()
    if not st["run"]["longest30_km"]:
        pytest.skip("needs runs in the local data")
    st["run"].update(days_since_long=9, longest30_km=20.3, week_km=0.0, chronic_km=29.2)
    st["hours_since_hard"] = 12          # a hard session yesterday: no intervals, so the long run is due
    rd = dict(coach.readiness(), level="green")
    w = coach.plan_run(st, rd)
    assert w["title"] == "Long easy run: 21.3 km", w["title"]
    assert not any(g.startswith("Keep this run") for g in w["guardrails"]), w["guardrails"]
    assert sum(g.startswith("Long-run limit: 21.3 km") for g in w["guardrails"]) == 1, w["guardrails"]
