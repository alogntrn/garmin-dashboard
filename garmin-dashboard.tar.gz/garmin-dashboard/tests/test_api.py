"""Server-side checks for the redesign (dev only)."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from garmin_dash import web  # noqa: E402


def test_index_is_revalidated():
    r = web.app.test_client().get("/")
    assert r.status_code == 200
    assert r.headers.get("Cache-Control") == "no-cache"


def test_static_files_are_revalidated():
    r = web.app.test_client().get("/static/style.css")
    assert r.status_code == 200
    assert r.headers.get("Cache-Control") == "no-cache"


def test_readiness_factors_carry_numbers():
    import pytest
    from garmin_dash import coach
    hrv = next(f for f in coach.readiness()["factors"] if f["name"] == "HRV")
    if hrv["status"] == "none" or "Garmin HRV status" in hrv["text"]:
        pytest.skip("no HRV baseline in the sample data")
    assert hrv["unit"] == "ms" and hrv["value"] > 0 and hrv["lo"] < hrv["hi"]


def test_context_has_week_cap_and_max_hard():
    from garmin_dash import coach
    ctx = coach.suggestions()["context"]
    assert ctx["max_hard"] in (2, 3)
    assert "run_week_cap" in ctx
