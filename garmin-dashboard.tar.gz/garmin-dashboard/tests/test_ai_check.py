"""Checks on what the Pi's AI made of a described session (ai._check), using the 21 Nov stair-stepper case."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from garmin_dash import ai  # noqa: E402

CAT = [{"id": i, "n": n, "kind": k, "uni": False} for i, n, k in (
    ("bike", "Bike", "min"), ("rower", "Rowing machine", "min"), ("stairs", "Stair stepper", "min"),
    ("xtrainer", "Cross trainer", "min"), ("pd", "Lat pulldown or assisted pull-up", "kg"),
    ("row", "Chest-supported row", "kg"), ("bench", "Barbell bench press", "kg"), ("abcircuit", "Ab circuit", "min"))]
CTX = {"catalog": CAT, "slots": [{"slot": "pd", "base": "pd", "alts": []}, {"slot": "row", "base": "row", "alts": []}]}
TEXT = "Stairstepper for about 10 minutes and approximately 900 steps to cool down."


def stairs(**extra):
    return {"items": [{"ex": "stairs", "side": "B", "mins": 10}], "unsure": [], **extra}


def test_planned_exercises_without_numbers_are_one_note_not_problems():
    res = stairs()
    res["items"] += [{"ex": "pd", "side": "B"}, {"ex": "row", "side": "B"}]
    out, issues, notes = ai._check(res, TEXT, CTX)
    assert [o["ex"] for o in out] == ["stairs"]
    assert issues == []
    assert any("Lat pulldown" in n and "Chest-supported row" in n for n in notes)


def test_a_machine_the_text_doesnt_name_is_flagged():
    res = {"items": [{"ex": "bike", "side": "B", "mins": 10}], "unsure": []}
    _, issues, _ = ai._check(res, TEXT, CTX)
    assert any("Stair stepper" in i and "Bike" in i for i in issues), issues


def test_an_invented_effort_is_dropped_not_saved():
    res = stairs(rpe=0)
    _, issues, notes = ai._check(res, TEXT, CTX)
    assert issues == [] and res["rpe"] is None
    assert any("effort" in n.lower() for n in notes)


def test_steps_get_a_note():
    _, _, notes = ai._check(stairs(), TEXT, CTX)
    assert any("steps" in n.lower() for n in notes)


def test_bike_in_german_or_french_is_not_flagged():
    for text, mins in (("15 min Velo zum Aufwärmen", 15), ("10 min Fahrrad", 10), ("vélo 12 min", 12)):
        res = {"items": [{"ex": "bike", "side": "B", "mins": mins}], "unsure": []}
        _, issues, _ = ai._check(res, text, CTX)
        assert issues == [], (text, issues)


def test_a_named_exercise_without_numbers_still_says_it_wasnt_logged():
    out, issues, notes = ai._check({"items": [{"ex": "bench", "side": "B"}], "unsure": []}, "bench felt heavy today", CTX)
    assert out == [] and issues, "nothing logged must go to review"
    assert any("Barbell bench press" in x for x in issues + notes)


def test_the_prompt_says_to_list_only_mentioned_exercises():
    assert "only exercises the text mentions" in ai._prompt(CTX).lower()
