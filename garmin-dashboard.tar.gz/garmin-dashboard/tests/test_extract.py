"""Daily summaries as Garmin's Personal API really sends them (shape from `garmin-dash inspect`, 23 Nov 2026;
values invented)."""
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from garmin_dash import extract  # noqa: E402

REAL_DAY = {
    "uuid": "u", "userProfilePk": 1, "calendarDate": "2026-11-22", "source": "garmin",
    "includesWellnessData": True, "includesActivityData": True,
    "wellnessChronology": {"startTimestampGmt": "2026-11-21T23:00:00.0", "totalDurationInMillis": 86400000},
    "movement": {"steps": {"goal": 8000, "value": 11234, "distanceInMeters": 8500}, "pushes": {},
                 "floorsAscended": {"goal": 10, "value": 12, "distanceInMeters": 36},
                 "floorsDescended": {"value": 9, "distanceInMeters": 27}},
    "calories": {"burnedResting": 1700, "burnedActive": 650, "burnedTotal": 2350},
    "heartRate": {"minValue": 44, "maxValue": 160, "restingValue": 49},
    "intensityMinutes": {"goal": 150, "moderate": 20, "vigorous": 35},
    "stress": {"avgLevel": 31, "maxLevel": 88, "restProportion": 0.4, "qualifier": "balanced", "totalDurationInMillis": 80000000},
    "bodyBattery": {"minValue": 18, "maxValue": 84, "chargedValue": 60, "drainedValue": 55, "latestValue": 40},
    "respiration": {"avgValue": 14, "maxValue": 20, "minValue": 9}, "pulseOx": {"avgValue": 96, "minValue": 90},
}


def test_daily_summary_fields_read_the_real_garmin_shape():
    f = extract.daily_summary_fields(REAL_DAY)
    assert f["steps"] == 11234
    assert f["stress_avg"] == 31 and f["stress_max"] == 88
    assert f["resting_hr"] == 49
    assert f["bb_high"] == 84 and f["bb_low"] == 18
    assert f["calories"] == 2350 and f["active_calories"] == 650
    assert f["floors"] == 12
    assert f["intensity_min"] == 90


def test_the_response_wrapper_is_unpacked():
    recs = extract.day_records({"data": [REAL_DAY]})
    assert [extract.record_date(r) for r in recs] == ["2026-11-22"]


def test_stored_daily_data_is_read_again_after_a_parser_fix(tmp_path, monkeypatch):
    from garmin_dash import config, db, sync
    monkeypatch.setattr(config, "DB_PATH", tmp_path / "garmin.sqlite")
    con = db.connect()
    con.execute("INSERT INTO raw_daily(date,source,data) VALUES(?,?,?)", ("2026-11-22", "summary", json.dumps(REAL_DAY)))
    con.execute("INSERT INTO daily(date, resting_hr) VALUES('2026-11-22', 49)")   # what the old parser had stored
    sync.reextract_daily(con)
    row = con.execute("SELECT steps, stress_avg, resting_hr FROM daily WHERE date='2026-11-22'").fetchone()
    assert (row["steps"], row["stress_avg"], row["resting_hr"]) == (11234, 31, 49)
