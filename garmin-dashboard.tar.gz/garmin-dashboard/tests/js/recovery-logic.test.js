"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const { loadScripts, plain } = require("./load");

const RL = loadScripts(["recovery-logic.js"]).RL;

// One row per day, the last one on `end`; f(i) gives the values of day i (0 = oldest).
const days = (end, n, f) => {
  const [y, m, d] = end.split("-").map(Number);
  return Array.from({ length: n }, (_, i) => ({ date: new Date(Date.UTC(y, m - 1, d - (n - 1 - i))).toISOString().slice(0, 10), ...f(i) }));
};
const F = (name, status, text = `${name} text`) => ({ name, status, text });

test("fresh: last night for today's or yesterday's data, the date when it is older", () => {
  assert.equal(RL.fresh("2026-11-24", "2026-11-24"), "Last night, compared with your normal range.");
  assert.equal(RL.fresh("2026-11-23", "2026-11-24"), "Last night, compared with your normal range.");
  assert.equal(RL.fresh("2026-11-18", "2026-11-24"), "Latest data from 18 Nov, compared with your normal range.");
  assert.equal(RL.fresh(null, "2026-11-24"), "No wellness data yet.");
});

test("usual range: 10th to 90th percentile of the 60 days before the last week", () => {
  const rows = days("2026-11-24", 67, (i) => ({ stress_avg: i < 60 ? i + 1 : 1000 }));
  assert.deepEqual(plain(RL.normal(rows, "stress_avg")), { lo: 6.9, hi: 54.1 });
});

test("normal range needs two weeks of earlier days and skips gaps", () => {
  assert.equal(RL.normal(days("2026-11-24", 20, () => ({ steps: 5000 })), "steps"), null);
  const gaps = days("2026-11-24", 67, (i) => ({ steps: i % 2 ? null : 4000 }));
  assert.deepEqual(plain(RL.normal(gaps, "steps")), { lo: 4000, hi: 4000 });
});

test("status compares a value with its range", () => {
  assert.equal(RL.status(10, { lo: 20, hi: 30 }), "below");
  assert.equal(RL.status(25, { lo: 20, hi: 30 }), "in");
  assert.equal(RL.status(31, { lo: 20, hi: 30 }), "above");
  assert.equal(RL.status(null, { lo: 20, hi: 30 }), null);
  assert.equal(RL.status(25, null), null);
});

test("headline: every check in range", () => {
  assert.deepEqual(plain(RL.headline([F("HRV", "green"), F("Resting HR", "green"), F("Sleep", "green"), F("Training load", "red")])),
    { call: "All three checks are in your normal range.", why: "HRV, resting HR and sleep, against your own recent data." });
  assert.deepEqual(plain(RL.headline([F("HRV", "green"), F("Resting HR", "green"), F("Sleep", "none")])),
    { call: "Both checks are in your normal range.", why: "HRV and resting HR, against your own recent data. Sleep needs more data." });
  assert.deepEqual(plain(RL.headline([F("HRV", "green"), F("Resting HR", "none"), F("Sleep", "none")])),
    { call: "HRV is in your normal range.", why: "Resting HR and sleep need more data." });
});

test("headline: checks out of range are named, with the coach's reason", () => {
  assert.deepEqual(plain(RL.headline([F("HRV", "amber", "7-day average 48 ms is below your normal range (52–60 ms)."), F("Resting HR", "green"), F("Sleep", "none")])),
    { call: "HRV is outside your normal range.", why: "7-day average 48 ms is below your normal range (52–60 ms)." });
  assert.equal(RL.headline([F("HRV", "amber"), F("Resting HR", "green"), F("Sleep", "red")]).call, "HRV and sleep are outside your normal range.");
});

test("headline: nothing to check yet", () => {
  assert.deepEqual(plain(RL.headline([F("HRV", "none"), F("Resting HR", "none")])),
    { call: "Not enough recent data for a check.", why: "Wear the watch at night: the checks need about three weeks of nights." });
  assert.equal(RL.headline(null).call, "Not enough recent data for a check.");
});

test("patterns in words", () => {
  assert.deepEqual(plain(RL.patterns({ hrv_after_hard: 52, hrv_after_easy: 58.4, sleep_vs_hrv: 0.36, load_vs_next_hrv: -0.12, load_vs_next_rhr: 0.05 })), [
    "After your hardest days, HRV is about 6 ms lower the next night.",
    "Longer sleep goes with higher HRV, a moderate link.",
    "Harder days go with lower HRV the next night, a weak link.",
    "Training load and next-day resting HR show no clear link.",
  ]);
});

test("patterns: the other direction, a strong link, and missing values left out", () => {
  assert.deepEqual(plain(RL.patterns({ hrv_after_hard: 61, hrv_after_easy: 58, sleep_vs_hrv: -0.55, load_vs_next_hrv: null, load_vs_next_rhr: 0.31 })), [
    "After your hardest days, HRV is about 3 ms higher the next night.",
    "Longer sleep goes with lower HRV, a strong link.",
    "Harder days go with a higher resting HR the next day, a moderate link.",
  ]);
  assert.deepEqual(plain(RL.patterns({ hrv_after_hard: 58.2, hrv_after_easy: 58.6 })), ["HRV after your hardest days is about the same as after other days."]);
  assert.deepEqual(plain(RL.patterns({})), []);
  assert.deepEqual(plain(RL.patterns(null)), []);
});
