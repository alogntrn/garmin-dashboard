/* Loads the dashboard's classic scripts into one vm context for unit tests (dev only). */
"use strict";
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const STATIC = path.join(__dirname, "..", "..", "garmin_dash", "static");
const ESC = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };

function loadScripts(files, extra = {}) {
  const mem = new Map();
  const ctx = {
    console, setTimeout, clearTimeout, setInterval, clearInterval,
    localStorage: { getItem: (k) => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)), removeItem: (k) => mem.delete(k) },
    document: { querySelector: () => null, querySelectorAll: () => [], addEventListener() {}, documentElement: {} },
    location: { hash: "" },
    addEventListener() {},
    matchMedia: () => ({ matches: false, addEventListener() {} }),
    esc: (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ESC[c]),
    ...extra,
  };
  ctx.window = ctx;
  vm.createContext(ctx);
  for (const f of files) vm.runInContext(fs.readFileSync(path.join(STATIC, f), "utf8"), ctx, { filename: f });
  return ctx;
}

const fixture = (name = "fixture-gym.json") => JSON.parse(fs.readFileSync(path.join(__dirname, name), "utf8"));
const plain = (x) => JSON.parse(JSON.stringify(x));

module.exports = { loadScripts, fixture, plain };
