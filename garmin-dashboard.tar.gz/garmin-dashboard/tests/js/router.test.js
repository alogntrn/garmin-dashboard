"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const { loadScripts, plain } = require("./load");

const w = loadScripts(["routes.js"]);
const R = (h, o) => plain(w.resolveRoute(h, o || {}));

test("empty hash opens Today", () => {
  assert.equal(R("").page, "today");
  assert.equal(R("#/").tab, "today");
});
test("old Overview link goes to Today", () => assert.equal(R("#/overview").redirect, "#/today"));
test("old Running and Cycling pages live under Progress", () => {
  assert.equal(R("#/running").redirect, "#/progress/run");
  assert.equal(R("#/cycling").redirect, "#/progress/ride");
});
test("old gym day links keep their date under Progress, Strength", () => {
  assert.equal(R("#/gym/2026-11-20").redirect, "#/progress/strength/2026-11-20");
});
test("old gym tab opens the workout only while a session is open", () => {
  assert.equal(R("#/gym", { sessionOpen: true }).redirect, "#/workout");
  assert.equal(R("#/gym", { sessionOpen: false }).redirect, "#/today");
});
test("old settings link opens Settings", () => assert.equal(R("#/status").redirect, "#/settings"));
test("Workouts details stay reachable under Today", () => assert.deepEqual(R("#/plan"), { tab: "today", page: "plan" }));
test("a gym session page belongs to the Activities tab", () => {
  assert.deepEqual(R("#/gym-session/2026-11-19"), { tab: "activities", page: "gym-session", arg: "2026-11-19" });
  assert.deepEqual(R("#/gym-session"), { redirect: "#/activities" });
});
test("activity detail belongs to the Activities tab", () => assert.deepEqual(R("#/activity/42"), { tab: "activities", page: "activity", arg: "42" }));
test("progress segments and the strength day argument", () => {
  assert.deepEqual(R("#/progress/strength/2026-11-20"), { tab: "progress", page: "progress", seg: "strength", arg: "2026-11-20" });
  assert.equal(R("#/progress").redirect, "#/progress/overview");
  assert.equal(R("#/progress/nope").redirect, "#/progress/overview");
});
test("workout is an overlay on the Today tab", () => assert.deepEqual(R("#/workout"), { tab: "today", page: "workout" }));
test("unknown pages fall back to Today", () => assert.equal(R("#/what").redirect, "#/today"));

test("Recovery details have their own routes", () => {
  assert.deepEqual(plain(R("#/recovery/hrv")), { tab: "recovery", page: "recovery", arg: "hrv" });
  assert.deepEqual(plain(R("#/recovery/steps")), { tab: "recovery", page: "recovery", arg: "steps" });
  assert.deepEqual(plain(R("#/recovery")), { tab: "recovery", page: "recovery" });
  assert.equal(R("#/recovery/weight").redirect, "#/recovery");
});

test("Settings pages open inside the Settings sheet", () => {
  assert.deepEqual(plain(R("#/settings")), { tab: null, page: "settings" });
  assert.deepEqual(plain(R("#/settings/log")), { tab: null, page: "settings", arg: "log" });
  assert.equal(R("#/settings/nope").redirect, "#/settings");
});
