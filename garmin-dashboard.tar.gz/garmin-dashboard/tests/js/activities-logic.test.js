const test = require("node:test");
const assert = require("node:assert/strict");
const { loadScripts, fixture, plain } = require("./load.js");

function load(mutate) {
  const w = loadScripts(["gym-lib.js", "gym.js", "activities-logic.js"]);
  const st = fixture();
  st.garmin = st.garmin || {};
  if (mutate) mutate(st);
  w.GYM.use(st);
  return w;
}
const GARMIN = [
  { id: 1, date: "2026-11-18", start: "2026-11-18 07:27:00", sport: "ride", name: "Tempo ride", km: 36.4, secs: 3570 },
  { id: 2, date: "2026-11-16", start: "2026-11-16 06:00:00", sport: "run", name: "Easy run", km: 10, secs: 3000 },
];

test("gym sessions come from the log, newest first, one per day", () => {
  const w = load();
  const g = plain(w.AL.gymSessions(w.GYM));
  assert.deepEqual(g.map((x) => x.date), ["2026-11-20", "2026-11-19", "2026-11-15"]);
  assert.equal(g[1].code, "A");
  assert.equal(g[1].name, w.GYM.sessName("A"));
  assert.ok(g[1].sets > 0 && g[1].kg > 0);
});

test("one list grouped by week with km and time totals", () => {
  const w = load();
  const weeks = plain(w.AL.merge(GARMIN, w.AL.gymSessions(w.GYM), { today: "2026-11-20" }));
  assert.deepEqual(weeks.map((x) => x.label), ["This week", "Last week"]);
  assert.deepEqual(weeks[0].items.map((x) => x.date), ["2026-11-20", "2026-11-19", "2026-11-18", "2026-11-16"]);
  assert.equal(Math.round(weeks[0].km * 10) / 10, 46.4);
  assert.equal(weeks[1].items[0].kind, "gym");
});

test("a watch strength activity on a gym day shows up once, in the gym row", () => {
  const w = load((st) => { st.garmin["2026-11-19"] = [{ id: 99, name: "Strength", min: 52, hr: 104, kcal: 300 }]; });
  const gym = w.AL.gymSessions(w.GYM);
  const items = plain(w.AL.merge([...GARMIN, { id: 99, date: "2026-11-19", start: "2026-11-19 18:00:00", sport: "other", name: "Strength", km: 0, secs: 3120 }], gym, { today: "2026-11-20" })).flatMap((x) => x.items);
  assert.equal(items.filter((x) => x.id === 99).length, 0);
  const a = items.find((x) => x.date === "2026-11-19" && x.kind === "gym");
  assert.deepEqual(a.watchIds, [99]);
  assert.equal(a.hr, 104);
});

test("the gym filter with a search matches session and exercise names", () => {
  const w = load();
  const weeks = plain(w.AL.merge([], w.AL.gymSessions(w.GYM), { sport: "gym", q: "bench", today: "2026-11-20" }));
  assert.deepEqual(weeks.flatMap((x) => x.items).map((x) => x.date), ["2026-11-19"]);
});

test("gym sessions older than the loaded activities wait for Load more", () => {
  const w = load();
  const items = plain(w.AL.merge(GARMIN, w.AL.gymSessions(w.GYM), { today: "2026-11-20", until: "2026-11-16" })).flatMap((x) => x.items);
  assert.ok(!items.some((x) => x.date === "2026-11-15"));
});

test("older weeks are labelled by their dates", () => {
  const w = load();
  assert.equal(w.AL.weekLabel("2026-11-02", "2026-11-20"), "2–8 Nov");
  assert.equal(w.AL.weekLabel("2026-10-26", "2026-11-20"), "26 Oct – 1 Nov");
  assert.equal(w.AL.weekLabel("2025-12-29", "2026-11-20"), "29 Dec 2025 – 4 Jan 2026");
});

test("the month calendar starts on Monday and shows what was done each day", () => {
  const w = load();
  const items = plain(w.AL.merge(GARMIN, w.AL.gymSessions(w.GYM), { today: "2026-11-20" })).flatMap((x) => x.items);
  const cal = plain(w.AL.calendar(2026, 11, items, "2026-11-20"));
  assert.equal(cal.title, "November 2026");
  assert.equal(cal.cells.length, 42);
  assert.equal(cal.cells[0].date, "2026-10-26");
  const by = Object.fromEntries(cal.cells.map((c) => [c.date, c]));
  assert.deepEqual(by["2026-11-18"].sports, ["ride"]);
  assert.deepEqual(by["2026-11-19"].sports, ["gym"]);
  assert.equal(by["2026-11-20"].today, true);
  assert.equal(by["2026-10-26"].inMonth, false);
  assert.equal(plain(w.AL.calendar(2027, 1, [], "2026-11-20")).cells[0].date, "2026-12-28");
});
