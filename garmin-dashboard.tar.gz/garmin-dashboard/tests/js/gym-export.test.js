"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const { loadScripts, fixture, plain } = require("./load");

const w = loadScripts(["gym-lib.js", "gym.js"]);
w.GYM.use(fixture());

test("plan letters follow A, B, C, rest from the block start", () => {
  assert.equal(w.GYM.planType("2026-11-19"), "A");
  assert.equal(w.GYM.planType("2026-11-22"), "R");
});

test("week number counts from the block start", () => {
  assert.equal(w.GYM.weekOf("2026-11-26"), 2);
});

test("session A has the six planned slots in order", () => {
  assert.deepEqual(plain(w.GYM.blocksFor("2026-11-19").map((s) => s.slot)), ["iso", "bench", "lp", "le", "fly", "lat"]);
});
