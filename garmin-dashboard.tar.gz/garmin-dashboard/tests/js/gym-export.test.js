"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const { loadScripts, fixture, plain } = require("./load");

const w = loadScripts(["gym-lib.js", "gym.js"]);
w.GYM.use(fixture());

test("a day has a workout only when one was chosen", () => {
  assert.equal(w.GYM.chosen("2026-11-19"), "A");
  assert.equal(w.GYM.chosen("2026-11-22"), null);
  assert.equal(w.GYM.sessOf("2026-11-22"), "F");
  assert.equal(w.GYM.planType, undefined);
});

test("a day with sets but no day record keeps the workout its sets were logged under", () => {
  assert.equal(w.GYM.chosen("2026-11-20"), "B");
});

function withDays(days, sets = []) {
  const v = loadScripts(["gym-lib.js", "gym.js"]);
  const st = fixture();
  for (const [d, session] of Object.entries(days)) st.days[d] = { date: d, session, done: false, pain: null, rpe: null, note: "", swaps: {}, extras: [] };
  st.sets.push(...sets.map((d, k) => ({ id: 900 + k, date: d, session: days[d], ex: "bench", slot: "bench", name: "Bench", kg: 50, reps: 8, secs: null, mins: null, rir: null, side: "", src: "manual", created_at: d + "T18:00:00" })));
  v.GYM.use(st);
  return v.GYM;
}
const isTest = (G, d) => G.notesFor(d).some((n) => n.includes("Test day"));

test("the knee test comes with the first A session from day 5 on", () => {
  assert.equal(isTest(withDays({ "2026-11-24": "A" }), "2026-11-24"), true);
  assert.equal(isTest(withDays({ "2026-11-22": "A" }), "2026-11-22"), false, "day 4 is too early");
  assert.equal(isTest(withDays({ "2026-11-23": "A", "2026-11-25": "A" }, ["2026-11-23"]), "2026-11-25"), false, "only the first A");
  assert.equal(isTest(withDays({ "2026-12-14": "A" }), "2026-12-14"), true, "second test in the last days");
});

test("week number counts from the block start", () => {
  assert.equal(w.GYM.weekOf("2026-11-26"), 2);
});

test("session A has the six planned slots in order", () => {
  assert.deepEqual(plain(w.GYM.blocksFor("2026-11-19").map((s) => s.slot)), ["iso", "bench", "lp", "le", "fly", "lat"]);
});

const oneSet = (id, d, ex, kg, reps) => ({ id, date: d, session: "F", ex, slot: ex, name: ex, kg, reps, secs: null, mins: null, rir: null, side: "", src: "manual", created_at: d + "T18:00:00" });

test("weight-per-arm exercises count both arms in kg lifted and show the weight as 'each'", () => {
  const v = loadScripts(["gym-lib.js", "gym.js"]);
  const st = fixture();
  st.sets.push(oneSet(950, "2026-12-01", "dbbench", 20, 10), oneSet(951, "2026-12-01", "bench", 40, 10), oneSet(952, "2026-12-01", "dbrow", 24, 10));
  v.GYM.use(st);
  assert.equal(v.GYM.sessionStats("2026-12-01").vol, 20 * 10 * 2 + 40 * 10 + 24 * 10, "dumbbell bench counts both arms, the one-arm row one");
  assert.equal(v.GYM.setTxt(st.sets.find((s) => s.id === 950)), "20 kg each × 10");
  assert.equal(v.GYM.setTxt(st.sets.find((s) => s.id === 951)), "40 kg × 10");
  assert.equal(v.GYM.def("dbbench").pair, true);
  assert.ok(!v.GYM.def("dbrow").pair && v.GYM.def("dbrow").db, "one-arm row: a dumbbell, logged per side");
  assert.ok(!v.GYM.def("bench").pair && !v.GYM.def("bench").db);
});

test("your own exercise can take its weight per arm", () => {
  const v = loadScripts(["gym-lib.js", "gym.js"]);
  const st = fixture();
  st.exercises.push({ id: "x-arnold", name: "Arnold press", kind: "kg", uni: false, cat: "Shoulders", mus: {}, note: "", archived: false, pair: true });
  st.sets.push(oneSet(960, "2026-12-02", "x-arnold", 14, 10));
  v.GYM.use(st);
  assert.equal(v.GYM.def("x-arnold").pair, true);
  assert.equal(v.GYM.sessionStats("2026-12-02").vol, 280);
});
