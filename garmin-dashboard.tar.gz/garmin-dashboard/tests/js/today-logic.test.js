"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const { loadScripts, fixture, plain } = require("./load");

const w = loadScripts(["gym-lib.js", "gym.js", "today-logic.js"]);
w.GYM.use(fixture());
const TL = w.TL;
const H = (o) => plain(TL.headline(o));

test("leg day without a hard session allowed", () => {
  assert.deepEqual(H({ level: "green", hardAllowed: false, gym: "A" }), { first: "Leg day.", second: "Keep cardio easy." });
});
test("upper-body day with a hard session allowed", () => {
  assert.deepEqual(H({ level: "green", hardAllowed: true, gym: "B" }), { first: "Upper-body day.", second: "Green light for a hard session." });
});
test("red readiness overrides the gym letter", () => {
  assert.equal(H({ level: "red", hardAllowed: false, gym: "C" }).first, "Recovery day.");
});
test("planned rest day", () => {
  assert.equal(H({ level: "green", hardAllowed: false, gym: "R" }).first, "Rest day.");
});
test("no gym plan gives no first sentence", () => {
  assert.equal(H({ level: "green", hardAllowed: true, gym: null }).first, null);
});
test("after the session the cardio line talks about tomorrow", () => {
  assert.deepEqual(H({ level: "green", hardAllowed: false, gym: "A", gymDone: true }), { first: "Done for today.", second: "Tomorrow: keep cardio easy." });
});

test("load meter buckets the 7-day vs 42-day ratio", () => {
  assert.equal(TL.loadBucket(62, 3).label, "Steady");
  assert.equal(TL.loadBucket(50, -10).label, "Above");
  assert.equal(TL.loadBucket(4, 0), null);
});

test("range bar places the value inside a padded band", () => {
  const r = TL.rangeBar(58, 55, 59);
  assert.ok(r.lo < r.val && r.val < r.hi);
  assert.equal(TL.rangeBar(null, 1, 2), null);
});

test("week budget scales running against the cap and cycling against its usual", () => {
  const b = plain(TL.weekBudget({ run_week_km: 10.2, run_week_cap: 37.2, ride_week_h: 1.2, ride_chronic_h: 2.8, hard_7d: 0, max_hard: 2 }));
  assert.equal(Math.round(b.run.pct), 27);
  assert.equal(Math.round(b.ride.usualPct), 77);
  assert.deepEqual(b.hard, { done: 0, max: 2 });
});

test("gym week shows what was done and plans nothing ahead", () => {
  const wk = plain(TL.gymWeek(w.GYM, "2026-11-20"));
  const byDate = Object.fromEntries(wk.days.map((d) => [d.date, d]));
  assert.equal(wk.days.length, 7);
  assert.equal(byDate["2026-11-19"].state, "done");
  assert.equal(byDate["2026-11-19"].letter, "A");
  assert.equal(byDate["2026-11-20"].state, "today");
  assert.equal(byDate["2026-11-21"].state, "none");
  assert.equal(byDate["2026-11-21"].letter, "");
  assert.equal(byDate["2026-11-22"].state, "none");
  assert.equal(wk.done, 1);
});

test("the workout done longest ago is suggested", () => {
  const c = plain(TL.choices(w.GYM, "2026-11-21"));
  assert.deepEqual(c.map((x) => x.code), ["A", "B", "C"]);
  assert.deepEqual(c.map((x) => x.suggested), [false, false, true], "C was never done");
  assert.ok(c.every((x) => !x.hint), "no leg day yesterday (B)");
});

test("after a leg day, B is suggested and A and C carry a hint", () => {
  const v = loadScripts(["gym-lib.js", "gym.js", "today-logic.js"]);
  const st = fixture();
  st.sets.push({ id: 950, date: "2026-11-21", session: "C", ex: "split", slot: "split", name: "Split squat", kg: 10, reps: 8, secs: null, mins: null, rir: null, side: "R", src: "manual", created_at: "2026-11-21T18:00:00" });
  v.GYM.use(st);
  const c = plain(v.TL.choices(v.GYM, "2026-11-22"));
  assert.deepEqual(c.map((x) => x.suggested), [false, true, false]);
  assert.match(c[0].hint, /Leg day yesterday/);
  assert.equal(c[1].hint, "");
  assert.match(c[2].hint, /Leg day yesterday/);
});
