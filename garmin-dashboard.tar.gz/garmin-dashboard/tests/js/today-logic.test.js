"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const { loadScripts, fixture, plain } = require("./load");

const w = loadScripts(["gym-lib.js", "gym.js", "today-logic.js"]);
w.GYM.use(fixture());
const TL = w.TL;
const H = (o) => plain(TL.headline(o));

test("leg day without a hard session allowed", () => {
  assert.deepEqual(H({ level: "green", hardAllowed: false, gym: "A" }), { first: "Leg day.", second: "Keep cardio easy." });
});
test("upper-body day with a hard session allowed", () => {
  assert.deepEqual(H({ level: "green", hardAllowed: true, gym: "B" }), { first: "Upper-body day.", second: "Green light for a hard session." });
});
test("red readiness overrides the gym letter", () => {
  assert.equal(H({ level: "red", hardAllowed: false, gym: "C" }).first, "Recovery day.");
});
test("planned rest day", () => {
  assert.equal(H({ level: "green", hardAllowed: false, gym: "R" }).first, "Rest day.");
});
test("no gym plan gives no first sentence", () => {
  assert.equal(H({ level: "green", hardAllowed: true, gym: null }).first, null);
});
test("after the session the cardio line talks about tomorrow", () => {
  assert.deepEqual(H({ level: "green", hardAllowed: false, gym: "A", gymDone: true }), { first: "Done for today.", second: "Tomorrow: keep cardio easy." });
});

test("load meter buckets the 7-day vs 42-day ratio", () => {
  assert.equal(TL.loadBucket(62, 3).label, "Steady");
  assert.equal(TL.loadBucket(50, -10).label, "Above");
  assert.equal(TL.loadBucket(4, 0), null);
});

test("range bar places the value inside a padded band", () => {
  const r = TL.rangeBar(58, 55, 59);
  assert.ok(r.lo < r.val && r.val < r.hi);
  assert.equal(TL.rangeBar(null, 1, 2), null);
});

test("week budget scales running against the cap and cycling against its usual", () => {
  const b = plain(TL.weekBudget({ run_week_km: 10.2, run_week_cap: 37.2, ride_week_h: 1.2, ride_chronic_h: 2.8, hard_7d: 0, max_hard: 2 }));
  assert.equal(Math.round(b.run.pct), 27);
  assert.equal(Math.round(b.ride.usualPct), 77);
  assert.deepEqual(b.hard, { done: 0, max: 2 });
});

test("gym week marks a finished past day done and today as today", () => {
  const wk = plain(TL.gymWeek(w.GYM, "2026-11-20"));
  const byDate = Object.fromEntries(wk.days.map((d) => [d.date, d]));
  assert.equal(wk.days.length, 7);
  assert.equal(byDate["2026-11-19"].state, "done");
  assert.equal(byDate["2026-11-20"].state, "today");
  assert.equal(byDate["2026-11-22"].state, "rest");
  assert.equal(byDate["2026-11-16"].state, "none");
});
