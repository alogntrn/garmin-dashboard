"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const { loadScripts, fixture, plain } = require("./load");

const load = (mutate) => {
  const w = loadScripts(["gym-lib.js", "gym.js", "workout-logic.js"]);
  const st = fixture();
  if (mutate) mutate(st);
  w.GYM.use(st);
  return w;
};
const w = load();
const WL = w.WL;

test("session A on day 1 lists the six exercises with week-1 chips", () => {
  const m = WL.model("2026-11-19");
  assert.equal(m.code, "A");
  assert.equal(m.day, 1);
  assert.equal(m.exercises.length, 6);
  assert.deepEqual(plain(m.exercises[2].chips), ["R 3 · L 2 sets", "8–12 reps", "RIR 3"]);
});

test("unilateral sets alternate legs, right first, as the plan's cues say", () => {
  const lp = WL.model("2026-11-19").exercises[2];
  assert.deepEqual(plain({ next: lp.prog.next, count: lp.prog.count, of: lp.prog.of }), { next: "L", count: 0, of: 2 });
});

test("R 4 · L 2 continues on the left once four right sets are in", () => {
  const w2 = load((st) => {
    for (let k = 0; k < 4; k++) st.sets.push({ id: 100 + k, date: "2026-11-27", session: "A", ex: "iso", slot: "iso", name: "iso", kg: 40, reps: null, secs: 40, mins: null, rir: null, side: "R", src: "manual", created_at: "2026-11-27T18:0" + k + ":00" });
  });
  const iso = w2.WL.model("2026-11-27").exercises[0];
  assert.equal(iso.prog.next, "L");
  assert.equal(iso.prog.of, 2);
});

test("bilateral exercises count all sets", () => {
  const bench = WL.model("2026-11-19").exercises[1];
  assert.equal(bench.prog.done, true);
  assert.equal(bench.prog.count, 3);
  assert.equal(bench.prog.of, 3);
});

test("mid-session, the first open exercise skips the finished ones", () => {
  assert.equal(WL.firstOpen(WL.model("2026-11-19")), 2);
});

test("a fresh session starts at the top, primer included", () => {
  const w2 = load((st) => { st.days["2026-11-23"] = { date: "2026-11-23", session: "A", done: false, swaps: {}, extras: [] }; });
  assert.equal(w2.WL.firstOpen(w2.WL.model("2026-11-23")), 0);
});

test("a day without a chosen workout says so", () => {
  assert.equal(WL.model("2026-11-23").chosen, false);
  assert.equal(WL.model("2026-11-19").chosen, true);
});

test("once sets exist, an unfinished primer still counts as open", () => {
  const w2 = load((st) => { st.sets = st.sets.filter((s) => !(s.date === "2026-11-19" && (s.slot || s.ex) === "iso")); });
  assert.equal(w2.WL.firstOpen(w2.WL.model("2026-11-19")), 0);
});

test("last time lists each leg, separated by a semicolon", () => {
  const lp = WL.model("2026-11-19").exercises[2];
  assert.equal(lp.last.date, "2026-11-15");
  assert.equal(lp.last.text, "right 57.5 kg × 10, 57.5 kg × 10; left 57.5 kg × 10");
});

test("prefill takes today's last set on that side", () => {
  const lp = WL.model("2026-11-19").exercises[2];
  assert.deepEqual(plain(WL.prefill(lp, "R")), { kg: 60, reps: 10, secs: null, mins: null, rir: 3 });
});

test("prefill falls back to the last session on the same side", () => {
  const lp = WL.model("2026-11-19").exercises[2];
  assert.equal(WL.prefill(lp, "L").kg, 57.5);
});

test("a free day outside the block has no planned exercises", () => {
  const m = WL.model("2026-12-20");
  assert.equal(m.code, "F");
  assert.equal(m.exercises.length, 0);
  assert.equal(WL.firstOpen(m), -1);
});

test("a saved order moves exercises and keeps the rest in plan order", () => {
  const m = WL.model("2026-11-19", ["lat"]);
  assert.deepEqual(plain(m.exercises.map((e) => e.slot)), ["lat", "iso", "bench", "lp", "le", "fly"]);
});

test("stepper sizes per field", () => {
  assert.equal(WL.step("kg"), 2.5);
  assert.equal(WL.step("reps"), 1);
  assert.equal(WL.step("secs"), 5);
});
