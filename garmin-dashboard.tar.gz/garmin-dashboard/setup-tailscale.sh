#!/usr/bin/env bash
# Makes the dashboard reachable from your phone/laptop anywhere, privately, via Tailscale.
# Nothing is opened to the public internet and no router settings are needed.
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT=$(grep -E '^\s*port\s*=' "$DIR/config.ini" 2>/dev/null | head -1 | sed 's/.*=\s*//' || true)
PORT=${PORT:-8050}

if ! command -v tailscale >/dev/null; then
  echo "==> Installing Tailscale"
  curl -fsSL https://tailscale.com/install.sh | sh
fi

if ! tailscale status >/dev/null 2>&1; then
  echo "==> Log in to Tailscale: open the link that appears below on your phone or laptop"
  sudo tailscale up
fi

echo "==> Publishing the dashboard inside your tailnet (HTTPS)"
if ! sudo tailscale serve --bg "$PORT"; then
  echo
  echo "Tailscale needs HTTPS enabled for your tailnet once:"
  echo "open the link shown above (or https://login.tailscale.com/admin/dns → enable MagicDNS and HTTPS),"
  echo "then run this script again."
  exit 1
fi
echo
sudo tailscale serve status
echo
echo "Open the https://… address above on any device where the Tailscale app is installed and logged in"
echo "with the same account. Tip: add it to your phone's home screen."
