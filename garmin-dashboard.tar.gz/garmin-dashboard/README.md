# Garmin training dashboard

A private dashboard for your Garmin data that runs on your Raspberry Pi, syncs
every hour through Garmin's official **Personal API**, and is reachable from your
phone anywhere through Tailscale.

**What you get**

- **Workouts**: every day one running and one cycling suggestion (pick either), based on
  your HRV, resting HR, sleep, recent hard sessions and volume trend – with the reasons,
  your targets (pace / HR / power) and the studies behind each rule
- **Overview**: this week vs. your 4-week average, fitness/fatigue/form (CTL/ATL/TSB),
  weekly hours by sport, time in HR zones, a 12-month activity calendar, and
  automatic insights (fatigue, ramp rate, elevated resting HR, HRV dips, new PRs…)
- **Running**: pace trend, weekly km, personal bests found inside every run
  (400 m to marathon), PR progression, race predictions, aerobic efficiency,
  VO₂ max, cadence and ground-contact time
- **Cycling**: power curve (all-time / 12 months / 90 days, W or W/kg), estimated
  FTP trend, automatically detected climbs ranked by VAM, climbing-speed trend,
  power zones, power/HR efficiency, weekly km and elevation
- **Recovery**: resting HR, HRV with your baseline band, sleep stages and score,
  Body Battery, stress, steps, and how your training load relates to your HRV
- **Every activity**: map, synced HR/pace/power/elevation/cadence charts, zones,
  laps, climbs, best efforts and its power curve vs. your best
- **Gym**: the 4-week knee-smart block (A → B → C → rest) as a tappable 28-day plan, each
  session with sets, reps, RIR, depth limits and cues. Log every set (weight × reps, reps,
  seconds, weight + seconds, or minutes; left / right / both legs), tap a set to edit it,
  swap any exercise for another (logged sets move with it), and move a session to another day.
  Build your own workouts and exercises (type, one side at a time, muscles trained), or save a
  logged session as a workout. A 60+ exercise library knows which muscles each exercise trains,
  so every session shows kilos lifted, sets, reps, time, personal records and muscles worked,
  and the week shows hard sets per muscle (legs per side) against the plan. Plus knee-pain
  trend, strength progress per exercise, the day-5/day-25 tests and watch strength workouts.
  A front/back **body map** colours every muscle by hard sets (session or week, the more sets the stronger the blue,
  right and left leg separately; the right knee turns amber/red on pain days). The **effort check**
  compares each session with the plan: reps in reserve against the week's target, your 0–10
  session rating, pace and heart rate from the watch recording, and knee pain.
  **Describe it in words**: type what you did ("bench 3x8 60kg, leg press both legs 3x12 120…")
  and a small AI model on the Pi turns it into logged sets – see *Local AI* below

**New in this version: pick your workout, better "Describe session"**

- No more fixed gym days. Today (or Workout mode) lets you pick A, B, C or an empty session when you get to
  the gym. *Suggested* marks the one you did longest ago, and A and C remind you when yesterday was a leg day.
  *Change workout* or *Switch workout* works until you log the first set. The 4-week block still sets the
  number of sets and the effort by week; the knee test comes with your first A session from day 5 and from day 25.
- "Describe session" on the Pi: lists only exercises you mention, never saves an effort or knee pain you didn't
  write, knows Stair stepper and Cross trainer, and flags it when the machine doesn't match your text.

**Earlier in phase 1: a new look and four tabs**

- **Today** opens first: today's call (which gym day it is and whether hard cardio is fine),
  recovery against your own normal range, the gym session with *Start session*, the two cardio
  options, and this week's running, cycling, gym and hard-session budget.
- **Workout mode** shows one exercise at a time: big steppers, set numbers per leg, and what you
  lifted last time. The list button or the progress bar opens the session overview: tap to jump,
  drag to change the order (kept for the day), swipe left or use *Swap exercise* when a machine is
  busy, add an exercise. *Finish* shows minutes, sets, kilos and new bests, then saves effort, knee
  pain and a note. There is no rest timer.
- Leave a session open and a **Resume** bar follows you to every tab.
- **Activities**, **Progress** (Overview, Run, Ride, Strength) and **Recovery** keep their
  current pages inside the new layout for now. Settings is the gear at the top right.

Your data stays on the Pi (`data/` folder; your gym log is `data/gym.sqlite`). The Garmin key never leaves it.

---

## Setup (about 15 minutes)

### 1. Create your Garmin API key
On a computer, log in to Garmin Connect and open
**https://connect.garmin.com/app/settings/personalApiToken** → *Create Key* →
accept → choose an expiry (the longest is easiest) → copy the key.
It is shown only once – keep it somewhere safe until step 4.

### 2. Copy this folder to the Pi
From your Mac/PC (same Wi-Fi as the Pi), in the folder where you downloaded the file:

```bash
scp garmin-dashboard.tar.gz loxopi@raspberrypi.local:~
```

### 3. Install
In a shell on the Pi (Raspberry Pi Connect or `ssh loxopi@raspberrypi.local`):

```bash
tar xzf garmin-dashboard.tar.gz
cd garmin-dashboard
./install.sh
```

### 4. Add your key and start the first download
```bash
./garmin-dash set-key                       # paste the key (it is hidden while you type)
./garmin-dash test                          # should list your last 5 activities
sudo systemctl start --no-block garmin-sync.service
```
The first download runs in the background (safe to close the shell). Depending on
how many activities you have it takes 10–60 minutes; watch it with
`journalctl -u garmin-sync -f` or on the dashboard's sync page (↻ icon).
After that it updates itself every hour.

### 5. Access from anywhere
```bash
./setup-tailscale.sh
```
Follow the login link, then install the **Tailscale** app on your phone and log in
with the same account. The script prints an address like
`https://raspberrypi.tailxxxx.ts.net` – open it on your phone and use
*Add to Home Screen*. Only your own devices can reach it.

---

## Everyday commands (in the `garmin-dashboard` folder)

| Command | What it does |
|---|---|
| `./update.sh` | download the latest version from GitHub and restart (keeps data, config, key) |
| `./garmin-dash sync` | fetch new data now (the dashboard's *Sync now* button does the same) |
| `./garmin-dash sync --full` | re-download the complete history |
| `./garmin-dash reprocess` | recompute all analysis from stored files (after an update) |
| `./garmin-dash set-key` | replace the API key (e.g. when it expires) |
| `./garmin-dash inspect` | show the *structure* of Garmin's responses – no values |
| `sudo systemctl restart garmin-dashboard` | restart the web server (after editing `config.ini`) |
| `journalctl -u garmin-sync -n 50` | last sync log |

**Going back to the previous version.** On GitHub, open `garmin-dashboard.tar.gz`, click *History*,
open the commit before this one and copy the link of its *Raw* button. Then run
`./update.sh <that link>`, for example
`./update.sh https://github.com/alogntrn/garmin-dashboard/raw/<commit>/garmin-dashboard.tar.gz`.
Your data, config and key stay as they are; the new files are simply no longer used.

## Settings
`config.ini` – override FTP, max HR, resting HR or weight if Garmin's values are
missing or wrong; change the port; set `host = 0.0.0.0` to also open it at
`http://raspberrypi.local:8050` on your home network; `[ai]` for the local model.

## Local AI ("Describe it in words" on the Gym page)
One-time setup on the Pi: `./setup-ai.sh` – installs or updates [Ollama](https://ollama.com),
downloads the model (`qwen3:4b-instruct-2507`, 2.5 GB) and limits Ollama: one job and one model
at a time, low priority, at most 3 of the 4 cores. It ends with a speed test and an estimate.
A Pi 4 reads prompts slowly (~2 tokens/s), so the model stays loaded (`keep_loaded = yes`,
≈3 GB RAM reserved, no CPU while idle) with its instructions already read – after a restart it
reads them once in the background (~10 min).

How a description is handled: a quick pass turns it into sets; the dashboard then checks the
answer against your text (every weight and rep count must appear in what you wrote, nothing
you wrote may be left out, exercises must exist). If something doesn't add up, a second
pass runs with the problems spelled out. A clean answer is logged straight away – the
sets carry an **AI** tag and the job card has *Undo*; anything still unclear is shown for you
to confirm or edit, and nothing is logged. Expect a few minutes per description on a Pi 4
(the setup script estimates it for your Pi), a few more when the second pass runs; you can
close the page meanwhile. While a job runs the Pi is busy
(≈3.5 GB RAM, 3 cores), the dashboard stays usable. Turn it off with `enabled = no` under `[ai]`.

## Troubleshooting
- **A chart says "not found in Garmin data"** (see the sync page): Garmin's Personal
  API is brand new and its field names aren't fully documented. Run
  `./garmin-dash inspect` and share the output – it contains only field names, no
  values – so the extraction can be adjusted.
- **"Garmin rejected the API key"**: the key expired or was deleted → create a new
  one and run `./garmin-dash set-key`.
- **Pi under load from Ollama**: the sync runs at low priority and is capped at
  1.5 CPU cores, so it won't starve the local AI.
- **"The local AI isn't running"** on the Gym page: run `./setup-ai.sh` (again); check
  `systemctl status ollama` and `ollama list`.
- **Power PRs or climbs look off after an update**: `./garmin-dash reprocess`.

## How the numbers are calculated
- **Training load** per activity = Garmin's own load (EPOC); if missing, Banister TRIMP from your heart rate.
- **Fitness / fatigue** = 42-day / 7-day exponentially weighted load; **form** = yesterday's fitness − fatigue.
- **eFTP** = 95 % of your best 20-minute power in the trailing 90 days (unless Garmin or `config.ini` provides an FTP).
- **Climbs** = sustained ascents of ≥ 50 m at ≥ 3 % over ≥ 400 m, with flat lead-ins trimmed. **VAM** = metres climbed per hour.
- **Race predictions** = Riegel formula (exponent 1.06) from your strongest effort ≥ 3 km in the last 90 days.
- **Efficiency** = output per heartbeat (runs: m/min per bpm on easy runs; rides: W per bpm). **HR drift** compares the first and second half.

## Credits
Body-map outlines: [body-muscles](https://www.npmjs.com/package/body-muscles) by Ivan Vulović, Apache License 2.0 – licence and notice in `garmin_dash/static/vendor/`. Charts: Chart.js; maps: Leaflet.
