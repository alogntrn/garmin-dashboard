# Garmin training dashboard

A private dashboard for your Garmin data that runs on your Raspberry Pi, syncs
every hour through Garmin's official **Personal API**, and is reachable from your
phone anywhere through Tailscale.

**What you get**

- **Overview**: this week vs. your 4-week average, fitness/fatigue/form (CTL/ATL/TSB),
  weekly hours by sport, time in HR zones, a 12-month activity calendar, and
  automatic insights (fatigue, ramp rate, elevated resting HR, HRV dips, new PRs…)
- **Running**: pace trend, weekly km, personal bests found inside every run
  (400 m to marathon), PR progression, race predictions, aerobic efficiency,
  VO₂ max, cadence and ground-contact time
- **Cycling**: power curve (all-time / 12 months / 90 days, W or W/kg), estimated
  FTP trend, automatically detected climbs ranked by VAM, climbing-speed trend,
  power zones, power/HR efficiency, weekly km and elevation
- **Recovery**: resting HR, HRV with your baseline band, sleep stages and score,
  Body Battery, stress, steps, and how your training load relates to your HRV
- **Every activity**: map, synced HR/pace/power/elevation/cadence charts, zones,
  laps, climbs, best efforts and its power curve vs. your best

Your data stays on the Pi (`data/` folder). The Garmin key never leaves it.

---

## Setup (about 15 minutes)

### 1. Create your Garmin API key
On a computer, log in to Garmin Connect and open
**https://connect.garmin.com/app/settings/personalApiToken** → *Create Key* →
accept → choose an expiry (the longest is easiest) → copy the key.
It is shown only once – keep it somewhere safe until step 4.

### 2. Copy this folder to the Pi
From your Mac/PC (same Wi-Fi as the Pi), in the folder where you downloaded the file:

```bash
scp garmin-dashboard.tar.gz loxopi@raspberrypi.local:~
```

### 3. Install
In a shell on the Pi (Raspberry Pi Connect or `ssh loxopi@raspberrypi.local`):

```bash
tar xzf garmin-dashboard.tar.gz
cd garmin-dashboard
./install.sh
```

### 4. Add your key and start the first download
```bash
./garmin-dash set-key                       # paste the key (it is hidden while you type)
./garmin-dash test                          # should list your last 5 activities
sudo systemctl start --no-block garmin-sync.service
```
The first download runs in the background (safe to close the shell). Depending on
how many activities you have it takes 10–60 minutes; watch it with
`journalctl -u garmin-sync -f` or on the dashboard's sync page (↻ icon).
After that it updates itself every hour.

### 5. Access from anywhere
```bash
./setup-tailscale.sh
```
Follow the login link, then install the **Tailscale** app on your phone and log in
with the same account. The script prints an address like
`https://raspberrypi.tailxxxx.ts.net` – open it on your phone and use
*Add to Home Screen*. Only your own devices can reach it.

---

## Everyday commands (in the `garmin-dashboard` folder)

| Command | What it does |
|---|---|
| `./garmin-dash sync` | fetch new data now (the dashboard's *Sync now* button does the same) |
| `./garmin-dash sync --full` | re-download the complete history |
| `./garmin-dash reprocess` | recompute all analysis from stored files (after an update) |
| `./garmin-dash set-key` | replace the API key (e.g. when it expires) |
| `./garmin-dash inspect` | show the *structure* of Garmin's responses – no values |
| `sudo systemctl restart garmin-dashboard` | restart the web server (after editing `config.ini`) |
| `journalctl -u garmin-sync -n 50` | last sync log |

## Settings
`config.ini` – override FTP, max HR, resting HR or weight if Garmin's values are
missing or wrong; change the port; set `host = 0.0.0.0` to also open it at
`http://raspberrypi.local:8050` on your home network.

## Troubleshooting
- **A chart says "not found in Garmin data"** (see the sync page): Garmin's Personal
  API is brand new and its field names aren't fully documented. Run
  `./garmin-dash inspect` and share the output – it contains only field names, no
  values – so the extraction can be adjusted.
- **"Garmin rejected the API key"**: the key expired or was deleted → create a new
  one and run `./garmin-dash set-key`.
- **Pi under load from Ollama**: the sync runs at low priority and is capped at
  1.5 CPU cores, so it won't starve the local AI.
- **Power PRs or climbs look off after an update**: `./garmin-dash reprocess`.

## How the numbers are calculated
- **Training load** per activity = Garmin's own load (EPOC); if missing, Banister TRIMP from your heart rate.
- **Fitness / fatigue** = 42-day / 7-day exponentially weighted load; **form** = yesterday's fitness − fatigue.
- **eFTP** = 95 % of your best 20-minute power in the trailing 90 days (unless Garmin or `config.ini` provides an FTP).
- **Climbs** = sustained ascents of ≥ 50 m at ≥ 3 % over ≥ 400 m, with flat lead-ins trimmed. **VAM** = metres climbed per hour.
- **Race predictions** = Riegel formula (exponent 1.06) from your strongest effort ≥ 3 km in the last 90 days.
- **Efficiency** = output per heartbeat (runs: m/min per bpm on easy runs; rides: W per bpm). **HR drift** compares the first and second half.
