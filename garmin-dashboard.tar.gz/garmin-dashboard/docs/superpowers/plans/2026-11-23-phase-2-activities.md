# Phase 2: Activities – plan

**Spec:** docs/superpowers/specs/2026-11-19-dashboard-redesign-design.md (Activities, routes) and the canvas boards
"Activities" and "Activity detail". **Tests:** `node --test tests/js/*.test.js`, `python3 -m pytest tests -q`,
`python3 -I tools/ui_smoke.py`.

## Global constraints
As phase 1: no build step, system fonts, API changes additive only, gym data format unchanged, 44 px targets,
status colours only with a symbol, sport colours Run/Ride/Strength from ui.css.

## Review focus
1. A gym day that also has a Garmin strength activity appears once (the gym row carries the watch data).
2. "Load more" keeps week totals right when a week spans two pages.
3. Filters and search combine (Gym + search matches session and exercise names).
4. Calendar month without any activity, and months across a year boundary.
5. Gym session page for a day without sets (chosen, nothing logged) and for an old day without a day record.

### Task 1: activities by date range
analytics.activity_list(sport, q, limit, offset, start=None, end=None); /api/activities gains `start`, `end` (ISO dates,
inclusive). Test: tests/test_api.py `test_activities_filter_by_date_range`.

### Task 2: activities-logic.js (window.AL)
`gymSessions(GYM)` → [{kind:"gym", date, code, letter, name, sets, kg, mins, hr, test, watchIds}];
`merge(garmin, gym, {sport, q, today, until})` → [{key (Monday ISO), label ("This week", "Last week", "16–22 Nov"),
km, secs, items:[…newest first]}]; gym items only on or after `until` (oldest loaded Garmin date) unless the list is
complete; Garmin strength activities folded into that day's gym row; `calendar(year, month, items, today)` →
6×7 cells {date, inMonth, today, sports:[…]}. Tests in tests/js/activities-logic.test.js.

### Task 3: Activities page (activities.js)
Large title, segmented All/Runs/Rides/Gym (saved), search, week sections with totals, rows as on the board, Load more,
calendar button → month grid with dots, ‹ › months, tapping a day opens that day's rows in a sheet.
Smoke: test_activities_weeks_and_gym, test_activities_filter_gym, test_activities_calendar.

### Task 4: gym session page (gym-session.js)
Route `#/gym-session/<date>` (tab Activities). Header with letter disc and date, minutes/sets/kg (+ watch HR), new bests,
exercises with their sets, sets per muscle, effort check (verdict, effort, knee pain, note), link to edit on the
Strength page. Tests: router test, smoke test_gym_session_page.

### Task 5: activity detail restyle
Title and date in the page header, stat grid as on the board, heart-rate zone card (one bar, "N % in zone K", max HR),
map and charts in the new cards. Smoke: test_activity_detail.

### Task 6: README, tarball, update check
