# Phase 4: Recovery, Settings, home-screen icon, iPad and Mac — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Finish the redesign: a Recovery tab that answers "am I recovered?", Settings as a sheet with everything from
the old Sync & settings page plus targets, gym setup, local AI and the method, pull down to sync, a real home-screen
icon, and wide layouts that use the space.

**Architecture:** Same as phases 1–3: classic scripts, no build step. Pure logic in `recovery-logic.js` (RL, unit
tested with the vm loader); pages in `recovery.js` and `settings.js`, loaded before `app.js` and called through
`window.*`. One additive API field (`syncing` in `/api/status`). Icons are PNGs generated once by `tools/make_icons.py`.

**Tech stack:** Flask/waitress, vanilla JS, Chart.js (detail charts), inline SVG (card sparklines), node:test,
pytest, Playwright smoke tests.

**Spec:** `docs/superpowers/specs/2026-11-19-dashboard-redesign-design.md` (sections 5 Recovery and Settings sheet,
6 home-screen app, 7 phase 4). Board "Recovery" and "iPad and Mac" in the Design canvas.

## Global constraints

- No build step, no CDN, no web fonts. API changes additive only. Gym data and `/api/gym*` unchanged.
- Recovery must agree with Today: HRV, resting HR and sleep use the coach's readiness factors (`/api/coach`).
- Status never by colour alone: a symbol and words with every out-of-range state.
- Every asset URL in `index.html` gets a new `?v=` when its file changes.
- Phone first (390 × 844), light and dark; wide = 1024 px and up (sidebar).

## Review focus

1. Stale data (the newest wellness row is days old): Recovery must say "Latest data from …", not "last night".
2. Missing metrics (no HRV, no stress, no Body Battery): the card says so instead of drawing empty axes; the headline
   counts only checks with data.
3. Settings opened directly by URL (`#/settings/log`) on a cold start: a page underneath, the sheet on top, Done works.
4. Pull to sync must not fire inside Workout mode, inside a sheet, or when the page isn't scrolled to the top.
5. A sync that fails or never finishes: the indicator stops after a timeout and says what happened.

---

### Task 1: Recovery logic (`recovery-logic.js`, `window.RL`)

- `RL.fresh(latestIso, todayIso)` → "Last night, compared with your normal range." when the newest row is today or
  yesterday, otherwise "Latest data from 18 Nov, compared with your normal range."
- `RL.normal(rows, key, n = 60)` → `{ lo, hi }`: 25th–75th percentile of the `n` values before the newest 7 days;
  null with fewer than 14 values. Used for Body Battery, stress and steps (HRV, resting HR, sleep come from the coach).
- `RL.status(value, range)` → "in" | "above" | "below" | null.
- `RL.headline(factors)` (coach factors without "Training load"):
  no known checks → "Not enough recent data for a check."; all green → "All three checks are in your normal range."
  ("HRV is in your normal range." for one); otherwise "HRV and sleep are outside your normal range." with the first
  out-of-range factor's text as the line below.
- `RL.patterns(corr)` → sentences: hardest-day HRV difference ("After your hardest days, HRV is about 6 ms lower the
  next night."), sleep ↔ HRV, load ↔ next-day HRV, load ↔ next-day resting HR, with "a weak / a moderate / a strong
  link" or "show no clear link"; null correlations are left out.
- Tests: `tests/js/recovery-logic.test.js` (fresh today/yesterday/stale, normal percentiles and too-few, headline
  three cases, patterns signs and strengths, null skipped).

### Task 2: Recovery page (`recovery.js`, `window.renderRecoveryPage(arg)`)

- Router: `#/recovery/<hrv|rhr|sleep|bb|stress|steps>` → `{ tab: "recovery", page: "recovery", arg }`; anything else
  under `#/recovery/` redirects to `#/recovery`. Router tests added.
- Overview: sub (RL.fresh), headline + line, six cards (two columns on phones, three on wide), each a link to its
  detail: HRV (last night big, "7-day 58, normal 54–61", 30-night sparkline over the normal band), Resting HR (same),
  Sleep (last night, score, 7 nights of stage bars Deep/Light/REM), Body Battery (high, low–high track), Stress
  (latest day, normal range, 30-day sparkline), Steps (last complete day, normal range, 14 bars). Out of range: a
  chip with ▲/▼ and words. Then "Patterns in your data".
- Detail: back to Recovery, range button (1 month … 2 years, stored as `rec-range`, same sheet as Progress), the
  existing full chart for that metric, a one-line explanation.
- Old `renderRecovery` and its `rg-rec` segmented control are removed; the chart code moves to `recovery.js`.
- Smoke: `test_recovery_overview` (headline, six cards, patterns, tap HRV → chart, back), the stress-empty test points
  at the Stress detail.

### Task 3: Sync status and pull to sync

- `/api/status` gains `syncing` (the sync lock is held). Test: false normally, true while a test holds the lock.
- `syncNow()` in `app.js`: POST `/api/sync`, a glass pill "Syncing with Garmin…", poll `/api/status` every 2.5 s until
  `syncing` is false (4 min at most), then reload the page data; "Synced" or the newest error from the log. Today's
  sync button and Settings use it.
- Pull to sync: touch at scroll top, drag ≥ 72 px, release → `syncNow()`. Off in Workout mode, with a sheet open, and
  for touches that start inside inputs. Indicator follows the finger.
- Sidebar footer on wide screens: "Synced at 07:00." plus "Pull down to sync." on touch screens.
- Smoke: `test_pull_to_sync` (synthetic touches; `/api/sync` and `/api/status` stubbed).

### Task 4: Settings sheet (`settings.js`, `window.Settings`)

- Router: `#/settings` and `#/settings/<log|data|heart|targets|tests|rules|ai|method>`. The page underneath stays;
  a cold start renders the last page (Today) first. Done, Escape and the dim go back to that page without reloading it.
- Root (grouped lists): Garmin — Sync now (with last sync), Sync log, Data; You — Heart rate and zones, Training
  targets; Gym — Block start (date, saves at once), Workouts and exercises (opens the 28-day block page at its
  editor), Tests, Rules; Local AI — status; About — How suggestions are made.
- Sub-pages inside the sheet with "‹ Settings". Tests reuse `GYM.testsHTML` and save through `/api/gym/settings`;
  Rules reuse `GYM.rulesHTML`; targets and the method come from `/api/coach`.
- Tall sheet on phones (full height below the status bar), centred form sheet on wide screens.
- The old `renderStatus` page is removed. Smoke: `test_settings_sheet` (gear opens it over Today, Sync log sub-page,
  back, Done returns to Today unchanged), `test_settings_cold_start`.

### Task 5: Home-screen icon and manifest

- `tools/make_icons.py` renders the existing pulse-line mark (white on black, full bleed) to
  `static/icons/apple-touch-icon.png` (180), `icon-192.png`, `icon-512.png`, `icon-maskable-512.png`.
- `static/manifest.json`: name and short_name "Training", start_url `/#/today`, display standalone, colours for the
  light background, the icons.
- `index.html`: apple-touch-icon, manifest link, `mobile-web-app-capable`.
- pytest: manifest parses, every icon it lists is served as PNG with the stated size.

### Task 6: iPad and Mac polish

- Today on wide screens: two columns (plan left; readiness and this week right), call and line across both.
- Page-header buttons line up with the content's right edge on narrow pages.
- Sheets: focus moves into the sheet when it opens and back when it closes.
- Smoke: `test_wide_layout` (1366 × 1024: Today's readiness card sits right of the plan; header buttons inside the
  content box; Settings sheet centred).

### Task 7: Deliver

- All suites green; screenshots phone light/dark and wide; README "New in this version"; bump `?v=`; tarball;
  `update.sh` simulation; send.

Out of scope (ruling): restyling the cardio "Workout details" page (`#/plan`) into a sheet; it keeps working as is.
