# Phase 3: Progress – plan

**Spec:** docs/superpowers/specs/2026-11-19-dashboard-redesign-design.md (Progress) and the canvas board "Progress".
**Tests:** `node --test tests/js/*.test.js`, `python3 -m pytest tests -q`, `python3 -I tools/ui_smoke.py`.

## Decided
- One range menu for the tab (page header, right): 3 months, 6 months, 1 year, 2 years, All; stored as `prog-range`
  (days). Overview, Run and Ride use it; their own range controls go. Strength is block-based: no range menu there.
- Overview as on the board: headline ("Fitness is building/steady/dropping." + change in a week and form in words),
  Training load (fitness and fatigue, with the trend), Form, Weekly training time (Run, Ride, Strength & other),
  Intensity (hours per week per heart-rate zone), Consistency (activity calendar). The old tiles, insights and recent
  list go (they live on Today, Recovery and Activities now).
- Run and Ride keep their cards; the old page heading is replaced by a short "this year so far" line.
- Strength without a date shows the analytics only (tiles, workout stats, muscles worked, sets vs plan, knee pain,
  strength progress, tests, rules) with a link to the 28-day block; `#/progress/strength/<date>` keeps the full page
  for logging or editing a day.

## Tests
Smoke: test_progress_overview, test_progress_range_menu, test_strength_analytics.
