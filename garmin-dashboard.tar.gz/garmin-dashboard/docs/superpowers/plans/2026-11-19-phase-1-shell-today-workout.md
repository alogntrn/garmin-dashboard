# Phase 1: new shell, Today and Workout mode – Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship the new four-tab shell, the Today tab and the full-screen gym Workout mode (with session overview and finish sheet) as one tarball, without touching gym data.

**Architecture:** Classic scripts, no build step, as today. `gym.js` exposes its model as `window.GYM`; two pure logic files (`today-logic.js`, `workout-logic.js`) hold every rule that can be unit-tested in Node; `today.js` and `workout.js` render; `app.js` keeps the old page renderers and gets the new router. Old pages render inside the new shell until their phase.

**Tech Stack:** Flask + waitress (unchanged), vanilla JS, vendored Chart.js / Leaflet, Node 22 `node --test` and Playwright (Python) for dev-only tests.

**Spec:** `docs/superpowers/specs/2026-11-19-dashboard-redesign-design.md` (approved 19 Nov 2026, no rest timer). Visual reference: the Design canvas boards Today, Workout mode, Session overview, Finish session, Design system.

## Global Constraints

- No build step, no npm packages shipped, no CDN or web fonts; system font stacks only (`-apple-system, BlinkMacSystemFont, "SF Pro Text", system-ui, sans-serif`; numbers and headline `ui-rounded, "SF Pro Rounded", …`).
- Gym data format and `/api/gym*` stay as they are; the server is the source of truth, every set is posted immediately. The phone keeps only current exercise and exercise order in `localStorage` (prefix `gd:`).
- No rest timer and no countdown anywhere. Session time is shown in whole minutes.
- API changes are additive only.
- Colours: Run `#0A6CFF` / dark `#2F7FF0`, Ride `#F07800` / `#E06A12`, Strength `#D63FA0` / `#E0499E` (button fill `#C2318E` / `#C93A92` with white text); status green / yellow / red only with a symbol; ink for everything else. Light page `#F2F2F7`, card `#FFFFFF`; dark page `#000000`, card `#1C1C1E`; secondary text `#636366` / `#98989D`.
- Glass blur only on floating chrome (tab bar, sidebar, sheets, Workout toolbar, Resume bar).
- Touch targets at least 44 px; real `<button>`/`<a>` elements.
- Asset URLs in `index.html` carry `?v=<version>`; `/` and `/static/*` are sent with `Cache-Control: no-cache`.

## Review Focus

1. Logging while offline or when the Pi is slow: a failed POST must leave the set unlogged, show an error on the button and keep the typed values (test: smoke `test_log_set_failure_keeps_values` with the route aborted).
2. Days outside the block or with a free/rest session: Today shows no gym card on rest/outside days, Workout mode opens a free session that can add exercises (test: logic `model free day has no slots`, smoke `test_today_rest_day`).
3. Unilateral exercises with unequal sets (`R 4 · L 2`): progress, next side and set numbers per side (test: logic `progress R4 L2`).
4. Reload mid-session: Workout mode reopens on the remembered exercise; the Resume bar appears on every tab while sets exist and the day is not done (test: smoke `test_resume_bar_and_reload`).
5. Coach data missing (fresh install, no HRV yet): readiness rows without numbers show the factor text instead of a bar, Today still renders (test: logic `rangeBar returns null without numbers`, smoke with a factor stubbed).

---

### Task 1: Dev harness, `window.GYM`, cache headers

**Files:**
- Modify: `garmin_dash/static/gym.js` (export block before `window.renderGym`; `#/gym` links → `#/progress/strength`)
- Modify: `garmin_dash/web.py` (`index`, `static_files`: `Cache-Control: no-cache`)
- Create: `tests/js/load.js` (vm loader), `tests/js/fixture-gym.json`, `tests/js/gym-export.test.js`, `tests/test_headers.py`, `tools/ui_smoke.py`

**Interfaces:**
- Produces `window.GYM`: `use(state)`, `get()`, `todayIso()`, `start()`, `idxOf(d)`, `planType(d)`, `weekOf(d)`, `sessOf(d)`, `sessName(code)`, `isW(code)`, `blocksFor(d)`, `effEx(d, sl)`, `setsOn(d)`, `slotOf(set)`, `def(id, name)`, `prevSets(exId, d)`, `slotProgress(sl, dfn, logged)`, `parseSets(str)`, `setTxt(set)`, `sessionStats(d)`, `rirCheck(d)`, `rpeCheck(d)`, `kneeCheck(d)`, `verdict(rir, rpe, pace, knee)`, `aiCtx(d)`, `jobHTML(job)`, `exOptions(sel, alts, withNew)`, `post(url, body, method)`, constants `CR10, PH, PHN, PLAN, REST, SNAME`.
- Produces `tests/js/load.js`: `loadScripts(files: string[]) → window` (runs classic scripts in one `vm` context with a stub `window`, `document`, `localStorage`).

- [ ] Write `gym-export.test.js`: with `fixture-gym.json` (start `2026-11-19`, sets on 19–20 Nov) `GYM.planType("2026-11-19") === "A"`, `planType("2026-11-22") === "R"`, `weekOf("2026-11-26") === 2`, `blocksFor("2026-11-19").map(s=>s.slot)` equals `["iso","bench","lp","le","fly","lat"]`.
- [ ] Write `tests/test_headers.py`: Flask test client, `GET /` and `GET /static/style.css` have `Cache-Control: no-cache`.
- [ ] Run both, see them fail; implement; run, see them pass.
- [ ] `tools/ui_smoke.py`: Playwright (Chrome) at 390 × 844 against `http://127.0.0.1:8050`, collects console errors, one function per smoke test named below, `python3 tools/ui_smoke.py [name…]`.
- [ ] Commit.

### Task 2: `today-logic.js` and additive coach fields

**Files:**
- Create: `garmin_dash/static/today-logic.js`, `tests/js/today-logic.test.js`
- Modify: `garmin_dash/coach.py` (`readiness().add(...)` gains optional `value, lo, hi, unit`; `suggestions().context` gains `max_hard`, `run_week_cap`)

**Interfaces:**
- Produces `window.TL`:
  - `headline({level, hardAllowed, gym, gymDone, forTomorrow}) → {first: string|null, second: string}`; rules from spec §6, plus: `gymDone` or (`forTomorrow` and no gym) gives first `"Done for today."` and second prefixed `"Tomorrow: "` with a lower-case start.
  - `loadBucket(ctl, tsb) → {idx: 0..4, label}`; ratio `(ctl - tsb) / ctl`, cuts `0.8, 0.95, 1.15, 1.3`, labels `Well below, Below, Steady, Above, Well above`; `ctl <= 5` gives `null`.
  - `rangeBar(value, lo, hi) → {lo, hi, val} | null` in percent of a domain padded by the band width on each side, clamped to 3–97; `null` when any input is missing.
  - `weekBudget(ctx) → {run: {km, cap, pct}, ride: {h, usual, pct, usualPct}, hard: {done, max}}`; `cap = ctx.run_week_cap`, ride scale `max(h, usual) × 1.3`.
  - `gymWeek(GYM, todayIso) → {done, planned, days: [{date, letter, state: "done"|"today"|"plan"|"rest"|"none"}]}` for Monday–Sunday of the current week.
- Coach factors: HRV `value` = 7-day average (or last night on a dip), `lo/hi` the normal range, `unit "ms"`; Resting HR `value` = 7-day mean, `lo/hi` = baseline − 3 / + 3, `unit "bpm"`; Sleep `value` = last night hours, `lo 6`, `hi 9`, `unit "h"`. Context: `max_hard = 3 if ctl >= 60 else 2`; `run_week_cap = max(chronic × 1.3, chronic + 5)` or `null`.

- [ ] Tests: `headline` for A green hard-false → `["Leg day.","Keep cardio easy."]`; B green hard-true → `["Upper-body day.","Green light for a hard session."]`; red any → first `"Recovery day."`; rest → `"Rest day."`; no gym → first `null`; gymDone → `["Done for today.","Tomorrow: keep cardio easy."]`. `loadBucket(62, 3).label === "Steady"`, `loadBucket(50, -20).label === "Above"`, `loadBucket(4, 0) === null`. `rangeBar(58, 55, 59)` has `lo < val < hi`; `rangeBar(null, 1, 2) === null`. `gymWeek` on the fixture for 2026-11-20 marks Thu 19 done, Fri 20 today.
- [ ] Python check (in `tests/test_headers.py` file renamed `tests/test_api.py`): `coach.readiness()` on the sample DB returns `value/lo/hi` for HRV when the factor is numeric (skipped without data).
- [ ] Run, fail, implement, pass, commit.

### Task 3: `workout-logic.js`

**Files:**
- Create: `garmin_dash/static/workout-logic.js`, `tests/js/workout-logic.test.js`

**Interfaces:**
- Consumes `window.GYM` (Task 1).
- Produces `window.WL`:
  - `model(date, order?: string[]) → {date, code, title, letter, day|null, week|null, phase|null, inPlan, exercises: Ex[], done, total, firstSetAt|null}` where `Ex = {slot, exId, name, kind, uni, tag, extra, chips: string[], note, cue, why, rest, tempo, need, logged: Set[], prog: {done, text, next, count, of}, last: {date, text}|null}`; `count/of` are sets done / planned on the side that is next (or all sets for bilateral).
  - `chips(sl, dfn) → string[]`: sets (`"3 sets per leg"` when R = L, `"R 4 · L 2 sets"` otherwise, `"4 sets"`), reps (`"8–12 reps"`, untouched when it already has a unit word), RIR (`"RIR 3"` or `"Effort 70–80%"`).
  - `firstOpen(model) → index` of the first countable exercise not done, else last index.
  - `prefill(ex, side) → {kg, reps, secs, mins, rir}`: last logged set today on that side, else last session's same side, else first set of last session, else empty strings.
  - `applyOrder(exercises, order) → exercises` (unknown slots keep plan order at the end).
  - `step(kind, field) → number`: kg 2.5, reps 1, secs 5, mins 1.

- [ ] Tests on the fixture: `model("2026-11-19")` has 6 exercises, `exercises[2].chips` equals `["R 3 · L 2 sets","8–12 reps","RIR 3"]` (week 1 leg press), `prog` for leg press after 2 right sets is `{next: "R", count: 2, of: 3}`; `R 4 · L 2` iso: after 4 R and 0 L → next `"L"`; `prefill` returns today's last right set values; free day (`2026-12-20`, outside block, no day record) → `exercises.length === 0`, `code === "F"`; `applyOrder` moves `"lat"` first and keeps the rest.
- [ ] Run, fail, implement, pass, commit.

### Task 4: Design tokens, shell and router

**Files:**
- Create: `garmin_dash/static/ui.css` (tokens, shell, sheet, buttons, steppers, chips, cards, Today, Workout)
- Modify: `garmin_dash/static/style.css` (`:root` tokens remapped to the new palette, radius 22 px, old `.top` header rules removed)
- Modify: `garmin_dash/static/index.html` (new shell: `#side` nav, `#tabbar`, `#pagehead`, `#app`, `#resume`, `#wm` layer, `#sheet` layer; versioned assets; theme-color `#F2F2F7` / `#000000`)
- Modify: `garmin_dash/static/app.js` (router, redirects, page headers, Progress segments, Settings route; Overview drops its suggestion block)

**Interfaces:**
- Produces `resolveRoute(hash) → {tab, page, seg?, arg?, redirect?}` (pure, exported as `window.resolveRoute`): `#/today` default; `#/overview` → redirect `#/today`; `#/running` → `#/progress/run`; `#/cycling` → `#/progress/ride`; `#/gym/<date>` → `#/progress/strength/<date>`; `#/gym` → `#/workout` when `window.sessionOpen()` else `#/today`; `#/status` → `#/settings`; `#/plan` stays (tab today); `#/activity/<id>` tab activities.
- Produces `pageHead(title, {seg, right})`, `openSheet(html) / closeSheet()`, `refreshResume()`, `window.sessionOpen() → boolean`.
- Progress segments map to the old renderers: overview → `renderOverview`, run → `renderRunning`, ride → `renderCycling`, strength → `renderGym(arg)`.

- [ ] Node test `tests/js/router.test.js`: every mapping above.
- [ ] Smoke `test_shell_routes`: each of `#/today #/activities #/progress/overview #/progress/run #/progress/ride #/progress/strength #/recovery #/settings` renders without console errors; tab bar shows 4 tabs with the right one `aria-current`; `#/overview` ends on `#/today`; at 1280 px the sidebar is visible and the tab bar hidden.
- [ ] Run, fail, implement, pass, commit.

### Task 5: Today tab

**Files:**
- Create: `garmin_dash/static/today.js` (`window.renderToday()`)

**Interfaces:**
- Consumes `TL` (Task 2), `GYM` (Task 1), app.js helpers (`api, esc, n1, hm, fdate, ICONS`), `pageHead` (Task 4).
- Layout as the Today board: header (Sync button posts `/api/sync`, reloads after 8 s), headline (`TL.headline`), coach subtext (first blocker, capitalised, or "Recovery markers are all in range."), readiness card linking `#/recovery`, Today's plan (gym card → `#/workout`; cardio rows run/ride → `#/plan`), This week (`TL.gymWeek`, `TL.weekBudget`), Highlights (`summary.insights`), Latest (`summary.recent[0]`).

- [ ] Smoke `test_today`: headline text non-empty, 4 readiness rows, gym card with Start button on a plan day, two cardio rows, week strip with 7 days; `test_today_rest_day` (gym start moved so today is R): no Start button, headline starts "Rest day."
- [ ] Run, fail, implement, pass, commit.

### Task 6: Workout mode, overview, finish, Resume bar

**Files:**
- Create: `garmin_dash/static/workout.js` (`window.Workout = {open(), close(), render()}`)

**Interfaces:**
- Consumes `WL`, `GYM`, `openSheet/closeSheet`, `refreshResume`.
- Exercise view as the Workout board: top bar (minimise → back to the last tab, overview button, title + minutes since first set, Finish), progress bar (opens overview), chips, logged sets (tap → edit mode with Save / Delete / Cancel), "Up now" row, last-time line, side switch for unilateral (R / L / Both), steppers by kind (`WL.step`), RIR chips 0–4 (optional), Up next card, log button `Log set N, right leg`. Swipe left/right changes exercise. Info (`kind "info"`) exercises show text and a Next button.
- Overview sheet: rows (status, name, detail, `count/of`), tap jumps, drag handle reorders (saved to `gd:wm-order:<date>`), swipe left reveals Swap (sheet with `GYM.exOptions` and `/api/gym/swap`), Add exercise (`/api/gym/day` extras), Describe session (`/api/gym/ai/jobs`, job list via `GYM.jobHTML`, polling every 5 s while queued/running) only when `G.ai.enabled`.
- Finish sheet: minutes / sets / kg (`GYM.sessionStats`), up to 3 bests, verdict (`GYM.verdict(rirCheck, rpeCheck, null, kneeCheck)` recomputed on each tap), effort 0–10 with CR10 label, knee pain 0–10 with the rule text, note, Save → `/api/gym/day {done: true, rpe, pain, note, session}` → Today.
- Screen wake lock while open (`navigator.wakeLock`, re-request on `visibilitychange`).
- Resume bar on every tab when `sessionOpen()`.

- [ ] Smoke `test_workout_log_set`: open `#/workout`, press +2.5 kg, log → POST `/api/gym/set` 200, the set row appears, button now says set 2; `test_log_set_failure_keeps_values`; `test_overview_jump_and_reorder` (jump to exercise 4, drag `lat` to the top, order survives reload); `test_finish_saves_day` (effort 6, pain 1, note → `/api/gym/day` has `done: true`); `test_resume_bar_and_reload`.
- [ ] Run, fail, implement, pass, commit.

### Task 7: Package and verify

**Files:**
- Modify: `README.md` (short "New in this version" + how to go back: `./update.sh <old tarball URL>`)
- Create: `dist/garmin-dashboard.tar.gz` (top folder `garmin-dashboard/`, no `data/`, no `tests/` artefacts beyond sources, no `.git`)

- [ ] `node --test tests/js`, `python3 -m pytest tests -q`, `python3 tools/ui_smoke.py` all pass.
- [ ] Phone-size screenshots of Today, Workout, overview, finish, every tab, light and dark; look at each.
- [ ] Build the tarball, check `update.sh`'s guard (`garmin-dashboard/garmin_dash` exists), list contents.
