# Free workout choice and AI parsing fixes – plan

**Spec:** docs/superpowers/specs/2026-11-22-free-workout-choice-design.md
**Tests:** `node --test tests/js/*.test.js`, `python3 -m pytest tests -q`, `python3 -I tools/ui_smoke.py`

## Global constraints
Same as phase 1 (no build step, gym data format unchanged, no rest timer, whole minutes, 44 px targets,
status colours only with a symbol). API changes additive only.

## Review focus
1. A day with sets but no session record (older data) still shows its workout.
2. Choosing a workout after midnight / on a day that already has sets must not wipe them.
3. AI: an exercise named in the text but without numbers still tells him it wasn't logged.
4. AI: "10 min Velo" / "Fahrrad" must not be flagged as a wrong machine.
5. Switching workout after the first set is not offered.

### Task 1: AI parsing fixes
ai.py `_prompt`/`_user_msg` wording; `_check`: number-less items → one note; ungrounded rpe/pain → None + note;
cardio machine aliases (bike, rower, stairs, xtrainer) → issue when the text names another machine or none;
steps note. gym-lib.js LIB gains `stairs` "Stair stepper" and `xtrainer` "Cross trainer" (min, Cardio).
Tests: tests/test_ai_check.py (stairstepper case, invented rpe, echo of planned items, Velo/Fahrrad not flagged,
named exercise without numbers).

### Task 2: sessions are chosen, not scheduled
gym.js: `chosen(d)` (explicit session, or "F" when sets exist), `sessOf(d)` = chosen || "F", test-day rule in
notesFor; gym.py `session_on` explicit only; coach `_gym_conflict` today only. today-logic.js: `choices(GYM, t)`,
`gymWeek` without planned letters. workout-logic.js: model gains `chosen`.
Tests: tests/js (choices: suggestion, leg hint; gymWeek; model.chosen; test day), tests/test_api.py (session_on,
gym conflict).

### Task 3: Today
today.js chooser card, Change workout, headline input, week strip. Smoke: test_today_choose_workout,
test_today (adapted), test_today_rest_day → test_today_unchosen_headline.

### Task 4: Workout mode
workout.js chooser view and "Switch workout" sheet. Smoke: test_workout_choose_then_log, test_switch_only_before_first_set.

### Task 5: Strength page, README, tarball
gym.js picker without Rest, rack, tiles, copy; README "New in this version"; build and verify the tarball.
