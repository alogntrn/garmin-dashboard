# 28-day block page in the new design — Plan

> **For agentic workers:** REQUIRED SUB-SKILL: superpowers:executing-plans.

**Goal:** The last page in the old style, `#/progress/strength/<date>` (opened from the Strength tab, from
Settings → Workouts and exercises, and from the rack), becomes a focused detail page in the new design.

**Spec:** `docs/superpowers/specs/2026-11-19-dashboard-redesign-design.md` ("every card on today's site keeps a home";
Strength = analytics, logging = Workout mode). No API changes; gym data untouched.

## Decisions

- Header: "28-day block", back to Strength, no tab segments. The block line and Day 1 date stay under it.
- Content: the 28-day rack, the selected day (session card and its effort check), your workouts and exercises,
  history. The analytics (tiles, workout stats, muscles, sets vs plan, knee pain, strength progress) stay on Strength;
  tests and rules are in Settings (and on Strength).
- Look: primary buttons are ink pills, text links are ink (not blue), fields use the fill background at 44 px,
  "How & why" uses the disclosure style of the cardio page, cards and exercise blocks use the --u tokens. CSS scoped
  to `#g-root`; markup and handlers unchanged so logging past days keeps working mid-block.
- Draw calls (`drawVol`, `drawStr`, `drawPain`, `drawMap`) only run when their element is on the page.

## Tests

- Smoke `test_block_page`: title and back link; rack, session, effort check and workouts present; analytics, tests
  and rules absent; Add set is an ink pill, links are ink, fields are at least 40 px tall.
- Existing: `test_shell_routes` (rack links), `test_strength_analytics`, `test_settings_gym` (#g-mgmtcard).

## Review focus

1. Logging a set on a past day still works (form submit, chips, edit, delete).
2. Swap, Move to another day, Save as one of my workouts, Describe it in words still open their panels.
3. Dark mode contrast of the restyled fields and buttons.
