# Phase 1 build notes

Decisions taken while building phase 1 (shell, Today, Workout mode), in the order they were made.
Each line: what was decided, why, and what it costs if it turns out wrong.

Tests: `node --test tests/js/*.test.js`, `python3 -m pytest tests -q`, `python3 -I tools/ui_smoke.py` (needs a running dashboard with sample data, Playwright and Chrome).
The final review was a self-review by the author, not an independent reviewer.

## Calls made

- **Setup.** Task 1 names tests/test_headers.py, Task 2 renames it to tests/test_api.py — create tests/test_api.py in Task 1 directly — avoids a rename commit — cost if wrong: none.
- **Setup.** readiness bars use the coach's own baselines (HRV 67-day band, RHR baseline ±3, sleep 6–9 h) instead of the spec's looser wording — bars then always agree with the coach's verdict — cost if wrong: band edges differ slightly from Garmin's own band.
- **Setup.** web.py needs no change — Flask/Werkzeug send_file already sends Cache-Control: no-cache when max_age is None; header tests kept as regression guard — cost if wrong: none (tests prove it)
- **Task 1.** gym.js #/gym link fixes moved to Task 4 — they only matter once the router changes and Task 4's smoke test covers them — cost if wrong: none
- **Task 2.** plan's test value loadBucket(50, -20) == 'Above' contradicts its own cuts (ratio 1.4 > 1.3 is 'Well above') — test uses loadBucket(50, -10) (ratio 1.2) instead — cost if wrong: none
- **Task 3.** plan expected leg-press next side 'R' after two right sets; the plan's own cues say 'Right first, alternate legs', which gym.js slotProgress already implements — test expects next 'L' (0 of 2) — cost if wrong: side order differs from what Alois does; he can still pick a side
- **Task 3.** prefill returns null (not empty strings) for missing values — steppers show a dash for null — cost if wrong: none
- **Task 4.** resolveRoute lives in its own file static/routes.js (loaded before app.js) instead of app.js — app.js renders on load and can't be unit-tested in a vm — cost if wrong: one more script tag
- **Task 5.** smoke headline checks also accept "Recovery day." — TL.headline (Task 2) puts a red readiness ahead of the gym letter, and the sample data's level can change daily — cost if wrong: a red day would hide a wrong gym headline from the test
- **Task 5.** the smoke tests set today's letter through /api/gym/settings + /api/gym/day on the dev data (start = today, explicit day) instead of relying on the sample start date — cost if wrong: dev sample data drifts; nothing shipped
- **Task 5.** new static/icons.js (stroke icons as window.UIC) shared by Today and Workout instead of growing app.js ICONS — cost if wrong: one more script tag
- **Task 5.** gym.js day notes extracted into notesFor(d) and exported on GYM, so Today shows the same "New this week"/taper/test-day notes as the gym page — cost if wrong: none, gym page output unchanged
- **Task 5.** Review Focus 5 smoke tests live in Task 5 (test_today_coach_stub: HRV without numbers shows text, run missing leaves one cardio row; test_today_without_coach: 503 keeps headline + gym card and says what failed); runner gained smoke(allow=...) for console errors a test provokes on purpose — cost if wrong: an allowed substring could mask an unrelated error with the same text
- **Task 5.** screenshot check found two Task 4 CSS defects — .u-bar/.u-range were inline spans (bars invisible outside grids) and the inset box-shadow row separator painted a square corner past the list's rounded edge; fixed with display:block and a ::before hairline — cost if wrong: none
- **Task 6.** WL.firstOpen (Task 3) now starts a fresh session at the top and, mid-session, picks the first unfinished exercise including uncounted primers (info cards skipped) — the old rule skipped the isometric primer, so Workout opened on bench and the primer was easy to miss; unit tests added — cost if wrong: none on days without a primer
- **Task 6.** one-leg exercises number sets per leg ("Log set 2, left leg"); others count straight through — with alternating legs a running number calls the left leg's first set "set 2" — cost if wrong: copy only
- **Task 6.** RIR chips start empty for every set instead of repeating the last value — a remembered RIR would get logged without a thought — cost if wrong: one tap per set for someone who always logs RIR
- **Task 6.** a "Swap exercise" button sits in the exercise view as well as swipe-left in the overview — the busy-machine case happens on the current exercise, and mouse/keyboard users get a way in — cost if wrong: one more control
- **Task 6.** when an exercise's sets are done the main button becomes "Next: <name>" with "Log an extra set" beside it; no automatic jump — cost if wrong: one tap
- **Task 6.** "Up next" is the next unfinished exercise after the current one, wrapping round, so an exercise skipped for a busy machine comes back at the end — cost if wrong: order differs from strict list order
- **Task 6.** overview reorder uses pointer drag on the handle plus arrow keys on the focused handle; swipe-left Swap is touch only — cost if wrong: desktop swaps go through the exercise view
- **Task 6.** Add exercise lists existing exercises only (no "New exercise…" editor in Workout mode); new ones are still made on the Strength page — cost if wrong: one trip to Progress → Strength
- **Task 6.** smoke tests reach exercise 2 via Up next (exercise 1 is the primer), the reorder test drags the last row (lat in session A) instead of naming a slot, and a reload() helper replaces go() to the same hash, which is a same-document navigation — cost if wrong: none
- **Task 6.** Resume bar (Task 4) shows the session title, then "Exercise k of n, m min so far" — title plus count was cut off on a phone; pages get extra bottom room while the bar shows — cost if wrong: none
- **Task 6.** the finish verdict's "not enough to judge" hint is reworded for the sheet ("Pick how hard it was below…") because gym.js's wording points at the old session card — cost if wrong: none
- **Task 6.** last-time text joins legs with "; " (was ". " followed by a lowercase "left"); unit test added. Screenshot fixes: dark-mode selected segment #636366 (was darker than its track), style.css details margin reset, solid Workout top bar — cost if wrong: none
- **Task 7.** tarball built with git archive from HEAD (tracked files only: same top-level set as the 18 Nov tarball plus docs/ and tests/ sources), so data/, config.ini, .superpowers and dist can't slip in — cost if wrong: docs/ and tests/ also land on the Pi, harmless
- **Task 7.** verified the update path by running the real update.sh (file:// URL, stub sudo/systemctl/pip) over an extracted copy of the 18 Nov tarball, then serving it on :8060 with a copy of the data and running 6 smoke tests — cost if wrong: none
- **Task 7.** removed the activity page's old "← Activities" link — the shell's back pill does the same job and the two sat on top of each other — cost if wrong: none
- **Final.** the 0–10 effort and knee scales keep ~27 px wide buttons (44 px tall) — eleven options in one row on a phone; two rows would hurt scanning — cost if wrong: an occasional mis-tap, visible in the label and fixed with another tap
- **Final.** the old pages inside the new shell (Activities, Progress segments, Recovery, Settings) were checked for rendering, not redesigned — that's phases 2–4 — cost if wrong: old styling there until then

## Left for later (minor)

- sheets don't move keyboard focus into the dialog (Escape and the close button work)
- the Describe-the-session job list reuses the old gym page styles
- on wide screens the header buttons sit at the window edge while content stops at 720 px
