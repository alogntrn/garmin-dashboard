# Training dashboard redesign: design

Date: 19 November 2026
Status: approved by Alois on 19 November 2026, with one change: no rest timer.
Visual reference: the Design canvas "Training Dashboard – new structure & design" (boards: Structure, Today, Workout mode, Session overview, Finish session, Activities, Activity detail, Progress, Recovery, iPad and Mac, Design system). Numbers on the boards are sample data.

## 1. Intent

The dashboard runs on Alois's Raspberry Pi (Flask + vanilla JS), is reached over Tailscale and is used mostly from an iPhone home-screen icon. It grew to eight tabs plus a settings page. Measured at 390 × 844 with the repo's sample data:

- the Gym page is 11.2 screens long, and the set logger starts about 2.5 screens down;
- the eight tabs scroll sideways, so Gym, Activities and Sync start off screen;
- Overview mixes today, this week, long-term trends and recent activities, with nine equally weighted tiles;
- run, ride and climb tables have up to 11 columns and scroll sideways.

The redesign should:

1. answer "what do I do today?" within seconds;
2. make logging a gym set a two-tap action during the 28-day block that started on 19 November 2026;
3. keep every analysis reachable;
4. look and feel like a current Apple app, in light and dark.

## 2. Goals, non-goals, anti-goals

Goals
- Four tabs: Today, Activities, Progress, Recovery. Gym logging becomes a full-screen Workout mode. Settings become a sheet.
- Every card on today's site keeps a home (Structure board, and section 5).
- A new design system (canvas board "Design system"), light and dark through `prefers-color-scheme`.
- iPhone first; the same app on iPad and Mac with a sidebar.

Non-goals
- No changes to the coach logic, the analytics maths, Garmin sync, FIT parsing or the local-AI pipeline.
- No native app, no new data sources.

Anti-goals (a failure even if it works)
- Losing or corrupting gym logs (`gym.sqlite`), or logging becoming unusable mid-block.
- A build step, npm toolchain, CDN or web-font dependency on the Pi.
- Pages loading slower on the Pi than today.
- Colour that carries no meaning, or status shown by colour alone.

## 3. Constraints

- Backend: Flask + waitress on a Raspberry Pi 4. JSON API in `web.py`: `/api/summary`, `/api/load`, `/api/weekly`, `/api/heatmap`, `/api/zones`, `/api/running`, `/api/cycling`, `/api/recovery`, `/api/activities`, `/api/activity/<id>`, `/api/coach`, `/api/status`, `/api/sync`, and the `/api/gym*` family.
- Front end: static files in `garmin_dash/static/` (`index.html`, `app.js`, `gym.js`, `gym-lib.js`, `style.css`) plus vendored Chart.js, the date-fns adapter, Leaflet and `body-paths.js`. No build step.
- Deployment: `update.sh` downloads `garmin-dashboard.tar.gz` from the repo's main branch (or a URL passed as its argument), copies it over the install (keeps `data/`, `config.ini`, the Garmin key and `.venv`), reinstalls requirements and restarts the service. Copying never deletes old files.
- Static files are sent without explicit cache headers: give asset URLs in `index.html` a version query string so the home-screen app picks up new code.
- The API stays backward compatible; new endpoints or fields are additive only.
- Gym data format and the `/api/gym*` endpoints stay as they are.
- There is no test suite in the repo today.

## 4. Approaches considered

1. Restyle the eight tabs. Cheapest, but keeps the 11-screen Gym page and the sideways tab strip. Rejected.
2. Four tabs, a full-screen Workout mode and a Settings sheet. Chosen by Alois.
3. One scrolling feed with drill-downs. Fewest taps, but the power curve, personal bests and climbs get buried. Rejected.

Build approach: incremental on the existing codebase, in phases that each ship on their own (section 7). Alois prefers iteration to big rewrites, and the gym logger can ship first while the block is running.

## 5. Structure

**Today**: What should I do today?
- Today's call (a headline sentence) and the readiness card: HRV, resting HR and sleep against the normal range, plus a load meter.
- Gym session card, opening Workout mode. No card on days without a planned session or after the block ends.
- Cardio options (run and ride from the coach), each opening a detail sheet with steps, targets, why, guardrails and evidence (today's Workouts page).
- This week: running against the weekly limit, cycling against the 4-week average, gym sessions done of planned, hard sessions allowed.
- Highlights (the existing insights) and the latest activity.

**Activities**: What did I do?
- One list of Garmin activities and gym sessions, grouped by week with totals; search; filter All, Runs, Rides, Gym; a month calendar view.
- Activity detail (today's detail page, restyled) and a gym session detail (sets, bests, muscles, effort check).

**Progress**: Am I getting fitter?
- Segments: Overview (training load, weekly time by sport, intensity, consistency heatmap), Run (today's Running page), Ride (today's Cycling page), Strength (gym analytics: strength progress, sets per muscle against the plan, body map, knee pain, tests, volume).
- One range menu for the whole tab: 3M, 6M, 1Y, 2Y, All.

**Recovery**: Am I recovered?
- HRV, resting HR, sleep (stages, score), Body Battery, stress, steps. Each card shows the normal range; tapping opens the full chart.
- Patterns in your data (the existing correlations).

**Workout mode** (full screen, from Today)
- One exercise at a time: prescription chips, logged sets, a last-time line, steppers (kg ±2.5, reps ±1, tap the number to type), RIR chips, an up-next card and the log button. No rest timer: Alois rests on his own feel, a countdown would only stress him.
- Session overview sheet, from the list button or the progress bar: every exercise with its status, sets logged of planned and the logged sets. Tap to jump, drag to reorder, swipe to swap. Add exercise. Describe session in words (local AI).
- Finish sheet: duration, sets, volume, bests, the effort check; effort 0–10; knee pain 0–10 with the existing rule text; note; save.
- A Resume bar above the tab bar while a session is open.

**Settings sheet** (gear on Today; sidebar item on iPad and Mac)
- Sync now, sync log, data coverage; athlete values, zones and training targets; gym block start; workouts and exercises library; tests and rules; local AI status; how suggestions are made, with references.
- Pull down on any tab to sync.

## 6. Behaviour decided

- Routes: `#/today`, `#/activities`, `#/activity/<id>`, `#/gym-session/<date>`, `#/progress/<overview|run|ride|strength>`, `#/recovery`, `#/workout`, and the overlay `#/settings`. Old routes redirect: `#/overview` to `#/today`, `#/plan` to `#/today` with the cardio detail open, `#/running` to `#/progress/run`, `#/cycling` to `#/progress/ride`, `#/recovery` stays, `#/gym` to `#/workout` when a session is open and otherwise `#/today`, `#/status` to `#/settings`.
- Today's call is generated from the coach (readiness level, `hard_allowed`, cardio intensity) and today's gym letter. First sentence: readiness red gives "Recovery day."; gym A or C gives "Leg day."; gym B gives "Upper-body day."; a planned rest day gives "Rest day."; otherwise none. Second sentence: hard allowed gives "Green light for a hard session.", otherwise "Keep cardio easy." The line below comes from the coach's guardrails or blockers. The builder may polish the wording within these rules.
- Readiness rows: HRV (7-day average against Garmin's baseline band), resting HR (against its 30-day baseline), sleep (last night against the 7-day average). Load meter from the ATL/CTL ratio: below 0.8 well below, 0.8–0.95 below, 0.95–1.15 steady, 1.15–1.3 above, above 1.3 well above.
- This week: the running limit is the coach's weekly ceiling (`max(1.3 × 4-week average, 4-week average + 5 km)`); cycling against its 4-week average; gym sessions from the plan for Monday to Sunday; hard sessions allowed from the coach context.
- Workout mode state: the server stays the source of truth, and every logged set is posted immediately, as today. The phone keeps only UI state (current exercise, exercise order) in `localStorage`, so a reload resumes where it was.
- Steppers pre-fill from the last logged set of that exercise and side, otherwise from the last session.
- Unilateral exercises: right side first, then left, as the plan says.
- Keep the screen awake in Workout mode where the browser supports it.
- Charts: keep Chart.js, restyled (thin lines, ink for fitness and fatigue, sport colours, no dual axes). On touch, press and drag to scrub.
- Tables become lists on phones; wide screens keep full tables.
- Colour: neutral ink for the interface. Run `#0A6CFF` light / `#2F7FF0` dark, Ride `#F07800` / `#E06A12`, Strength `#D63FA0` / `#E0499E`. Green, yellow and red only for status, always with a symbol. Zones take the activity's hue as a ramp.
- Type: system fonts only (SF Pro; SF Pro Rounded through `ui-rounded` for numbers and the headline).
- Glass (blur) only on chrome that floats over content: tab bar, toolbars, sheets.
- Home-screen app: apple-touch-icon PNGs, a web manifest, `theme-color` for both schemes, safe-area insets, standalone mode.

## 7. Build order (each phase ships as a new tarball)

1. Foundation and gym: tokens and base CSS; app shell (tab bar, sidebar, routing, redirects; Settings sheet linking to today's sync page); Workout mode with session overview and finish sheet; the Today tab; the Resume bar. Activities, Progress and Recovery render today's pages inside the new shell until replaced.
2. Activities: merged list, calendar, activity detail restyle, gym session detail.
3. Progress: Overview, Run, Ride, Strength.
4. Recovery, the full Settings sheet, home-screen icon and manifest, iPad and Mac polish.

## 8. Left to the builder

File and module structure, component code, Chart.js options, empty, loading and error states, animations, exact copy within the rules above, and additive API helpers (for example a combined `/api/today`) if they make Today faster. Old styles may be scoped under a wrapper class while old pages live inside the new shell. Reordering exercises in the session overview: the API has no order field today, so either add one additively to the day record or keep the order on the phone. Pull to sync needs its own touch handling, because a home-screen web app has no built-in pull to refresh.

## 9. Calls made without Alois (to check)

- Phased delivery with the gym logger and Today first; the other tabs show today's pages inside the new shell until their phase.
- The server stays the source of truth for gym logs; only UI position lives on the phone.
- Pre-fill rules (section 6).
- Headline rules and load thresholds (section 6).
- Old bookmarks redirect.
- Delivery as before: a new `garmin-dashboard.tar.gz` for the repo, then `./update.sh` on the Pi.
