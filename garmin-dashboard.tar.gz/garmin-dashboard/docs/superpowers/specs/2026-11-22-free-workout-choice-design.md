# Free workout choice and better session parsing (phase 1.1)

Status: approved by Alois on 22 November 2026 ("gentle hints are great"), after trying phase 1 in the gym.

## Intent
Alois doesn't want a calendar deciding which days are gym days. He goes to the gym and picks the workout there.
The Pi's AI also misread a described session ("stairstepper 10 min, ~900 steps") as Bike, invented an effort of 0
and listed every planned exercise as "no reps given".

## Decided
- No day gets a letter from the calendar any more. A day's workout is the session he chooses (stored as the day's
  session, as before). Days without a choice have none. Old days keep what they had.
- The 4-week block still runs by date: the week sets the number of sets and the effort (Calibrate → Peak & test),
  the last four days are the lighter taper, week 2 brings the 2-up/1-down note.
- Knee test: on the first A session from day 5 to day 14, and the first A session from day 25 to day 28.
- Today: until a workout is chosen, the gym card offers A, B, C (with names) and an empty session. Gentle hints:
  "Suggested" marks the one done longest ago, skipping A and C the day after a leg day; A and C carry
  "Leg day yesterday – B is easier on your knees." after a leg day. Any choice is allowed. Choosing opens Workout mode.
  Before the first set the card offers "Change workout".
- Headline: the gym line ("Leg day." etc.) only once a workout is chosen or done; otherwise just the cardio call.
- This week: the strip shows sessions chosen or done, no planned letters; the gym row counts sessions, no target.
- Workout mode: opened with nothing chosen it shows the same choice; the overview offers "Switch workout" until
  the first set is logged.
- Strength page (old page, phase 3 redesigns it): session picker A, B, C, Free (+ your workouts), no Rest; the
  28-day rack shows what was done; tiles drop the "planned" totals.
- Coach: "keep cardio easy" on a day whose chosen workout is A or C; the "tomorrow is A" rule goes (nothing is planned).
- AI parsing: list only exercises the text mentions; items without any numbers become one note instead of warnings;
  an effort or knee-pain number that isn't in the text is dropped with a note instead of saved; Stair stepper and
  Cross trainer join the exercise list; a cardio machine the text doesn't name is flagged; steps get a note
  ("only minutes are stored").

## Approaches
1. Free choice with gentle hints (picked). 2. Completely neutral choice (no hints). 3. Keep the calendar and add
"train anyway" (rejected: Alois doesn't want fixed days).

## Left to the builder
Exact copy, layout of the choice card, how the hint and suggestion are computed beyond the rules above.
