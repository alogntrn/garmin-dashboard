#!/usr/bin/env bash
# Updates the dashboard code from GitHub and restarts it.
# Keeps your data/ folder, config.ini, Garmin key and Python environment.
# Run from the project folder:  ./update.sh            (or pass another .tar.gz URL)
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
URL="${1:-https://github.com/alogntrn/garmin-dashboard/raw/main/garmin-dashboard.tar.gz}"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "==> Downloading $URL"
curl -fsSL "$URL" -o "$TMP/update.tar.gz"
tar xzf "$TMP/update.tar.gz" -C "$TMP"
SRC="$TMP/garmin-dashboard"
[ -d "$SRC/garmin_dash" ] || { echo "The download doesn't look like the dashboard – nothing changed."; exit 1; }

echo "==> Copying new code (data, config and key stay as they are)"
cp -a "$SRC/." "$DIR/"
chmod +x "$DIR/garmin-dash" "$DIR/install.sh" "$DIR/setup-tailscale.sh" "$DIR/update.sh" "$DIR/setup-ai.sh"

echo "==> Checking Python packages"
"$DIR/.venv/bin/pip" install -q -r "$DIR/requirements.txt"

echo "==> Restarting the dashboard"
sudo systemctl restart garmin-dashboard.service
sleep 2
systemctl is-active --quiet garmin-dashboard.service && echo "Done – reload the dashboard on your phone." \
  || { echo "The dashboard didn't start. Last log lines:"; journalctl -u garmin-dashboard -n 30 --no-pager; exit 1; }
