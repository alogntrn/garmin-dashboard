"""Minimal client for Garmin's official Connect Personal API (read-only).

Follows Garmin's own client (github.com/garmin/connect-personal-api-python):
the API key is exchanged for a 24 h bearer token, which is cached and reused.
"""
from __future__ import annotations

import base64
import json
import logging
import os
import time
from datetime import date
from pathlib import Path

import requests

from . import config

log = logging.getLogger("garmin.api")

TOKEN_PATH = "/personalapitoken-service/personal-api/personal-api-key/token"
REFRESH_WINDOW = 3600  # renew tokens that expire within the hour


class GarminError(RuntimeError):
    def __init__(self, msg: str, status: int | None = None):
        super().__init__(msg)
        self.status = status


def read_api_key() -> str:
    key = os.environ.get("GARMIN_PERSONAL_API_KEY", "").strip()
    if key:
        return key
    path = config.API_KEY_FILE
    if not path.exists():
        raise GarminError(
            f"No API key found. Run `./garmin-dash set-key` (expected file: {path})."
        )
    key = path.read_text(encoding="utf-8").strip()
    if not key:
        raise GarminError(f"API key file {path} is empty.")
    return key


def save_api_key(key: str) -> Path:
    path = config.API_KEY_FILE
    path.parent.mkdir(parents=True, exist_ok=True)
    os.chmod(path.parent, 0o700)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(key.strip() + "\n")
    return path


def _short(text: str) -> str:
    import re
    text = re.sub(r"<[^>]+>", " ", text or "")
    return " ".join(text.split())[:160]


def _jwt_exp(token: str) -> float:
    try:
        part = token.split(".")[1]
        payload = json.loads(base64.urlsafe_b64decode(part + "=" * (-len(part) % 4)))
        return float(payload["exp"])
    except Exception:
        return time.time() + 23 * 3600


class GarminClient:
    def __init__(self, api_key: str | None = None):
        self.base = config.BASE_URL
        self.key = api_key or read_api_key()
        self.session = requests.Session()
        self.session.headers["User-Agent"] = "garmin-dash/1.0 (personal dashboard)"
        self._token: str | None = None
        self._exp = 0.0
        self._last_call = 0.0
        self.calls = 0

    # ---- auth -------------------------------------------------------------
    def _load_cached_token(self) -> None:
        try:
            data = json.loads(config.TOKEN_CACHE.read_text())
            if data.get("base") == self.base and data.get("key_tail") == self.key[-6:]:
                self._token, self._exp = data["token"], float(data["exp"])
        except Exception:
            pass

    def token(self, force: bool = False) -> str:
        if not force and self._token is None:
            self._load_cached_token()
        if not force and self._token and self._exp - time.time() > REFRESH_WINDOW:
            return self._token
        r = self.session.post(
            self.base + TOKEN_PATH,
            headers={"Accept": "*/*", "Authorization": f"ApiKey {self.key}"},
            timeout=30,
        )
        if r.status_code in (401, 403):
            raise GarminError("Garmin rejected the API key (expired or deleted?). Create a new one and run `./garmin-dash set-key`.", r.status_code)
        if not r.ok:
            raise GarminError(f"Token request failed: HTTP {r.status_code} {_short(r.text)}", r.status_code)
        text = r.text.strip()
        if text.startswith("{"):
            body = json.loads(text)
            text = body.get("access_token") or body.get("accessToken") or ""
        self._token, self._exp = text, _jwt_exp(text)
        config.ensure_dirs()
        fd = os.open(config.TOKEN_CACHE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump({"base": self.base, "key_tail": self.key[-6:], "token": self._token, "exp": self._exp}, f)
        log.info("Obtained new access token")
        return self._token

    # ---- transport ---------------------------------------------------------
    def _request(self, path: str, params: dict | None = None, accept: str = "application/json") -> requests.Response:
        delays = [5, 20, 60, 180]
        refreshed = False
        attempt = 0
        while True:
            wait = config.REQUEST_INTERVAL - (time.time() - self._last_call)
            if wait > 0:
                time.sleep(wait)
            self._last_call = time.time()
            self.calls += 1
            try:
                r = self.session.get(
                    self.base + path,
                    params=params,
                    headers={"Authorization": f"Bearer {self.token()}", "Accept": accept},
                    timeout=60,
                )
            except requests.RequestException as e:
                if attempt < len(delays):
                    log.warning("Network error on %s (%s), retrying in %ss", path, e, delays[attempt])
                    time.sleep(delays[attempt]); attempt += 1
                    continue
                raise GarminError(f"Network error on {path}: {e}")
            if r.status_code == 401 and not refreshed:
                self.token(force=True); refreshed = True
                continue
            if (r.status_code == 429 or r.status_code >= 502) and attempt < len(delays):
                retry_after = r.headers.get("Retry-After")
                d = int(retry_after) if retry_after and retry_after.isdigit() else delays[attempt]
                log.warning("HTTP %s on %s, waiting %ss", r.status_code, path, d)
                time.sleep(d); attempt += 1
                continue
            if not r.ok:
                raise GarminError(f"HTTP {r.status_code} on {path}: {_short(r.text)}", r.status_code)
            return r

    def get(self, path: str, params: dict | None = None):
        r = self._request(path, params)
        if not r.content:
            return None
        try:
            return r.json()
        except ValueError:
            return None

    # ---- endpoints (same paths as Garmin's official client) -----------------
    def profile_settings(self):
        return self.get("/userprofile-service/userprofile/settings")

    def heart_rate_zones(self):
        return self.get("/biometric-service/heartRateZones/v2")

    def search_activities(self, start: int = 0, limit: int = 50, start_date: date | None = None, end_date: date | None = None):
        p: dict = {"start": start, "limit": limit}
        if start_date:
            p["startDate"] = start_date.isoformat()
        if end_date:
            p["endDate"] = end_date.isoformat()
        return self.get("/activitylist-service/activities/search/activities", p)

    def download_activity(self, activity_id: int) -> bytes:
        r = self._request(
            f"/download-service/files/activity/{int(activity_id)}",
            accept="application/zip, application/x-zip-compressed, application/octet-stream",
        )
        return r.content

    def daily_summaries(self, start: date, end: date):  # max 180 days
        return self.get("/usersummary-service/v2/dailysummaries", {"startDate": start.isoformat(), "endDate": end.isoformat()})

    def sleep_summaries(self, start: date, end: date):  # max 28 days
        return self.get("/sleep-service/sleep/dailySleepSummariesByDate", {"startDate": start.isoformat(), "endDate": end.isoformat()})

    def daily_sleep(self, day: date):
        return self.get("/sleep-service/sleep/dailySleep", {"date": day.isoformat()})

    def hrv_summaries(self, start: date, end: date):  # max 180 days
        return self.get(f"/hrv-service/hrv/daily/{start.isoformat()}/{end.isoformat()}")

    def body_battery(self, start: date, end: date):  # max 28 days
        return self.get("/wellness-service/wellness/bodyBattery/reports/daily", {"startDate": start.isoformat(), "endDate": end.isoformat()})

    def weight(self, start: date, end: date):  # max 365 days
        return self.get(f"/weight-service/weight/range/{start.isoformat()}/{end.isoformat()}", {"includeAll": "true"})
