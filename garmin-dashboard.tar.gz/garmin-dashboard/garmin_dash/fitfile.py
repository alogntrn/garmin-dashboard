"""Decode an original activity file (FIT, usually inside a ZIP) into 1-second arrays."""
from __future__ import annotations

import io
import zipfile

import fitdecode
import numpy as np

SEMI = 180.0 / 2**31


def extract_fit(blob: bytes) -> bytes | None:
    """Garmin delivers a ZIP; return the first .fit inside (or the blob if it already is a FIT)."""
    if blob[:2] == b"PK":
        with zipfile.ZipFile(io.BytesIO(blob)) as z:
            for name in z.namelist():
                if name.lower().endswith(".fit"):
                    return z.read(name)
        return None
    if len(blob) > 12 and blob[8:12] == b".FIT":
        return blob
    return None  # GPX/TCX uploads etc. are not parsed


def _num(v):
    return float(v) if isinstance(v, (int, float)) else None


def parse(fit_bytes: bytes) -> dict:
    recs, laps, session = [], [], {}
    with fitdecode.FitReader(io.BytesIO(fit_bytes), check_crc=fitdecode.CrcCheck.DISABLED,
                             error_handling=fitdecode.ErrorHandling.IGNORE) as fr:
        for frame in fr:
            if not isinstance(frame, fitdecode.FitDataMessage):
                continue
            vals = {f.name: f.value for f in frame.fields if f.value is not None}
            if frame.name == "record" and "timestamp" in vals:
                recs.append(vals)
            elif frame.name == "lap":
                laps.append(vals)
            elif frame.name == "session" and not session:
                session = vals

    if not recs:
        return {"t": np.array([]), "laps": [], "session": session}

    t0 = recs[0]["timestamp"]
    secs = np.array([(r["timestamp"] - t0).total_seconds() for r in recs])
    n = int(secs[-1]) + 1 if len(secs) else 0
    n = min(n, 24 * 3600)

    def col(*names, scale=1.0, transform=None):
        raw = np.full(len(recs), np.nan)
        for i, r in enumerate(recs):
            for nm in names:
                v = _num(r.get(nm))
                if v is not None:
                    raw[i] = v * scale
                    break
        if transform:
            raw = transform(raw)
        return raw

    raw = {
        "hr": col("heart_rate"),
        "power": col("power"),
        "speed": col("enhanced_speed", "speed"),
        "cadence": col("cadence"),
        "alt": col("enhanced_altitude", "altitude"),
        "dist": col("distance"),
        "lat": col("position_lat", scale=SEMI),
        "lon": col("position_long", scale=SEMI),
        "temp": col("temperature"),
    }
    # running cadence in FIT is strides/min (one foot): double it to steps/min
    sport = str(session.get("sport", "")).lower()
    if "run" in sport or "walk" in sport:
        frac = col("fractional_cadence")
        raw["cadence"] = (raw["cadence"] + np.nan_to_num(frac)) * 2

    # Put samples on a 1 s grid; carry values forward over gaps up to 5 s.
    grid = {}
    idx = np.clip(secs.astype(int), 0, n - 1)
    gap_ok = np.zeros(n, dtype=bool)
    for k, arr in raw.items():
        g = np.full(n, np.nan)
        g[idx] = arr
        # forward fill with limit
        last_v, last_i = np.nan, -10**9
        for i in range(n):
            if not np.isnan(g[i]):
                last_v, last_i = g[i], i
            elif i - last_i <= 5 and k not in ("lat", "lon"):
                g[i] = last_v
        grid[k] = g
    gap_ok[idx] = True
    # mark "recording" seconds: within 5 s of a real sample (pauses become gaps)
    rec = np.zeros(n, dtype=bool)
    last = -10**9
    for i in range(n):
        if gap_ok[i]:
            last = i
        rec[i] = i - last <= 5
    grid["recording"] = rec
    grid["t"] = np.arange(n, dtype=float)

    lap_out = []
    for lp in laps:
        lap_out.append({
            "elapsed_s": _num(lp.get("total_elapsed_time")),
            "timer_s": _num(lp.get("total_timer_time")),
            "dist_m": _num(lp.get("total_distance")),
            "avg_hr": _num(lp.get("avg_heart_rate")),
            "max_hr": _num(lp.get("max_heart_rate")),
            "avg_power": _num(lp.get("avg_power")),
            "norm_power": _num(lp.get("normalized_power")),
            "avg_speed": _num(lp.get("enhanced_avg_speed") or lp.get("avg_speed")),
            "ascent": _num(lp.get("total_ascent")),
            "avg_cadence": _num(lp.get("avg_cadence")),
        })
    grid["laps"] = lap_out
    grid["session"] = {k: (v if isinstance(v, (int, float, str)) else str(v)) for k, v in session.items()
                       if k in ("sport", "sub_sport", "total_ascent", "total_descent", "threshold_power",
                                "avg_temperature", "total_training_effect", "training_load_peak")}
    return grid
