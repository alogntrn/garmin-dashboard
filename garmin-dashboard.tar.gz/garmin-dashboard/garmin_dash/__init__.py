"""Personal Garmin dashboard (runs on a Raspberry Pi)."""
__version__ = "1.0.0"
