"""Describe a workout in plain words; a small model on the Pi turns it into logged sets.

Everything runs locally through Ollama (http://127.0.0.1:11434 by default), one job at a time,
in a background thread of the dashboard. The model itself runs in Ollama's own (niced, capped) process.

1. quick pass   - the model answers in a fixed JSON shape (constrained decoding), thinking off
2. check        - every number must come from your text, exercises must exist, set lists must line up ...
3. careful pass - only if the check found something: thinking on, told exactly what was wrong
4. clean        - sets are logged, tagged "ai:<job>" so one tap undoes them
   still unsure - nothing is logged; the page shows what it understood and asks you to confirm
"""
from __future__ import annotations

import json
import re
import threading
import time
import urllib.error
import urllib.request

from . import config, gym

CATS = ["Chest", "Back", "Shoulders", "Arms", "Legs", "Glutes & hips", "Core", "Cardio", "Mobility", "Other"]
MUSCLES = sorted(gym.MUSCLES)
KIND_TXT = {"kg": "kg", "reps": "reps", "secs": "s", "hold": "kg+s", "min": "min"}
_FAIL = re.compile(r"\b(fail\w*|versagen|muskelversagen|échec|echec|to failure|bis zum schluss)\b", re.I)


class AIError(Exception):
    pass


# ------------------------------------------------------------------ jobs (stored in gym.sqlite)
def _now():
    return gym._now()


def _job(r, full=False) -> dict:
    d = dict(r)
    d["result"] = gym._loads(d.get("result"), None)
    d["applied"] = gym._loads(d.get("applied"), None)
    ctx = d.pop("ctx", None)
    if full:
        d["ctx"] = gym._loads(ctx, {})
    return d


def _clean_ctx(ctx) -> dict:
    ctx = ctx if isinstance(ctx, dict) else {}
    cat = []
    for e in (ctx.get("catalog") or [])[:400]:
        if not isinstance(e, dict):
            continue
        try:
            eid = gym._id(e.get("id"))
        except ValueError:
            continue
        kind = gym._text(e.get("kind"), 8)
        if kind not in gym.KINDS:
            continue
        cat.append({"id": eid, "n": gym._text(e.get("n"), 80) or eid, "kind": kind, "uni": bool(e.get("uni")),
                    "cat": gym._text(e.get("cat"), 30)})
    slots = []
    for sl in (ctx.get("slots") or [])[:40]:
        if not isinstance(sl, dict):
            continue
        try:
            slots.append({"slot": gym._id(sl.get("slot"), "slot"), "base": gym._id(sl.get("base")),
                          "alts": [gym._id(a) for a in (sl.get("alts") or [])[:12]], "plan": bool(sl.get("plan")),
                          "n": gym._text(sl.get("n"), 80)})
        except ValueError:
            continue
    return {"catalog": cat, "slots": slots, "session": gym._session(ctx.get("session")) if ctx.get("session") else None,
            "sname": gym._text(ctx.get("sname"), 60)}


def create_job(d: dict) -> dict:
    day = gym._date(d.get("date"))
    text = gym._text(d.get("text"), 2000)
    if len(text) < 3:
        raise ValueError("describe what you did first")
    ctx = _clean_ctx(d.get("ctx"))
    if not ctx["catalog"]:
        raise ValueError("exercise list missing – reload the page")
    with gym.connect() as con:
        jid = con.execute("INSERT INTO ai_jobs(date, text, ctx, status, model, created_at) VALUES(?,?,?,?,?,?)",
                          (day, text, json.dumps(ctx), "queued", config.AI_MODEL, _now())).lastrowid
        row = con.execute("SELECT * FROM ai_jobs WHERE id=?", (jid,)).fetchone()
    start_worker()
    _wake.set()
    return _job(row)


def list_jobs(day: str | None = None, limit: int = 40) -> list:
    with gym.connect() as con:
        if day:
            rows = con.execute("SELECT * FROM ai_jobs WHERE date=? ORDER BY id DESC LIMIT ?", (gym._date(day), limit))
        else:
            rows = con.execute("SELECT * FROM ai_jobs ORDER BY id DESC LIMIT ?", (limit,))
        return [_job(r) for r in rows]


def _get(jid: int, full=False) -> dict:
    with gym.connect() as con:
        r = con.execute("SELECT * FROM ai_jobs WHERE id=?", (int(jid),)).fetchone()
    if not r:
        raise ValueError("job not found")
    return _job(r, full)


def _update(jid: int, **f):
    for k in ("result", "applied"):
        if k in f and not isinstance(f[k], (str, type(None))):
            f[k] = json.dumps(f[k])
    with gym.connect() as con:
        con.execute(f"UPDATE ai_jobs SET {', '.join(k + '=?' for k in f)} WHERE id=?", [*f.values(), int(jid)])


def retry_job(jid: int) -> dict:
    j = _get(jid)
    if j["status"] not in ("error", "review", "discarded", "undone"):
        raise ValueError("this job can't be retried")
    _update(jid, status="queued", stage=None, message=None, result=None, applied=None, started_at=None,
            finished_at=None, model=config.AI_MODEL)
    start_worker()
    _wake.set()
    return _get(jid)


def discard_job(jid: int) -> dict:
    j = _get(jid)
    if j["status"] not in ("queued", "review", "error"):
        raise ValueError("only waiting, failed or unconfirmed jobs can be dismissed")
    _update(jid, status="discarded", finished_at=j["finished_at"] or _now())
    return _get(jid)


def confirm_job(jid: int) -> dict:
    """Log the sets of a job that was held back for review."""
    j = _get(jid, full=True)
    if j["status"] != "review" or not j["result"]:
        raise ValueError("nothing to confirm")
    applied = _apply(j["id"], j["date"], j["ctx"], j["result"])
    _update(jid, status="done", applied=applied, message="Logged after you confirmed it.")
    return _get(jid)


def undo_job(jid: int) -> dict:
    j = _get(jid)
    if j["status"] != "done" or not j["applied"]:
        raise ValueError("nothing to undo")
    a = j["applied"]
    with gym.connect() as con:
        con.execute("DELETE FROM sets WHERE src=?", (f"ai:{j['id']}",))
    names = {e["id"]: e["n"] for e in (_get(jid, full=True)["ctx"].get("catalog") or [])}
    for sw in reversed(a.get("swaps") or []):
        back = sw.get("prev") or sw.get("before") or sw["ex"]
        gym.swap({"date": j["date"], "slot": sw["slot"], "ex": back, "name": names.get(back, back), "clear": not sw.get("prev")})
    with gym.connect() as con:
        for ex in a.get("created") or []:
            if not con.execute("SELECT 1 FROM sets WHERE ex=? LIMIT 1", (ex,)).fetchone():
                con.execute("UPDATE exercises SET archived=1, updated_at=? WHERE id=?", (_now(), ex))
        day = gym._get_day(con, j["date"])
        changed = False
        for k, v in (a.get("day") or {}).items():
            if day.get(k) == v:
                day[k] = None
                changed = True
        if changed:
            gym._put_day(con, day)
    _update(jid, status="undone", message="Undone – the sets it logged were removed.")
    return _get(jid)


# ------------------------------------------------------------------ Ollama
def _http(path: str, body: dict | None = None, timeout: float = 5):
    model = (body or {}).get("model") or config.AI_MODEL
    req = urllib.request.Request(config.AI_URL + path, data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Content-Type": "application/json"}, method="POST" if body is not None else "GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        msg = e.read().decode(errors="replace")[:300]
        if e.code == 404 and "not found" in msg.lower():
            raise AIError(f"The model {model} isn't downloaded yet. On the Pi run: ./setup-ai.sh (or ollama pull {model})")
        raise AIError(f"Ollama answered {e.code}: {msg}")
    except (urllib.error.URLError, ConnectionError, OSError) as e:
        if isinstance(e, TimeoutError) or "timed out" in str(e):
            raise AIError("The model took too long and was stopped. Try a shorter description, or raise "
                          "timeout_minutes in config.ini [ai].")
        raise AIError(f"The local AI (Ollama) isn't reachable at {config.AI_URL}. On the Pi run: ./setup-ai.sh")


def status() -> dict:
    out = {"enabled": config.AI_ENABLED, "model": config.AI_MODEL, "careful_model": config.AI_CAREFUL_MODEL,
           "url": config.AI_URL, "reachable": False, "model_ready": False, "careful_ready": False, "version": None, "busy": None}
    if not config.AI_ENABLED:
        return out
    try:
        out["version"] = _http("/api/version", timeout=3).get("version")
        tags = _http("/api/tags", timeout=3)
        out["reachable"] = True
        names = {m.get("name") for m in tags.get("models", [])} | {m.get("model") for m in tags.get("models", [])}
        have = lambda m: m in names or (":" not in m and m + ":latest" in names)
        out["model_ready"] = have(config.AI_MODEL)
        out["careful_ready"] = have(config.AI_CAREFUL_MODEL)
    except AIError as e:
        out["error"] = str(e)
    with gym.connect() as con:
        r = con.execute("SELECT id, date, stage, started_at FROM ai_jobs WHERE status='running' LIMIT 1").fetchone()
        out["busy"] = dict(r) if r else None
        out["queued"] = con.execute("SELECT count(*) FROM ai_jobs WHERE status='queued'").fetchone()[0]
    return out


def _chat(system: str, user: str, schema: dict, think: bool, num_predict: int, model: str | None = None) -> tuple[dict, dict]:
    body = {
        "model": model or config.AI_MODEL, "stream": False, "format": schema, "think": think, "keep_alive": config.AI_KEEP_ALIVE,
        "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
        "options": {"temperature": 0.6 if think else 0.2, "top_p": 0.95 if think else 0.9, "top_k": 20,
                    "num_ctx": config.AI_CTX, "num_thread": config.AI_THREADS, "num_predict": num_predict},
    }
    t0 = time.time()
    try:
        r = _http("/api/chat", body, timeout=config.AI_TIMEOUT_MIN * 60)
    except AIError as e:
        # very old Ollama versions reject "think" for some models; retry without it once
        if think and "think" in str(e).lower():
            body.pop("think")
            r = _http("/api/chat", body, timeout=config.AI_TIMEOUT_MIN * 60)
        else:
            raise
    msg = r.get("message") or {}
    timing = {"s": round(time.time() - t0), "prompt_tokens": r.get("prompt_eval_count"), "tokens": r.get("eval_count"),
              "think": think, "thinking_chars": len(msg.get("thinking") or ""), "model": body["model"]}
    return _parse_json(msg.get("content") or ""), timing


def _parse_json(text: str) -> dict:
    text = text.split("</think>")[-1].strip()
    try:
        out = json.loads(text)
        if isinstance(out, dict):
            return out
    except ValueError:
        pass
    a, b = text.find("{"), text.rfind("}")
    if a >= 0 and b > a:
        try:
            out = json.loads(text[a:b + 1])
            if isinstance(out, dict):
                return out
        except ValueError:
            pass
    raise AIError("The model's answer wasn't readable JSON.")


# ------------------------------------------------------------------ prompt
def _schema(ids: list) -> dict:
    num_list = {"type": "array", "items": {"type": "number"}}
    item = {"type": "object", "properties": {
        "ex": {"type": "string", "enum": ids + ["new"]},
        "side": {"type": "string", "enum": ["B", "R", "L"]},
        "reps": {"type": "array", "items": {"type": "integer"}},
        "kg": num_list, "secs": num_list, "mins": {"type": "number"},
        "rir": {"type": "number"}, "rir_last": {"type": "number"},
        "new_name": {"type": "string"}, "new_kind": {"type": "string", "enum": sorted(gym.KINDS)},
        "new_cat": {"type": "string", "enum": CATS}, "new_uni": {"type": "boolean"},
        "new_main": {"type": "array", "items": {"type": "string", "enum": MUSCLES}},
        "new_help": {"type": "array", "items": {"type": "string", "enum": MUSCLES}},
    }, "required": ["ex", "side"]}
    return {"type": "object", "properties": {
        "items": {"type": "array", "items": item},
        "rpe": {"type": "number"}, "pain": {"type": "integer"},
        "unsure": {"type": "array", "items": {"type": "string"}},
    }, "required": ["items", "unsure"]}


EXAMPLE_IN = ("bench 3x8 60kg last one to failure, leg press right leg 3x12 80 left 2x12 90, "
              "10 min abs, plank 2x45s, felt like 7/10, knee 2")
EXAMPLE_OUT = ('{"items":[{"ex":"bench","side":"B","reps":[8,8,8],"kg":[60],"rir_last":0},'
               '{"ex":"lp","side":"R","reps":[12,12,12],"kg":[80]},{"ex":"lp","side":"L","reps":[12,12],"kg":[90]},'
               '{"ex":"abcircuit","side":"B","mins":10},{"ex":"plank","side":"B","secs":[45,45]}],'
               '"rpe":7,"pain":2,"unsure":[]}')


def _prompt(ctx: dict) -> str:
    lines = []
    for e in ctx["catalog"]:
        lines.append(f"{e['id']}: {e['n']} [{KIND_TXT.get(e['kind'], e['kind'])}{', 1 side' if e['uni'] else ''}]")
    plan = ""
    if ctx.get("slots"):
        bits = [sl["base"] + (f" (or {', '.join(sl['alts'])})" if sl["alts"] else "") for sl in ctx["slots"]]
        plan = f"\nPlanned today{' (' + ctx['sname'] + ')' if ctx.get('sname') else ''}: " + "; ".join(bits) + "\n"
    return f"""You turn a gym workout description into structured sets for a training log.
The text may be English, German or French, typed quickly on a phone.

Exercises as id: name [type]. Types: kg = weight x reps, reps = bodyweight reps, s = hold in seconds,
kg+s = weight + hold, min = minutes. "1 side" = each leg or arm is logged separately as R or L.
{chr(10).join(lines)}
{plan}
Rules:
- One item per exercise and side. Same exercise on both sides with different numbers = two items (R and L).
- reps, kg and secs are lists, one value per set: "3x10 at 60" -> reps [10,10,10], kg [60]. One kg value = every set.
- "60kg 10,10,8" -> reps [10,10,8], kg [60]. Leave kg out for bodyweight. Dumbbells: weight of one dumbbell.
- side "B" = both together or a normal exercise. "R"/"L" only for one-side exercises.
- "single leg", "right", "left", "einbeinig" -> the one-side version; "both legs", "beidbeinig" -> the both-legs version.
- Timed holds -> secs per set. Work measured in minutes ("10 min abs", "15 min bike") -> mins, one item.
- rir = reps left before failure for every set, only if said; rir_last = only the last set ("last set to failure" -> rir_last 0).
- Nothing in the list fits -> ex "new" with new_name, new_kind, new_cat, new_uni, new_main (main muscles), new_help (helpers).
- rpe = how hard the whole session felt, 0-10, only if said. pain = knee pain 0-10, only if said.
- Use only numbers from the text. Never guess a weight. Anything you can't place goes in "unsure"; otherwise "unsure": [].

Example
Text: {EXAMPLE_IN}
Answer: {EXAMPLE_OUT}"""


# ------------------------------------------------------------------ checking the answer
def _numbers(text: str) -> set:
    nums = set()
    for t in (text, re.sub(r"(\d),(\d)", r"\1.\2", text)):        # "62,5" may be 62.5 or "62 and 5"
        for m in re.finditer(r"\d+(?:\.\d+)?", t):
            nums.add(round(float(m.group()), 3))
        for m in re.finditer(r"(\d+(?:\.\d+)?)\s*(?:min|mins|minute|minutes|minuten|')", t, re.I):
            nums.add(round(float(m.group(1)) * 60, 3))
        for m in re.finditer(r"(\d+(?:\.\d+)?)\s*(?:s|sec|secs|sek|seconds|sekunden|\")\b", t, re.I):
            nums.add(round(float(m.group(1)) / 60, 3))
        for m in re.finditer(r"(\d{1,2})\s*[x×*]\s*(\d+(?:\.\d+)?)", t):   # "2x10 min" -> 20 min in total
            total = int(m.group(1)) * float(m.group(2))
            nums.update({round(total, 3), round(total * 60, 3), round(total / 60, 3)})
    if _FAIL.search(text):
        nums.add(0.0)
    return nums


def _check(res: dict, text: str, ctx: dict):
    """-> (items ready to log, problems that need another look, harmless notes)"""
    cat = {e["id"]: e for e in ctx["catalog"]}
    nums = _numbers(text)
    issues, notes, out = [], [], []
    items = res.get("items") if isinstance(res.get("items"), list) else []
    if not items:
        issues.append("No exercises were found in the text.")
    used_kg, used_reps, used_secs, used_mins = set(), set(), set(), set()

    def grounded(v, what, label):
        if v is None:
            return
        if round(float(v), 3) not in nums and not (what == "kg" and float(v) == 0):
            issues.append(f"{label}: {v:g} {what} isn't in your text.")

    for i, it in enumerate(items):
        if not isinstance(it, dict):
            issues.append(f"Item {i + 1} is malformed.")
            continue
        ex = str(it.get("ex") or "")
        side = str(it.get("side") or "B").upper()
        new = None
        if ex == "new":
            name = gym._text(it.get("new_name"), 60)
            if not name:
                issues.append(f"Item {i + 1}: a new exercise without a name.")
                continue
            kind = it.get("new_kind") if it.get("new_kind") in gym.KINDS else (
                "kg" if it.get("kg") else "secs" if it.get("secs") else "min" if it.get("mins") else "reps")
            new = {"name": name, "kind": kind, "cat": it.get("new_cat") if it.get("new_cat") in CATS else "Other",
                   "uni": bool(it.get("new_uni")),
                   "main": [m for m in it.get("new_main") or [] if m in gym.MUSCLES],
                   "help": [m for m in it.get("new_help") or [] if m in gym.MUSCLES]}
            dfn = {"n": name, "kind": kind, "uni": new["uni"]}
            if not new["main"]:
                notes.append(f"New exercise “{name}”: no muscles given – set them under Your exercises.")
        elif ex in cat:
            dfn = cat[ex]
        else:
            issues.append(f"Item {i + 1}: unknown exercise id “{ex}”.")
            continue
        label = dfn["n"] + (f" ({side})" if side in ("R", "L") else "")
        if side not in ("B", "R", "L"):
            side = "B"
        if side in ("R", "L") and not dfn["uni"]:
            issues.append(f"{dfn['n']} is done with both sides together, but side {side} was given.")

        def lst(k, integer=False):
            v = it.get(k)
            if v is None:
                return []
            v = v if isinstance(v, list) else [v]
            try:
                return [int(round(float(x))) if integer else float(x) for x in v if x is not None]
            except (TypeError, ValueError):
                issues.append(f"{label}: {k} has something that isn't a number.")
                return []

        reps, kg, secs = lst("reps", True), lst("kg"), lst("secs")
        mins = it.get("mins")
        try:
            mins = float(mins) if mins not in (None, "") else None
        except (TypeError, ValueError):
            mins = None
        kind = dfn["kind"]
        if kind in ("secs", "hold") and not secs and mins:
            secs, mins = [mins * 60], None
        if kind == "min" and mins is None and secs:
            mins, secs = sum(secs) / 60, []
        if kind == "min":
            if not mins or not 0.5 <= mins <= 240:
                issues.append(f"{label}: needs minutes (0.5–240).")
                continue
            grounded(mins, "min", label)
            out.append({"ex": ex, "new": new, "name": dfn["n"], "side": side if dfn["uni"] and side in ("R", "L") else "",
                        "sets": [{"mins": round(mins, 1)}]})
            used_mins.add(round(mins, 3))
            continue
        main = secs if kind in ("secs", "hold") else reps
        if not main:
            issues.append(f"{label}: no {'seconds' if kind in ('secs', 'hold') else 'reps'} given.")
            continue
        n = max(len(main), len(kg), 1)
        bad = [k for k, v in (("reps", reps), ("kg", kg), ("secs", secs)) if v and len(v) not in (1, n)]
        if bad:
            issues.append(f"{label}: {' and '.join(bad)} list doesn't match the number of sets ({n}).")
            continue
        if n > 15:
            issues.append(f"{label}: {n} sets looks wrong.")
            continue
        at = lambda v, j: v[j] if len(v) > 1 else (v[0] if v else None)
        rir, rir_last = it.get("rir"), it.get("rir_last")
        sets = []
        for j in range(n):
            s = {"reps": at(reps, j) if kind in ("kg", "reps") else None, "kg": at(kg, j),
                 "secs": int(round(at(secs, j))) if kind in ("secs", "hold") and secs else None}
            r = rir_last if (j == n - 1 and rir_last is not None) else rir
            s["rir"] = float(r) if isinstance(r, (int, float)) and 0 <= r <= 10 else None
            if s["reps"] is not None and not 1 <= s["reps"] <= 100:
                issues.append(f"{label}: {s['reps']} reps looks wrong.")
            if s["kg"] is not None and not 0 <= s["kg"] <= 400:
                issues.append(f"{label}: {s['kg']:g} kg looks wrong.")
            if s["secs"] is not None and not 1 <= s["secs"] <= 3600:
                issues.append(f"{label}: {s['secs']} s looks wrong.")
            sets.append(s)
        for v in set(reps):
            grounded(v, "reps", label)
        for v in set(kg):
            grounded(v, "kg", label)
        for v in set(secs):
            grounded(v, "s", label)
        for r in (rir, rir_last):
            if isinstance(r, (int, float)):
                grounded(r, "RIR", label)
        used_kg |= {round(v, 3) for v in kg}
        used_reps |= set(reps)
        used_secs |= {int(round(v)) for v in secs}
        if kind == "kg" and not kg:
            notes.append(f"{label}: no weight in your text – logged reps only.")
        out.append({"ex": ex, "new": new, "name": dfn["n"], "side": side if dfn["uni"] and side in ("R", "L") else "",
                    "sets": sets})
    # numbers you wrote that nothing used: "... 70kg" or "3x12" that didn't make it into any exercise
    t2 = re.sub(r"(\d),(\d)", r"\1.\2", text)
    for m in re.finditer(r"(\d+(?:\.\d+)?)\s*(?:kg|kilo)", t2, re.I):
        if round(float(m.group(1)), 3) not in used_kg:
            issues.append(f"“{m.group(0)}” from your text wasn't used.")
    for m in re.finditer(r"\b(\d{1,2})\s*[x×*]\s*(\d{1,3}(?:\.\d+)?)(?!\d)\s*(min\w*|'|s\b|sec\w*|sek\w*|\")?", t2, re.I):
        n_, m_, unit = int(m.group(1)), float(m.group(2)), (m.group(3) or "").lower()
        if unit.startswith("min") or unit == "'":
            ok = round(m_ * 60) in used_secs or round(m_, 3) in used_mins or round(m_ * n_, 3) in used_mins
        elif unit:
            ok = round(m_) in used_secs
        else:
            ok = m_ in used_reps or n_ in used_reps or round(m_) in used_secs
        if not ok:
            issues.append(f"“{m.group(0).strip()}” from your text wasn't used.")
    for k, lo, hi in (("rpe", 0, 10), ("pain", 0, 10)):
        v = res.get(k)
        if v is not None:
            if not isinstance(v, (int, float)) or not lo <= v <= hi:
                issues.append(f"{k} {v} is out of range.")
            elif round(float(v), 3) not in nums:
                issues.append(f"{'Session rating' if k == 'rpe' else 'Knee pain'} {v:g} isn't in your text.")
    for u in res.get("unsure") or []:
        if isinstance(u, str) and u.strip():
            issues.append("Model unsure: " + u.strip()[:160])
    return out, list(dict.fromkeys(issues)), list(dict.fromkeys(notes))


# ------------------------------------------------------------------ logging the result
def _effective(day_row: dict, swaps_global: dict, sl: dict) -> str:
    return (day_row.get("swaps") or {}).get(sl["slot"]) or (swaps_global.get(sl["slot"]) if sl.get("plan") else None) or sl["base"]


def _new_exercise(new: dict) -> tuple[str, bool]:
    with gym.connect() as con:
        r = con.execute("SELECT id, archived FROM exercises WHERE lower(name)=lower(?)", (new["name"],)).fetchone()
    if r and not r["archived"]:
        return r["id"], False
    mus = {m: 1 for m in new["main"]}
    for m in new["help"]:
        mus.setdefault(m, 0.5)
    saved = gym.save_exercise({"id": r["id"] if r else None, "name": new["name"], "kind": new["kind"], "cat": new["cat"],
                               "uni": new["uni"], "mus": mus, "note": "Created by the local AI from your description."})
    return saved["id"], True


def _slot_used(day: str, slot: str) -> bool:
    with gym.connect() as con:
        return con.execute("SELECT 1 FROM sets WHERE date=? AND (slot=? OR (slot IS NULL AND ex=?)) LIMIT 1",
                           (day, slot, slot)).fetchone() is not None


def _apply(jid: int, day: str, ctx: dict, result: dict) -> dict:
    applied = {"sets": [], "created": [], "swaps": [], "day": {}}
    with gym.connect() as con:
        day_row = gym._get_day(con, day)
        swaps_global = gym._get(con, "swaps", {})
    session = day_row.get("session") or ctx.get("session")
    claimed: dict = {}
    for it in result["items"]:
        ex = it["ex"]
        name = it["name"]
        if ex == "new":
            ex, created = _new_exercise(it["new"])
            if created:
                applied["created"].append(ex)
        slot = None
        for sl in ctx.get("slots") or []:                        # already what the plan shows today
            if claimed.get(sl["slot"], ex) == ex and _effective(day_row, swaps_global, sl) == ex:
                slot = sl["slot"]
                break
        if not slot:
            for sl in ctx.get("slots") or []:                    # a listed alternative: swap that slot for today,
                if claimed.get(sl["slot"], ex) == ex and (ex == sl["base"] or ex in sl["alts"]) \
                        and not _slot_used(day, sl["slot"]):    # unless you already logged sets there yourself
                    prev = (day_row.get("swaps") or {}).get(sl["slot"])
                    before = _effective(day_row, swaps_global, sl)
                    res = gym.swap({"date": day, "slot": sl["slot"], "ex": ex, "name": name, "session": session})
                    day_row = res["day"]
                    applied["swaps"].append({"slot": sl["slot"], "ex": ex, "prev": prev, "before": before})
                    slot = sl["slot"]
                    break
        slot = slot or ex
        claimed[slot] = ex
        for s in it["sets"]:
            row = gym.add_set({"date": day, "session": session, "ex": ex, "name": name, "slot": slot,
                               "side": it["side"], "src": f"ai:{jid}", **{k: v for k, v in s.items() if v is not None}})
            applied["sets"].append(row["id"])
    fields = {k: result.get(k) for k in ("rpe", "pain") if result.get(k) is not None}
    if fields:
        with gym.connect() as con:
            cur = gym._get_day(con, day)
        todo = {k: v for k, v in fields.items() if cur.get(k) is None}
        if todo:
            gym.save_day({"date": day, **({"session": session} if session and not cur.get("session") else {}), **todo})
            applied["day"] = {k: (int(v) if k == "pain" else float(v)) for k, v in todo.items()}
    return applied


# ------------------------------------------------------------------ worker
_wake = threading.Event()
_lock = threading.Lock()
_started = False


def start_worker():
    global _started
    with _lock:
        if _started or not config.AI_ENABLED:
            return
        _started = True
    with gym.connect() as con:
        con.execute("UPDATE ai_jobs SET status='queued', stage=NULL, started_at=NULL WHERE status='running'")
    threading.Thread(target=_loop, name="ai-worker", daemon=True).start()


def _next():
    with gym.connect() as con:
        r = con.execute("SELECT * FROM ai_jobs WHERE status='queued' ORDER BY id LIMIT 1").fetchone()
    return _job(r, full=True) if r else None


def _loop():
    while True:
        job = _next()
        if not job:
            _wake.wait(300)
            _wake.clear()
            continue
        try:
            _run(job)
        except AIError as e:
            _update(job["id"], status="error", stage=None, message=str(e), finished_at=_now())
        except Exception as e:  # never let the worker die
            _update(job["id"], status="error", stage=None, message=f"{type(e).__name__}: {e}", finished_at=_now())


def _summary(items, res, issues, notes, timings):
    return {"items": [{"ex": it["ex"], "name": it["name"], "side": it["side"], "new": it["new"], "sets": it["sets"]}
                      for it in items],
            "rpe": res.get("rpe"), "pain": res.get("pain"), "issues": issues, "notes": notes, "passes": timings}


def _run(job: dict):
    jid, ctx, text = job["id"], job["ctx"], job["text"]
    _update(jid, status="running", stage="quick pass", started_at=_now(),
            model=config.AI_MODEL + (f" + {config.AI_CAREFUL_MODEL}" if config.AI_CAREFUL and config.AI_CAREFUL_MODEL != config.AI_MODEL else ""))
    system = _prompt(ctx)
    schema = _schema([e["id"] for e in ctx["catalog"]])
    timings = []
    res, tm = _chat(system, f"Text: {text}", schema, think=False, num_predict=900)
    timings.append(tm)
    items, issues, notes = _check(res, text, ctx)
    if issues and config.AI_CAREFUL:
        _update(jid, stage="careful pass")
        feedback = (f"Text: {text}\n\nA first answer was:\n{json.dumps(res, ensure_ascii=False)}\n\n"
                    "Problems found when checking it against the text:\n- " + "\n- ".join(issues) +
                    "\n\nGo through the text exercise by exercise and give the complete corrected answer.")
        try:
            try:
                res2, tm2 = _chat(system, feedback, schema, think=True, num_predict=2400, model=config.AI_CAREFUL_MODEL)
            except AIError as e:
                if "JSON" not in str(e) and "isn't downloaded" not in str(e):
                    raise
                res2, tm2 = _chat(system, feedback, schema, think=False, num_predict=900)
            timings.append(tm2)
            items2, issues2, notes2 = _check(res2, text, ctx)
            if len(issues2) <= len(issues):
                res, items, issues, notes = res2, items2, issues2, notes2
        except AIError as e:
            notes = notes + [f"The careful second pass failed ({e}) – showing the first answer."]
    summary = _summary(items, res, issues, notes, timings)
    if issues:
        _update(jid, status="review", stage=None, result={**summary, "raw": res}, finished_at=_now(),
                message="Not sure about everything – check what it understood, then log it or edit your text.")
        return
    _update(jid, stage="logging")
    applied = _apply(jid, job["date"], ctx, {**summary, "items": items})
    _update(jid, status="done", stage=None, result=summary, applied=applied, finished_at=_now(),
            message=f"Logged {len(applied['sets'])} sets.")
