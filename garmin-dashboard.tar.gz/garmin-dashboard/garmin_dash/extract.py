"""Defensive field extraction. Garmin's JSON shapes vary between endpoints and
over time, so every value is looked up by a list of candidate names/paths."""
from __future__ import annotations

import re

DATE_KEYS = ("calendarDate", "date", "summaryDate", "calendarDay")
_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}")


def getp(obj, path: str):
    cur = obj
    for part in path.split("."):
        if isinstance(cur, dict):
            if part in cur:
                cur = cur[part]
                continue
            low = {k.lower(): k for k in cur}
            if part.lower() in low:
                cur = cur[low[part.lower()]]
                continue
        return None
    return cur


def _is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def find_num(obj, candidates, deep: bool = True):
    """First numeric value for any candidate (dotted paths allowed); falls back to a
    recursive search for plain key names when deep=True."""
    if obj is None:
        return None
    for c in candidates:
        v = getp(obj, c)
        if _is_num(v):
            return float(v)
    if deep:
        names = {c.lower() for c in candidates if "." not in c}
        stack = [obj]
        while stack:
            cur = stack.pop(0)
            if isinstance(cur, dict):
                for k, v in cur.items():
                    if k.lower() in names and _is_num(v):
                        return float(v)
                    if isinstance(v, (dict, list)):
                        stack.append(v)
            elif isinstance(cur, list):
                stack.extend(x for x in cur if isinstance(x, (dict, list)))
    return None


def find_str(obj, candidates):
    for c in candidates:
        v = getp(obj, c)
        if isinstance(v, str) and v:
            return v
    return None


def sub(obj, *needles):
    """Return the first nested dict whose key contains one of the needles."""
    if not isinstance(obj, dict):
        return None
    for k, v in obj.items():
        if isinstance(v, dict) and any(n.lower() in k.lower() for n in needles):
            return v
    return None


def record_date(rec) -> str | None:
    if not isinstance(rec, dict):
        return None
    for k in DATE_KEYS:
        v = rec.get(k)
        if isinstance(v, str) and _DATE_RE.match(v):
            return v[:10]
    return None


def day_records(resp) -> list:
    """All outermost dicts in a response that carry a calendar date."""
    out, stack = [], [resp]
    while stack:
        cur = stack.pop(0)
        if isinstance(cur, dict):
            if record_date(cur):
                out.append(cur)
                continue
            stack.extend(v for v in cur.values() if isinstance(v, (dict, list)))
        elif isinstance(cur, list):
            stack.extend(x for x in cur if isinstance(x, (dict, list)))
    return out


def as_list(resp, marker: str):
    """Return the list of dicts containing `marker` (e.g. activityId)."""
    if isinstance(resp, list):
        return [x for x in resp if isinstance(x, dict)]
    if isinstance(resp, dict):
        for v in resp.values():
            if isinstance(v, list) and v and isinstance(v[0], dict) and marker in v[0]:
                return v
        for v in resp.values():
            if isinstance(v, (dict, list)):
                found = as_list(v, marker)
                if found:
                    return found
    return []


def shape(obj, depth=0, max_depth=6):
    """Structure of a JSON value with all values redacted (for `inspect`)."""
    if depth > max_depth:
        return "…"
    if isinstance(obj, dict):
        return {k: shape(v, depth + 1) for k, v in obj.items()}
    if isinstance(obj, list):
        if not obj:
            return []
        return [shape(obj[0], depth + 1), f"… {len(obj)} items"]
    if isinstance(obj, bool):
        return "bool"
    if isinstance(obj, (int, float)):
        return "number"
    if isinstance(obj, str):
        return "date-string" if _DATE_RE.match(obj) else "string"
    return "null"


# ---------------------------------------------------------------- activities
RUN_WORDS = ("run",)
RIDE_WORDS = ("cycl", "bik", "ride")


def classify(type_key: str) -> tuple[str, bool]:
    t = (type_key or "").lower()
    indoor = any(w in t for w in ("indoor", "treadmill", "virtual", "trainer"))
    if any(w in t for w in RUN_WORDS) and "e_bike" not in t:
        return "run", indoor
    if any(w in t for w in RIDE_WORDS):
        return "ride", indoor
    return "other", indoor


def activity_row(a: dict) -> dict:
    type_key = find_str(a, ["activityType.typeKey", "activityTypeDTO.typeKey", "activityType"]) or ""
    sport, indoor = classify(type_key)
    start = find_str(a, ["startTimeLocal", "summaryDTO.startTimeLocal", "startTimeGMT"]) or ""
    cad = find_num(a, ["averageRunningCadenceInStepsPerMinute", "averageBikingCadenceInRevPerMinute",
                       "averageCadence", "avgCadence"], deep=False)
    stride = find_num(a, ["avgStrideLength"], deep=False)
    return {
        "id": int(a["activityId"]),
        "start_local": start.replace("T", " ")[:19],
        "date": start[:10],
        "sport": sport,
        "type_key": type_key,
        "indoor": int(indoor),
        "name": a.get("activityName") or type_key.replace("_", " ").title(),
        "distance_m": find_num(a, ["distance"], deep=False),
        "duration_s": find_num(a, ["duration", "elapsedDuration"], deep=False),
        "moving_s": find_num(a, ["movingDuration", "duration"], deep=False),
        "elev_gain": find_num(a, ["elevationGain"], deep=False),
        "elev_loss": find_num(a, ["elevationLoss"], deep=False),
        "avg_speed": find_num(a, ["averageSpeed", "avgSpeed"], deep=False),
        "max_speed": find_num(a, ["maxSpeed"], deep=False),
        "avg_hr": find_num(a, ["averageHR", "averageHeartRate", "avgHr"], deep=False),
        "max_hr": find_num(a, ["maxHR", "maxHeartRate"], deep=False),
        "avg_power": find_num(a, ["avgPower", "averagePower"], deep=False),
        "max_power": find_num(a, ["maxPower"], deep=False),
        "norm_power": find_num(a, ["normPower", "normalizedPower"], deep=False),
        "avg_cadence": cad,
        "calories": find_num(a, ["calories"], deep=False),
        "training_load": find_num(a, ["activityTrainingLoad", "trainingLoad"], deep=False),
        "aerobic_te": find_num(a, ["aerobicTrainingEffect"], deep=False),
        "anaerobic_te": find_num(a, ["anaerobicTrainingEffect"], deep=False),
        "vo2max": find_num(a, ["vO2MaxValue", "vo2MaxValue"], deep=False),
        "avg_stride": stride / 100 if stride and stride > 10 else stride,  # cm -> m
        "avg_gct": find_num(a, ["avgGroundContactTime"], deep=False),
        "avg_vo": find_num(a, ["avgVerticalOscillation"], deep=False),
        "location": a.get("locationName"),
    }


# --------------------------------------------------------------- daily data
def daily_summary_fields(r: dict) -> dict:
    def pick(needles, specific, generic=(), deep_generic=False):
        """Specific names are searched anywhere; generic names (avg, max…) only
        inside a sub-object whose key matches one of the needles."""
        v = find_num(r, specific)
        if v is not None:
            return v
        so = sub(r, *needles) if needles else None
        if so is not None and generic:
            return find_num(so, list(generic), deep=deep_generic)
        return None

    mod = pick(["intensity"], ["moderateIntensityMinutes"], ["moderateMinutes", "moderate", "moderateValue"])
    vig = pick(["intensity"], ["vigorousIntensityMinutes"], ["vigorousMinutes", "vigorous", "vigorousValue"])
    return {
        "steps": pick(["movement", "steps"], ["totalSteps"], ["steps", "value", "total"]),
        "resting_hr": pick(["heartRate", "heartrate"], ["restingHeartRate"], ["restingValue", "resting", "restingHR"]),
        "min_hr": pick(["heartRate", "heartrate"], ["minHeartRate"], ["minValue", "min"]),
        "max_hr": pick(["heartRate", "heartrate"], ["maxHeartRate"], ["maxValue", "max"]),
        "stress_avg": pick(["stress"], ["averageStressLevel", "avgStressLevel"], ["averageLevel", "averageValue", "average", "avg", "avgValue"]),
        "stress_max": pick(["stress"], ["maxStressLevel"], ["maxLevel", "maxValue", "max"]),
        "bb_high": pick(["bodyBattery", "bodybattery"], ["bodyBatteryHighestValue"], ["highestValue", "highest", "maxValue", "max", "high"]),
        "bb_low": pick(["bodyBattery", "bodybattery"], ["bodyBatteryLowestValue"], ["lowestValue", "lowest", "minValue", "min", "low"]),
        "bb_charged": pick(["bodyBattery", "bodybattery"], ["bodyBatteryChargedValue"], ["chargedValue", "charged"]),
        "bb_drained": pick(["bodyBattery", "bodybattery"], ["bodyBatteryDrainedValue"], ["drainedValue", "drained"]),
        "calories": pick(["calorie"], ["totalKilocalories"], ["totalValue", "total", "totalCalories"]),
        "active_calories": pick(["calorie"], ["activeKilocalories"], ["activeValue", "active", "activeCalories"]),
        "intensity_min": (mod or 0) + 2 * (vig or 0) if (mod is not None or vig is not None) else None,
        "floors": pick(["floor"], ["floorsAscended", "floorsClimbed"], ["ascended", "climbed", "value"]),
        "resp_avg": pick(["respiration"], ["avgWakingRespirationValue"], ["averageValue", "avgValue", "average", "avg"]),
        "spo2_avg": pick(["spo2", "pulseOx", "pulseox"], ["averageSpo2", "averageSpO2"], ["averageValue", "avgValue", "average", "avg"]),
    }


def sleep_fields(r: dict) -> dict:
    s = sub(r, "dailySleepDTO") or r

    def secs(names):
        v = find_num(s, names)
        return v

    total = secs(["sleepTimeSeconds", "totalSleepSeconds", "sleepTimeInSeconds", "durationInSeconds", "totalSleepTimeInSeconds"])
    deep = secs(["deepSleepSeconds", "deepSleepDurationInSeconds", "deepSleepTimeInSeconds"])
    light = secs(["lightSleepSeconds", "lightSleepDurationInSeconds", "lightSleepTimeInSeconds"])
    rem = secs(["remSleepSeconds", "remSleepDurationInSeconds", "remSleepTimeInSeconds"])
    awake = secs(["awakeSleepSeconds", "awakeDurationInSeconds", "awakeSleepTimeInSeconds", "awakeTimeInSeconds"])
    if total is None and any(v is not None for v in (deep, light, rem)):
        total = (deep or 0) + (light or 0) + (rem or 0)
    score = find_num(s, ["sleepScores.overall.value", "overall.value", "overallSleepScore.value",
                         "overallSleepScore", "sleepScore", "overallScore", "score"], deep=False)
    if score is None:
        sc = sub(s, "score")
        score = find_num(sc, ["value", "overall"]) if sc else None
    return {
        "sleep_s": total, "deep_s": deep, "light_s": light, "rem_s": rem, "awake_s": awake,
        "sleep_score": score,
        "resp_avg": find_num(s, ["averageRespirationValue", "avgSleepRespirationValue"], deep=False),
        "spo2_avg": find_num(s, ["averageSpO2Value", "averageSpo2Value"], deep=False),
    }


def hrv_fields(r: dict) -> dict:
    base = sub(r, "baseline") or {}
    return {
        "hrv_night": find_num(r, ["lastNightAvg", "lastNightAverage", "avgOvernightHrv", "nightlyAvg"], deep=False),
        "hrv_weekly": find_num(r, ["weeklyAvg", "weeklyAverage", "sevenDayAvg"], deep=False),
        "hrv_low": find_num(base, ["balancedLow", "lowUpper"], deep=False),
        "hrv_high": find_num(base, ["balancedUpper", "balancedHigh"], deep=False),
        "hrv_status": find_str(r, ["status", "hrvStatus"]),
    }


def body_battery_fields(r: dict) -> dict:
    vals = r.get("bodyBatteryValuesArray") or []
    levels = [v[1] for v in vals if isinstance(v, list) and len(v) > 1 and _is_num(v[1])]
    out = {
        "bb_charged": find_num(r, ["charged", "chargedValue"], deep=False),
        "bb_drained": find_num(r, ["drained", "drainedValue"], deep=False),
    }
    if levels:
        out["bb_high"], out["bb_low"] = float(max(levels)), float(min(levels))
    return out
