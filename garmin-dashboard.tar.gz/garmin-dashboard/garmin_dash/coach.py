"""Daily workout suggestions (one run, one ride) from your own data.

Every rule is tied to a reference in REFS and shown to the user. Where the
evidence is practice-based rather than experimental, the workout says so.

Decision order
1. Readiness (green / amber / red) from HRV, resting HR, sleep and form.
2. Is a hard session allowed?  Needs green readiness, >= 48 h since the last
   hard session, fewer than 2-3 hard sessions in the last 7 days, and an
   intensity distribution that is still mostly easy (polarised).
3. Which session?  Hard -> alternate threshold / VO2max; otherwise a long
   session if one is due, else an easy aerobic session.
4. Dose: duration/distance stay inside your recent trend. Runs are never
   longer than your longest run of the last 30 days (+5 % at most); weekly
   volume stays below 1.3x your 4-week average.
"""
from __future__ import annotations

import math
import statistics
from datetime import date, datetime, timedelta

from . import analytics as A
from . import db

# --------------------------------------------------------------------- refs
REFS = {
    "frandsen2025": {
        "cite": "Frandsen et al. 2025, British Journal of Sports Medicine",
        "finding": "5,205 runners, 588,000 runs tracked with Garmin watches: a single run more than 10 % longer than the "
                   "longest run of the previous 30 days raised the injury rate by about 64 %; bigger spikes raised it more. "
                   "Gradual weekly build-up (acute:chronic ratio) was not clearly linked to injury.",
    },
    "nielsen2014": {
        "cite": "Nielsen et al. 2014, J Orthop Sports Phys Ther",
        "finding": "Novice runners who increased weekly distance by more than 30 % over two weeks had more distance-related injuries.",
    },
    "stoggl2014": {
        "cite": "Stöggl & Sperlich 2014, Frontiers in Physiology",
        "finding": "In trained endurance athletes, 9 weeks of polarised training (mostly easy, some very hard, little in between) "
                   "improved VO₂peak and performance more than threshold-, volume- or HIIT-focused training.",
    },
    "seiler2007": {
        "cite": "Seiler, Haugen & Kuffel 2007, Med Sci Sports Exerc; Stanley, Peake & Buchheit 2013, Sports Med",
        "finding": "Autonomic (HRV) recovery is fast after easy sessions but takes considerably longer after sessions above the "
                   "aerobic threshold – up to about 48 h after high-intensity work.",
    },
    "helgerud2007": {
        "cite": "Helgerud et al. 2007, Med Sci Sports Exerc",
        "finding": "Runners doing 4 × 4 min at 90–95 % of max heart rate (3 min active recovery) twice a week for 8 weeks raised "
                   "VO₂max by about 7 %; easy long runs and threshold runs at matched work did not.",
    },
    "ronnestad2015": {
        "cite": "Rønnestad et al. 2015, Scand J Med Sci Sports",
        "finding": "Cyclists doing 3 sets of 13 × (30 s hard / 15 s easy) improved VO₂max and power more than cyclists doing "
                   "effort-matched 4 × 5 min intervals over 10 weeks.",
    },
    "javaloyes2019": {
        "cite": "Javaloyes et al. 2019, Int J Sports Physiol Perform; Plews et al. 2013, Sports Med",
        "finding": "Choosing hard vs. easy days from the 7-day rolling HRV average (hard only when it sits inside your normal "
                   "range) improved cycling performance more than a fixed plan. Rolling averages are more reliable than single nights.",
    },
    "buchheit2014": {
        "cite": "Buchheit 2014, Frontiers in Physiology",
        "finding": "A sustained rise in resting heart rate together with lower HRV is a practical marker of accumulated fatigue, "
                   "illness or stress.",
    },
    "fullagar2015": {
        "cite": "Fullagar et al. 2015, Sports Medicine",
        "finding": "Sleep restriction impairs endurance performance, perceived effort and recovery.",
    },
    "daniels": {
        "cite": "Daniels & Gilbert 1979; Daniels' Running Formula",
        "finding": "Training paces (easy, threshold, interval) derived from your current race fitness (VDOT). Widely used, "
                   "practice-based.",
    },
    "coggan": {
        "cite": "Allen & Coggan, Training and Racing with a Power Meter",
        "finding": "Power zones as % of FTP (endurance 56–75 %, threshold 91–105 %). Widely used, practice-based.",
    },
    "laursen2002": {
        "cite": "Laursen & Jenkins 2002, Sports Med; Seiler & Kjerland 2006, Scand J Med Sci Sports",
        "finding": "Well-trained endurance athletes spend roughly 75–80 % of sessions at low intensity; the large easy volume "
                   "builds the aerobic base that hard sessions sit on.",
    },
}

EASY, MODERATE, HARD, REST = "easy", "moderate", "hard", "rest"


# ------------------------------------------------------------------ helpers
def _fmt_pace(s):
    if not s:
        return None
    return f"{int(s // 60)}:{int(round(s % 60)):02d}"


def _round5(x):
    return int(5 * round(x / 5))


def _start_dt(a):
    try:
        return datetime.fromisoformat(a["start_local"])
    except Exception:
        return datetime.combine(a["d"], datetime.min.time())


# VDOT (Daniels & Gilbert): oxygen cost of running speed and the fraction of
# VO2max that can be sustained for a given duration.
def _vo2_cost(v):  # v in m/min
    return -4.60 + 0.182258 * v + 0.000104 * v * v


def _pct_max(t_min):
    return 0.8 + 0.1894393 * math.exp(-0.012778 * t_min) + 0.2989558 * math.exp(-0.1932605 * t_min)


def vdot(meters, seconds):
    t = seconds / 60
    return _vo2_cost(meters / t) / _pct_max(t)


def pace_at(vdot_value, frac):
    """Seconds per km at `frac` of VDOT."""
    vo2 = frac * vdot_value
    a, b, c = 0.000104, 0.182258, -(4.60 + vo2)
    v = (-b + math.sqrt(b * b - 4 * a * c)) / (2 * a)
    return 60000 / v


# ---------------------------------------------------------------- readiness
def readiness():
    con = db.connect()
    today = date.today()
    rows = [dict(r) for r in con.execute(
        "SELECT date, resting_hr, hrv_night, hrv_low, hrv_high, hrv_status, sleep_s FROM daily WHERE date>=? ORDER BY date",
        ((today - timedelta(days=75)).isoformat(),))]
    factors, score = [], 0  # score: 0 = green, 1 = amber, 2+ = red

    def add(name, status, text, ref):
        factors.append({"name": name, "status": status, "text": text, "ref": ref})

    # --- HRV: 7-day rolling mean of ln(HRV) vs. personal baseline ± SWC (0.5 SD)
    hrv = [(r["date"], r["hrv_night"]) for r in rows if r["hrv_night"]]
    recent_dates = {(today - timedelta(days=i)).isoformat() for i in range(7)}
    last7 = [math.log(v) for d, v in hrv if d in recent_dates]
    base = [math.log(v) for d, v in hrv if d not in recent_dates and d >= (today - timedelta(days=67)).isoformat()]
    hrv_flag = None
    if len(last7) >= 3 and len(base) >= 14:
        mu, sd = statistics.mean(base), statistics.pstdev(base) or 0.05
        swc = 0.5 * sd
        roll = statistics.mean(last7)
        last = hrv[-1]
        last_ln = math.log(last[1])
        lo, hi = math.exp(mu - swc), math.exp(mu + swc)
        if roll < mu - swc:
            hrv_flag = "low"
            score += 1
            add("HRV", "amber", f"7-day average {math.exp(roll):.0f} ms is below your normal range ({lo:.0f}–{hi:.0f} ms).", "javaloyes2019")
        elif last_ln < mu - 1.5 * sd and last[0] in recent_dates:
            hrv_flag = "dip"
            score += 1
            add("HRV", "amber", f"Last night {last[1]:.0f} ms – a clear dip below your usual {math.exp(mu):.0f} ms.", "javaloyes2019")
        else:
            add("HRV", "green", f"7-day average {math.exp(roll):.0f} ms – inside your normal range ({lo:.0f}–{hi:.0f} ms).", "javaloyes2019")
    else:
        st = next((r["hrv_status"] for r in reversed(rows) if r["hrv_status"]), None)
        if st and st.upper() in ("LOW", "POOR", "UNBALANCED"):
            score += 1
            hrv_flag = "low"
            add("HRV", "amber", f"Garmin HRV status: {st.lower()}.", "javaloyes2019")
        elif st:
            add("HRV", "green", f"Garmin HRV status: {st.lower()}.", "javaloyes2019")
        else:
            add("HRV", "none", "Not enough HRV nights yet (needs ~3 weeks).", "javaloyes2019")

    # --- resting HR: 7-day mean vs. 60-day baseline
    rhr7 = [r["resting_hr"] for r in rows if r["resting_hr"] and r["date"] in recent_dates]
    rhrb = [r["resting_hr"] for r in rows if r["resting_hr"] and r["date"] not in recent_dates]
    if len(rhr7) >= 3 and len(rhrb) >= 14:
        d = statistics.mean(rhr7) - statistics.mean(rhrb)
        if d >= 5:
            score += 2
            add("Resting HR", "red", f"{statistics.mean(rhr7):.0f} bpm – {d:.0f} bpm above your baseline. Possible fatigue or illness.", "buchheit2014")
        elif d >= 3:
            score += 1
            add("Resting HR", "amber", f"{statistics.mean(rhr7):.0f} bpm – {d:.0f} bpm above your baseline.", "buchheit2014")
        else:
            add("Resting HR", "green", f"{statistics.mean(rhr7):.0f} bpm – normal for you ({statistics.mean(rhrb):.0f} baseline).", "buchheit2014")
    else:
        add("Resting HR", "none", "Not enough data yet.", "buchheit2014")

    # --- sleep: last night and 3-night average
    sl = [(r["date"], r["sleep_s"]) for r in rows if r["sleep_s"]]
    if sl and sl[-1][0] >= (today - timedelta(days=1)).isoformat():
        last_h = sl[-1][1] / 3600
        avg3 = statistics.mean(s for _, s in sl[-3:]) / 3600
        if last_h < 5:
            score += 2
            add("Sleep", "red", f"Only {last_h:.1f} h last night.", "fullagar2015")
        elif last_h < 6 or avg3 < 6.5:
            score += 1
            add("Sleep", "amber", f"{last_h:.1f} h last night, {avg3:.1f} h average over 3 nights.", "fullagar2015")
        else:
            add("Sleep", "green", f"{last_h:.1f} h last night.", "fullagar2015")
    else:
        add("Sleep", "none", "No sleep recorded for last night.", "fullagar2015")

    # --- form (TSB)
    ls = A.load_series()
    tsb = ls["tsb"][-1] if ls["tsb"] else None
    ctl = ls["ctl"][-1] if ls["ctl"] else 0
    if tsb is not None and ctl > 5:
        if tsb < -30:
            score += 2
            add("Training load", "red", f"Form {tsb:.0f}: fatigue far above fitness.", "seiler2007")
        elif tsb < -20:
            score += 1
            add("Training load", "amber", f"Form {tsb:.0f}: carrying a lot of fatigue.", "seiler2007")
        else:
            add("Training load", "green", f"Form {tsb:+.0f}.", "seiler2007")

    level = "green" if score == 0 else "amber" if score == 1 else "red"
    return {"level": level, "score": score, "factors": factors, "hrv_flag": hrv_flag, "ctl": ctl, "tsb": tsb}


# ------------------------------------------------------------ history state
def _classify(a, ath, ftp):
    """Was this session hard, and of which type?"""
    m = a["m"]
    floors = ath["zones"][a["sport"]]
    z = A.zone_seconds(m.get("hr_hist"), floors) if m.get("hr_hist") else None
    pz = A.power_zone_seconds(m.get("power_hist"), ftp) if (m.get("power_hist") and ftp) else None
    hi_hr = (z[3] + z[4]) if z else 0
    hi_pw = sum(pz[3:]) if pz else 0
    vo2 = (z[4] >= 300 if z else False) or (sum(pz[4:]) >= 360 if pz else False)
    hard = hi_hr >= 600 or hi_pw >= 900 or (a["anaerobic_te"] or 0) >= 2.5 or vo2
    return hard, ("vo2" if vo2 else "threshold") if hard else None


def state(now: datetime | None = None):
    now = now or datetime.now()
    ath = A.athlete()
    ftp, ftp_src = A.ftp_now()
    acts = A.activities()
    today = now.date()
    trained_today = any(a["d"] == today for a in acts)
    plan_day = today + timedelta(days=1) if trained_today else today
    ref_time = datetime.combine(plan_day, datetime.min.time()) + timedelta(hours=8) if trained_today else now

    hard_list, z_tot = [], [0] * 5
    for a in acts:
        if a["d"] < today - timedelta(days=60):
            continue
        hard, kind = _classify(a, ath, ftp)
        a["_hard"], a["_kind"] = hard, kind
        if hard:
            hard_list.append(a)
        if a["d"] >= today - timedelta(days=28) and a["m"].get("hr_hist"):
            z_tot = [x + y for x, y in zip(z_tot, A.zone_seconds(a["m"]["hr_hist"], ath["zones"][a["sport"]]))]
    last_hard = max(hard_list, key=_start_dt) if hard_list else None
    hours_since_hard = (ref_time - _start_dt(last_hard)).total_seconds() / 3600 if last_hard else None
    hard_7d = sum(1 for a in hard_list if a["d"] > plan_day - timedelta(days=7))
    tot = sum(z_tot)
    dist = {"easy": (z_tot[0] + z_tot[1]) / tot, "mid": z_tot[2] / tot, "hard": (z_tot[3] + z_tot[4]) / tot} if tot > 3600 else None

    def sport_state(sport):
        xs = [a for a in acts if a["sport"] == sport]
        recent = [a for a in xs if a["d"] >= today - timedelta(days=60)]
        last30 = [a for a in xs if a["d"] > plan_day - timedelta(days=30)]
        last7 = [a for a in xs if a["d"] > plan_day - timedelta(days=7)]
        prev28 = [a for a in xs if plan_day - timedelta(days=35) < a["d"] <= plan_day - timedelta(days=7)]
        dur = lambda a: (a["moving_s"] or a["duration_s"] or 0)
        km = lambda a: (a["distance_m"] or 0) / 1000
        med_dur = statistics.median([dur(a) for a in recent]) if recent else None
        med_km = statistics.median([km(a) for a in recent if km(a) > 0]) if any(km(a) > 0 for a in recent) else None
        easy = [a for a in recent if not a.get("_hard")]
        easy_dur = statistics.median([dur(a) for a in easy[-10:]]) if easy else med_dur
        easy_km = statistics.median([km(a) for a in easy[-10:] if km(a) > 0]) if any(km(a) > 0 for a in easy[-10:]) else med_km

        def is_long(a):
            if sport == "run":
                return med_km and km(a) >= max(1.35 * med_km, 10) or dur(a) >= 75 * 60
            return med_dur and dur(a) >= max(1.35 * med_dur, 90 * 60)
        longs = [a for a in recent if is_long(a)]
        last = max(xs, key=_start_dt) if xs else None
        last_hard_sport = {k: max((a for a in hard_list if a["sport"] == sport and a["_kind"] == k), key=_start_dt, default=None)
                           for k in ("threshold", "vo2")}
        return {
            "n": len(xs), "n_recent": len(recent),
            "last": last, "days_since_last": (plan_day - last["d"]).days if last else None,
            "yesterday": [a for a in xs if a["d"] == plan_day - timedelta(days=1)],
            "longest30_km": max((km(a) for a in last30), default=0),
            "longest30_s": max((dur(a) for a in last30), default=0),
            "week_km": sum(km(a) for a in last7), "week_s": sum(dur(a) for a in last7),
            "chronic_km": sum(km(a) for a in prev28) / 4, "chronic_s": sum(dur(a) for a in prev28) / 4,
            "easy_s": easy_dur, "easy_km": easy_km, "med_s": med_dur,
            "days_since_long": (plan_day - max(a["d"] for a in longs)).days if longs else None,
            "last_threshold": last_hard_sport["threshold"], "last_vo2": last_hard_sport["vo2"],
        }

    # running fitness → VDOT from the strongest effort ≥ 3 km in the last 90 days (else 365)
    v, v_src = None, None
    run = A.running()
    for window, label in ((run["best_90d"], "last 90 days"), (run["best_365d"], "last 12 months")):
        cands = [(vdot(e["meters"], e["seconds"]), k, e) for k, e in window.items() if e["meters"] >= 3000]
        if cands:
            best = max(cands, key=lambda c: c[0])
            v, v_src = best[0], f"your {best[1]} in {_fmt_pace(best[2]['seconds'] / (best[2]['meters'] / 1000))}/km pace ({label})"
            break

    return {
        "now": now, "today": today, "plan_day": plan_day, "trained_today": trained_today,
        "ath": ath, "ftp": ftp, "ftp_src": ftp_src,
        "last_hard": last_hard, "hours_since_hard": hours_since_hard, "hard_7d": hard_7d, "dist28": dist,
        "run": sport_state("run"), "ride": sport_state("ride"), "vdot": v, "vdot_src": v_src,
    }


# ----------------------------------------------------------------- targets
def run_targets(st):
    f = st["ath"]["zones"]["run"]
    mx = st["ath"]["max_hr"]
    t = {
        "recovery_hr": f"below {int(f[1])} bpm",
        "easy_hr": f"{int(f[1])}–{int(f[2]) - 1} bpm (zone 2; low zone 3 is fine on hills)",
        "threshold_hr": f"{int(f[3])}–{int(f[4]) - 1} bpm (zone 4)",
        "vo2_hr": f"{round(mx * 0.90)}–{round(mx * 0.95)} bpm (90–95 % of max {int(mx)})",
    }
    if st["vdot"]:
        v = st["vdot"]
        t["easy_pace"] = f"{_fmt_pace(pace_at(v, 0.74))}–{_fmt_pace(pace_at(v, 0.65))}/km"
        t["threshold_pace"] = f"{_fmt_pace(pace_at(v, 0.89))}–{_fmt_pace(pace_at(v, 0.86))}/km"
        t["vo2_pace"] = f"{_fmt_pace(pace_at(v, 1.0))}–{_fmt_pace(pace_at(v, 0.96))}/km"
        t["easy_s_per_km"] = pace_at(v, 0.70)
    return t


def ride_targets(st):
    f = st["ath"]["zones"]["ride"]
    ftp = st["ftp"]
    t = {
        "recovery_hr": f"below {int(f[1])} bpm",
        "easy_hr": f"{int(f[1])}–{int(f[2]) - 1} bpm (zone 2)",
        "threshold_hr": f"{int(f[3])}–{int(f[4]) - 1} bpm (zone 4)",
    }
    if ftp:
        t["recovery_w"] = f"below {round(ftp * 0.55)} W"
        t["endurance_w"] = f"{round(ftp * 0.56)}–{round(ftp * 0.75)} W"
        t["threshold_w"] = f"{round(ftp * 0.91)}–{round(ftp * 0.97)} W"
        t["vo2_w"] = f"about {round(ftp * 1.15)}–{round(ftp * 1.25)} W"
    return t


def _step(label, minutes, target, note=None):
    return {"label": label, "min": round(minutes), "target": target, "note": note}


# ----------------------------------------------------------------- planner
def _hard_gate(st, rd):
    """Can today be a hard day?  Returns (allowed, reasons_against)."""
    why_not = []
    if rd["level"] != "green":
        why_not.append("recovery markers are not all green")
    h = st["hours_since_hard"]
    if h is not None and h < 48:
        why_not.append(f"your last hard session was {h:.0f} h ago (allow ~48 h)")
    max_hard = 3 if (rd["ctl"] or 0) >= 60 else 2
    if st["hard_7d"] >= max_hard:
        why_not.append(f"you've already done {st['hard_7d']} hard sessions in 7 days")
    d = st["dist28"]
    if d and d["hard"] > 0.20:
        why_not.append(f"{d['hard']:.0%} of your training time in the last 4 weeks was already in zones 4–5 "
                       "(polarised programmes keep it well below 20 %)")
    return not why_not, why_not


def plan_run(st, rd):
    s, T = st["run"], run_targets(st)
    pace = T.get("easy_s_per_km")
    hard_ok, why_not = _hard_gate(st, rd)
    reasons, guards, refs = [], [], ["frandsen2025", "stoggl2014"]
    longest = s["longest30_km"]
    chronic = s["chronic_km"]
    week_cap = max(chronic * 1.3, chronic + 5) if chronic else None
    budget = (week_cap - s["week_km"]) if week_cap else None

    # cap for any single run: never beyond the longest of the last 30 days (+5 % on long-run days)
    def cap_km(target, allow_spike=False):
        lim = longest * (1.05 if allow_spike else 1.0) if longest else target
        out = min(target, lim)
        if budget is not None:
            out = min(out, max(budget, 0))
        return out

    def km_to_min(km):
        return km * (pace or 360) / 60

    def mins_to_km(mn):
        return mn * 60 / (pace or 360)

    guards.append(f"Keep this run ≤ {longest:.1f} km – your longest of the last 30 days. Single runs beyond that "
                  "are the strongest injury predictor in the largest study to date." if longest else
                  "No runs in the last 30 days – start short and easy.")
    if week_cap:
        guards.append(f"Last 7 days: {s['week_km']:.1f} km "
                      + (f"of a {week_cap:.0f} km ceiling" if s['week_km'] <= week_cap else f"– already above the {week_cap:.0f} km ceiling")
                      + f" (1.3 × your 4-week average of {chronic:.1f} km/week).")
        refs.append("nielsen2014")

    # --- no data / long break
    if s["n_recent"] == 0 or (s["days_since_last"] or 0) >= 14:
        mins = 25 if s["n_recent"] == 0 else min(35, max(20, (s["easy_s"] or 1800) / 60 * 0.6))
        reasons.append("No run in the last two weeks – coming back with short, easy runs lets tendons and bones re-adapt "
                       "before volume returns." if s["n_recent"] else "No recent runs – a short easy run to establish a baseline.")
        return _w("run", "Comeback easy run", EASY, [_step("Easy running, walk breaks allowed", mins, T["easy_hr"])], T,
                  reasons, guards, refs, "moderate", mins_to_km(mins))

    if rd["level"] == "red":
        reasons.append("Several recovery markers are off, so today is for recovery.")
        reasons += [f["text"] for f in rd["factors"] if f["status"] == "red"]
        return _w("run", "Rest day – or 20 min very easy", REST,
                  [_step("Optional: very easy jog or walk", 20, T["recovery_hr"], "Skip it entirely if you feel unwell")],
                  T, reasons, guards, refs + ["buchheit2014", "javaloyes2019"], "strong", mins_to_km(20))

    if budget is not None and budget < 3:
        reasons.append(f"You've reached your running trend: {s['week_km']:.0f} km in the last 7 days. "
                       "A ride is the better choice today – it adds aerobic work without impact.")
        return _w("run", "Recovery jog (or ride instead)", EASY,
                  [_step("Very easy jog", 20, T["recovery_hr"])], T, reasons, guards, refs, "moderate", mins_to_km(20))

    yesterday_hard_run = any(a.get("_hard") or (a["distance_m"] or 0) / 1000 >= max(longest * 0.85, 12) for a in s["yesterday"])
    session_km = mins_to_km(50)
    if hard_ok and budget is not None and budget < session_km:
        hard_ok = False
        why_not = why_not + [f"only {budget:.0f} km are left in this week's running trend"]
    if hard_ok and not yesterday_hard_run:
        lt, lv = s["last_threshold"], s["last_vo2"]
        no_recent_hard = not lt and not lv
        do_vo2 = (lv is None or (lt and _start_dt(lt) > _start_dt(lv))) and not no_recent_hard
        ctl = rd["ctl"] or 0
        if do_vo2:
            reps = 3 if ctl < 30 else 4
            main = reps * 4 + (reps - 1) * 3
            steps = [_step("Warm-up, easy, finish with 3 short pick-ups", 15, T["easy_hr"]),
                     _step(f"{reps} × 4 min hard / 3 min easy jog", main,
                           f"{T['vo2_hr']}" + (f" · ≈ {T['vo2_pace']}" if "vo2_pace" in T else ""),
                           "Reach the target HR in the 2nd–3rd minute; the last rep should feel hard but controlled"),
                     _step("Cool-down, easy", 10, T["recovery_hr"])]
            reasons += ["Recovery markers are green and it's been more than 48 h since your last hard session.",
                        "VO₂max intervals are your least recent hard session type – alternating keeps both stimuli without stacking stress.",
                        "The 4 × 4 min format has one of the strongest evidence bases for raising VO₂max."]
            tot = sum(x["min"] for x in steps)
            return _w("run", f"VO₂max intervals: {reps} × 4 min", HARD, steps, T, reasons, guards,
                      refs + ["helgerud2007", "seiler2007", "javaloyes2019", "daniels"], "strong (randomised trial)",
                      min(mins_to_km(tot) * 1.05, longest or 99))
        reps, rep_min = (3, 6) if ctl < 30 else (3, 8) if ctl < 55 else (4, 8)
        if no_recent_hard:
            reps, rep_min = 3, 5
        main = reps * rep_min + (reps - 1) * 2
        steps = [_step("Warm-up, easy", 15, T["easy_hr"]),
                 _step(f"{reps} × {rep_min} min at threshold / 2 min easy jog", main,
                       f"{T['threshold_hr']}" + (f" · ≈ {T['threshold_pace']}" if "threshold_pace" in T else ""),
                       "'Comfortably hard' – you could speak a few words, not sentences"),
                 _step("Cool-down, easy", 10, T["recovery_hr"])]
        reasons += ["Recovery markers are green and it's been more than 48 h since your last hard session."]
        reasons.append("No hard sessions recently – a short threshold session reintroduces intensity safely before VO₂max work."
                       if no_recent_hard else "Threshold is your least recent hard session type.")
        tot = sum(x["min"] for x in steps)
        return _w("run", f"Threshold intervals: {reps} × {rep_min} min", HARD, steps, T, reasons, guards,
                  refs + ["daniels", "seiler2007", "javaloyes2019"], "moderate (practice-based, widely used)",
                  min(mins_to_km(tot), longest or 99))

    # --- long run if due
    long_due = (s["days_since_long"] is None or s["days_since_long"] >= 6) and rd["level"] == "green" and not yesterday_hard_run
    if long_due and longest >= 6:
        km = cap_km(longest * 1.05 if rd["level"] == "green" else longest * 0.9, allow_spike=True)
        if km < max(longest * 0.8, 6):
            reasons.append(f"A long run is due, but only {max(budget or 0, 0):.0f} km remain in this week's trend – "
                           "it moves to a day with more room.")
        else:
            reasons += [f"Your last long run was {s['days_since_long']} days ago." if s["days_since_long"] else "No long run in the last 2 months.",
                        "Long easy runs build aerobic endurance and are the backbone of polarised training."]
            if not hard_ok and why_not:
                reasons.append("No intervals today because " + "; ".join(why_not) + ".")
            guards.insert(0, f"Long-run limit: {longest * 1.05:.1f} km (at most +5 % on your longest run of the last 30 days). "
                             "In the 2025 study, even spikes of 10–30 % raised injury rates by ~64 %.")
            return _w("run", f"Long easy run: {km:.1f} km", EASY,
                      [_step(f"{km:.1f} km steady and easy", km_to_min(km), T["easy_hr"] + (f" · ≈ {T['easy_pace']}" if "easy_pace" in T else ""),
                             "Walk the steep uphills if HR goes above zone 2")],
                      T, reasons, guards, refs + ["laursen2002"], "strong (observational + training studies)", km)

    # --- easy aerobic run (default)
    base_min = (s["easy_s"] or 2400) / 60
    if rd["level"] == "amber" or yesterday_hard_run:
        mins = max(20, base_min * 0.75)
        title = "Easy recovery run"
        reasons.append("Some recovery markers are amber – keep it easy and a bit shorter than usual."
                       if rd["level"] == "amber" else "Your legs had a hard or long run yesterday – today stays easy.")
        reasons += [f["text"] for f in rd["factors"] if f["status"] == "amber"]
    else:
        mins = base_min
        title = "Easy aerobic run"
        if why_not:
            reasons.append("No intervals today because " + "; ".join(why_not) + ".")
        reasons.append("Easy volume makes up ~80 % of training in polarised programmes and carries little injury risk at your usual duration.")
    km = cap_km(mins_to_km(mins))
    mins = km_to_min(km)
    steps = [_step(f"Easy running ({km:.1f} km)", mins, T["easy_hr"] + (f" · ≈ {T['easy_pace']}" if "easy_pace" in T else ""))]
    if rd["level"] == "green" and not yesterday_hard_run and mins >= 25:
        steps.append(_step("6 × 20 s strides, walk back to recover", 5, "fast but relaxed – not a sprint",
                           "Keeps running form sharp with almost no fatigue"))
    return _w("run", title, EASY, steps, T, reasons, guards, refs + ["laursen2002"], "strong", km)


def plan_ride(st, rd):
    s, T = st["ride"], ride_targets(st)
    ftp = st["ftp"]
    hard_ok, why_not = _hard_gate(st, rd)
    reasons, guards, refs = [], [], ["stoggl2014"]
    longest = s["longest30_s"] / 60
    chronic = s["chronic_s"] / 60
    week_cap = max(chronic * 1.3, chronic + 60) if chronic else None
    budget = (week_cap - s["week_s"] / 60) if week_cap else None

    def cap_min(m, factor=1.1):
        lim = max(longest * factor, 60) if longest else m
        out = min(m, lim)
        if budget is not None:
            out = min(out, max(budget, 30))
        return _round5(out)

    p = lambda key: (f" · {T[key]}" if key in T else "")
    if longest:
        guards.append(f"Keep the ride ≤ {_round5(max(longest * 1.1, 60))} min (+10 % on your longest ride of the last 30 days). "
                      "Cycling injury data are thin, so this mirrors the conservative running rule.")
    if week_cap:
        guards.append(f"Last 7 days: {s['week_s'] / 3600:.1f} h "
                      + (f"of a {week_cap / 60:.1f} h ceiling" if s['week_s'] / 60 <= week_cap else f"– already above the {week_cap / 60:.1f} h ceiling")
                      + " (1.3 × your 4-week average).")
    if not ftp:
        guards.append("No power data – targets use heart rate only.")

    if s["n_recent"] == 0 or (s["days_since_last"] or 0) >= 21:
        mins = 60 if s["n_recent"] == 0 else _round5(min(75, max(45, (s["easy_s"] or 3600) / 60 * 0.7)))
        reasons.append("No ride in the last three weeks – an easy endurance ride rebuilds the habit before adding intensity."
                       if s["n_recent"] else "No recent rides – an easy endurance ride to establish a baseline.")
        return _w("ride", "Easy endurance ride", EASY, [_step("Easy, mostly flat", mins, T["easy_hr"] + p("endurance_w"))], T,
                  reasons, guards, refs + ["coggan"], "moderate", None)

    if rd["level"] == "red":
        reasons.append("Several recovery markers are off, so today is for recovery.")
        reasons += [f["text"] for f in rd["factors"] if f["status"] == "red"]
        return _w("ride", "Rest day – or 30 min easy spin", REST,
                  [_step("Optional: very easy spin, flat roads or trainer", 30, T["recovery_hr"] + p("recovery_w"),
                         "Skip it entirely if you feel unwell")],
                  T, reasons, guards, refs + ["buchheit2014", "javaloyes2019"], "strong", None)

    yesterday_hard = any(a.get("_hard") for a in st["run"]["yesterday"] + s["yesterday"])
    if hard_ok and not yesterday_hard:
        lt, lv = s["last_threshold"], s["last_vo2"]
        no_recent_hard = not lt and not lv
        do_vo2 = (lv is None or (lt and _start_dt(lt) > _start_dt(lv))) and not no_recent_hard
        ctl = rd["ctl"] or 0
        if do_vo2:
            sets, reps = (2, 10) if ctl < 30 else (3, 13)
            block = reps * 0.75
            main = sets * block + (sets - 1) * 3
            steps = [_step("Warm-up, progressive, with 2 × 1 min brisk", 15, T["easy_hr"] + p("endurance_w")),
                     _step(f"{sets} sets of {reps} × (30 s hard / 15 s easy), 3 min easy between sets", main,
                           ("30 s at " + T["vo2_w"] if "vo2_w" in T else "30 s very hard (≈ 9/10 effort)") + " · 15 s spin easy",
                           "Pace each set so the last reps match the first – the original study used the highest power you can hold evenly"),
                     _step("Cool-down, easy spin", 15, T["recovery_hr"] + p("recovery_w"))]
            reasons += ["Recovery markers are green and it's been more than 48 h since your last hard session.",
                        "VO₂max work is your least recent hard session type on the bike.",
                        "The 30/15 format beat classic 4 × 5 min intervals for VO₂max and power in a controlled trial."]
            return _w("ride", f"VO₂max: Rønnestad 30/15 ({sets} × {reps})", HARD, steps, T, reasons, guards,
                      refs + ["ronnestad2015", "seiler2007", "javaloyes2019", "coggan"], "strong (randomised trial)", None)
        reps, rep_min = (2, 12) if ctl < 30 else (2, 20) if ctl < 55 else (3, 15)
        if no_recent_hard:
            reps, rep_min = 2, 10
        main = reps * rep_min + (reps - 1) * 5
        steps = [_step("Warm-up, progressive", 15, T["easy_hr"] + p("endurance_w")),
                 _step(f"{reps} × {rep_min} min at threshold / 5 min easy", main,
                       (T["threshold_w"] + " · " if "threshold_w" in T else "") + T["threshold_hr"],
                       "A steady climb is ideal – hold even power, seated"),
                 _step("Cool-down, easy spin", 15, T["recovery_hr"] + p("recovery_w"))]
        reasons += ["Recovery markers are green and it's been more than 48 h since your last hard session."]
        reasons.append("No hard sessions recently – a moderate threshold dose reintroduces intensity."
                       if no_recent_hard else "Threshold is your least recent hard session type on the bike.")
        return _w("ride", f"Threshold: {reps} × {rep_min} min", HARD, steps, T, reasons, guards,
                  refs + ["coggan", "seiler2007", "javaloyes2019"], "moderate (practice-based, widely used)", None)

    long_due = (s["days_since_long"] is None or s["days_since_long"] >= 6) and rd["level"] == "green" and not yesterday_hard
    if long_due and longest >= 60:
        mins = cap_min(longest * 1.1)
        reasons += [f"Your last long ride was {s['days_since_long']} days ago." if s["days_since_long"] else "No long ride in the last 2 months.",
                    "Long zone-2 rides build aerobic capacity and fat oxidation; climbs are fine if you stay in zone 2."]
        if why_not:
            reasons.append("No intervals today because " + "; ".join(why_not) + ".")
        return _w("ride", f"Long endurance ride: {mins // 60} h {mins % 60:02d}", EASY,
                  [_step("Steady endurance riding", mins, T["easy_hr"] + p("endurance_w"),
                         "On climbs, shift down and keep HR in zone 2; eat ~60 g carbs per hour after the first hour")],
                  T, reasons, guards, refs + ["laursen2002", "coggan"], "strong", None)

    base = (s["easy_s"] or 3600) / 60
    if rd["level"] == "amber" or yesterday_hard:
        mins = cap_min(max(40, base * 0.75))
        title = "Easy recovery ride"
        reasons.append("Some recovery markers are amber – keep the intensity low." if rd["level"] == "amber"
                       else "You trained hard yesterday – an easy spin speeds recovery without adding stress.")
        reasons += [f["text"] for f in rd["factors"] if f["status"] == "amber"]
        steps = [_step("Easy spin, flat or rolling", mins, T["recovery_hr"] + p("recovery_w"))]
    else:
        mins = cap_min(max(60, base))
        title = "Endurance ride (zone 2)"
        if why_not:
            reasons.append("No intervals today because " + "; ".join(why_not) + ".")
        reasons.append("Zone-2 endurance makes up most of a polarised week and adds fitness with little fatigue.")
        steps = [_step("Steady endurance", mins, T["easy_hr"] + p("endurance_w"), "Cadence 85–95 rpm; easy on the climbs")]
    return _w("ride", title, EASY, steps, T, reasons, guards, refs + ["laursen2002", "coggan"], "strong", None)


def _w(sport, title, intensity, steps, targets, reasons, guards, refs, evidence, km):
    seen, refs_u = set(), []
    for r in refs:
        if r not in seen:
            seen.add(r)
            refs_u.append(r)
    return {"sport": sport, "title": title, "intensity": intensity, "steps": steps,
            "minutes": sum(s["min"] for s in steps), "km": round(km, 1) if km else None,
            "targets": {k: v for k, v in targets.items() if not k.endswith("_s_per_km")},
            "why": reasons, "guardrails": guards, "evidence_level": evidence,
            "refs": [{"id": r, **REFS[r]} for r in refs_u]}


def suggestions(now: datetime | None = None):
    st = state(now)
    rd = readiness()
    hard_ok, why_not = _hard_gate(st, rd)
    lh = st["last_hard"]
    return {
        "plan_day": st["plan_day"].isoformat(),
        "for_tomorrow": st["trained_today"],
        "readiness": rd,
        "hard_allowed": hard_ok, "hard_blockers": why_not,
        "context": {
            "hours_since_hard": round(st["hours_since_hard"]) if st["hours_since_hard"] is not None else None,
            "last_hard": {"id": lh["id"], "name": lh["name"], "date": lh["date"], "sport": lh["sport"], "kind": lh["_kind"]} if lh else None,
            "hard_7d": st["hard_7d"],
            "dist28": st["dist28"],
            "vdot": round(st["vdot"], 1) if st["vdot"] else None, "vdot_src": st["vdot_src"],
            "ftp": st["ftp"], "ftp_src": st["ftp_src"],
            "run_week_km": round(st["run"]["week_km"], 1), "run_chronic_km": round(st["run"]["chronic_km"], 1),
            "run_longest30": round(st["run"]["longest30_km"], 1),
            "ride_week_h": round(st["ride"]["week_s"] / 3600, 1), "ride_chronic_h": round(st["ride"]["chronic_s"] / 3600, 1),
        },
        "run": plan_run(st, rd),
        "ride": plan_ride(st, rd),
        "refs": REFS,
    }
