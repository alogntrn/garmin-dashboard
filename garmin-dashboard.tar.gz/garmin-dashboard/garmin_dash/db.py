"""SQLite storage. Raw Garmin JSON is kept alongside extracted columns so
fields can be re-extracted later without downloading anything again."""
from __future__ import annotations

import json
import sqlite3
import zlib
from datetime import datetime

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS activities (
    id INTEGER PRIMARY KEY,
    start_local TEXT, date TEXT, sport TEXT, type_key TEXT, indoor INTEGER,
    name TEXT, distance_m REAL, duration_s REAL, moving_s REAL,
    elev_gain REAL, elev_loss REAL, avg_speed REAL, max_speed REAL,
    avg_hr REAL, max_hr REAL, avg_power REAL, max_power REAL, norm_power REAL,
    avg_cadence REAL, calories REAL, training_load REAL,
    aerobic_te REAL, anaerobic_te REAL, vo2max REAL,
    avg_stride REAL, avg_gct REAL, avg_vo REAL, location TEXT,
    raw TEXT, fit_status TEXT DEFAULT 'pending', updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_act_date ON activities(date);
CREATE TABLE IF NOT EXISTS activity_detail (
    id INTEGER PRIMARY KEY,
    streams BLOB, laps TEXT, metrics TEXT, processed_at TEXT
);
CREATE TABLE IF NOT EXISTS daily (
    date TEXT PRIMARY KEY,
    steps REAL, resting_hr REAL, min_hr REAL, max_hr REAL,
    stress_avg REAL, stress_max REAL, bb_high REAL, bb_low REAL, bb_charged REAL, bb_drained REAL,
    calories REAL, active_calories REAL, intensity_min REAL, floors REAL,
    sleep_s REAL, deep_s REAL, light_s REAL, rem_s REAL, awake_s REAL, sleep_score REAL,
    resp_avg REAL, spo2_avg REAL,
    hrv_night REAL, hrv_weekly REAL, hrv_low REAL, hrv_high REAL, hrv_status TEXT,
    weight_kg REAL
);
CREATE TABLE IF NOT EXISTS raw_daily (
    date TEXT, source TEXT, data TEXT, PRIMARY KEY (date, source)
);
CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS sync_log (ts TEXT, level TEXT, message TEXT);
"""


def connect() -> sqlite3.Connection:
    config.ensure_dirs()
    con = sqlite3.connect(config.DB_PATH, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.executescript(SCHEMA)
    return con


def kv_get(con, key, default=None):
    row = con.execute("SELECT value FROM kv WHERE key=?", (key,)).fetchone()
    return json.loads(row[0]) if row else default


def kv_set(con, key, value):
    con.execute("INSERT OR REPLACE INTO kv(key,value) VALUES(?,?)", (key, json.dumps(value)))


def log(con, level, message):
    con.execute("INSERT INTO sync_log VALUES(?,?,?)", (datetime.now().isoformat(timespec="seconds"), level, message))
    con.execute("DELETE FROM sync_log WHERE rowid NOT IN (SELECT rowid FROM sync_log ORDER BY rowid DESC LIMIT 500)")
    con.commit()


def pack(obj) -> bytes:
    return zlib.compress(json.dumps(obj, separators=(",", ":")).encode(), 6)


def unpack(blob):
    return json.loads(zlib.decompress(blob)) if blob else None


def upsert_daily(con, day: str, fields: dict):
    fields = {k: v for k, v in fields.items() if v is not None}
    if not fields:
        return
    con.execute("INSERT OR IGNORE INTO daily(date) VALUES(?)", (day,))
    sets = ",".join(f"{k}=?" for k in fields)
    con.execute(f"UPDATE daily SET {sets} WHERE date=?", (*fields.values(), day))
