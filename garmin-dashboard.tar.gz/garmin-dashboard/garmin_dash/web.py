"""Web server: JSON API + the single-page dashboard."""
from __future__ import annotations

import subprocess
import sys
from datetime import date, datetime
from pathlib import Path

from flask import Flask, abort, jsonify, request, send_from_directory

from . import analytics as A
from . import config

STATIC = Path(__file__).parent / "static"
app = Flask(__name__, static_folder=None)
app.json.sort_keys = False


def _json(obj):
    def fix(o):
        if isinstance(o, dict):
            return {str(k): fix(v) for k, v in o.items()}
        if isinstance(o, (list, tuple, set)):
            return [fix(v) for v in o]
        if isinstance(o, (date, datetime)):
            return o.isoformat()
        return o
    resp = jsonify(fix(obj))
    resp.headers["Cache-Control"] = "no-store"
    return resp


@app.get("/")
def index():
    return send_from_directory(STATIC, "index.html")


@app.get("/static/<path:name>")
def static_files(name):
    return send_from_directory(STATIC, name)


@app.get("/api/summary")
def summary():
    return _json(A.summary())


@app.get("/api/load")
def load():
    return _json(A.load_series())


@app.get("/api/weekly")
def weekly():
    return _json(A.weekly(min(int(request.args.get("weeks", 52)), 520)))


@app.get("/api/heatmap")
def heatmap():
    return _json(A.heatmap())


@app.get("/api/zones")
def zones():
    return _json(A.zones_weekly(min(int(request.args.get("weeks", 16)), 104)))


@app.get("/api/running")
def running():
    return _json(A.running())


@app.get("/api/cycling")
def cycling():
    return _json(A.cycling())


@app.get("/api/recovery")
def recovery():
    return _json(A.recovery(min(int(request.args.get("days", 365)), 3650)))


@app.get("/api/activities")
def activities():
    return _json(A.activity_list(request.args.get("sport") or None, request.args.get("q") or None,
                                 min(int(request.args.get("limit", 50)), 500), int(request.args.get("offset", 0)),
                                 request.args.get("start") or None, request.args.get("end") or None))


@app.get("/api/activity/<int:act_id>")
def activity(act_id):
    d = A.activity_detail(act_id)
    if d is None:
        abort(404)
    return _json(d)


@app.get("/api/coach")
def coach_api():
    from . import coach
    return _json(coach.suggestions())


@app.get("/api/status")
def status():
    return _json(A.sync_status())


# ------------------------------------------------------------------ gym log
def _gym_call(fn, *args):
    try:
        return _json(fn(*args))
    except ValueError as e:
        return _json({"error": str(e)}), 400


def _body():
    return request.get_json(silent=True) or {}


@app.get("/api/gym")
def gym_state():
    from . import ai, gym
    st = gym.state()
    st["ai"] = {"enabled": config.AI_ENABLED, "model": config.AI_MODEL, "jobs": ai.list_jobs(limit=60)}
    return _json(st)


@app.post("/api/gym/set")
def gym_add_set():
    from . import gym
    return _gym_call(gym.add_set, _body())


@app.put("/api/gym/set/<int:set_id>")
def gym_update_set(set_id):
    from . import gym
    return _gym_call(gym.update_set, set_id, _body())


@app.delete("/api/gym/set/<int:set_id>")
def gym_delete_set(set_id):
    from . import gym
    return _json({"deleted": gym.delete_set(set_id)})


@app.post("/api/gym/day")
def gym_day():
    from . import gym
    return _gym_call(gym.save_day, _body())


@app.post("/api/gym/swap")
def gym_swap():
    from . import gym
    return _gym_call(gym.swap, _body())


@app.post("/api/gym/move")
def gym_move():
    from . import gym
    return _gym_call(gym.move_day, _body())


@app.post("/api/gym/exercise")
def gym_exercise():
    from . import gym
    return _gym_call(gym.save_exercise, _body())


@app.delete("/api/gym/exercise/<ex_id>")
def gym_delete_exercise(ex_id):
    from . import gym
    return _gym_call(gym.delete_exercise, ex_id)


@app.post("/api/gym/workout")
def gym_workout():
    from . import gym
    return _gym_call(gym.save_workout, _body())


@app.delete("/api/gym/workout/<int:wid>")
def gym_delete_workout(wid):
    from . import gym
    return _gym_call(gym.delete_workout, wid)


@app.get("/api/gym/effort")
def gym_effort():
    from . import gym
    return _gym_call(gym.effort, request.args.get("date", ""))


@app.get("/api/gym/ai")
def gym_ai_status():
    from . import ai
    return _json(ai.status())


@app.get("/api/gym/ai/jobs")
def gym_ai_jobs():
    from . import ai
    return _gym_call(ai.list_jobs, request.args.get("date") or None)


@app.post("/api/gym/ai/jobs")
def gym_ai_create():
    from . import ai
    return _gym_call(ai.create_job, _body())


@app.post("/api/gym/ai/jobs/<int:jid>/<action>")
def gym_ai_action(jid, action):
    from . import ai
    fn = {"retry": ai.retry_job, "discard": ai.discard_job, "confirm": ai.confirm_job, "undo": ai.undo_job}.get(action)
    if not fn:
        abort(404)
    return _gym_call(fn, jid)


@app.post("/api/gym/settings")
def gym_settings():
    from . import gym
    return _gym_call(gym.save_settings, _body())


@app.post("/api/sync")
def sync_now():
    lock = config.DATA_DIR / "sync.lock"
    subprocess.Popen([sys.executable, "-m", "garmin_dash", "sync"], cwd=str(config.ROOT),
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    return _json({"started": True, "lock": lock.exists()})


def serve():
    from waitress import serve as wserve
    from . import ai
    print(f"Dashboard on http://{config.HOST}:{config.PORT}")
    try:
        ai.start_worker()     # picks up AI jobs left over from before a restart
    except Exception as e:
        print(f"AI worker not started: {e}")
    wserve(app, host=config.HOST, port=config.PORT, threads=4)
