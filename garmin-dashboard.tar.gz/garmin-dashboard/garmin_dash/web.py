"""Web server: JSON API + the single-page dashboard."""
from __future__ import annotations

import subprocess
import sys
from datetime import date, datetime
from pathlib import Path

from flask import Flask, abort, jsonify, request, send_from_directory

from . import analytics as A
from . import config

STATIC = Path(__file__).parent / "static"
app = Flask(__name__, static_folder=None)
app.json.sort_keys = False


def _json(obj):
    def fix(o):
        if isinstance(o, dict):
            return {str(k): fix(v) for k, v in o.items()}
        if isinstance(o, (list, tuple, set)):
            return [fix(v) for v in o]
        if isinstance(o, (date, datetime)):
            return o.isoformat()
        return o
    resp = jsonify(fix(obj))
    resp.headers["Cache-Control"] = "no-store"
    return resp


@app.get("/")
def index():
    return send_from_directory(STATIC, "index.html")


@app.get("/static/<path:name>")
def static_files(name):
    return send_from_directory(STATIC, name)


@app.get("/api/summary")
def summary():
    return _json(A.summary())


@app.get("/api/load")
def load():
    return _json(A.load_series())


@app.get("/api/weekly")
def weekly():
    return _json(A.weekly(min(int(request.args.get("weeks", 52)), 520)))


@app.get("/api/heatmap")
def heatmap():
    return _json(A.heatmap())


@app.get("/api/zones")
def zones():
    return _json(A.zones_weekly(min(int(request.args.get("weeks", 16)), 104)))


@app.get("/api/running")
def running():
    return _json(A.running())


@app.get("/api/cycling")
def cycling():
    return _json(A.cycling())


@app.get("/api/recovery")
def recovery():
    return _json(A.recovery(min(int(request.args.get("days", 365)), 3650)))


@app.get("/api/activities")
def activities():
    return _json(A.activity_list(request.args.get("sport") or None, request.args.get("q") or None,
                                 min(int(request.args.get("limit", 50)), 500), int(request.args.get("offset", 0))))


@app.get("/api/activity/<int:act_id>")
def activity(act_id):
    d = A.activity_detail(act_id)
    if d is None:
        abort(404)
    return _json(d)


@app.get("/api/coach")
def coach_api():
    from . import coach
    return _json(coach.suggestions())


@app.get("/api/status")
def status():
    return _json(A.sync_status())


@app.post("/api/sync")
def sync_now():
    lock = config.DATA_DIR / "sync.lock"
    subprocess.Popen([sys.executable, "-m", "garmin_dash", "sync"], cwd=str(config.ROOT),
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    return _json({"started": True, "lock": lock.exists()})


def serve():
    from waitress import serve as wserve
    print(f"Dashboard on http://{config.HOST}:{config.PORT}")
    wserve(app, host=config.HOST, port=config.PORT, threads=4)
