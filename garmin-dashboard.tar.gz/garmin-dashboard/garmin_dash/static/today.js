/* Today tab: today's call, recovery, the gym session, cardio options, this week. Uses app.js helpers inside functions. */
(function () {
  "use strict";

  const LEVEL = { green: ["Recovered", "check"], amber: ["Take it easy", "bang"], red: ["Recovery day", "cross"], none: ["No recovery data yet", "info"] };
  const ROW_NAME = { HRV: "HRV", "Resting HR": "Resting HR", Sleep: "Sleep" };
  const SPORT_ICON = { run: "run", ride: "ride", other: "other" };
  const SPORT_VAR = { run: "var(--u-runT)", ride: "var(--u-rideT)", other: "var(--u-ink2)" };

  const capFirst = (t) => (t ? t.charAt(0).toUpperCase() + t.slice(1) : "");
  const tile = (sport) => `<span class="u-tile" style="background:${SPORT_VAR[sport] || SPORT_VAR.other}">${UIC[SPORT_ICON[sport] || "other"]}</span>`;
  const dayLabel = (iso) => fdate(iso, { weekday: "long", day: "numeric", month: "long" });

  function syncedText(ts) {
    if (!ts) return "Not synced yet.";
    const d = new Date(String(ts).replace(" ", "T"));
    const sameDay = d.toDateString() === new Date().toDateString();
    const hm = d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
    return sameDay ? `Synced at ${hm}.` : `Synced ${fdate(ts, { day: "numeric", month: "short" })}, ${hm}.`;
  }

  function fmtVal(f) {
    if (f.unit === "h") { const m = Math.round(f.value * 60); return `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, "0")}`; }
    return `${Math.round(f.value)} ${f.unit}`;
  }

  function readinessCard(rd) {
    const factors = (rd?.factors || []).filter((f) => f.name !== "Training load");
    const known = (rd?.factors || []).filter((f) => f.status !== "none");
    const inRange = known.filter((f) => f.status === "green").length;
    const [label, icon] = LEVEL[rd?.level || "none"] || LEVEL.none;
    const rows = factors.map((f) => {
      const bar = TL.rangeBar(f.value, f.lo, f.hi);
      const viz = bar
        ? `<span class="u-range" aria-hidden="true"><i class="tr"></i><i class="bd" style="left:${bar.lo}%;width:${bar.hi - bar.lo}%"></i><i class="dt ${f.status === "green" ? "" : f.status}" style="left:${bar.val}%"></i></span>`
        : `<span class="td-rtext">${esc(f.text)}</span>`;
      return `<div class="td-rrow"><span>${esc(ROW_NAME[f.name] || f.name)}</span>${viz}<b class="u-num">${bar ? fmtVal(f) : ""}</b></div>`;
    });
    const lb = TL.loadBucket(rd?.ctl, rd?.tsb);
    const meter = lb ? `<span class="u-meter" aria-hidden="true">${TL.LOAD_LABELS.map((_, i) => `<i class="${i === lb.idx ? "on" : ""}"></i>`).join("")}</span>` : `<span class="td-rtext">Not enough training yet.</span>`;
    rows.push(`<div class="td-rrow"><span>Load</span>${meter}<b>${lb ? lb.label : ""}</b></div>`);
    return `<a class="u-card td-ready" href="#/recovery" aria-label="${esc(label)}: ${inRange} of ${known.length} checks in range. Open Recovery.">
      <div class="td-rhead"><span class="u-status ${rd?.level || "none"}">${UIC[icon]}</span><b>${esc(label)}</b><span class="u-c2">${known.length ? `${inRange} of ${known.length} in range` : ""}</span>${UIC.chev.replace("u-ic", "u-ic chev")}</div>
      <div class="td-rows">${rows.join("")}</div>
      <p class="td-note">Shaded: your normal range, from your own recent data.</p></a>`;
  }

  function gymCard(t) {
    const G = window.GYM, g = G.get(), m = WL.model(t, store.get("wm-order:" + t, null));
    if (m.code === "R" || (!m.inPlan && !G.isW(m.code) && !g.days[t] && !m.exercises.length)) return "";
    const day = g.days[t] || {};
    const started = G.setsOn(t).length > 0;
    const st = G.sessionStats(t);
    const sub = m.inPlan ? `Gym, day ${m.day} of 28. Week ${m.week}: ${m.phase}` : "Gym";
    const est = Math.max(15, Math.round((m.setsPlanned * 2.1) / 5) * 5);
    const note = G.notesFor(t)[0];
    const facts = day.done
      ? `<div class="td-facts"><div><b class="u-num">${st.n}</b><span>sets</span></div><div><b class="u-num">${st.vol ? Math.round(st.vol).toLocaleString("de-CH") : "–"}</b><span>kg lifted</span></div>${st.mins ? `<div><b class="u-num">${st.mins}</b><span>minutes</span></div>` : ""}</div>`
      : `<div class="td-facts"><div><b class="u-num">${m.exercises.length}</b><span>exercises</span></div><div><b class="u-num">${m.setsPlanned || "–"}</b><span>sets</span></div>${m.setsPlanned ? `<div><b class="u-num">~${est}</b><span>minutes</span></div>` : ""}</div>`;
    const btn = day.done ? `<a class="u-btn" href="#/workout">See session</a>`
      : `<a class="u-btn ink" href="#/workout">${started ? "Resume session" : "Start session"}</a><button type="button" class="u-btn" data-act="preview">Preview</button>`;
    return `<div class="u-card td-gym">
      <div class="td-gtop"><span class="u-disc" style="width:46px;height:46px;font-size:21px" aria-hidden="true">${esc(m.letter)}</span>
        <div><b>${esc(m.title)}</b><span>${esc(sub)}</span></div>${day.done ? `<span class="td-done">${UIC.check}Done</span>` : ""}</div>
      ${facts}
      ${note && !day.done ? `<p class="td-gnote">${note}</p>` : ""}
      <div class="td-btns">${btn}</div></div>`;
  }

  function cardioCard(co) {
    if (!co) return "";
    // The longest step is the main set; "118–136 bpm (zone 2; …)" reads as "Zone 2, 118–136 bpm".
    const target = (t) => {
      const m = String(t || "").match(/^(.*?)\s*\((zone \d)[^)]*\)\s*$/i);
      return m ? `${capFirst(m[2])}, ${m[1]}` : String(t || "");
    };
    const row = (w) => {
      const main = [...(w.steps || [])].sort((a, b) => (b.min || 0) - (a.min || 0))[0] || { target: "" };
      return `<a class="u-row" href="#/plan">${tile(w.sport)}<span class="rt"><b>${esc(w.title.replace(/\s*\(zone \d\)\s*$/i, ""))}</b><span>${esc(target(main.target))}</span></span><span class="rr">${w.minutes} min</span>${UIC.chev.replace("u-ic", "u-ic chev")}</a>`;
    };
    const opts = [co.run, co.ride].filter(Boolean);
    if (!opts.length) return "";
    const pick = opts.length > 1 ? ", pick one" : "";
    const head = (co.for_tomorrow ? "Tomorrow’s cardio" : co.hard_allowed ? "Cardio" : "Optional cardio") + pick;
    return `<div class="u-list td-cardio"><div class="td-lhead">${head}</div>${opts.map(row).join("")}</div>
      <p class="u-foot">Tap one for the steps, targets and the evidence behind it.</p>`;
  }

  // Monday to Sunday around `iso`, as ISO dates (works without the gym log).
  function weekDates(iso) {
    const [y, m, d] = iso.split("-").map(Number), wd = (new Date(y, m - 1, d).getDay() + 6) % 7;
    return Array.from({ length: 7 }, (_, k) => {
      const x = new Date(y, m - 1, d - wd + k);
      return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, "0")}-${String(x.getDate()).padStart(2, "0")}`;
    });
  }

  function weekCard(t, co, summary) {
    const wk = window.GYM.get() ? TL.gymWeek(window.GYM, t) : null;
    const dates = weekDates(t), first = dates[0], last = dates[6];
    const acts = (summary?.recent || []).filter((a) => a.date >= first && a.date <= last);
    const days = (wk ? wk.days : []).map((d) => {
      const dots = [...new Set(acts.filter((a) => a.date === d.date).map((a) => a.sport))].map((sp) => `<i style="background:${SPORT_VAR[sp] || SPORT_VAR.other}"></i>`).join("");
      return `<div class="td-day ${d.state}${d.today ? " is-today" : ""}"><span>${fdate(d.date, { weekday: "narrow" })}</span><b class="u-num">${esc(d.letter || "")}</b><em>${dots}</em></div>`;
    }).join("");
    const b = TL.weekBudget(co?.context);
    const pills = (n, of, col) => `<span class="u-pills" aria-hidden="true">${Array.from({ length: of }, (_, i) => `<i style="${i < n ? `background:${col}` : ""}"></i>`).join("")}</span>`;
    const rows = [];
    if (co) {
      rows.push(`<div class="td-brow"><div><span>Running</span><span class="u-c2 u-num">${n1(b.run.km)}${b.run.cap ? ` of ${Math.round(b.run.cap)} km` : " km"}</span></div>${b.run.pct != null ? `<span class="u-bar"><i style="width:${b.run.pct}%;background:var(--u-run)"></i></span>` : ""}</div>`);
      rows.push(`<div class="td-brow"><div><span>Cycling</span><span class="u-c2 u-num">${n1(b.ride.h)} h, usually ${n1(b.ride.usual)} h</span></div><span class="u-bar"><i style="width:${b.ride.pct}%;background:var(--u-ride)"></i><b style="left:${b.ride.usualPct}%"></b></span></div>`);
    }
    if (wk && wk.planned) rows.push(`<div class="td-brow"><div><span>Gym sessions</span><span class="u-c2 u-num">${wk.done} of ${wk.planned}</span></div>${pills(Math.min(wk.done, wk.planned), wk.planned, "var(--u-str)")}</div>`);
    if (co && b.hard.max) rows.push(`<div class="td-brow"><div><span>Hard sessions, 7 days</span><span class="u-c2 u-num">${b.hard.done} of ${b.hard.max}</span></div>${pills(Math.min(b.hard.done, b.hard.max), b.hard.max, "var(--u-ink)")}</div>`);
    return `<div class="u-h2row"><h2 class="u-h2">This week</h2><span class="u-c2" style="font-size:13px">${fdate(first, { day: "numeric" })}–${fdate(last, { day: "numeric", month: "long" })}</span></div>
      <div class="u-card td-week">${wk ? `<div class="td-strip" role="img" aria-label="This week's gym plan and activities">${days}</div>` : ""}
      ${rows.length ? `${wk ? '<div class="u-hair" style="margin:14px 0"></div>' : ""}<div class="td-budget">${rows.join("")}</div>` : ""}
      ${b.run.cap ? `<p class="td-note">The running limit is 1.3× your 4-week average, so the week stays within your trend.</p>` : ""}</div>`;
  }

  function highlights(summary) {
    const ins = summary?.insights || [];
    if (!ins.length) return "";
    const ico = { good: ["green", "check"], warn: ["amber", "bang"], info: ["none", "info"] };
    return `<h2 class="u-h2">Highlights</h2>${ins.slice(0, 3).map((i) => {
      const [cls, ic] = ico[i.level] || ico.info;
      return `<div class="u-card td-hl"><span class="u-status ${cls}">${UIC[ic]}</span><div><b>${esc(i.title)}</b><p>${esc(i.text)}</p></div></div>`;
    }).join("")}`;
  }

  function latest(summary) {
    const a = summary?.recent?.[0];
    if (!a) return "";
    const when = fdate(a.start || a.date, { weekday: "long" }) + (a.start ? ", " + String(a.start).slice(11, 16) : "");
    return `<h2 class="u-h2">Latest</h2><div class="u-list"><a class="u-row" href="#/activity/${a.id}">${tile(a.sport)}<span class="rt"><b>${esc(a.name)}</b><span>${esc(when)}</span></span>
      <span class="rr">${a.km ? `${n1(a.km)} km` : ""}<span>${hm(a.secs)}</span></span>${UIC.chev.replace("u-ic", "u-ic chev")}</a></div>`;
  }

  function previewSheet(t) {
    const m = WL.model(t, store.get("wm-order:" + t, null));
    const rows = m.exercises.map((e, i) => `<div class="u-row"><span class="u-disc" style="background:var(--u-fill);color:var(--u-ink2);width:28px;height:28px;font-size:13px">${i + 1}</span>
      <span class="rt"><b>${esc(e.name)}</b><span>${esc(e.chips.join(", "))}</span></span></div>`).join("");
    openSheet(`<div class="sheet-head"><h2>${esc(m.title)}</h2><button type="button" class="sheet-x" aria-label="Close" onclick="closeSheet()">${UIC.close}</button></div>
      <div class="u-list" style="background:var(--u-card2)">${rows || '<p class="u-foot">Nothing planned. Start the session and add exercises.</p>'}</div>
      <div class="td-btns" style="margin-top:14px"><a class="u-btn ink" style="flex:1" href="#/workout" onclick="closeSheet()">Start session</a></div>`);
  }

  async function sync(btn) {
    btn.disabled = true;
    btn.classList.add("td-spin");
    try { await fetch("/api/sync", { method: "POST" }); } catch { /* the page reloads anyway */ }
    setTimeout(() => { cache.clear(); route(); }, 8000);
  }

  async function renderToday() {
    const [co, summary] = await Promise.all([api("/api/coach", true).catch(() => null), api("/api/summary", true).catch(() => null), loadGym(true)]);
    const t = window.GYM.todayIso();
    const g = window.GYM.get();
    pageHead("Today", {
      sub: `${dayLabel(t)}. ${syncedText(summary?.last_sync)}`,
      right: `<button type="button" class="gbtn glass" id="td-sync" aria-label="Sync now">${UIC.sync}</button><a class="gbtn glass" href="#/settings" aria-label="Settings">${UIC.gear}</a>`,
    });
    const code = g ? (g.days[t]?.session || (window.GYM.idxOf(t) >= 0 && window.GYM.idxOf(t) < 28 ? window.GYM.planType(t) : null)) : null;
    const gymDone = !!g?.days[t]?.done;
    const h = TL.headline({ level: co?.readiness?.level, hardAllowed: !!co?.hard_allowed, gym: code, gymDone, forTomorrow: !!co?.for_tomorrow });
    const why = !co ? "Coach data didn't load. Reload the page to try again." : co.hard_allowed ? "Recovery markers are all in range." : co.hard_blockers?.length ? capFirst(co.hard_blockers[0]) + "." : "";
    const gym = g ? gymCard(t) : "";
    app.innerHTML = `<section class="td">
      <p class="td-call u-num">${h.first ? `${esc(h.first)}<br>` : ""}${co ? esc(h.second) : "No cardio advice right now."}</p>
      ${why ? `<p class="td-why">${esc(why)}</p>` : ""}
      ${co ? readinessCard(co.readiness) : ""}
      ${gym || co ? `<h2 class="u-h2">Today’s plan</h2>${gym}${cardioCard(co)}` : ""}
      ${g || co ? weekCard(t, co, summary) : ""}
      ${highlights(summary)}
      ${latest(summary)}
    </section>`;
    $("#td-sync")?.addEventListener("click", (e) => sync(e.currentTarget));
    app.querySelector("[data-act=preview]")?.addEventListener("click", () => previewSheet(t));
  }

  window.renderToday = renderToday;
})();
