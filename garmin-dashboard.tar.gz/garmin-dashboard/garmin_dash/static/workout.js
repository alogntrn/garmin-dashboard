/* Workout mode: one exercise at a time in the full-screen layer #wm, plus the session overview, swap, add,
   describe and finish sheets. Uses app.js globals (esc, store, shell, api, loadGym, openSheet, closeSheet,
   parseTs, fdate) inside functions only, so it can load before app.js. No rest timer, by design. */
(function () {
  "use strict";

  const FIELD = {
    kg: { label: "Weight", unit: "kg", mode: "decimal", max: 500 },
    reps: { label: "Reps", unit: "reps", mode: "numeric", max: 300 },
    secs: { label: "Time", unit: "s", mode: "numeric", max: 3600 },
    mins: { label: "Time", unit: "min", mode: "decimal", max: 600 },
  };
  const SIDE = { R: "right leg", L: "left leg", "": "both legs" };
  const SIDE_SHORT = { R: "Right", L: "Left", "": "Both" };
  const PAIN_RULE = "0–2 train as written. 3–4 hold the weight, go shallower. 5 or more: stop that exercise.";
  const LOOK = { ok: ["green", "check"], high: ["amber", "bang"], low: ["none", "info"], knee: ["red", "bang"], none: ["none", "info"] };

  const W = { open: false, date: null, cur: 0, side: "", vals: {}, rir: null, err: "", fin: null, tick: null, poll: null, lock: null, touch: null, swiped: 0 };

  const layer = () => document.getElementById("wm");
  const GY = () => window.GYM;
  const G = () => window.GYM.get();
  const model = () => window.WL.model(W.date, store.get("wm-order:" + W.date, null));
  const saveCur = () => store.set("wm-cur:" + W.date, W.cur);
  const ic = (name, cls) => (cls ? window.UIC[name].replace('class="u-ic"', `class="u-ic ${cls}"`) : window.UIC[name]);
  const num = (s) => { const t = String(s ?? "").trim().replace(",", "."); if (!t) return null; const x = Number(t); return Number.isFinite(x) ? x : NaN; };
  const fmtNum = (v) => (v == null || Number.isNaN(v) ? "" : String(Math.round(v * 100) / 100));
  const f1 = (v) => String(Math.round(v * 10) / 10);
  const capFirst = (t) => (t ? t.charAt(0).toUpperCase() + t.slice(1) : "");
  const aiOn = () => !!G()?.ai?.enabled;
  const closeBtn = `<button type="button" class="sheet-x" data-act="close" aria-label="Close">${'<svg class="u-ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/></svg>'}</button>`;

  function minutesIn(m) { return m.firstSetAt ? Math.max(1, Math.round((Date.now() - parseTs(m.firstSetAt)) / 60000)) : 0; }
  const clockText = (m) => { const n = minutesIn(m); return n ? `${n} min` : "Not started"; };

  // One-leg exercises count per leg ("Set 2, left leg"); everything else counts straight through.
  function setNumber(ex, s, idx) {
    if (!ex.uni) return idx + 1;
    const sd = s.side || "";
    return ex.logged.slice(0, idx + 1).filter((x) => (x.side || "") === sd).length;
  }
  const nextNumber = (ex, side) => (ex.uni ? ex.logged.filter((x) => (x.side || "") === side).length : ex.logged.length) + 1;
  const logLabel = (ex) => `Log set ${nextNumber(ex, W.side)}${ex.uni ? `, ${SIDE[W.side]}` : ""}`;

  // The next exercise still to do after `from`, wrapping round so a skipped one comes back at the end.
  function nextIdx(m, from) {
    const n = m.exercises.length;
    for (let k = 1; k < n; k++) {
      const i = (from + k) % n, e = m.exercises[i];
      if (e.countable ? !e.prog.done : i > from) return i;
    }
    return -1;
  }

  function resetInputs(ex) {
    W.side = ex && ex.uni ? ex.prog.next || "R" : "";
    W.vals = ex ? window.WL.prefill(ex, W.side) : {};
    W.rir = null;
    W.err = "";
  }

  // ------------------------------------------------------------ pieces
  function stepper(f, v, pre) {
    const F = FIELD[f], st = window.WL.step(f);
    return `<div class="wo-step" data-f="${f}"><label for="${pre}-${f}">${F.label}</label>
      <div class="wo-sc"><button type="button" data-d="-1" aria-label="${F.label} minus ${st} ${F.unit}">${ic("minus")}</button>
      <input id="${pre}-${f}" class="u-num" inputmode="${F.mode}" autocomplete="off" enterkeyhint="done" value="${fmtNum(v)}" placeholder="–">
      <button type="button" data-d="1" aria-label="${F.label} plus ${st} ${F.unit}">${ic("plus")}</button></div>
      <span class="wo-unit">${F.unit}</span></div>`;
  }
  const rirChips = (cur) => `<div class="wo-rir"><span>Reps in reserve<em>Optional</em></span><div class="wo-rirb" role="group" aria-label="Reps in reserve">${[0, 1, 2, 3, 4]
    .map((v) => `<button type="button" data-act="rir" data-rir="${v}" aria-pressed="${cur === v}">${v}</button>`).join("")}</div></div>`;
  const sideSeg = (cur, act) => `<div class="segc wo-side" role="group" aria-label="Side">${["R", "L", ""]
    .map((s) => `<button type="button" data-act="${act}" data-side="${s}" aria-pressed="${cur === s}">${SIDE_SHORT[s]}</button>`).join("")}</div>`;
  const pressOnly = (group, attr, val) => group.querySelectorAll("button").forEach((x) => x.setAttribute("aria-pressed", String(x.dataset[attr] === String(val))));

  function bump(st, d, vals) {
    const f = st.dataset.f, input = st.querySelector("input"), cur = num(input.value);
    const base = cur == null || Number.isNaN(cur) ? (d > 0 ? 0 : null) : cur;
    if (base == null) return;
    const v = Math.min(FIELD[f].max, Math.max(0, Math.round((base + d * window.WL.step(f)) * 100) / 100));
    vals[f] = v;
    input.value = fmtNum(v);
  }

  function showErr(root, msg) {
    let n = root.querySelector(".wo-err");
    if (!n) {
      n = document.createElement("p");
      n.className = "wo-err";
      n.setAttribute("role", "alert");
      const btns = root.querySelector(".wo-btns");
      if (btns) btns.prepend(n);
      else { const a = root.querySelector(".wo-sbtns, .fin-save"); if (a) a.before(n); else root.appendChild(n); }
    }
    n.textContent = msg;
  }

  // Sheets share one panel element, so handlers are assigned as properties and cleared on close.
  const HANDLERS = ["onclick", "oninput", "onpointerdown", "onkeydown", "ontouchstart", "ontouchend"];
  function sheet(html, handlers) {
    const p = openSheet(html, () => { HANDLERS.forEach((h) => { p[h] = null; }); });
    HANDLERS.forEach((h) => { p[h] = handlers[h] || null; });
    return p;
  }

  // ------------------------------------------------------------ exercise view
  function topBar(m) {
    return `<header class="wo-top">
      <button type="button" class="gbtn glass" data-act="min" aria-label="Minimise">${ic("chevd")}</button>
      <button type="button" class="gbtn glass" data-act="ov" aria-label="Session overview">${ic("list")}</button>
      <div class="wo-tt"><b>${esc(m ? m.title : "Workout")}</b><span class="wo-clock">${m ? clockText(m) : ""}</span></div>
      ${m ? `<button type="button" class="gpill glass wo-finish" data-act="finish">Finish</button>` : ""}
    </header>`;
  }

  function progress(m) {
    const segs = m.exercises.map((e, i) => `<i class="${e.countable && e.prog.done ? "done" : ""}${i === W.cur ? " cur" : ""}${e.countable ? "" : " info"}"></i>`).join("");
    const sets = m.setsPlanned ? `${m.setsDone} of ${m.setsPlanned} sets` : `${m.setsDone} ${m.setsDone === 1 ? "set" : "sets"}`;
    return `<button type="button" class="wo-prog" data-act="ov" aria-label="Exercise ${W.cur + 1} of ${m.exercises.length}, ${sets}. Open the session overview.">
      <span class="wo-segs" aria-hidden="true">${segs}</span>
      <span class="wo-pt"><span>Exercise ${W.cur + 1} of ${m.exercises.length}</span><span>${sets}</span></span></button>`;
  }

  function exerciseView(m, ex) {
    const fields = window.WL.fields(ex.kind), info = !fields.length;
    const done = ex.countable && ex.prog.done, nx = nextIdx(m, W.cur), nxEx = nx >= 0 ? m.exercises[nx] : null;
    const head = `<h1 class="wo-name" tabindex="-1">${esc(ex.name)}</h1>
      ${ex.chips.length ? `<div class="wo-chips">${ex.chips.map((c) => `<span class="u-chip">${esc(c)}</span>`).join("")}</div>` : ""}
      ${ex.cue ? `<p class="wo-cue">${esc(ex.cue)}</p>` : ""}
      ${ex.note ? `<p class="wo-note">${esc(ex.note)}</p>` : ""}
      <div class="wo-tools">${info ? "" : `<button type="button" class="wo-link" data-act="swap">${ic("swap")}Swap exercise</button>`}${ex.why ? `<details class="wo-why"><summary>Why this exercise</summary><p>${esc(ex.why)}</p></details>` : ""}</div>`;
    if (info) {
      const btn = nxEx ? `<button type="button" class="u-btn ink" data-act="go" data-go="${nx}">Next: ${esc(nxEx.name)}</button>` : `<button type="button" class="u-btn ink" data-act="finish">Finish session</button>`;
      return `<section class="wo-ex">${head}<div class="wo-btns">${btn}</div></section>`;
    }
    const rows = ex.logged.map((s, i) => `<button type="button" class="wo-set" data-act="edit" data-id="${s.id}" aria-label="Edit set ${setNumber(ex, s, i)}${ex.uni ? ", " + SIDE[s.side || ""] : ""}">
        <span class="wo-sn">Set ${setNumber(ex, s, i)}</span><span class="wo-sv">${ex.uni ? `<em>${SIDE_SHORT[s.side || ""]}</em>` : ""}${esc(GY().setTxt(s))}</span>
        <span class="wo-sr">${s.rir != null ? `RIR ${f1(s.rir)}` : ""}</span>${ic("check", "wo-ok")}</button>`).join("");
    const up = done ? `<div class="wo-up done">${ic("check")}<b>All sets done</b></div>`
      : `<div class="wo-up"><span class="wo-sn">Set ${nextNumber(ex, W.side)}</span><b>Up now</b>${ex.uni ? `<span>${SIDE_SHORT[W.side]}</span>` : ""}</div>`;
    const last = ex.last ? `<p class="wo-last">Last time, ${esc(fdate(ex.last.date, { weekday: "long", day: "numeric", month: "short" }))}: ${esc(ex.last.text)}.</p>` : "";
    const steps = `<div class="wo-steps">${fields.map((f) => stepper(f, W.vals[f], "wo")).join("")}</div>`;
    const upNext = nxEx && !done ? `<button type="button" class="u-card wo-next" data-act="go" data-go="${nx}"><span class="wo-nt"><span class="wo-nl">Up next</span><b>${esc(nxEx.name)}</b>${nxEx.chips.length ? `<span>${esc(nxEx.chips.join(", "))}</span>` : ""}</span>${ic("chev", "chev")}</button>` : "";
    const err = W.err ? `<p class="wo-err" role="alert">${esc(W.err)}</p>` : "";
    const btns = done
      ? `${err}${nxEx ? `<button type="button" class="u-btn ink" data-act="go" data-go="${nx}">Next: ${esc(nxEx.name)}</button>` : `<button type="button" class="u-btn ink" data-act="finish">Finish session</button>`}<button type="button" class="u-btn wo-log" data-act="log">Log an extra set</button>`
      : `${err}<button type="button" class="u-btn ink wo-log" data-act="log">${logLabel(ex)}</button>`;
    return `<section class="wo-ex">${head}<div class="u-card wo-sets">${rows}${up}${last}</div>
      ${ex.uni ? sideSeg(W.side, "side") : ""}${steps}${window.WL.hasRir(ex.kind) ? rirChips(W.rir) : ""}${upNext}
      <div class="wo-btns">${btns}</div></section>`;
  }

  function emptyView(m) {
    const rest = m.code === "R";
    return `<section class="wo-ex wo-empty"><h1 class="wo-name" tabindex="-1">${rest ? "Rest day" : "Nothing planned"}</h1>
      <p class="wo-cue">${rest ? "Today is a rest day in the plan. Add an exercise if you train anyway." : "This day has no exercises yet. Add the first one."}</p>
      <div class="wo-btns"><button type="button" class="u-btn ink" data-act="add">${ic("plus")}Add exercise</button>${aiOn() ? `<button type="button" class="u-btn" data-act="describe">${ic("text")}Describe session</button>` : ""}</div></section>`;
  }

  function render() {
    const el = layer();
    if (!el || !W.open || !W.date) return;
    const m = model();
    if (W.cur >= m.exercises.length) W.cur = Math.max(0, m.exercises.length - 1);
    const ex = m.exercises[W.cur];
    el.innerHTML = `${topBar(m)}<main class="wo-main">${ex ? progress(m) + exerciseView(m, ex) : emptyView(m)}</main>`;
  }

  function go(i) {
    const m = model();
    if (i < 0 || i >= m.exercises.length || i === W.cur) return;
    W.cur = i;
    saveCur();
    resetInputs(m.exercises[i]);
    render();
    layer().scrollTo(0, 0);
  }

  function readInputs() {
    layer().querySelectorAll(".wo-step").forEach((st) => { W.vals[st.dataset.f] = num(st.querySelector("input").value); });
  }

  async function logSet(btn) {
    const ex = model().exercises[W.cur];
    if (!ex) return;
    const fields = window.WL.fields(ex.kind);
    readInputs();
    const bad = fields.find((f) => Number.isNaN(W.vals[f]));
    if (bad) { showErr(layer(), `${FIELD[bad].label} needs a number.`); return; }
    const body = { date: W.date, session: GY().sessOf(W.date), ex: ex.exId, slot: ex.slot, name: GY().def(ex.exId, ex.name).n };
    for (const f of fields) body[f] = W.vals[f];
    if (ex.uni) body.side = W.side;
    if (window.WL.hasRir(ex.kind) && W.rir != null) body.rir = W.rir;
    btn.disabled = true;
    try {
      const row = await GY().post("/api/gym/set", body);
      const g = G();
      g.sets.push(row);
      if (!g.days[W.date]) g.days[W.date] = { date: W.date, session: GY().sessOf(W.date), swaps: {}, extras: [] };
      const both = W.side === "", ex2 = model().exercises[W.cur];
      W.side = ex2.uni ? (both ? "" : ex2.prog.next || "R") : "";
      W.vals = window.WL.prefill(ex2, W.side);
      W.rir = null;
      W.err = "";
      render();
    } catch (err) {
      btn.disabled = false;
      showErr(layer(), err instanceof TypeError ? "Couldn't save the set. Check the connection to the Pi and try again." : `Couldn't save the set: ${err.message}.`);
    }
  }

  function minimise() {
    location.hash = shell.last && shell.last !== "#/workout" ? shell.last : "#/today";
  }

  function onClick(e) {
    const b = e.target.closest("button");
    if (!b || !layer().contains(b)) return;
    const st = b.closest(".wo-step");
    if (st && b.dataset.d) { bump(st, +b.dataset.d, W.vals); return; }
    const act = b.dataset.act, m = W.date ? model() : null, ex = m?.exercises[W.cur];
    if (act === "min") minimise();
    else if (act === "ov") overview();
    else if (act === "finish") finishSheet();
    else if (act === "go") go(+b.dataset.go);
    else if (act === "log") logSet(b);
    else if (act === "edit") editSheet(+b.dataset.id);
    else if (act === "swap" && ex) swapSheet(ex.slot);
    else if (act === "add") addSheet();
    else if (act === "describe") describeSheet();
    else if (act === "side" && ex) { W.side = b.dataset.side; W.vals = window.WL.prefill(ex, W.side); W.err = ""; render(); }
    else if (act === "rir") { const v = +b.dataset.rir; W.rir = W.rir === v ? null : v; pressOnly(b.parentElement, "rir", W.rir); }
  }

  // ------------------------------------------------------------ overview
  function ovRow(e, i) {
    const state = e.countable && e.prog.done ? "done" : i === W.cur ? "cur" : "";
    const detail = e.logged.length ? e.logged.map((s) => (e.uni && s.side ? `${s.side} ` : "") + GY().setTxt(s)).join(", ") : e.chips.join(", ");
    const count = e.countable && e.tally.of ? `${e.tally.done}/${e.tally.of}` : e.logged.length ? String(e.logged.length) : "";
    return `<div class="u-row wo-row ${state}" data-slot="${esc(e.slot)}">
      <span class="wo-mark" aria-hidden="true">${state === "done" ? ic("check") : i + 1}</span>
      <button type="button" class="rt" data-act="jump" data-i="${i}"><b>${esc(e.name)}</b><span>${esc(detail)}</span></button>
      <span class="rr u-num">${count}</span>
      <span class="wo-grip" role="button" tabindex="0" aria-label="Move ${esc(e.name)} with the arrow keys">${ic("grip")}</span>
      ${e.countable ? `<button type="button" class="wo-rowswap" data-act="row-swap" tabindex="-1">Swap</button>` : ""}
    </div>`;
  }

  function overview() {
    if (!W.date) return;
    const m = model(), st = GY().sessionStats(W.date);
    const html = `<div class="sheet-head"><h2>${esc(m.title)}</h2>${closeBtn}</div>
      ${m.inPlan ? `<p class="wo-sub">Day ${m.day} of 28. Week ${m.week}: ${esc(m.phase)}</p>` : ""}
      <div class="wo-stats"><div><b class="u-num">${minutesIn(m) || "–"}</b><span>${minutesIn(m) === 1 ? "minute" : "minutes"}</span></div><div><b class="u-num">${m.setsDone}</b><span>${m.setsPlanned ? `of ${m.setsPlanned} sets` : "sets"}</span></div><div><b class="u-num">${st.vol ? Math.round(st.vol).toLocaleString("de-CH") : "–"}</b><span>kg so far</span></div></div>
      ${m.exercises.length ? `<div class="u-list wo-ov">${m.exercises.map(ovRow).join("")}</div>
      <p class="u-foot">Tap an exercise to jump to it. Drag the handle to change the order, swipe left to swap one.</p>` : ""}
      <div class="wo-sbtns"><button type="button" class="u-btn" data-act="add">${ic("plus")}Add exercise</button>${aiOn() ? `<button type="button" class="u-btn" data-act="describe">${ic("text")}Describe session</button>` : ""}</div>`;
    sheet(html, { onclick: ovClick, onpointerdown: dragStart, onkeydown: gripKey, ontouchstart: rowTouchStart, ontouchend: rowTouchEnd });
  }

  function ovClick(e) {
    const b = e.target.closest("[data-act]");
    if (!b) return;
    const act = b.dataset.act;
    if (act === "close") closeSheet();
    else if (act === "jump") { if (Date.now() - W.swiped < 450) return; closeSheet(); go(+b.dataset.i); }
    else if (act === "row-swap") swapSheet(b.closest(".wo-row").dataset.slot);
    else if (act === "add") addSheet();
    else if (act === "describe") describeSheet();
  }

  function commitOrder(list) {
    const curSlot = model().exercises[W.cur]?.slot;
    store.set("wm-order:" + W.date, [...list.querySelectorAll(".wo-row")].map((r) => r.dataset.slot));
    const m = model();
    W.cur = Math.max(0, m.exercises.findIndex((x) => x.slot === curSlot));
    saveCur();
    list.innerHTML = m.exercises.map(ovRow).join("");
    render();
  }

  function dragStart(e) {
    const grip = e.target.closest(".wo-grip");
    if (!grip) return;
    e.preventDefault();
    const list = grip.closest(".wo-ov"), row = grip.closest(".wo-row");
    row.classList.add("drag");
    const move = (ev) => {
      const after = [...list.querySelectorAll(".wo-row")].filter((r) => r !== row)
        .find((r) => { const b = r.getBoundingClientRect(); return ev.clientY < b.top + b.height / 2; });
      if (after) { if (row.nextElementSibling !== after) list.insertBefore(row, after); }
      else if (list.lastElementChild !== row) list.appendChild(row);
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
      row.classList.remove("drag");
      commitOrder(list);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
  }

  function gripKey(e) {
    const grip = e.target.closest(".wo-grip");
    if (!grip || (e.key !== "ArrowUp" && e.key !== "ArrowDown")) return;
    e.preventDefault();
    const list = grip.closest(".wo-ov"), row = grip.closest(".wo-row"), slot = row.dataset.slot;
    const sib = e.key === "ArrowUp" ? row.previousElementSibling : row.nextElementSibling;
    if (!sib) return;
    if (e.key === "ArrowUp") list.insertBefore(row, sib); else list.insertBefore(sib, row);
    commitOrder(list);
    list.querySelector(`.wo-row[data-slot="${CSS.escape(slot)}"] .wo-grip`)?.focus();
  }

  function rowTouchStart(e) {
    const row = e.target.closest(".wo-row");
    W.touch = row && !e.target.closest(".wo-grip") ? { row, x: e.touches[0].clientX, y: e.touches[0].clientY } : null;
  }
  function rowTouchEnd(e) {
    const s = W.touch;
    W.touch = null;
    if (!s) return;
    const t = e.changedTouches[0], dx = t.clientX - s.x, dy = t.clientY - s.y;
    if (Math.abs(dx) < 40 || Math.abs(dy) > 30) return;
    s.row.parentElement.querySelectorAll(".wo-row.open").forEach((r) => { if (r !== s.row) r.classList.remove("open"); });
    s.row.classList.toggle("open", dx < 0);
    W.swiped = Date.now();
  }

  // ------------------------------------------------------------ swap and add
  async function doSwap(sl, slot, exId, clear, persist) {
    const g = G(), dfn = GY().def(exId);
    const body = { date: W.date, slot, ex: exId, name: dfn.n, session: GY().sessOf(W.date), clear: !!clear };
    if (persist !== undefined) body.persist = persist;
    else if (clear && sl.plan && g.swaps?.[slot]) body.persist = false;
    const res = await GY().post("/api/gym/swap", body);
    g.days[W.date] = res.day;
    g.swaps = res.swaps;
    g.sets.forEach((s) => { if (s.date === W.date && GY().slotOf(s) === slot) { s.ex = exId; s.name = dfn.n; s.slot = slot; } });
  }

  function swapSheet(slot) {
    const ex = model().exercises.find((x) => x.slot === slot);
    if (!ex) return;
    const sl = GY().blocksFor(W.date).find((b) => b.slot === slot) || {};
    const baseName = sl.n || GY().def(ex.base).n;
    const html = `<div class="sheet-head"><h2>Swap exercise</h2>${closeBtn}</div>
      <p class="wo-sub">Instead of ${esc(ex.name)}</p>
      <label class="wo-field"><span>Do this instead</span><select name="ex">${GY().exOptions(ex.exId, ex.alts, false)}</select></label>
      ${sl.plan ? `<label class="wo-chk"><input type="checkbox" name="persist" ${G().swaps?.[slot] ? "checked" : ""}>Every time this exercise comes up</label>` : ""}
      <p class="u-foot">Sets you already logged here move to the new exercise.</p>
      <div class="wo-sbtns"><button type="button" class="u-btn ink" data-act="sw-do">Swap</button>${ex.swapped && !ex.extra ? `<button type="button" class="u-btn" data-act="sw-back">Back to ${esc(baseName)}</button>` : ""}</div>`;
    const p = sheet(html, {
      async onclick(e) {
        const b = e.target.closest("[data-act]");
        if (!b) return;
        if (b.dataset.act === "close") { closeSheet(); return; }
        if (b.dataset.act !== "sw-do" && b.dataset.act !== "sw-back") return;
        const back = b.dataset.act === "sw-back", persist = p.querySelector("input[name=persist]");
        b.disabled = true;
        try {
          await doSwap(sl, slot, back ? ex.base : p.querySelector("select[name=ex]").value, back, back ? undefined : persist ? persist.checked : undefined);
          closeSheet();
          const m = model(), i = m.exercises.findIndex((x) => x.slot === slot);
          if (i === W.cur) resetInputs(m.exercises[i]);
          render();
        } catch (err) { b.disabled = false; showErr(p, `Couldn't swap: ${err.message}.`); }
      },
    });
  }

  function addSheet() {
    const html = `<div class="sheet-head"><h2>Add exercise</h2>${closeBtn}</div>
      <label class="wo-field"><span>Exercise</span><select name="ex"><option value="">Choose an exercise</option>${GY().exOptions("", [], false)}</select></label>
      <p class="u-foot">It goes to the end of today’s list. New exercises are made on the Strength page.</p>
      <div class="wo-sbtns"><button type="button" class="u-btn ink" data-act="add-do">Add</button></div>`;
    const p = sheet(html, {
      async onclick(e) {
        const b = e.target.closest("[data-act]");
        if (!b) return;
        if (b.dataset.act === "close") { closeSheet(); return; }
        if (b.dataset.act !== "add-do") return;
        const exId = p.querySelector("select[name=ex]").value;
        if (!exId) { showErr(p, "Choose an exercise first."); return; }
        b.disabled = true;
        try {
          const g = G();
          if (!GY().blocksFor(W.date).some((x) => x.slot === exId)) {
            g.days[W.date] = await GY().post("/api/gym/day", { date: W.date, extras: [...(g.days[W.date]?.extras || []), exId] });
          }
          closeSheet();
          const m = model(), i = m.exercises.findIndex((x) => x.slot === exId);
          if (i >= 0) { W.cur = i; saveCur(); resetInputs(m.exercises[i]); }
          render();
        } catch (err) { b.disabled = false; showErr(p, `Couldn't add it: ${err.message}.`); }
      },
    });
  }

  // ------------------------------------------------------------ describe the session (AI on the Pi)
  const liveJobs = () => (G().ai?.jobs || []).some((j) => j.date === W.date && (j.status === "queued" || j.status === "running"));
  const jobsHTML = () => (G().ai?.jobs || []).filter((j) => j.date === W.date).map(GY().jobHTML).join("");
  function drawJobs() { const el = document.querySelector("#sheet .wo-jobs"); if (el) el.innerHTML = jobsHTML(); }

  async function reloadGym() {
    await loadGym(true);
    render();
  }

  function pollJobs() {
    clearTimeout(W.poll);
    if (!W.open || !liveJobs()) return;
    W.poll = setTimeout(async () => {
      try {
        const jobs = await api(`/api/gym/ai/jobs?date=${W.date}`, true);
        const before = new Map((G().ai.jobs || []).filter((j) => j.date === W.date).map((j) => [j.id, j.status]));
        const logged = jobs.some((j) => j.status === "done" && before.get(j.id) !== "done");
        G().ai.jobs = [...jobs, ...(G().ai.jobs || []).filter((j) => j.date !== W.date)];
        if (logged) await reloadGym();
        drawJobs();
      } catch { /* the Pi is busy; the next tick tries again */ }
      pollJobs();
    }, 5000);
  }

  function describeSheet() {
    const html = `<div class="sheet-head"><h2>Describe the session</h2>${closeBtn}</div>
      <p class="wo-sub">Write what you did in your own words. The Pi turns it into sets, and you can undo it.</p>
      <textarea class="wo-ai" rows="5" aria-label="What you did" placeholder="Leg press right 60 kg 10, 10, 9. Left 55 kg 10, 10."></textarea>
      <div class="wo-sbtns"><button type="button" class="u-btn ink" data-act="ai-send">Send</button></div>
      <div class="wo-jobs">${jobsHTML()}</div>`;
    const p = sheet(html, {
      async onclick(e) {
        const b = e.target.closest("[data-act]");
        if (!b) return;
        const act = b.dataset.act;
        if (act === "close") { closeSheet(); return; }
        try {
          if (act === "ai-send") {
            const ta = p.querySelector(".wo-ai"), text = ta.value.trim();
            if (!text) { showErr(p, "Write a few words about what you did first."); return; }
            b.disabled = true;
            const j = await GY().post("/api/gym/ai/jobs", { date: W.date, text, ctx: GY().aiCtx(W.date) });
            G().ai.jobs = [j, ...(G().ai.jobs || [])];
            ta.value = "";
            b.disabled = false;
          } else if (act === "ai-edit") {
            const j = (G().ai.jobs || []).find((x) => x.id === +b.dataset.id);
            p.querySelector(".wo-ai").value = j ? j.text : "";
            return;
          } else if (act.startsWith("ai-")) {
            const action = act.slice(3), j = await GY().post(`/api/gym/ai/jobs/${b.dataset.id}/${action}`, {});
            G().ai.jobs = (G().ai.jobs || []).map((x) => (x.id === j.id ? j : x));
            if (action === "undo" || action === "confirm") await reloadGym();
          } else return;
          drawJobs();
          pollJobs();
        } catch (err) { b.disabled = false; showErr(p, err.message); }
      },
    });
    pollJobs();
  }

  // ------------------------------------------------------------ edit a logged set
  function editSheet(id) {
    const ex = model().exercises[W.cur], s = G().sets.find((x) => x.id === id);
    if (!ex || !s) return;
    const n = setNumber(ex, s, ex.logged.findIndex((x) => x.id === id)), fields = window.WL.fields(ex.kind), rirOk = window.WL.hasRir(ex.kind);
    const vals = { kg: s.kg ?? null, reps: s.reps ?? null, secs: s.secs ?? null, mins: s.mins ?? null };
    let side = s.side || "", rir = s.rir ?? null;
    const html = `<div class="sheet-head"><h2>Set ${n}${ex.uni ? `, ${SIDE[side]}` : ""}</h2>${closeBtn}</div>
      <p class="wo-sub">${esc(ex.name)}</p>
      ${ex.uni ? sideSeg(side, "es-side") : ""}
      <div class="wo-steps">${fields.map((f) => stepper(f, vals[f], "es")).join("")}</div>
      ${rirOk ? rirChips(rir) : ""}
      <div class="wo-sbtns"><button type="button" class="u-btn ink" data-act="es-save">Save</button><button type="button" class="u-btn" data-act="es-del">Delete set</button><button type="button" class="u-btn" data-act="close">Cancel</button></div>`;
    const p = sheet(html, {
      oninput(e) { const st = e.target.closest(".wo-step"); if (st) vals[st.dataset.f] = num(e.target.value); },
      async onclick(e) {
        const b = e.target.closest("button");
        if (!b) return;
        const st = b.closest(".wo-step");
        if (st && b.dataset.d) { bump(st, +b.dataset.d, vals); return; }
        const act = b.dataset.act;
        if (act === "close") { closeSheet(); return; }
        if (act === "es-side") { side = b.dataset.side; pressOnly(b.parentElement, "side", side); return; }
        if (act === "rir") { const v = +b.dataset.rir; rir = rir === v ? null : v; pressOnly(b.parentElement, "rir", rir); return; }
        if (act === "es-del" && !b.classList.contains("confirm")) { b.classList.add("confirm"); b.textContent = "Tap again to delete"; return; }
        if (act !== "es-save" && act !== "es-del") return;
        b.disabled = true;
        try {
          if (act === "es-save") {
            const bad = fields.find((f) => Number.isNaN(vals[f]));
            if (bad) throw new Error(`${FIELD[bad].label} needs a number`);
            const body = { side };
            for (const f of fields) body[f] = vals[f];
            if (rirOk) body.rir = rir;
            Object.assign(s, await GY().post("/api/gym/set/" + id, body, "PUT"));
          } else {
            await GY().post("/api/gym/set/" + id, null, "DELETE");
            const g = G();
            g.sets = g.sets.filter((x) => x.id !== id);
          }
          closeSheet();
          render();
        } catch (err) { b.disabled = false; showErr(p, `Couldn't save: ${err.message}.`); }
      },
    });
  }

  // ------------------------------------------------------------ finish
  const scale = (cur) => Array.from({ length: 11 }, (_, v) => `<button type="button" data-v="${v}" aria-pressed="${cur === v}">${v}</button>`).join("");
  const effLabel = (v) => (v == null ? "" : `${v}, ${GY().CR10[v]}`);
  const painLabel = (v) => (v == null ? "" : `${v}, ${v <= 2 ? "train as written" : v <= 4 ? "hold the weight, go shallower" : "stop that exercise"}`);

  function prText(p) {
    if (p.unit === "reps") return `${f1(p.today)} reps, was ${f1(p.prev)}.`;
    const label = p.label === "est. 1RM" ? "Estimated 1-rep max" : capFirst(p.label);
    return `${label} ${f1(p.today)} ${p.unit}, was ${f1(p.prev)} ${p.unit}.`;
  }

  // The verdict reads effort and knee pain from the day record, so the draft values are put in place just for the check.
  function verdictHTML() {
    const g = G(), t = W.date, orig = g.days[t];
    g.days[t] = { ...(orig || { date: t }), rpe: W.fin.rpe, pain: W.fin.pain };
    let v;
    try { v = GY().verdict(GY().rirCheck(t), GY().rpeCheck(t), null, GY().kneeCheck(t)); } finally { if (orig) g.days[t] = orig; else delete g.days[t]; }
    const [cls, , title] = v;
    const text = cls === "none" ? "Pick how hard it was below, or add reps in reserve to a few sets next time." : v[3];
    const [look, icon] = LOOK[cls] || LOOK.none;
    return `<span class="u-status ${look}">${ic(icon)}</span><div><b>${esc(title)}</b><p>${esc(text)}</p></div>`;
  }

  function finishSheet() {
    if (!W.date) return;
    const t = W.date, day = G().days[t] || {}, m = model(), st = GY().sessionStats(t);
    W.fin = { rpe: day.rpe ?? null, pain: day.pain ?? null };
    const mins = st.mins || minutesIn(m);
    const bests = (st.prs || []).slice(0, 3).map((p) => `<div class="fin-row"><span class="u-status green">${ic("trend")}</span><div><b>New best: ${esc(p.n)}${p.side ? (p.side === "R" ? ", right" : ", left") : ""}</b><p>${esc(prText(p))}</p></div></div>`).join("");
    const html = `<div class="sheet-head"><h2>Finish ${esc(m.title)}</h2>${closeBtn}</div>
      <div class="wo-stats"><div><b class="u-num">${mins || "–"}</b><span>${mins === 1 ? "minute" : "minutes"}</span></div><div><b class="u-num">${st.n}</b><span>sets</span></div><div><b class="u-num">${st.vol ? Math.round(st.vol).toLocaleString("de-CH") : "–"}</b><span>kg lifted</span></div></div>
      ${bests}
      <div class="fin-row fin-verdict">${verdictHTML()}</div>
      <div class="fin-q"><div class="fin-qh"><b id="fin-eff-h">How hard was it?</b><span class="fin-eff-l">${effLabel(W.fin.rpe)}</span></div><div class="fin-scale fin-eff" role="group" aria-labelledby="fin-eff-h">${scale(W.fin.rpe)}</div></div>
      <div class="fin-q"><div class="fin-qh"><b id="fin-pain-h">Knee pain</b><span class="fin-pain-l">${painLabel(W.fin.pain)}</span></div><div class="fin-scale fin-pain" role="group" aria-labelledby="fin-pain-h">${scale(W.fin.pain)}</div><p class="u-foot fin-rule">${PAIN_RULE}</p></div>
      <label class="fin-q"><b>Note</b><textarea class="fin-note" rows="3" placeholder="Anything worth remembering next time">${esc(day.note || "")}</textarea></label>
      <button type="button" class="u-btn ink fin-save" data-act="fin-save">Save session</button>`;
    const p = sheet(html, {
      async onclick(e) {
        const b = e.target.closest("button");
        if (!b) return;
        if (b.dataset.act === "close") { closeSheet(); return; }
        const grp = b.closest(".fin-scale");
        if (grp) {
          const key = grp.classList.contains("fin-eff") ? "rpe" : "pain", v = +b.dataset.v;
          W.fin[key] = W.fin[key] === v ? null : v;
          pressOnly(grp, "v", W.fin[key]);
          p.querySelector(key === "rpe" ? ".fin-eff-l" : ".fin-pain-l").textContent = key === "rpe" ? effLabel(W.fin.rpe) : painLabel(W.fin.pain);
          p.querySelector(".fin-verdict").innerHTML = verdictHTML();
          return;
        }
        if (b.dataset.act !== "fin-save") return;
        b.disabled = true;
        try {
          G().days[t] = await GY().post("/api/gym/day", { date: t, done: true, rpe: W.fin.rpe, pain: W.fin.pain, note: p.querySelector(".fin-note").value, session: GY().sessOf(t) });
          closeSheet();
          location.hash = "#/today";
        } catch (err) { b.disabled = false; showErr(p, `Couldn't save the session: ${err.message}.`); }
      },
    });
  }

  // ------------------------------------------------------------ open / close
  async function lockScreen() {
    try { if (W.open && navigator.wakeLock && document.visibilityState === "visible") W.lock = await navigator.wakeLock.request("screen"); } catch { W.lock = null; }
  }

  async function open() {
    const el = layer();
    if (!W.open) {
      W.open = true;
      el.hidden = false;
      document.body.classList.add("wm-open");
      el.innerHTML = `${topBar(null)}<div class="loading">Loading…</div>`;
      clearInterval(W.tick);
      W.tick = setInterval(() => { const c = layer().querySelector(".wo-clock"); if (c && W.date) c.textContent = clockText(model()); }, 30000);
      lockScreen();
    }
    const g = await loadGym(true);
    if (!W.open) return;
    if (!g) { el.innerHTML = `${topBar(null)}<main class="wo-main"><p class="wo-err" role="alert">Couldn't load today’s session. Check the connection to the Pi, then reload the page.</p></main>`; return; }
    W.date = GY().todayIso();
    const m = model(), saved = store.get("wm-cur:" + W.date, null);
    W.cur = m.exercises.length ? Math.max(0, Math.min(m.exercises.length - 1, Number.isInteger(saved) ? saved : window.WL.firstOpen(m))) : 0;
    resetInputs(m.exercises[W.cur]);
    render();
    el.scrollTo(0, 0);
    el.querySelector(".wo-name")?.focus({ preventScroll: true });
    if (liveJobs()) pollJobs();
  }

  function close() {
    if (!W.open) return;
    W.open = false;
    const el = layer();
    el.hidden = true;
    el.innerHTML = "";
    document.body.classList.remove("wm-open");
    clearInterval(W.tick);
    clearTimeout(W.poll);
    if (W.lock) { W.lock.release().catch(() => {}); W.lock = null; }
    closeSheet();
  }

  // ------------------------------------------------------------ wiring (the layer exists before this script runs)
  const el = layer();
  el.addEventListener("click", onClick);
  el.addEventListener("input", (e) => { const st = e.target.closest(".wo-step"); if (st) W.vals[st.dataset.f] = num(e.target.value); });
  el.addEventListener("keydown", (e) => { if (e.key === "Enter" && e.target.matches(".wo-step input")) { e.preventDefault(); e.target.blur(); } });
  el.addEventListener("touchstart", (e) => {
    W.touch = e.target.closest(".wo-steps, .wo-rir, .segc, input, select, textarea, details") ? null : { x: e.touches[0].clientX, y: e.touches[0].clientY };
  }, { passive: true });
  el.addEventListener("touchend", (e) => {
    const s = W.touch;
    W.touch = null;
    if (!s || !W.open) return;
    const t = e.changedTouches[0], dx = t.clientX - s.x, dy = t.clientY - s.y;
    if (Math.abs(dx) > 70 && Math.abs(dy) < 45) go(W.cur + (dx < 0 ? 1 : -1));
  }, { passive: true });
  document.addEventListener("visibilitychange", () => { if (W.open && document.visibilityState === "visible") lockScreen(); });

  window.Workout = { open, close, render, isOpen: () => W.open };
})();
