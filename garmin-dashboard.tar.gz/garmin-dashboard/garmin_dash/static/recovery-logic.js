/* Recovery tab: pure logic (no DOM), unit-tested in tests/js/recovery-logic.test.js. */
(function () {
  "use strict";

  const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const dayNum = (iso) => { const [y, m, d] = iso.split("-").map(Number); return Date.UTC(y, m - 1, d) / 86400000; };
  const short = (iso) => `${+iso.slice(8, 10)} ${MON[+iso.slice(5, 7) - 1]}`;
  const has = (v) => v != null && !Number.isNaN(+v);

  // The page's subtitle: "last night" only while the newest data really is from last night.
  function fresh(latestIso, todayIso) {
    if (!latestIso) return "No wellness data yet.";
    return dayNum(todayIso) - dayNum(latestIso) <= 1
      ? "Last night, compared with your normal range."
      : `Latest data from ${short(latestIso)}, compared with your normal range.`;
  }

  // Linear-interpolated percentile of a sorted array (p in 0..1).
  function pct(sorted, p) {
    const i = p * (sorted.length - 1), lo = Math.floor(i), hi = Math.ceil(i);
    return sorted[lo] + (sorted[hi] - sorted[lo]) * (i - lo);
  }

  // Usual range for metrics without a coach check: 10th to 90th percentile (eight days in ten) of the `n` days before
  // the newest week, so a bad week doesn't widen its own yardstick. Null with fewer than 14 such days.
  function normal(rows, key, n = 60) {
    const withV = (rows || []).filter((r) => has(r[key]));
    if (!withV.length) return null;
    const last = dayNum(withV[withV.length - 1].date);
    const vals = withV.filter((r) => { const age = last - dayNum(r.date); return age >= 7 && age < 7 + n; }).map((r) => +r[key]).sort((a, b) => a - b);
    if (vals.length < 14) return null;
    const r1 = (x) => Math.round(x * 10) / 10;
    return { lo: r1(pct(vals, 0.1)), hi: r1(pct(vals, 0.9)) };
  }

  function status(value, range) {
    if (!has(value) || !range) return null;
    return value < range.lo ? "below" : value > range.hi ? "above" : "in";
  }

  // Names inside a sentence; capitalised again at its start.
  const MID = { "HRV": "HRV", "Resting HR": "resting HR", "Sleep": "sleep" };
  const mid = (n) => MID[n] || n.toLowerCase();
  const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
  const list = (xs) => (xs.length < 2 ? xs.join("") : `${xs.slice(0, -1).join(", ")} and ${xs[xs.length - 1]}`);
  const COUNT = { 2: "Both checks are", 3: "All three checks are", 4: "All four checks are" };

  // Headline from the coach's readiness factors (the same checks as Today).
  function headline(factors) {
    const fs = (factors || []).filter((f) => f.name !== "Training load");
    const known = fs.filter((f) => f.status && f.status !== "none"), unknown = fs.filter((f) => !f.status || f.status === "none");
    if (!known.length) return { call: "Not enough recent data for a check.", why: "Wear the watch at night: the checks need about three weeks of nights." };
    const out = known.filter((f) => f.status !== "green");
    if (out.length) {
      return { call: `${cap(list(out.map((f) => mid(f.name))))} ${out.length > 1 ? "are" : "is"} outside your normal range.`, why: out[0].text || "" };
    }
    const more = unknown.length ? `${cap(list(unknown.map((f) => mid(f.name))))} ${unknown.length > 1 ? "need" : "needs"} more data.` : "";
    if (known.length === 1) return { call: `${cap(mid(known[0].name))} is in your normal range.`, why: more };
    return {
      call: `${COUNT[known.length] || "All checks are"} in your normal range.`,
      why: [`${cap(list(known.map((f) => mid(f.name))))}, against your own recent data.`, more].filter(Boolean).join(" "),
    };
  }

  const strength = (r) => (Math.abs(r) < 0.3 ? "a weak link" : Math.abs(r) < 0.5 ? "a moderate link" : "a strong link");
  const linked = (r) => has(r) && Math.abs(r) >= 0.1;

  // "Patterns in your data": the correlations from /api/recovery in plain sentences; missing ones are left out.
  function patterns(corr) {
    const k = corr || {}, out = [];
    if (has(k.hrv_after_hard) && has(k.hrv_after_easy)) {
      const d = k.hrv_after_easy - k.hrv_after_hard;
      out.push(Math.abs(d) < 1
        ? "HRV after your hardest days is about the same as after other days."
        : `After your hardest days, HRV is about ${Math.round(Math.abs(d))} ms ${d > 0 ? "lower" : "higher"} the next night.`);
    }
    if (has(k.sleep_vs_hrv)) {
      out.push(linked(k.sleep_vs_hrv) ? `Longer sleep goes with ${k.sleep_vs_hrv > 0 ? "higher" : "lower"} HRV, ${strength(k.sleep_vs_hrv)}.` : "Sleep length and HRV show no clear link.");
    }
    if (has(k.load_vs_next_hrv)) {
      out.push(linked(k.load_vs_next_hrv)
        ? `Harder days go with ${k.load_vs_next_hrv < 0 ? "lower" : "higher"} HRV the next night, ${strength(k.load_vs_next_hrv)}.`
        : "Training load and next-night HRV show no clear link.");
    }
    if (has(k.load_vs_next_rhr)) {
      out.push(linked(k.load_vs_next_rhr)
        ? `Harder days go with a ${k.load_vs_next_rhr > 0 ? "higher" : "lower"} resting HR the next day, ${strength(k.load_vs_next_rhr)}.`
        : "Training load and next-day resting HR show no clear link.");
    }
    return out;
  }

  window.RL = { fresh, normal, status, headline, patterns, short };
})();
