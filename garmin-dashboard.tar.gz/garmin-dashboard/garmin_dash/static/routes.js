/* Hash routes for the four-tab shell: pure, unit-tested in tests/js/router.test.js. */
(function () {
  "use strict";

  const SEGMENTS = ["overview", "run", "ride", "strength"];
  const SIMPLE = { today: "today", plan: "today", workout: "today", activities: "activities", recovery: "recovery" };

  function resolveRoute(hash, { sessionOpen = false } = {}) {
    const [, page = "", a = "", b = ""] = String(hash || "").split("/");
    if (!page || page === "today") return { tab: "today", page: "today" };
    if (SIMPLE[page]) return { tab: SIMPLE[page], page };
    switch (page) {
      case "activity": return { tab: "activities", page: "activity", arg: a };
      case "gym-session": return a ? { tab: "activities", page: "gym-session", arg: a } : { redirect: "#/activities" };
      case "settings": return { tab: null, page: "settings" };
      case "progress":
        if (!SEGMENTS.includes(a)) return { redirect: "#/progress/overview" };
        return b ? { tab: "progress", page: "progress", seg: a, arg: b } : { tab: "progress", page: "progress", seg: a };
      // pages of the old eight-tab site
      case "overview": return { redirect: "#/today" };
      case "running": return { redirect: "#/progress/run" };
      case "cycling": return { redirect: "#/progress/ride" };
      case "status": return { redirect: "#/settings" };
      case "gym": return { redirect: a ? `#/progress/strength/${a}` : sessionOpen ? "#/workout" : "#/today" };
      default: return { redirect: "#/today" };
    }
  }

  window.resolveRoute = resolveRoute;
})();
