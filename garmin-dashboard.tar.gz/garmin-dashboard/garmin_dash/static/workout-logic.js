/* Workout mode rules on top of window.GYM: no DOM, unit-tested in tests/js/workout-logic.test.js. */
(function () {
  "use strict";

  const STEP = { kg: 2.5, reps: 1, secs: 5, mins: 1 };
  const FIELDS = { kg: ["kg", "reps"], reps: ["reps", "kg"], hold: ["kg", "secs"], secs: ["secs"], min: ["mins"], info: [] };

  const step = (field) => STEP[field] || 1;
  const fields = (kind) => FIELDS[kind] || FIELDS.kg;
  const hasRir = (kind) => kind === "kg" || kind === "reps";
  const countable = (dfn) => dfn.count !== false && dfn.kind !== "info";

  function chips(sl, dfn) {
    const G = window.GYM, out = [];
    const p = G.parseSets(sl.sets);
    if (p) {
      if (p.all != null) out.push(dfn.uni ? `${p.all} sets per leg` : `${p.all} ${p.all === 1 ? "set" : "sets"}`);
      else if (p.R != null && p.R === p.L) out.push(`${p.R} sets per leg`);
      else out.push(["R", "L"].filter((s) => p[s] != null).map((s) => `${s} ${p[s]}`).join(" · ") + " sets");
    }
    if (sl.reps) out.push(/^[\d\s–-]+$/.test(String(sl.reps)) ? `${sl.reps} reps` : String(sl.reps));
    if (sl.rir) out.push(sl.rir[0] === "RIR" ? `RIR ${sl.rir[1]}` : `Effort ${sl.rir[1]}`);
    return out;
  }

  function lastText(prev) {
    if (!prev) return null;
    const G = window.GYM, uni = prev.sets.some((s) => s.side);
    const parts = ["R", "L", ""].map((sd) => {
      const l = prev.sets.filter((s) => (s.side || "") === sd);
      if (!l.length) return "";
      const label = sd === "R" ? "right " : sd === "L" ? "left " : uni ? "both " : "";
      return label + l.map(G.setTxt).join(", ");
    }).filter(Boolean);
    return { date: prev.date, text: parts.join("; ") };
  }

  function exerciseFor(d, sl) {
    const G = window.GYM, st = G.get();
    const logged = G.setsOn(d).filter((s) => G.slotOf(s) === sl.slot);
    const exId = sl.extra ? (st.days[d]?.swaps?.[sl.slot] || logged[0]?.ex || sl.slot) : G.effEx(d, sl);
    const dfn = G.def(exId, logged[0]?.name);
    const swapped = !sl.extra && exId !== sl.base;
    const prog = G.slotProgress(sl, dfn, logged);
    const need = G.parseSets(sl.sets);
    const side = (s) => s.side || "";
    const both = logged.filter((s) => !side(s)).length;
    const cR = logged.filter((s) => side(s) === "R").length + both;
    const cL = logged.filter((s) => side(s) === "L").length + both;
    let count = logged.length, of = null;
    if (need && need.all != null) { count = dfn.uni ? (prog.next === "L" ? cL : cR) : logged.length; of = need.all; }
    else if (need) { const sd = prog.next || "R"; count = sd === "R" ? cR : cL; of = need[sd] ?? 0; }
    const total = !need ? null : need.all != null ? need.all * (dfn.uni ? 2 : 1) : (need.R || 0) + (need.L || 0);
    const tallyDone = dfn.uni ? cR + cL : logged.length;
    const prev = G.prevSets(exId, d);
    return {
      slot: sl.slot, exId, name: !swapped && sl.n ? sl.n : dfn.n, kind: dfn.kind, uni: !!dfn.uni, tag: sl.tag || "", extra: !!sl.extra,
      swapped, base: sl.base, alts: sl.alts || [], countable: countable(dfn),
      chips: sl.extra ? [] : chips(sl, dfn), note: sl.note || "", cue: sl.cue || dfn.note || "", why: sl.why || "", rest: sl.rest || "", tempo: sl.tempo || "",
      need, logged, prog: { ...prog, count, of }, tally: { done: tallyDone, of: total }, prev, last: lastText(prev),
    };
  }

  function applyOrder(exercises, order) {
    if (!order || !order.length) return exercises;
    const rank = new Map(order.map((s, i) => [s, i]));
    return exercises
      .map((e, i) => ({ e, i }))
      .sort((a, b) => (rank.has(a.e.slot) ? rank.get(a.e.slot) : 1e6 + a.i) - (rank.has(b.e.slot) ? rank.get(b.e.slot) : 1e6 + b.i))
      .map((x) => x.e);
  }

  function model(d, order) {
    const G = window.GYM;
    const code = G.sessOf(d), i = G.idxOf(d);
    const inPlan = i >= 0 && i < 28 && !!G.PLAN[code];
    const exercises = applyOrder(G.blocksFor(d).map((sl) => exerciseFor(d, sl)), order);
    const counted = exercises.filter((e) => e.countable);
    const times = G.setsOn(d).map((s) => s.created_at).filter(Boolean).sort();
    return {
      date: d, code, title: G.sessName(code),
      letter: code === "R" ? "–" : G.isW(code) ? (G.sessName(code).trim().charAt(0) || "W").toUpperCase() : code,
      day: inPlan ? i + 1 : null, week: inPlan ? G.weekOf(d) : null, phase: inPlan ? G.PH[G.weekOf(d) - 1] : null, inPlan,
      exercises, done: counted.filter((e) => e.prog.done).length, total: counted.length,
      setsDone: counted.reduce((a, e) => a + e.tally.done, 0), setsPlanned: counted.reduce((a, e) => a + (e.tally.of || 0), 0),
      firstSetAt: times[0] || null,
    };
  }

  // A fresh session starts at the top (the primer comes first). Mid-session: the first exercise still to do,
  // planned or added, primers included; info cards are skipped.
  function firstOpen(m) {
    if (!m.exercises.length) return -1;
    if (!m.exercises.some((e) => e.logged.length)) return 0;
    const k = m.exercises.findIndex((e) => e.kind !== "info" && (e.need ? !e.prog.done : !e.logged.length));
    return k >= 0 ? k : m.exercises.length - 1;
  }

  const pick = (s) => (s ? { kg: s.kg ?? null, reps: s.reps ?? null, secs: s.secs ?? null, mins: s.mins ?? null, rir: s.rir ?? null } : null);

  function prefill(ex, side) {
    const sd = side ?? ex.prog.next ?? "";
    const on = (s) => (s.side || "") === sd;
    const today = [...ex.logged].reverse().find(on);
    const prevSame = ex.prev?.sets.find(on);
    return pick(today) || pick(prevSame) || pick(ex.prev?.sets[0]) || pick(ex.logged[ex.logged.length - 1]) || { kg: null, reps: null, secs: null, mins: null, rir: null };
  }

  window.WL = { model, firstOpen, prefill, applyOrder, chips, step, fields, hasRir };
})();
