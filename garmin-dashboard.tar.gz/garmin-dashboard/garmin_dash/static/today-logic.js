/* Today tab rules: no DOM, unit-tested in tests/js/today-logic.test.js. */
(function () {
  "use strict";

  const GYM_FIRST = { A: "Leg day.", C: "Leg day.", B: "Upper-body day.", R: "Rest day." };

  // Spec §6: one sentence from the gym plan (or recovery), one from the cardio gate.
  function headline({ level, hardAllowed, gym, gymDone = false, forTomorrow = false }) {
    const cardio = hardAllowed ? "Green light for a hard session." : "Keep cardio easy.";
    if (gymDone || (forTomorrow && !gym)) {
      return { first: "Done for today.", second: "Tomorrow: " + cardio.charAt(0).toLowerCase() + cardio.slice(1) };
    }
    const first = level === "red" ? "Recovery day." : GYM_FIRST[gym] || null;
    return { first, second: cardio };
  }

  const LOAD_LABELS = ["Well below", "Below", "Steady", "Above", "Well above"];

  // Acute (7-day) against chronic (42-day) load, as Apple-style five steps.
  function loadBucket(ctl, tsb) {
    if (ctl == null || tsb == null || ctl <= 5) return null;
    const ratio = (ctl - tsb) / ctl;
    const idx = ratio < 0.8 ? 0 : ratio < 0.95 ? 1 : ratio <= 1.15 ? 2 : ratio <= 1.3 ? 3 : 4;
    return { idx, label: LOAD_LABELS[idx], ratio };
  }

  const missing = (v) => v == null || Number.isNaN(+v);

  // Positions (percent) for a value against its normal band, on a domain padded by the band width.
  function rangeBar(value, lo, hi) {
    if (missing(value) || missing(lo) || missing(hi)) return null;
    const w = hi - lo || Math.max(1, Math.abs(hi) * 0.1);
    const min = lo - w, max = hi + w;
    const pct = (x) => Math.min(97, Math.max(3, ((x - min) / (max - min)) * 100));
    return { lo: pct(lo), hi: pct(hi), val: pct(value) };
  }

  function weekBudget(ctx) {
    const c = ctx || {};
    const km = c.run_week_km || 0, cap = c.run_week_cap || null;
    const h = c.ride_week_h || 0, usual = c.ride_chronic_h || 0;
    const scale = Math.max(h, usual) * 1.3 || 1;
    return {
      run: { km, cap, pct: cap ? Math.min(100, (km / cap) * 100) : null },
      ride: { h, usual, pct: Math.min(100, (h / scale) * 100), usualPct: (usual / scale) * 100 },
      hard: { done: c.hard_7d ?? 0, max: c.max_hard ?? null },
    };
  }

  const pad = (x) => String(x).padStart(2, "0");
  const isoOf = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const parse = (s) => { const [y, m, d] = s.split("-").map(Number); return new Date(y, m - 1, d); };

  // Monday to Sunday of the week holding `today`: the workout chosen or done each day. Nothing is planned ahead.
  function gymWeek(GYM, today) {
    const G = GYM.get();
    const t = parse(today);
    const monday = new Date(t.getFullYear(), t.getMonth(), t.getDate() - ((t.getDay() + 6) % 7));
    const days = [];
    let done = 0;
    for (let k = 0; k < 7; k++) {
      const d = isoOf(new Date(monday.getFullYear(), monday.getMonth(), monday.getDate() + k));
      const code = GYM.chosen(d), rec = G.days[d];
      const isDone = !!rec?.done || (d < today && GYM.setsOn(d).length > 0);
      const shown = code && (isDone || d >= today);
      const letter = !shown ? "" : code === "R" ? "–" : GYM.isW(code) ? (GYM.sessName(code).trim().charAt(0) || "W").toUpperCase() : code;
      const state = isDone ? "done" : d === today ? "today" : d > today && code ? "plan" : "none";
      if (isDone) done++;
      days.push({ date: d, letter, code, state, today: d === today });
    }
    return { done, days };
  }

  const LEGS = new Set(["A", "C"]);

  // A, B and C with gentle hints: the one done longest ago is suggested, skipping A and C the day after a leg day.
  function choices(GYM, today) {
    const G = GYM.get();
    const did = (d) => GYM.setsOn(d).length > 0 || !!G.days[d]?.done;
    const last = { A: "", B: "", C: "" };
    for (const d of new Set([...Object.keys(G.days), ...G.sets.map((s) => s.date)])) {
      const c = GYM.chosen(d);
      if (d < today && c in last && did(d) && d > last[c]) last[c] = d;
    }
    const t = parse(today), y = isoOf(new Date(t.getFullYear(), t.getMonth(), t.getDate() - 1));
    const legsYesterday = LEGS.has(GYM.chosen(y)) && did(y);
    const pool = ["A", "B", "C"].filter((c) => !(legsYesterday && LEGS.has(c)));
    const sug = (pool.length ? pool : ["A", "B", "C"]).reduce((a, c) => (last[c] < last[a] ? c : a));
    return ["A", "B", "C"].map((c) => ({
      code: c, name: GYM.sessName(c), suggested: c === sug, last: last[c] || null,
      hint: legsYesterday && LEGS.has(c) ? "Leg day yesterday – B is easier on your knees." : "",
    }));
  }

  window.TL = { headline, loadBucket, rangeBar, weekBudget, gymWeek, choices, LOAD_LABELS };
})();
