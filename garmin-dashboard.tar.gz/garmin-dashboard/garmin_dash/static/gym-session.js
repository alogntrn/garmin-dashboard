/* Gym session page (#/gym-session/<date>): what was done, new bests, sets per muscle and the effort check.
   Uses app.js globals (app, esc, fdate, pageHead, loadGym) and window.GYM / WL / UIC / GYMDATA inside functions. */
(function () {
  "use strict";

  const SIDE = { R: "Right", L: "Left", "": "" };
  const LOOK = { ok: ["green", "check"], high: ["amber", "bang"], low: ["none", "info"], knee: ["red", "bang"], none: ["none", "info"] };
  const f1 = (v) => String(Math.round(v * 10) / 10);
  const kg = (v) => Math.round(v || 0).toLocaleString("de-CH");
  const capFirst = (t) => (t ? t.charAt(0).toUpperCase() + t.slice(1) : "");

  function prText(p) {
    if (p.unit === "reps") return `${f1(p.today)} reps, was ${f1(p.prev)}.`;
    const label = p.label === "est. 1RM" ? "Estimated 1-rep max" : capFirst(p.label);
    return `${label} ${f1(p.today)} ${p.unit}, was ${f1(p.prev)} ${p.unit}.`;
  }

  // Hard sets per muscle: a main muscle counts 1 per set, a helper ½.
  function muscles(G, sets) {
    const tot = {};
    for (const s of sets) {
      const dfn = G.def(s.ex, s.name);
      if (dfn.kind === "min" || dfn.kind === "info") continue;
      for (const [m, w] of Object.entries(dfn.mus || {})) tot[m] = (tot[m] || 0) + w;
    }
    const names = Object.fromEntries((window.GYMDATA?.MUSCLES || []).map(([k, l]) => [k, l]));
    return Object.entries(tot).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([k, v]) => ({ name: names[k] || k, v }));
  }

  async function renderGymSession(date) {
    const g = await loadGym(true);
    const G = window.GYM;
    if (!g || !/^\d{4}-\d{2}-\d{2}$/.test(date || "")) {
      pageHead("Gym session", { back: "#/activities", backLabel: "Activities" });
      app.innerHTML = `<p class="wo-err">Couldn't load this gym session.</p>`;
      return;
    }
    const code = G.chosen(date) || "F", sets = G.setsOn(date), day = g.days[date] || {};
    const st = G.sessionStats(date), m = window.WL.model(date, null), watch = g.garmin?.[date]?.[0];
    const first = sets.map((s) => s.created_at).filter(Boolean).sort()[0];
    const test = G.notesFor(date).some((n) => n.includes("Test day"));
    const sub = [fdate(date, { weekday: "long", day: "numeric", month: "long" }), first ? first.replace("T", " ").slice(11, 16) : "", test ? "test day" : ""].filter(Boolean).join(", ");
    pageHead(G.sessName(code), { sub, back: "#/activities", backLabel: "Activities" });
    const edit = date === G.todayIso() ? `<a class="u-btn" href="#/workout">Open in Workout mode</a>` : `<a class="u-btn" href="#/progress/strength/${date}">Edit on the Strength page</a>`;
    if (!sets.length) {
      app.innerHTML = `<section class="gs"><p class="gs-none">Nothing logged on this day${code !== "F" ? `, although ${esc(G.sessName(code))} was chosen` : ""}.</p><div class="gs-btns">${edit}</div></section>`;
      return;
    }
    const mins = st.mins || watch?.min || null;
    const stats = `<div class="u-card gs-stats"><div class="wo-stats">
        <div><b class="u-num">${mins || "–"}</b><span>${mins === 1 ? "minute" : "minutes"}</span></div>
        <div><b class="u-num">${st.n}</b><span>${st.n === 1 ? "set" : "sets"}</span></div>
        <div><b class="u-num">${st.vol ? kg(st.vol) : "–"}</b><span>kg lifted</span></div>
        ${watch?.hr ? `<div><b class="u-num">${Math.round(watch.hr)}</b><span>bpm average</span></div>` : ""}</div>
        ${watch ? `<p class="gs-watch u-c2">From your watch: ${watch.min ? `${Math.round(watch.min)} min` : ""}${watch.kcal ? `, ${Math.round(watch.kcal)} kcal` : ""}.</p>` : ""}</div>`;
    const bests = (st.prs || []).map((p) => `<div class="fin-row"><span class="u-status green">${window.UIC.trend}</span><div><b>New best: ${esc(p.n)}${p.side ? (p.side === "R" ? ", right" : ", left") : ""}</b><p>${esc(prText(p))}</p></div></div>`).join("");
    const done = m.exercises.filter((e) => e.logged.length), skipped = m.exercises.filter((e) => !e.logged.length && e.countable);
    const exHTML = done.map((e) => `<div class="u-card gs-ex"><div class="gs-exh"><b>${esc(e.name)}</b>${e.tally.of ? `<span class="u-c2 u-num">${e.tally.done} of ${e.tally.of}</span>` : ""}</div>
        ${e.logged.map((s, i) => `<div class="gs-set"><span class="u-c2">Set ${e.uni ? e.logged.slice(0, i + 1).filter((x) => (x.side || "") === (s.side || "")).length : i + 1}</span><span class="gs-sv">${e.uni && s.side ? `<em>${SIDE[s.side]}</em>` : ""}${esc(G.setTxt(s))}</span><span class="u-c2">${s.rir != null ? `RIR ${f1(s.rir)}` : ""}</span></div>`).join("")}</div>`).join("");
    const mus = muscles(G, sets), top = mus.length ? mus[0].v : 1;
    const musHTML = mus.length ? `<h2 class="u-h2">Sets per muscle</h2><div class="u-card gs-mus">${mus.map((x) => `<div class="gs-mrow"><span>${esc(x.name)}</span>
        <span class="u-bar" aria-hidden="true"><i style="width:${Math.max(6, Math.round((x.v / top) * 100))}%;background:var(--u-str)"></i></span><b class="u-num">${f1(x.v)}</b></div>`).join("")}
        <p class="u-foot" style="margin:10px 0 0">A main muscle counts one per set, a helping muscle half.</p></div>` : "";
    const [cls, , title, text] = G.verdict(G.rirCheck(date), G.rpeCheck(date), null, G.kneeCheck(date));
    const [look, icon] = LOOK[cls] || LOOK.none;
    const facts = [day.rpe != null ? `Effort ${f1(day.rpe)}, ${G.CR10[Math.round(day.rpe)] || ""}` : "", day.pain != null ? `Knee pain ${f1(day.pain)}` : ""].filter(Boolean).join(". ");
    app.innerHTML = `<section class="gs">${stats}
      ${bests ? `<h2 class="u-h2">New bests</h2>${bests}` : ""}
      <h2 class="u-h2">Effort check</h2><div class="fin-row gs-check"><span class="u-status ${look}">${window.UIC[icon]}</span><div><b>${esc(title)}</b><p>${esc(cls === "none" ? "Add how hard it was, or reps in reserve on a few sets, to get a verdict." : text)}</p>
        ${facts ? `<p>${esc(facts)}.</p>` : ""}${day.note ? `<p class="gs-note">“${esc(day.note)}”</p>` : ""}</div></div>
      <h2 class="u-h2">Exercises</h2>${exHTML}
      ${skipped.length ? `<p class="u-foot">Not done: ${esc(skipped.map((e) => e.name).join(", "))}.</p>` : ""}
      ${musHTML}
      <div class="gs-btns">${edit}</div></section>`;
  }

  window.renderGymSession = renderGymSession;
})();
