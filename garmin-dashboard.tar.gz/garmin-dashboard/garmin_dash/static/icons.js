/* Stroke icons for the new screens (24 px grid). window.UIC.name -> inline SVG string. */
(function () {
  "use strict";
  const P = {
    run: '<circle cx="15" cy="4.6" r="1.9"/><path d="M8.2 20.5l2.9-5.1 3 2.6v3.2"/><path d="M6.6 11.9l2.6-3 3.9.9 2 3.2 3 .9"/><path d="M11.1 15.4l2-5.6"/>',
    ride: '<circle cx="6" cy="16" r="3.7"/><circle cx="18" cy="16" r="3.7"/><path d="M6 16l3.4-6.6h5.4L18 16"/><path d="M9.4 9.4L12.3 16l2.5-6.6"/><path d="M13.6 6.5h2.7"/>',
    other: '<path d="M4 12h3l3-7 4 14 3-7h3"/>',
    dumbbell: '<path d="M3.5 10v4M6.8 7.5v9M17.2 7.5v9M20.5 10v4M6.8 12h10.4"/>',
    check: '<path d="M5.5 12.5l4.2 4.2 8.8-9.4"/>',
    bang: '<path d="M12 6.5v7M12 17.5v.1"/>',
    cross: '<path d="M7 7l10 10M17 7L7 17"/>',
    info: '<circle cx="12" cy="12" r="8.6"/><path d="M12 11v5.5M12 7.6v.2"/>',
    chev: '<path d="M9.5 6l6 6-6 6"/>',
    chevl: '<path d="M14.5 6l-6 6 6 6"/>',
    chevd: '<path d="M6 9.5l6 6 6-6"/>',
    close: '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
    plus: '<path d="M12 5.5v13M5.5 12h13"/>',
    minus: '<path d="M5.5 12h13"/>',
    list: '<path d="M9 7h11M9 12h11M9 17h11"/><path d="M4.6 7h.1M4.6 12h.1M4.6 17h.1"/>',
    text: '<path d="M4.5 18.5h4l9.8-9.8a2.8 2.8 0 0 0-4-4L4.5 14.5z"/><path d="M13 6.5l4 4"/>',
    grip: '<path d="M6 9h12M6 12h12M6 15h12"/>',
    sync: '<path d="M19.5 12a7.5 7.5 0 0 1-13.2 4.9M4.5 12a7.5 7.5 0 0 1 13.2-4.9"/><path d="M17.7 3.6v3.6h-3.6M6.3 20.4v-3.6h3.6"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M12 3.5l1.3 2.3 2.6-.6.6 2.6 2.3 1.3-1.2 2.4 1.2 2.4-2.3 1.3-.6 2.6-2.6-.6L12 20.5l-1.3-2.3-2.6.6-.6-2.6-2.3-1.3L6.4 12 5.2 9.6l2.3-1.3.6-2.6 2.6.6z"/>',
    trend: '<path d="M4 19.5h16"/><path d="M5.5 15.5l4-4.5 3.5 2.5 5.5-6.5"/><path d="M15.5 7h3v3"/>',
    heart: '<path d="M12 20s-7.5-4.4-7.5-10.1A4.2 4.2 0 0 1 12 7.3a4.2 4.2 0 0 1 7.5 2.6C19.5 15.6 12 20 12 20z"/>',
    pulse: '<path d="M12 20s-7.5-4.4-7.5-10.1A4.2 4.2 0 0 1 12 7.3a4.2 4.2 0 0 1 7.5 2.6C19.5 15.6 12 20 12 20z"/><path d="M7 12.2h3l1.2-2.2 1.8 4 1.2-1.8H17"/>',
    moon: '<path d="M19.2 14.6A7.6 7.6 0 0 1 9.4 4.8a7.6 7.6 0 1 0 9.8 9.8z"/>',
    bolt: '<path d="M13.2 3.5L6 13.4h5.2l-1 7.1 7.8-10.3h-5.4z"/>',
    wave: '<path d="M3.5 12c1.6-3 3.2-3 4.8 0s3.2 3 4.8 0 3.2-3 4.8 0 2.1 2.2 2.6 1.4"/>',
    steps: '<path d="M8.6 3.8c1.8 0 2.7 2 2.4 4.4l-.4 3.3H6.4l-.3-2.6C5.8 6 6.8 3.8 8.6 3.8zM6.6 14h3.8l-.2 1.8a1.9 1.9 0 0 1-3.7 0z"/><path d="M15.4 8.8c1.8 0 2.8 2.2 2.5 4.6l-.3 2.6h-4.2l-.4-3.3c-.3-2.4.6-3.9 2.4-3.9zM13.6 18.5h3.8l-.2 1.4a1.9 1.9 0 0 1-3.7 0z"/>',
    swap: '<path d="M7 7h11l-3-3M17 17H6l3 3"/>',
    calendar: '<rect x="4" y="5.5" width="16" height="14" rx="3"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/>',
    search: '<circle cx="10.5" cy="10.5" r="6"/><path d="M15 15l4.5 4.5"/>',
  };
  const UIC = {};
  for (const [k, v] of Object.entries(P)) UIC[k] = `<svg class="u-ic" viewBox="0 0 24 24" aria-hidden="true">${v}</svg>`;
  window.UIC = UIC;
})();
