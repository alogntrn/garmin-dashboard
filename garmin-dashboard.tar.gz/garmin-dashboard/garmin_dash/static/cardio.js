/* Cardio details (#/plan/run, #/plan/ride): the coach's suggestion for one sport, in the new design. Opened from the
   cardio rows on Today. Steps, why, limits, this sport's targets and the evidence behind it. */
(function () {
  "use strict";

  const SPORT = { run: "Running", ride: "Cycling" };
  const INTENSITY = { easy: "easy", moderate: "moderate", hard: "hard", rest: "rest" };
  const TARGETS = [
    ["recovery_hr", "Recovery"], ["recovery_w", "Recovery power"],
    ["easy_pace", "Easy pace"], ["easy_hr", "Easy"], ["endurance_w", "Endurance power"],
    ["threshold_pace", "Threshold pace"], ["threshold_hr", "Threshold"], ["threshold_w", "Threshold power"],
    ["vo2_pace", "VO₂max pace"], ["vo2_hr", "VO₂max"], ["vo2_w", "VO₂max power"],
  ];
  const mins = (m) => (m >= 60 ? `${Math.floor(m / 60)} h ${String(Math.round(m % 60)).padStart(2, "0")}` : `${Math.round(m)} min`);
  const list = (cls, items) => `<ul class="u-card cd-list ${cls}">${items.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>`;

  async function renderCardio(sport) {
    const co = await api("/api/coach", true);
    const w = co && co[sport];
    const title = w ? w.title.split(":")[0].trim() : SPORT[sport];
    pageHead(title, { back: "#/today", backLabel: "Today", sub: w ? `${SPORT[sport]}, ${INTENSITY[w.intensity] || w.intensity}${co.for_tomorrow ? ", for tomorrow" : ", for today"}.` : "" });
    if (!w) { app.innerHTML = '<div class="empty">No suggestion for this sport right now.</div>'; return; }
    const effort = (INTENSITY[w.intensity] || w.intensity || "").replace(/^./, (c) => c.toUpperCase());
    const stats = [w.km ? [n1(w.km), "km"] : null, [mins(w.minutes), "in total"], effort ? [effort, "effort"] : null].filter(Boolean);
    const targets = TARGETS.filter(([k]) => w.targets && w.targets[k]);
    const left = `
      <div class="u-card cd-stats">${stats.map(([v, l]) => `<span><b class="u-num">${esc(String(v))}</b>${l}</span>`).join("")}</div>
      <h2 class="u-h2">Steps</h2>
      <div class="u-list cd-steps">${w.steps.map((st) => `<div class="u-row"><span class="rt"><b>${esc(st.label)}</b><span>${esc(st.target)}</span>${st.note ? `<span class="cd-note">${esc(st.note)}</span>` : ""}</span><span class="rr u-num">${mins(st.min)}</span></div>`).join("")}</div>
      <h2 class="u-h2">Why this workout</h2>${list("cd-why", w.why)}`;
    const right = `
      <h2 class="u-h2">Staying within your trend</h2>${list("cd-limits", w.guardrails)}
      ${targets.length ? `<h2 class="u-h2">Your ${sport === "run" ? "running" : "cycling"} targets</h2>
        <div class="u-list cd-targets">${targets.map(([k, l]) => `<div class="u-row"><span class="rt"><b>${l}</b></span><span class="rr">${esc(w.targets[k])}</span></div>`).join("")}</div>` : ""}
      <details class="u-card cd-ev"><summary>Evidence: ${esc(w.evidence_level)}, ${w.refs.length} ${w.refs.length === 1 ? "study" : "studies"}</summary>
        <ul>${w.refs.map((r) => `<li><b>${esc(r.cite)}</b><span>${esc(r.finding)}</span></li>`).join("")}</ul></details>
      <p class="u-foot">Suggestions from your data, not medical advice. If something hurts or feels wrong, switch to easy: how you feel beats the numbers. All targets and the method are in <a href="#/settings/targets">Settings</a>.</p>`;
    app.innerHTML = `<section class="cd"><div class="cd-cols"><div class="cd-a">${left}</div><div class="cd-b">${right}</div></div></section>`;
  }

  window.renderCardio = renderCardio;
})();
