/* Activities tab logic, no DOM: gym sessions from the log, one merged list grouped by week, the month calendar.
   window.AL. Pure functions; GYM is passed in. */
(function () {
  "use strict";

  const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const MONTH = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const ORDER = { run: 0, ride: 1, gym: 2, other: 3 };
  const pad = (n) => String(n).padStart(2, "0");
  const parse = (iso) => { const [y, m, d] = String(iso).slice(0, 10).split("-").map(Number); return new Date(y, m - 1, d); };
  const isoOf = (dt) => `${dt.getFullYear()}-${pad(dt.getMonth() + 1)}-${pad(dt.getDate())}`;
  const addDays = (dt, n) => new Date(dt.getFullYear(), dt.getMonth(), dt.getDate() + n);
  const mondayOf = (iso) => { const t = parse(iso); return isoOf(addDays(t, -((t.getDay() + 6) % 7))); };

  // One entry per day with sets or marked done. A Garmin strength activity on that day (G.garmin) rides along.
  function gymSessions(GYM) {
    const G = GYM.get();
    if (!G) return [];
    const dates = new Set([...G.sets.map((s) => s.date), ...Object.keys(G.days).filter((d) => G.days[d]?.done)]);
    return [...dates].sort().reverse().map((d) => {
      const code = GYM.chosen(d) || "F", st = GYM.sessionStats(d), watch = G.garmin?.[d] || [], sets = GYM.setsOn(d);
      const first = sets.map((s) => s.created_at).filter(Boolean).sort()[0];
      const letter = GYM.isW(code) ? (GYM.sessName(code).trim().charAt(0) || "W").toUpperCase() : code === "F" ? null : code;
      return {
        kind: "gym", id: "gym-" + d, date: d, start: first ? first.replace("T", " ").slice(0, 16) : null,
        code, letter, name: GYM.sessName(code), sets: st.n, kg: st.vol, mins: st.mins || watch[0]?.min || null,
        hr: watch[0]?.hr ?? null, test: GYM.notesFor(d).some((n) => n.includes("Test day")),
        watchIds: watch.map((x) => x.id), exercises: [...new Set(sets.map((s) => GYM.def(s.ex, s.name).n))],
      };
    });
  }

  const matches = (g, ql) => [g.name, g.date, ...g.exercises].some((t) => String(t || "").toLowerCase().includes(ql));

  // Newest first, grouped Monday to Sunday with km and time. Garmin rows are already filtered by the API;
  // gym rows are filtered here, and stop at `until` (oldest loaded Garmin date) while more pages remain.
  function merge(garmin, gym, { sport = "", q = "", today, until = null } = {}) {
    const ql = q.trim().toLowerCase();
    const gymRows = !sport || sport === "gym" ? gym.filter((g) => (!until || g.date >= until) && (!ql || matches(g, ql))) : [];
    const folded = new Set(gymRows.flatMap((g) => g.watchIds));
    const items = [
      ...(sport === "gym" ? [] : garmin.filter((a) => !folded.has(a.id)).map((a) => ({ ...a, kind: "act" }))),
      ...gymRows,
    ].sort((a, b) => String(b.start || b.date).localeCompare(String(a.start || a.date)));
    const weeks = new Map();
    for (const it of items) {
      const k = mondayOf(it.date);
      if (!weeks.has(k)) weeks.set(k, { key: k, label: weekLabel(k, today), km: 0, secs: 0, items: [] });
      const w = weeks.get(k);
      w.items.push(it);
      if (it.kind === "act") { w.km += it.km || 0; w.secs += it.secs || 0; } else w.secs += (it.mins || 0) * 60;
    }
    return [...weeks.values()];
  }

  function weekLabel(monday, today) {
    const tm = mondayOf(today);
    if (monday === tm) return "This week";
    if (monday === isoOf(addDays(parse(tm), -7))) return "Last week";
    const a = parse(monday), b = addDays(a, 6), ty = parse(today).getFullYear();
    if (a.getFullYear() !== b.getFullYear()) return `${a.getDate()} ${MON[a.getMonth()]} ${a.getFullYear()} – ${b.getDate()} ${MON[b.getMonth()]} ${b.getFullYear()}`;
    const yr = b.getFullYear() !== ty ? ` ${b.getFullYear()}` : "";
    return a.getMonth() === b.getMonth() ? `${a.getDate()}–${b.getDate()} ${MON[b.getMonth()]}${yr}` : `${a.getDate()} ${MON[a.getMonth()]} – ${b.getDate()} ${MON[b.getMonth()]}${yr}`;
  }

  // Six rows of seven days, Monday first, with the sports done each day (run, ride, gym, other).
  function calendar(year, month, items, today) {
    const first = new Date(year, month - 1, 1), start = addDays(first, -((first.getDay() + 6) % 7));
    const by = {};
    for (const it of items) (by[it.date] = by[it.date] || new Set()).add(it.kind === "gym" ? "gym" : it.sport || "other");
    const cells = [];
    for (let k = 0; k < 42; k++) {
      const dt = addDays(start, k), d = isoOf(dt);
      cells.push({ date: d, day: dt.getDate(), inMonth: dt.getMonth() === month - 1, today: d === today, sports: [...(by[d] || [])].sort((x, y) => (ORDER[x] ?? 9) - (ORDER[y] ?? 9)) });
    }
    return { year, month, title: `${MONTH[month - 1]} ${year}`, first: isoOf(cells[0] ? parse(cells[0].date) : first), last: cells[41].date, cells };
  }

  window.AL = { gymSessions, merge, weekLabel, calendar, mondayOf };
})();
