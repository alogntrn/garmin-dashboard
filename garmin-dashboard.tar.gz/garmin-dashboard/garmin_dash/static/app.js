/* Training dashboard – single page app (no build step). */
"use strict";

// ------------------------------------------------------------------ utils
const $ = (sel, el = document) => el.querySelector(sel);
const app = $("#app");
const tipEl = $("#tip");
const charts = [];
let map = null;

const css = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();
const C = () => ({
  run: css("--series-1"), ride: css("--series-2"), other: css("--series-3"),
  s1: css("--series-1"), s2: css("--series-2"), s3: css("--series-3"), s4: css("--series-4"), s7: css("--series-7"),
  text: css("--text-primary"), text2: css("--text-secondary"), muted: css("--text-muted"),
  grid: css("--grid"), axis: css("--axis"), surface: css("--surface-1"),
  seq: [1, 2, 3, 4, 5, 6, 7].map((i) => css(`--seq-${i}`)),
  good: css("--good"), warning: css("--warning"), serious: css("--serious"), critical: css("--critical"),
  heat0: css("--heat-0"),
});
const SPORT_NAME = { run: "Run", ride: "Ride", other: "Other" };
const ICONS = {
  run: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="14" cy="4" r="2"/><path d="M6 21l3-6 3 2v4M9 12l2-4 4 2 2 3h3M11 8l-3 1-2 3"/></svg>',
  ride: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="6" cy="16" r="4"/><circle cx="18" cy="16" r="4"/><path d="M6 16l4-8h5l3 8M10 8l2 8h-6M14 5h3"/></svg>',
  other: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 12h3l3-7 4 14 3-7h3"/></svg>',
};

const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const n0 = (v) => (v == null ? "–" : Math.round(v).toLocaleString("de-CH"));
const n1 = (v) => (v == null ? "–" : (Math.round(v * 10) / 10).toLocaleString("de-CH", { minimumFractionDigits: 1, maximumFractionDigits: 1 }));
const dur = (s) => {
  if (s == null) return "–";
  s = Math.round(s);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = s % 60;
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(ss).padStart(2, "0")}` : `${m}:${String(ss).padStart(2, "0")}`;
};
const hm = (s) => { if (s == null) return "–"; const m = Math.round(s / 60); return `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, "0")}m`; };
const pace = (sPerKm) => (sPerKm == null ? "–" : `${Math.floor(sPerKm / 60)}:${String(Math.round(sPerKm % 60)).padStart(2, "0")}`);
const fdate = (iso, opts = { day: "numeric", month: "short", year: "numeric" }) => (iso ? new Date(iso.length === 10 ? iso + "T12:00:00" : iso.replace(" ", "T")).toLocaleDateString("en-GB", opts) : "–");
const daysAgo = (n) => { const d = new Date(); d.setDate(d.getDate() - n); return d.toISOString().slice(0, 10); };

const cache = new Map();
async function api(path, fresh = false) {
  if (!fresh && cache.has(path)) return cache.get(path);
  const p = fetch(path).then((r) => { if (!r.ok) throw new Error(`${r.status} ${path}`); return r.json(); });
  cache.set(path, p);
  p.catch(() => cache.delete(path));
  return p;
}

const store = {
  get(k, d) { try { const v = localStorage.getItem("gd:" + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem("gd:" + k, JSON.stringify(v)); } catch { /* ignore */ } },
};

function rolling(points, key, days = 30) {
  // trailing average over `days` calendar days, points sorted by date
  const out = [];
  let j = 0, sum = 0, cnt = 0;
  for (let i = 0; i < points.length; i++) {
    const t = Date.parse(points[i].date);
    if (points[i][key] != null) { sum += points[i][key]; cnt++; }
    while (Date.parse(points[j].date) < t - days * 864e5) { if (points[j][key] != null) { sum -= points[j][key]; cnt--; } j++; }
    out.push({ x: points[i].date, y: cnt ? sum / cnt : null });
  }
  return out;
}

// ------------------------------------------------------------------ charts
Chart.defaults.font.family = 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
Chart.defaults.font.size = 11.5;
Chart.defaults.animation = false;
Chart.defaults.maintainAspectRatio = false;
Chart.defaults.plugins.legend.display = false;

function showTip(html, x, y) {
  tipEl.innerHTML = html;
  tipEl.hidden = false;
  const w = tipEl.offsetWidth, h = tipEl.offsetHeight;
  let left = x + 14, top = y - h - 10;
  if (left + w > window.innerWidth - 8) left = x - w - 14;
  if (left < 8) left = 8;
  if (top < 8) top = y + 16;
  tipEl.style.left = left + "px";
  tipEl.style.top = top + "px";
}
function hideTip() { tipEl.hidden = true; }
document.addEventListener("scroll", hideTip, { passive: true });

function externalTooltip({ chart, tooltip }) {
  if (tooltip.opacity === 0 || !tooltip.dataPoints?.length) return hideTip();
  const first = tooltip.dataPoints[0];
  const title = chart.$tipTitle ? chart.$tipTitle(first) : tooltip.title?.[0] ?? "";
  const rows = tooltip.dataPoints
    .filter((dp) => !dp.dataset.noTip && dp.raw != null && (dp.parsed.y != null || dp.parsed.x != null))
    .map((dp) => {
      const ds = dp.dataset;
      const color = ds.keyColor || (Array.isArray(ds.backgroundColor) ? ds.backgroundColor[dp.dataIndex] : ds.type === "bar" || chart.config.type === "bar" ? ds.backgroundColor : ds.borderColor);
      const val = ds.fmt ? ds.fmt(dp.raw, dp) : n1(dp.parsed.y);
      return `<div class="tr"><span class="key" style="background:${color}"></span>${esc(ds.label || "")}<b>${val}</b></div>`;
    }).join("");
  if (!rows) return hideTip();
  const r = chart.canvas.getBoundingClientRect();
  showTip(`<div class="tt">${esc(title)}</div>${rows}`, r.left + tooltip.caretX, r.top + tooltip.caretY);
}

const crosshair = {
  id: "crosshair",
  afterDatasetsDraw(chart) {
    const a = chart.getActiveElements();
    if (!a?.length || chart.config.type !== "line" || chart.options.plugins.noCrosshair) return;
    const x = a[0].element.x, { top, bottom } = chart.chartArea, ctx = chart.ctx;
    ctx.save(); ctx.strokeStyle = C().axis; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(x, top); ctx.lineTo(x, bottom); ctx.stroke(); ctx.restore();
  },
};
const bands = {
  id: "bands",
  beforeDatasetsDraw(chart, _, opts) {
    if (!opts?.items) return;
    const { ctx, chartArea: { left, right }, scales: { y } } = chart;
    ctx.save();
    for (const b of opts.items) {
      const y1 = y.getPixelForValue(Math.min(b.to, y.max)), y2 = y.getPixelForValue(Math.max(b.from, y.min));
      if (y2 <= y1) continue;
      ctx.fillStyle = b.color; ctx.fillRect(left, y1, right - left, y2 - y1);
      ctx.fillStyle = C().muted; ctx.font = "11px system-ui"; ctx.textAlign = "right"; ctx.textBaseline = "top";
      if (y2 - y1 > 14) ctx.fillText(b.label, right - 4, y1 + 3);
    }
    ctx.restore();
  },
};
Chart.register(crosshair, bands);

function axes({ time = true, yFmt, yReverse = false, yMin, yMax, xType, xFmt, yBegin = false, stacked = false, unit = "month", xMin } = {}) {
  const c = C();
  const x = {
    type: xType || (time ? "time" : "category"),
    grid: { display: false }, border: { color: c.axis },
    ticks: { color: c.muted, maxRotation: 0, autoSkipPadding: 14, ...(xFmt ? { callback: xFmt, autoSkip: false } : {}) },
    stacked,
  };
  if (time && !xType) x.time = { unit, tooltipFormat: "d MMM yyyy", displayFormats: { month: "MMM yy", week: "d MMM", day: "d MMM" } };
  if (xMin) x.min = xMin;
  return {
    x,
    y: {
      reverse: yReverse, min: yMin, max: yMax, beginAtZero: yBegin, stacked,
      grid: { color: c.grid, drawTicks: false }, border: { display: false },
      ticks: { color: c.muted, padding: 6, maxTicksLimit: 6, ...(yFmt ? { callback: yFmt } : {}) },
    },
  };
}

// True when no dataset holds a real value (null, NaN or 0 everywhere; [low, high] pairs count too).
function chartIsEmpty(cfg) {
  const real = (v) => (Array.isArray(v) ? v.some(real) : v != null && typeof v === "object" ? real(v.y) : v != null && !Number.isNaN(+v) && +v !== 0);
  return !(cfg.data?.datasets || []).some((ds) => (ds.data || []).some(real));
}

function mkChart(el, cfg) {
  if (typeof el === "string") el = $(el);
  if (!el) return null;
  if (chartIsEmpty(cfg)) {
    el.innerHTML = `<p class="ch-empty">${esc(cfg.empty || "No data for this period yet.")}</p>`;
    return null;
  }
  delete cfg.empty;
  const canvas = document.createElement("canvas");
  el.innerHTML = ""; el.appendChild(canvas);
  cfg.options = cfg.options || {};
  const tipTitle = cfg.options.plugins?.tipTitle;
  if (tipTitle) delete cfg.options.plugins.tipTitle;
  cfg.options.plugins = { ...(cfg.options.plugins || {}), tooltip: { enabled: false, external: externalTooltip, ...(cfg.options.plugins?.tooltip || {}) } };
  cfg.options.interaction = cfg.options.interaction || { mode: "index", intersect: false };
  cfg.options.onHover = cfg.options.onHover;
  const ch = new Chart(canvas, cfg);
  ch.$tipTitle = tipTitle;
  canvas.addEventListener("mouseleave", hideTip);
  canvas.addEventListener("touchend", () => setTimeout(hideTip, 1800), { passive: true });
  charts.push(ch);
  return ch;
}

const line = (label, data, color, extra = {}) => ({
  type: "line", label, data, borderColor: color, backgroundColor: color, borderWidth: 2, pointRadius: 0,
  pointHoverRadius: 5, pointHoverBorderWidth: 2, pointHoverBorderColor: C().surface, tension: 0.25, spanGaps: true,
  borderCapStyle: "round", borderJoinStyle: "round", ...extra,
});
const dots = (label, data, color, extra = {}) => ({
  type: "line", label, data, showLine: false, borderColor: C().surface, backgroundColor: color, pointRadius: 3.5,
  pointBorderWidth: 1.5, pointHoverRadius: 6, pointHoverBorderWidth: 2, keyColor: color, ...extra,
});
// Width of one category slot; under 7px (a year or more of weeks on a phone) bars drop the surface gap and the rounded
// top, which would otherwise cover the whole bar.
const barSlot = (ctx) => { const a = ctx.chart.chartArea, n = ctx.chart.data.labels?.length || ctx.dataset.data.length; return a && n ? a.width / n : 99; };
const bars = (label, data, color, extra = {}) => ({
  type: "bar", label, data, backgroundColor: color, borderSkipped: "bottom", maxBarThickness: 24, categoryPercentage: 0.8, barPercentage: 0.92, borderColor: C().surface,
  borderRadius: (ctx) => (barSlot(ctx) < 7 ? 0 : { topLeft: 4, topRight: 4 }),
  borderWidth: (ctx) => (barSlot(ctx) < 7 ? 0 : { top: 0, left: 1, right: 1, bottom: 0 }), ...extra,
});

function legend(items) {
  return `<div class="legend">${items.map(([label, color, kind]) => `<span><i class="key ${kind === "line" ? "line" : ""}" style="background:${color}"></i>${esc(label)}</span>`).join("")}</div>`;
}

function seg(id, options, current) {
  return `<div class="seg" id="${id}">${options.map(([v, l]) => `<button data-v="${v}" class="${String(v) === String(current) ? "on" : ""}">${l}</button>`).join("")}</div>`;
}
function onSeg(id, fn) {
  const el = $("#" + id);
  el?.addEventListener("click", (e) => {
    const b = e.target.closest("button"); if (!b) return;
    el.querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b));
    fn(b.dataset.v);
  });
}

function tile(label, value, unit = "", delta = "", hero = false) {
  return `<div class="tile ${hero ? "hero" : ""}"><div class="label">${label}</div><div class="value">${value}${unit ? `<small>${unit}</small>` : ""}</div>${delta ? `<div class="delta">${delta}</div>` : ""}</div>`;
}
function deltaTxt(cur, ref, unit = "", upGood = true) {
  if (cur == null || ref == null) return "";
  const d = cur - ref;
  if (Math.abs(d) < 0.05) return "same as 4-week average";
  const cls = (d > 0) === upGood ? "up" : "down";
  return `<span class="${cls}">${d > 0 ? "▲" : "▼"} ${n1(Math.abs(d))}${unit}</span> vs 4-week avg`;
}

function card(title, body, { span = 12, sub = "", right = "" } = {}) {
  return `<section class="card span-${span}"><div class="card-head"><div><h2>${title}</h2>${sub ? `<p class="sub">${sub}</p>` : ""}</div>${right}</div>${body}</section>`;
}

function actRow(a) {
  const c = C()[a.sport];
  const main = a.sport === "run" ? `${n1(a.km)} km · ${pace(a.pace)}/km` : `${n1(a.km)} km · ${n1(a.speed_kmh)} km/h`;
  return `<a class="act" href="#/activity/${a.id}">
    <div class="ic" style="background:${c}">${ICONS[a.sport]}</div>
    <div style="min-width:0"><div class="t">${esc(a.name)}</div><div class="m">${fdate(a.start, { weekday: "short", day: "numeric", month: "short" })} · ${hm(a.secs)}${a.elev ? ` · ${n0(a.elev)} m ↑` : ""}${a.location ? ` · ${esc(a.location)}` : ""}</div></div>
    <div class="r"><b>${a.km ? main : hm(a.secs)}</b><br>${a.hr ? `${a.hr} bpm` : ""}${a.np ? ` · ${a.np} W NP` : a.power ? ` · ${a.power} W` : ""}</div></a>`;
}

const rangeOpts = [["90", "3M"], ["180", "6M"], ["365", "1Y"], ["730", "2Y"], ["9999", "All"]];
// One range for the whole Progress tab (Overview, Run, Ride), chosen in the page header.
const PROG_RANGES = [[90, "3 months"], [180, "6 months"], [365, "1 year"], [730, "2 years"], [9999, "All"]];
// A range menu in the page header: options [[days, label]], remembered under `key`. Progress and Recovery share it.
function rangeGet(key, opts, def) { const v = +store.get(key, def); return opts.some(([d]) => d === v) ? v : def; }
function rangeBtn(key, opts, def) {
  const l = opts.find(([d]) => d === rangeGet(key, opts, def))[1];
  return `<button type="button" class="gpill glass pg-range" aria-label="Range: ${l}. Change">${l}${window.UIC ? window.UIC.chevd : ""}</button>`;
}
function rangeSheet(key, opts, def) {
  const cur = rangeGet(key, opts, def);
  const p = openSheet(`<div class="sheet-head"><h2>Show</h2><button type="button" class="sheet-x" aria-label="Close" onclick="closeSheet()">${window.UIC ? window.UIC.close : CLOSE}</button></div>
    <div class="u-list pg-ranges">${opts.map(([d, l]) => `<button type="button" class="u-row" data-range="${d}" aria-pressed="${d === cur}"><span class="rt"><b>${l}</b></span>${d === cur ? (window.UIC ? window.UIC.check : "✓") : ""}</button>`).join("")}</div>`);
  p.querySelectorAll("[data-range]").forEach((b) => b.addEventListener("click", () => { store.set(key, +b.dataset.range); closeSheet(); route(); }));
}
const progRange = () => rangeGet("prog-range", PROG_RANGES, 180);
// Weeks of /api/weekly a range needs; "All" asks for five years and trims the empty start with emptyLead.
const progWeeks = (days = progRange()) => Math.max(4, Math.min(days >= 9999 ? 260 : Math.ceil(days / 7), 260));
// How many leading weeks are empty in every series (always keeps the last `keep`).
const emptyLead = (n, series, keep = 4) => { let i = 0; while (i < n - keep && series.every((a) => !(a[i] > 0))) i++; return i; };
const progRangeBtn = () => rangeBtn("prog-range", PROG_RANGES, 180);
const progRangeSheet = () => rangeSheet("prog-range", PROG_RANGES, 180);

// ------------------------------------------------------------------ shell (four tabs)
const GEAR = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M12 3.5l1.3 2.3 2.6-.6.6 2.6 2.3 1.3-1.2 2.4 1.2 2.4-2.3 1.3-.6 2.6-2.6-.6L12 20.5l-1.3-2.3-2.6.6-.6-2.6-2.3-1.3L6.4 12 5.2 9.6l2.3-1.3.6-2.6 2.6.6z"/></svg>';
const CHEV_L = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14.5 6l-6 6 6 6"/></svg>';
const CLOSE = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/></svg>';
const SEGS = [["overview", "Overview"], ["run", "Run"], ["ride", "Ride"], ["strength", "Strength"]];
// last: the page under the Settings sheet; keep: that page is still rendered (don't reload it when Settings closes);
// scrollTo: an element to bring into view after the next page renders.
const shell = { last: "#/today", gymAt: 0, keep: null, scrollTo: null };

function pageHead(title, { sub = "", back = "", backLabel = "", right = null, seg = "" } = {}) {
  const r = right ?? `<a class="gbtn glass" href="#/settings" aria-label="Settings">${GEAR}</a>`;
  $("#pagehead").innerHTML = `<div class="ph-top">${back ? `<a class="gpill glass ph-back" href="${back}">${CHEV_L}${esc(backLabel)}</a>` : ""}${r}</div>
    ${title ? `<h1 class="ph-title">${esc(title)}</h1>` : ""}${sub ? `<p class="ph-sub">${sub}</p>` : ""}${seg}`;
  document.body.dataset.shelltitle = title ? "1" : "0";
}
function progressSeg(cur) {
  return `<nav class="segc" aria-label="Progress sections">${SEGS.map(([k, l]) => `<a href="#/progress/${k}"${k === cur ? ' aria-current="page"' : ""}>${l}</a>`).join("")}</nav>`;
}
function setTabs(tab) {
  document.querySelectorAll("#tabbar a, #side a").forEach((a) => (a.dataset.tab === tab ? a.setAttribute("aria-current", "page") : a.removeAttribute("aria-current")));
}

let sheetClose = null, sheetReturn = null;
// Focus moves into the sheet when it opens and back to what opened it when it closes.
function openSheet(html, onClose) {
  const sh = $("#sheet"), panel = $(".sheet-panel", sh);
  if (sh.hidden) sheetReturn = document.activeElement;
  panel.innerHTML = `<div class="sheet-grab" aria-hidden="true"></div>${html}`;
  sh.hidden = false;
  sheetClose = onClose || null;
  $(".sheet-dim", sh).onclick = closeSheet;
  panel.tabIndex = -1;
  panel.focus({ preventScroll: true });
  return panel;
}
function closeSheet() {
  const sh = $("#sheet");
  if (sh.hidden) return;
  sh.hidden = true;
  $(".sheet-panel", sh).innerHTML = "";
  const f = sheetClose, back = sheetReturn; sheetClose = null; sheetReturn = null;
  if (f) f();
  if (back && back.isConnected && typeof back.focus === "function") back.focus({ preventScroll: true });
}
window.openSheet = openSheet;
window.closeSheet = closeSheet;
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeSheet(); });

async function loadGym(fresh = true) {
  try { const g = await api("/api/gym", fresh); window.GYM.use(g); shell.gymAt = Date.now(); return g; } catch { return null; }
}
window.loadGym = loadGym;
const parseTs = (t) => Date.parse(String(t || "").replace(" ", "T"));
window.parseTs = parseTs;
window.sessionOpen = () => {
  const g = window.GYM && window.GYM.get();
  if (!g) return false;
  const t = window.GYM.todayIso();
  return window.GYM.setsOn(t).length > 0 && !g.days[t]?.done;
};
async function refreshResume(fresh) {
  const el = $("#resume");
  if (fresh || Date.now() - shell.gymAt > 30000) await loadGym(true);
  if (!window.sessionOpen() || document.body.classList.contains("wm-open") || !window.WL) { el.hidden = true; return; }
  const t = window.GYM.todayIso(), m = window.WL.model(t, store.get("wm-order:" + t, null));
  const cur = Math.max(0, Math.min(m.exercises.length - 1, store.get("wm-cur:" + t, window.WL.firstOpen(m))));
  const mins = m.firstSetAt ? Math.max(1, Math.round((Date.now() - parseTs(m.firstSetAt)) / 60000)) : 0;
  el.innerHTML = `<span class="u-disc" aria-hidden="true">${esc(m.letter)}</span><span class="rs-t"><b>${esc(m.title)}</b><span>Exercise ${cur + 1} of ${m.exercises.length}${mins ? `, ${mins} min so far` : ""}</span></span><span class="rs-go">Resume</span>`;
  el.setAttribute("aria-label", `Resume ${m.title}, exercise ${cur + 1} of ${m.exercises.length}`);
  el.hidden = false;
}
window.refreshResume = refreshResume;

// ------------------------------------------------------------------ sync (Today's button, Settings, pull down)
const sleepMs = (ms) => new Promise((r) => setTimeout(r, ms));
const syncState = { running: false };
function syncedLabel(ts) {
  if (!ts) return "Not synced yet.";
  const d = new Date(String(ts).replace(" ", "T")), hhmm = d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
  return d.toDateString() === new Date().toDateString() ? `Synced at ${hhmm}.` : `Synced ${d.toLocaleDateString("en-GB", { day: "numeric", month: "short" })}, ${hhmm}.`;
}
// Sync status: a pill above the tab bar on phones, the line at the bottom of the sidebar on wide screens.
function syncBar(text, { busy = false, hideIn = 0 } = {}) {
  const el = $("#syncbar"), side = $("#side-sync"), icon = busy && window.UIC ? window.UIC.sync : "";
  clearTimeout(syncBar.t);
  el.innerHTML = `${icon}<span>${esc(text)}</span>`;
  el.classList.toggle("busy", busy);
  el.hidden = false;
  if (side) side.innerHTML = `${icon}${esc(text)}`;
  if (hideIn) syncBar.t = setTimeout(() => { el.hidden = true; updateSideSync(); }, hideIn);
}
// Starts a sync on the Pi and waits for it: the page reloads its data when Garmin's numbers are in.
async function syncNow() {
  if (syncState.running) return;
  syncState.running = true;
  syncBar("Syncing with Garmin…", { busy: true });
  // The Pi writes its log in local time, so compare with a local timestamp.
  const n = new Date(), p2 = (x) => String(x).padStart(2, "0");
  const startedAt = `${n.getFullYear()}-${p2(n.getMonth() + 1)}-${p2(n.getDate())}T${p2(n.getHours())}:${p2(n.getMinutes())}:${p2(n.getSeconds())}`;
  let before = null, st = null, seen = false;
  try { before = (await api("/api/status", true)).last_sync; } catch { /* still try */ }
  try {
    const r = await fetch("/api/sync", { method: "POST" });
    if (!r.ok) throw new Error(String(r.status));
  } catch {
    syncState.running = false;
    syncBar("Couldn't reach the Pi. Check the connection and try again.", { hideIn: 6000 });
    return;
  }
  const t0 = Date.now();
  while (Date.now() - t0 < 240000) {
    await sleepMs(2500);
    try { st = await api("/api/status", true); } catch { continue; }
    if (st.syncing) { seen = true; continue; }
    if (seen || st.last_sync !== before || Date.now() - t0 > 12000) break;
  }
  syncState.running = false;
  if (!st || st.syncing) { syncBar("The sync is still running on the Pi. Pull down again in a minute.", { hideIn: 6000 }); return; }
  const err = (st.log || []).find((l) => l.level === "error" && String(l.ts) >= startedAt);
  if (st.last_sync && st.last_sync !== before) syncBar(syncedLabel(st.last_sync).replace(/\.$/, ""), { hideIn: 2500 });
  else syncBar(err ? `Sync failed: ${err.message}` : "Sync finished, nothing new.", { hideIn: 6000 });
  cache.clear();
  if (window.Settings && window.Settings.isOpen()) window.Settings.refresh(); else route();
}
window.syncNow = syncNow;

// Pull down at the top of any tab to sync (a home-screen web app has no built-in pull to refresh).
(function pullToSync() {
  const PULL = 72;
  let y0 = null, dy = 0;
  const ind = () => $("#ptr");
  const blocked = (e) => window.scrollY > 0 || document.body.classList.contains("wm-open") || !$("#sheet").hidden || syncState.running
    || (e.target.closest && e.target.closest("input, textarea, select, canvas, .leaflet-container"));
  const show = () => {
    const el = ind(), k = Math.min(1, dy / PULL);
    el.hidden = false;
    el.style.transform = `translate(-50%, ${Math.min(dy * 0.5, 64) - 44}px) rotate(${dy * 3}deg)`;
    el.style.opacity = String(k);
    el.classList.toggle("ready", dy >= PULL);
  };
  const reset = () => { y0 = null; dy = 0; const el = ind(); if (el) { el.hidden = true; el.classList.remove("ready"); } };
  addEventListener("touchstart", (e) => { if (e.touches.length !== 1 || blocked(e)) { reset(); return; } y0 = e.touches[0].clientY; dy = 0; }, { passive: true });
  addEventListener("touchmove", (e) => {
    if (y0 == null) return;
    dy = e.touches[0].clientY - y0;
    if (dy <= 0 || window.scrollY > 0) { reset(); return; }
    show();
  }, { passive: true });
  addEventListener("touchend", () => { if (y0 == null) return; const go = dy >= PULL; reset(); if (go) syncNow(); }, { passive: true });
  addEventListener("touchcancel", reset, { passive: true });
})();

// Wide screens: when the last sync was, at the bottom of the sidebar (board "iPad and Mac").
async function updateSideSync() {
  const el = $("#side-sync");
  if (!el || !matchMedia("(min-width: 1024px)").matches || syncState.running) return;   // keep "Syncing…" while it runs
  try {
    const s = await api("/api/summary");
    el.textContent = syncedLabel(s.last_sync) + (matchMedia("(hover: none)").matches ? " Pull down to sync." : "");
  } catch { el.textContent = ""; }
}

// ------------------------------------------------------------------ router
const PAGES = {
  today: () => (window.renderToday ? window.renderToday() : (pageHead("Today"), renderOverview())),
  plan: () => { pageHead("Workout details", { back: "#/today", backLabel: "Today" }); return renderPlan(); },
  activities: () => (window.renderActivitiesPage ? window.renderActivitiesPage() : (pageHead("Activities"), renderActivities())),
  "gym-session": (r) => window.renderGymSession(r.arg),
  activity: (r) => { pageHead("", { back: "#/activities", backLabel: "Activities" }); return renderActivity(r.arg); },
  recovery: (r) => window.renderRecoveryPage(r.arg),
  progress: (r) => {
    const ranged = r.seg !== "strength";
    pageHead("Progress", { seg: progressSeg(r.seg), right: ranged ? progRangeBtn() : "" });
    if (ranged) $("#pagehead .pg-range")?.addEventListener("click", progRangeSheet);
    return ({ overview: renderOverview, run: renderRunning, ride: renderCycling, strength: () => window.renderGym(r.arg) }[r.seg])();
  },
};

async function route() {
  const r = resolveRoute(location.hash, { sessionOpen: window.sessionOpen() });
  if (r.redirect) { location.replace(r.redirect); return; }
  if (r.page === "settings") {
    // Settings is a sheet over the current page; opened by URL, the last page (or Today) goes underneath first.
    if (window.Workout && window.Workout.isOpen()) window.Workout.close();
    if (!app.dataset.page) {
      const u = resolveRoute(shell.last || "#/today", { sessionOpen: window.sessionOpen() });
      const under = u.redirect || u.page === "workout" || u.page === "settings" ? { tab: "today", page: "today" } : u;
      setTabs(under.tab);
      await renderPage(under);
    }
    setTabs("settings");
    await window.Settings.open(r.arg || null);
    return;
  }
  if (shell.keep && shell.keep === location.hash) { shell.keep = null; setTabs(r.tab); return; }
  shell.keep = null;
  setTabs(r.tab);
  if (r.page === "workout") {
    if (!window.Workout) { location.replace("#/today"); return; }
    if (!app.dataset.page) await renderPage({ tab: "today", page: "today" });
    window.Workout.open();
    return;
  }
  if (window.Workout && window.Workout.isOpen()) window.Workout.close();
  shell.last = location.hash || "#/today";
  await renderPage(r);
  refreshResume(false);
  updateSideSync();
  if (shell.scrollTo) { const el = document.getElementById(shell.scrollTo); shell.scrollTo = null; el?.scrollIntoView({ block: "start" }); }
}

async function renderPage(r) {
  charts.splice(0).forEach((c) => c.destroy());
  if (map) { map.remove(); map = null; }
  hideTip();
  closeSheet();
  document.body.dataset.page = r.page;
  app.dataset.page = r.page;
  app.innerHTML = '<div class="loading">Loading…</div>';
  try {
    await PAGES[r.page](r);
  } catch (e) {
    console.error(e);
    app.innerHTML = `<div class="empty">Couldn't load this page (${esc(e.message)}).<br>Is the sync finished? See <a href="#/settings">Settings</a>.</div>`;
  }
  window.scrollTo(0, 0);
}
window.addEventListener("hashchange", route);
matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => { if (!document.body.classList.contains("wm-open")) route(); });

// ------------------------------------------------------------------ overview
async function renderOverview() {
  const days = progRange(), nWeeks = progWeeks(days);
  const [s, ld, wk, hm_, zn] = await Promise.all([api("/api/summary"), api("/api/load"), api(`/api/weekly?weeks=${nWeeks}`), api("/api/heatmap"), api(`/api/zones?weeks=${Math.min(nWeeks, 52)}`)]);
  if (!s.n_activities) {
    app.innerHTML = `<div class="empty">No activities yet. The first sync may still be running – check <a href="#/settings">Settings</a>.</div>`;
    return;
  }
  const c = C(), tw = s.this_week, pv = s.avg_prev4, L = s.latest;
  const hours = tw.run.h + tw.ride.h + tw.other.h, phours = pv.run.h + pv.ride.h + pv.other.h;
  const tsb = s.tsb, formLabel = tsb == null ? "" : tsb < -30 ? "high fatigue" : tsb < -10 ? "building" : tsb <= 5 ? "neutral" : "fresh";
  const ctlDelta = s.ctl != null && s.ctl_7d_ago != null ? s.ctl - s.ctl_7d_ago : null;
  // Board "Progress": one call in words, then the charts.
  const trend = ctlDelta == null ? null : ctlDelta > 1 ? "building" : ctlDelta < -1 ? "dropping" : "steady";
  const formText = tsb == null ? "" : tsb < -30 ? "very tired, take it easy" : tsb < -10 ? "tired from training, which is how fitness builds" : tsb <= 5 ? "fresh enough for a hard day" : "fresh, a good day for a hard session or a test";
  const why = [ctlDelta == null ? "" : `${ctlDelta >= 0 ? "Up" : "Down"} ${n1(Math.abs(ctlDelta))} ${Math.abs(ctlDelta).toFixed(1) === "1.0" ? "point" : "points"} in a week.`,
    tsb == null ? "" : `Form ${tsb > 0 ? "+" : ""}${n0(tsb)}, ${formText}.`].filter(Boolean).join(" ");
  const sportKeys = legend([["Run", c.run], ["Ride", c.ride], ["Strength & other", c.other]]);
  app.innerHTML = `
    <section class="pg">
      <p class="pg-call">${trend ? `Fitness is ${trend}.` : "Not enough training yet for a trend."}</p>
      ${why ? `<p class="pg-why">${esc(why)}</p>` : ""}
    </section>
    <div class="grid">
      ${card("Training load", `<div class="pg-vals">${s.ctl != null ? `<span>Fitness <b class="u-num">${n0(s.ctl)}</b></span>` : ""}${s.ctl != null && tsb != null ? `<span>Fatigue <b class="u-num">${n0(s.atl ?? s.ctl - tsb)}</b></span>` : ""}</div><div class="chart" id="ch-load"></div>`, { span: 8, sub: "Fitness: 42-day average of daily training load. Fatigue: 7-day average.", right: trend ? `<span class="u-chip">${trend.charAt(0).toUpperCase() + trend.slice(1)}</span>` : "" })}
      ${card("Form", `<div class="chart" id="ch-form"></div>`, { span: 4, sub: "Fitness minus fatigue" })}
      ${card("Weekly training time", `<div class="chart" id="ch-weekly"></div>`, { span: 7, sub: "Hours per week", right: sportKeys })}
      ${card("Intensity", `<div class="chart" id="ch-zones"></div>`, { span: 5, sub: "Hours per week in each heart-rate zone", right: legend([1, 2, 3, 4, 5].map((z) => ["Z" + z, c.seq[z]])) })}
      ${card("Consistency", `<div id="heat"></div>`, { span: 12, sub: "Daily training load, last 12 months" })}
    </div>`;

  const drawLoad = (days) => {
    const cut = daysAgo(+days);
    const idx = ld.days.findIndex((d) => d >= cut);
    const i0 = idx < 0 ? 0 : idx;
    const xs = ld.days.slice(i0);
    const pick = (arr) => arr.slice(i0).map((y, i) => ({ x: xs[i], y }));
    charts.filter((ch) => ch.canvas.parentNode?.id === "ch-load" || ch.canvas.parentNode?.id === "ch-form").forEach((ch) => { ch.destroy(); charts.splice(charts.indexOf(ch), 1); });
    const unit = +days <= 120 ? "week" : "month";
    mkChart("#ch-load", {
      type: "line",
      data: { datasets: [line("Fitness", pick(ld.ctl), c.s1, { fmt: (r) => n1(r.y) }), line("Fatigue", pick(ld.atl), c.s2, { fmt: (r) => n1(r.y) }) ] },
      options: { scales: axes({ unit, yBegin: true }) },
    });
    mkChart("#ch-form", {
      type: "line",
      data: { datasets: [line("Form", pick(ld.tsb), c.s1, { fmt: (r) => (r.y > 0 ? "+" : "") + n1(r.y), fill: { target: { value: 0 }, above: "rgba(12,163,12,.10)", below: "rgba(208,59,59,.08)" } })] },
      options: {
        scales: axes({ unit }),
        plugins: { bands: { items: [{ from: -30, to: -10, color: "rgba(12,163,12,.07)", label: "productive" }, { from: -80, to: -30, color: "rgba(208,59,59,.07)", label: "overreaching" }, { from: 5, to: 60, color: "rgba(42,120,214,.06)", label: "fresh" }] } },
      },
    });
  };
  drawLoad(days);

  // "All" asks the server for five years; start the bars at the first week with any training.
  const lead = days >= 9999 ? emptyLead(wk.weeks.length, [wk.data.run.h, wk.data.ride.h, wk.data.other.h]) : 0;
  const weeks = wk.weeks.slice(lead);
  const wch = mkChart("#ch-weekly", {
    type: "bar",
    data: {
      labels: weeks,
      datasets: ["run", "ride", "other"].map((sp) => bars(sp === "other" ? "Strength & other" : SPORT_NAME[sp], wk.data[sp].h.slice(lead), c[sp], { stack: "s", fmt: (r) => n1(r) + " h", borderRadius: sp === "other" ? { topLeft: 4, topRight: 4 } : 0, borderSkipped: false, borderWidth: { top: sp === "run" ? 0 : 2, bottom: 0, left: 0, right: 0 } })),
    },
    options: { scales: axes({ time: false, stacked: true, xFmt: function (v, i) { const d = weeks[i]; return d && d.slice(8, 10) <= "07" && +d.slice(5, 7) % 2 ? fdate(d, { month: "short" }) : ""; }, yFmt: (v) => v + " h" }),
      plugins: { tipTitle: (dp) => "Week of " + fdate(weeks[dp.dataIndex], { day: "numeric", month: "short" }) } },
  });
  // stacked bars: square joins, 2px surface gap, rounded top only on the topmost non-zero segment
  if (wch) wch.data.datasets.forEach((ds, k) => {
    ds.borderRadius = (ctx) => {
      const i = ctx.dataIndex; const above = wch.data.datasets.slice(k + 1).some((d) => d.data[i] > 0);
      return above ? 0 : { topLeft: 4, topRight: 4 };
    };
    ds.borderColor = c.surface; ds.borderWidth = { top: k === 0 ? 0 : 2, bottom: 0, left: 0, right: 0 };
  });
  wch?.update();

  mkChart("#ch-zones", { empty: "No heart-rate zone times yet. They come from your activity files after a sync.",
    type: "bar",
    data: { labels: zn.weeks, datasets: zn.zones.map((z, i) => bars(`Zone ${i + 1}`, z, c.seq[i + 1], { stack: "z", fmt: (r) => n1(r) + " h", borderRadius: i === 4 ? { topLeft: 4, topRight: 4 } : 0, borderSkipped: false, borderColor: c.surface, borderWidth: { top: i ? 2 : 0, left: 0, right: 0, bottom: 0 } })) },
    options: { scales: axes({ time: false, stacked: true, xFmt: (v, i) => (i % 4 === 0 ? fdate(zn.weeks[i], { day: "numeric", month: "short" }) : ""), yFmt: (v) => v + " h" }),
      plugins: { tipTitle: (dp) => "Week of " + fdate(zn.weeks[dp.dataIndex], { day: "numeric", month: "short" }) } },
  });

  renderHeatmap($("#heat"), hm_);
}

function renderHeatmap(el, hm_) {
  const c = C();
  const start = new Date(hm_.start + "T12:00:00");
  const vals = Object.values(hm_.days).map((d) => d.load).filter((v) => v > 0).sort((a, b) => a - b);
  const q = (p) => vals[Math.floor(p * (vals.length - 1))] || 1;
  const th = [q(0.2), q(0.45), q(0.7), q(0.9)];
  const steps = [c.seq[0], c.seq[2], c.seq[4], c.seq[6]];
  const col = (v) => (!v ? c.heat0 : v < th[0] ? steps[0] : v < th[1] ? steps[1] : v < th[2] ? steps[2] : steps[3]);
  const cells = [];
  const today = new Date();
  for (let d = new Date(start); d <= today; d.setDate(d.getDate() + 1)) {
    const iso = d.toISOString().slice(0, 10);
    const x = hm_.days[iso];
    cells.push(`<i style="background:${col(x?.load)}" data-d="${iso}" data-l="${x ? x.load : 0}" data-k="${x ? x.km : 0}" data-s="${x ? x.sports.join(",") : ""}"></i>`);
  }
  el.innerHTML = `<div class="heat-wrap"><div class="heat-days"><span></span><span>Tue</span><span></span><span>Thu</span><span></span><span>Sat</span><span></span></div><div class="heat">${cells.join("")}</div></div>
    <div class="heat-legend">Rest ${[c.heat0, ...steps].map((x) => `<i style="background:${x}"></i>`).join("")} Hard</div>`;
  const heat = $(".heat", el);
  heat.scrollLeft = heat.scrollWidth;
  heat.addEventListener("pointermove", (e) => {
    const t = e.target.closest("i"); if (!t) return hideTip();
    const s = t.dataset.s ? t.dataset.s.split(",").map((x) => SPORT_NAME[x]).join(" + ") : "Rest day";
    showTip(`<div class="tt">${fdate(t.dataset.d, { weekday: "short", day: "numeric", month: "short", year: "numeric" })}</div><div class="tr">${s}${+t.dataset.k ? `<b>${n1(+t.dataset.k)} km</b>` : ""}</div>${+t.dataset.l ? `<div class="tr">Load<b>${t.dataset.l}</b></div>` : ""}`, e.clientX, e.clientY);
  });
  heat.addEventListener("pointerleave", hideTip);
}


// ------------------------------------------------------------------ workouts
const LEVEL = {
  green: { label: "Ready for training", ico: "✓", cls: "good" },
  amber: { label: "Take it easy today", ico: "!", cls: "warn" },
  red: { label: "Recovery day", ico: "×", cls: "crit" },
};
const INTENSITY = { easy: "Easy", moderate: "Moderate", hard: "Hard", rest: "Rest" };
const dayWord = (co) => (co.for_tomorrow ? "tomorrow" : "today");

function readinessPill(rd) {
  const L = LEVEL[rd.level];
  return `<span class="ready ${L.cls}"><span class="ico">${L.ico}</span>${L.label}</span>`;
}

function workoutMini(w) {
  const c = C();
  const main = w.steps.find((x) => x.label.includes("×")) || w.steps[0];
  return `<a class="wo-mini" href="#/plan">
    <div class="wo-top"><span class="ic" style="background:${c[w.sport]}">${ICONS[w.sport]}</span>
      <div style="min-width:0"><div class="wo-sport">${w.sport === "run" ? "Running" : "Cycling"} · <span class="int ${w.intensity}">${INTENSITY[w.intensity]}</span></div>
      <div class="wo-title">${esc(w.title)}</div></div></div>
    <div class="wo-meta">${w.minutes} min${w.km ? ` · ~${n1(w.km)} km` : ""}</div>
    <div class="wo-target">${esc(main.target)}</div>
  </a>`;
}

function todayBlock(co, gy) {
  return `<section class="today">
    <div class="today-head"><h2>Suggested workout ${dayWord(co)}</h2>${readinessPill(co.readiness)}<a class="small" href="#/plan">Details &amp; evidence →</a></div>
    <div class="today-cards">${workoutMini(co.run)}${workoutMini(co.ride)}${window.gymToday ? window.gymToday(gy) : ""}</div>
  </section>`;
}

function workoutFull(w) {
  const c = C();
  return `<section class="card span-6 wo">
    <div class="wo-top"><span class="ic" style="background:${c[w.sport]}">${ICONS[w.sport]}</span>
      <div><div class="wo-sport">${w.sport === "run" ? "Running" : "Cycling"} · <span class="int ${w.intensity}">${INTENSITY[w.intensity]}</span></div>
      <h2 class="wo-title">${esc(w.title)}</h2>
      <div class="wo-meta">${w.minutes} min total${w.km ? ` · ~${n1(w.km)} km` : ""} · evidence: ${esc(w.evidence_level)}</div></div></div>
    <ol class="steps">${w.steps.map((st) => `<li><div class="st-head"><b>${esc(st.label)}</b><span>${st.min} min</span></div><div class="st-target">${esc(st.target)}</div>${st.note ? `<div class="st-note">${esc(st.note)}</div>` : ""}</li>`).join("")}</ol>
    <h3>Why this workout</h3><ul class="why">${w.why.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>
    <h3>Staying within your trend</h3><ul class="why guard">${w.guardrails.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>
    <details><summary>Evidence (${w.refs.length})</summary><ul class="refs">${w.refs.map((r) => `<li><b>${esc(r.cite)}</b><br>${esc(r.finding)}</li>`).join("")}</ul></details>
  </section>`;
}

async function renderPlan() {
  const co = await api("/api/coach", true);
  const rd = co.readiness, cx = co.context;
  const dot = { green: "var(--good)", amber: "var(--warning)", red: "var(--critical)", none: "var(--axis)" };
  const runT = co.run.targets, rideT = co.ride.targets;
  const d28 = cx.dist28;
  app.innerHTML = `
    <div class="page-head"><div><h1>Workout ${dayWord(co)}</h1><p class="sub">${fdate(co.plan_day, { weekday: "long", day: "numeric", month: "long" })} · pick whichever you feel like – one of the two, not both${co.for_tomorrow ? " · you've already trained today; check again tomorrow morning after your night's HRV and sleep are synced" : ""}</p></div>${readinessPill(rd)}</div>
    <div class="grid">
      ${card("Recovery check", `<ul class="factors">${rd.factors.map((f) => `<li><i style="background:${dot[f.status]}"></i><b>${esc(f.name)}</b><span>${esc(f.text)}</span></li>`).join("")}</ul>
        <p class="small muted" style="margin:10px 0 0">${co.hard_allowed ? "All checks passed – a hard session is allowed." : "No hard session " + dayWord(co) + ": " + esc(co.hard_blockers.join("; ")) + "."}</p>`, { span: 7 })}
      ${card("Context", `<dl class="kv">
        <dt>Last hard session</dt><dd>${cx.last_hard ? `<a href="#/activity/${cx.last_hard.id}">${esc(cx.last_hard.name)}</a> · ${cx.hours_since_hard} h ago` : "none in 60 days"}</dd>
        <dt>Hard sessions, 7 days</dt><dd>${cx.hard_7d}</dd>
        <dt>Intensity, 4 weeks</dt><dd>${d28 ? `${Math.round(d28.easy * 100)} % easy · ${Math.round(d28.mid * 100)} % moderate · ${Math.round(d28.hard * 100)} % hard` : "–"}</dd>
        <dt>Running, last 7 days</dt><dd>${n1(cx.run_week_km)} km <span class="muted">(4-week avg ${n1(cx.run_chronic_km)} km)</span></dd>
        <dt>Longest run, 30 days</dt><dd>${n1(cx.run_longest30)} km</dd>
        <dt>Cycling, last 7 days</dt><dd>${n1(cx.ride_week_h)} h <span class="muted">(4-week avg ${n1(cx.ride_chronic_h)} h)</span></dd>
      </dl>`, { span: 5 })}
      ${workoutFull(co.run)}
      ${workoutFull(co.ride)}
      ${card("Your training targets", `<div class="table-wrap"><table><thead><tr><th>Intensity</th><th>Running</th><th>Cycling</th></tr></thead><tbody>
        <tr><td>Recovery</td><td>${esc(runT.recovery_hr)}</td><td>${esc(rideT.recovery_w ? rideT.recovery_w + " · " : "")}${esc(rideT.recovery_hr)}</td></tr>
        <tr><td>Easy / endurance</td><td>${esc(runT.easy_pace ? runT.easy_pace + " · " : "")}${esc(runT.easy_hr)}</td><td>${esc(rideT.endurance_w ? rideT.endurance_w + " · " : "")}${esc(rideT.easy_hr)}</td></tr>
        <tr><td>Threshold</td><td>${esc(runT.threshold_pace ? runT.threshold_pace + " · " : "")}${esc(runT.threshold_hr)}</td><td>${esc(rideT.threshold_w ? rideT.threshold_w + " · " : "")}${esc(rideT.threshold_hr)}</td></tr>
        <tr><td>VO₂max</td><td>${esc(runT.vo2_pace ? runT.vo2_pace + " · " : "")}${esc(runT.vo2_hr)}</td><td>${esc(rideT.vo2_w ? "30/15 work " + rideT.vo2_w : "very hard, ~9/10")}</td></tr>
      </tbody></table></div>
      <p class="small muted" style="margin:10px 0 0">Paces from VDOT ${cx.vdot ?? "–"}${cx.vdot_src ? ` (${esc(cx.vdot_src)})` : " – no recent run ≥ 3 km, so heart rate only"}. Power from FTP ${cx.ftp ? n0(cx.ftp) + " W" : "–"} (${esc(cx.ftp_src)}). On hilly routes go by heart rate, not pace.</p>`, { span: 12 })}
      ${card("How suggestions are made", `<ol class="method">
        <li><b>Recovery check.</b> HRV is compared as a 7-day rolling average of ln(HRV) against your own baseline ± 0.5 SD (the "smallest worthwhile change"), as in HRV-guided training studies. Resting HR ≥ 3–5 bpm above baseline, short sleep and very negative form also count. One flag → easy day; two or more → recovery day.</li>
        <li><b>Hard day gate.</b> Intervals only if everything is green, at least 48 h have passed since your last hard session, you've had fewer than 2 hard sessions this week (3 if your fitness is high), and less than 20 % of your recent training time was in zones 4–5 (polarised training).</li>
        <li><b>Session type.</b> Hard days alternate between threshold and VO₂max work; after a break you restart with a short threshold session. Otherwise a long session if none in 6 days, else easy aerobic volume.</li>
        <li><b>Dose.</b> A run is never longer than your longest run of the last 30 days (+5 % at most on long-run days) – the strongest injury predictor in the largest running study to date. Weekly volume stays below 1.3 × your 4-week average. Rides are capped at +10 % on your longest ride.</li>
        <li><b>Targets.</b> Running paces from your VDOT (Daniels), heart rate from your Garmin zones, cycling power from your FTP (Coggan zones).</li>
      </ol>
      <details><summary>All references</summary><ul class="refs">${Object.values(co.refs).map((r) => `<li><b>${esc(r.cite)}</b><br>${esc(r.finding)}</li>`).join("")}</ul></details>
      <p class="small muted" style="margin:10px 0 0">These are suggestions from your data, not medical advice. Stop and switch to easy if something hurts or feels wrong – how you feel always overrides the numbers.</p>`, { span: 12 })}
    </div>`;
}

// ------------------------------------------------------------------ running
async function renderRunning() {
  const [r, wk] = await Promise.all([api("/api/running"), api(`/api/weekly?weeks=${progWeeks()}`)]);
  const c = C();
  if (!r.trend.length) { app.innerHTML = '<div class="empty">No runs yet.</div>'; return; }
  const latestVo2 = r.vo2max.length ? r.vo2max[r.vo2max.length - 1].v : null;
  const pr5 = r.best.find((b) => b.label === "5 km");
  const distances = r.best.map((b) => b.label);
  const rg = progRange();
  app.innerHTML = `
    <p class="pg-ytd">${new Date().getFullYear()} so far: ${r.ytd.n} ${r.ytd.n === 1 ? "run" : "runs"}.</p>
    <div class="tiles">
      ${tile("Distance this year", n0(r.ytd.km), "km")}
      ${tile("Time this year", n0(r.ytd.h), "h")}
      ${tile("VO₂ max", latestVo2 ? n0(latestVo2) : "–", "", "Garmin estimate")}
      ${tile("5 km best", pr5 ? dur(pr5.seconds) : "–", "", pr5 ? fdate(pr5.date) : "")}
      ${tile("Predicted 10 km", r.predictions["10 km"] ? dur(r.predictions["10 km"]) : "–", "", r.prediction_basis ? `from your ${r.prediction_basis.label} (last 90 days)` : "needs a recent run ≥ 3 km")}
      ${tile("Predicted half", r.predictions["Half marathon"] ? dur(r.predictions["Half marathon"]) : "–")}
    </div>
    <div class="grid">
      ${card("Pace", `<div class="chart tall" id="ch-pace"></div>`, { span: 8, sub: "Average moving pace per run (faster is higher)", right: legend([["Run", c.run], ["30-day average", c.text2, "line"]]) })}
      ${card("Weekly distance", `<div class="chart tall" id="ch-wkm"></div>`, { span: 4, sub: "km per week" })}
      ${card("Personal bests", bestTable(r), { span: 12, sub: "Fastest segments found inside your runs (from the activity files)" })}
      ${card("PR progression", `<div class="chart" id="ch-prog"></div>`, { span: 6, sub: "Each time you set a new best", right: `<select id="sel-prog">${distances.map((d) => `<option ${d === "5 km" ? "selected" : ""}>${d}</option>`).join("")}</select>` })}
      ${card("Aerobic efficiency", `<div class="chart" id="ch-ef"></div>`, { span: 6, sub: "Easy runs only: metres per minute per heartbeat. Rising = fitter.", right: legend([["Easy run", c.run], ["30-day average", c.text2, "line"]]) })}
      ${card("VO₂ max", `<div class="chart short" id="ch-vo2"></div>`, { span: 4 })}
      ${card("Cadence", `<div class="chart short" id="ch-cad"></div>`, { span: 4, sub: "steps per minute" })}
      ${card("Ground contact time", `<div class="chart short" id="ch-gct"></div>`, { span: 4, sub: "milliseconds – lower is usually more efficient" })}
      ${card("Recent runs", runTable(r.runs.slice(0, 25)), { span: 12 })}
    </div>`;

  const draw = (days) => {
    charts.splice(0).forEach((ch) => ch.destroy());
    const cut = daysAgo(+days);
    const f = (arr) => arr.filter((p) => p.date >= cut);
    const tr = f(r.trend);
    const unit = +days <= 120 ? "week" : "month";
    mkChart("#ch-pace", {
      type: "line",
      data: { datasets: [
        dots("Pace", tr.map((p) => ({ x: p.date, y: p.pace, km: p.km, hr: p.hr, id: p.id })), c.run, { fmt: (raw) => `${pace(raw.y)}/km · ${n1(raw.km)} km${raw.hr ? ` · ${raw.hr} bpm` : ""}` }),
        line("30-day average", rolling(tr, "pace"), c.text2, { fmt: (raw) => pace(raw.y) + "/km", pointHoverRadius: 0 }),
      ] },
      options: { interaction: { mode: "nearest", intersect: false, axis: "x" }, scales: axes({ unit, yReverse: true, yFmt: (v) => pace(v) }),
        onClick: (e, els) => { const el = els.find((x) => x.datasetIndex === 0); if (el) location.hash = "#/activity/" + tr[el.index].id; } },
    });
    let weeksIdx = wk.weeks.map((w, i) => [w, i]).filter(([w]) => w >= cut);
    if (+days >= 9999) weeksIdx = weeksIdx.slice(emptyLead(weeksIdx.length, [weeksIdx.map(([, i]) => wk.data.run.km[i])]));
    mkChart("#ch-wkm", {
      type: "bar",
      data: { labels: weeksIdx.map(([w]) => w), datasets: [bars("Distance", weeksIdx.map(([, i]) => wk.data.run.km[i]), c.run, { fmt: (v) => n1(v) + " km" })] },
      options: { scales: axes({ time: false, yBegin: true, xFmt: (v, i) => (i % Math.ceil(weeksIdx.length / 6) === 0 ? fdate(weeksIdx[i][0], { day: "numeric", month: "short" }) : "") }),
        plugins: { tipTitle: (dp) => "Week of " + fdate(weeksIdx[dp.dataIndex][0], { day: "numeric", month: "short" }) } },
    });
    const ef = f(r.easy_ef);
    mkChart("#ch-ef", { empty: "Needs runs with heart rate and pace from the activity files.",
      type: "line",
      data: { datasets: [dots("Efficiency", ef.map((p) => ({ x: p.date, y: p.ef })), c.run, { fmt: (raw) => raw.y.toFixed(3) }), line("30-day average", rolling(ef, "ef"), c.text2, { fmt: (raw) => raw.y.toFixed(3) })] },
      options: { interaction: { mode: "nearest", intersect: false, axis: "x" }, scales: axes({ unit, yFmt: (v) => v.toFixed(2) }) },
    });
    const vo = f(r.vo2max);
    mkChart("#ch-vo2", { type: "line", data: { datasets: [line("VO₂ max", vo.map((p) => ({ x: p.date, y: p.v })), c.run, { stepped: true, tension: 0, fmt: (raw) => n0(raw.y) })] }, options: { scales: axes({ unit, yFmt: (v) => Math.round(v) }) } });
    const fm = f(r.form);
    mkChart("#ch-cad", { type: "line", data: { datasets: [dots("Cadence", fm.filter((p) => p.cad).map((p) => ({ x: p.date, y: p.cad })), c.run, { pointRadius: 2.5, fmt: (raw) => n0(raw.y) + " spm" })] }, options: { interaction: { mode: "nearest", intersect: false, axis: "x" }, scales: axes({ unit }) } });
    mkChart("#ch-gct", { type: "line", data: { datasets: [dots("Ground contact", fm.filter((p) => p.gct).map((p) => ({ x: p.date, y: p.gct })), c.run, { pointRadius: 2.5, fmt: (raw) => n0(raw.y) + " ms" })] }, options: { interaction: { mode: "nearest", intersect: false, axis: "x" }, scales: axes({ unit }) } });
    drawProg();
  };
  const drawProg = () => {
    const ex = charts.find((ch) => ch.canvas.parentNode?.id === "ch-prog");
    if (ex) { ex.destroy(); charts.splice(charts.indexOf(ex), 1); }
    const d = $("#sel-prog").value;
    const pts = (r.progression[d] || []).map((p) => ({ x: p.date, y: p.seconds, id: p.id }));
    if (pts.length) pts.push({ x: new Date().toISOString().slice(0, 10), y: pts[pts.length - 1].y, end: true });
    mkChart("#ch-prog", { empty: "Your best efforts show up here once activity files are in.",
      type: "line",
      data: { datasets: [line(d, pts, c.run, { stepped: "before", tension: 0, pointRadius: (ctx) => (ctx.raw?.end ? 0 : 4), pointBackgroundColor: c.run, pointBorderColor: c.surface, pointBorderWidth: 2, fmt: (raw) => (raw.end ? "current best " : "") + dur(raw.y) })] },
      options: { interaction: { mode: "nearest", intersect: false, axis: "x" }, scales: axes({ yFmt: (v) => dur(v) }) },
    });
  };
  draw(rg);
  $("#sel-prog").addEventListener("change", drawProg);
}

function bestTable(r) {
  if (!r.best.length) return '<p class="muted small">Personal bests appear once activity files have been downloaded.</p>';
  const pred = r.predictions || {};
  return `<div class="table-wrap"><table><thead><tr><th>Distance</th><th class="num">All-time best</th><th>Date</th><th class="num">Last 12 months</th><th class="num">Last 90 days</th><th class="num">Pace</th><th class="num">Predicted now</th></tr></thead><tbody>
    ${r.best.map((b) => `<tr class="click" onclick="location.hash='#/activity/${b.id}'"><td>${b.label}</td><td class="num"><b>${dur(b.seconds)}</b></td><td class="muted">${fdate(b.date)}</td>
      <td class="num">${r.best_365d[b.label] ? dur(r.best_365d[b.label].seconds) : "–"}</td><td class="num">${r.best_90d[b.label] ? dur(r.best_90d[b.label].seconds) : "–"}</td>
      <td class="num muted">${pace(b.seconds / (b.meters / 1000))}/km</td><td class="num">${pred[b.label] ? dur(pred[b.label]) : ""}</td></tr>`).join("")}
  </tbody></table></div>`;
}

function runTable(runs) {
  return `<div class="table-wrap"><table><thead><tr><th>Date</th><th>Name</th><th class="num">Distance</th><th class="num">Time</th><th class="num">Pace</th><th class="num">HR</th><th class="num">Elev.</th><th class="num">Load</th></tr></thead><tbody>
  ${runs.map((a) => `<tr class="click" onclick="location.hash='#/activity/${a.id}'"><td class="muted">${fdate(a.date, { day: "numeric", month: "short", year: "2-digit" })}</td><td>${esc(a.name)}</td><td class="num">${n1(a.km)} km</td><td class="num">${dur(a.secs)}</td><td class="num">${pace(a.pace)}</td><td class="num">${a.hr ?? "–"}</td><td class="num">${n0(a.elev)} m</td><td class="num">${n0(a.load)}</td></tr>`).join("")}
  </tbody></table></div>`;
}

// ------------------------------------------------------------------ cycling
const DUR_LABEL = (s) => (s < 60 ? `${s}s` : s < 3600 ? `${s / 60}m` : `${s / 3600}h`);

async function renderCycling() {
  const [cy, wk] = await Promise.all([api("/api/cycling"), api(`/api/weekly?weeks=${progWeeks()}`)]);
  const c = C();
  if (!cy.rides.length) { app.innerHTML = '<div class="empty">No rides yet.</div>'; return; }
  const wkg = cy.ftp && cy.weight ? cy.ftp / cy.weight : null;
  const rg = progRange();
  const pm = store.get("pc-mode", "w");
  app.innerHTML = `
    <p class="pg-ytd">${new Date().getFullYear()} so far: ${cy.ytd.n} ${cy.ytd.n === 1 ? "ride" : "rides"}.</p>
    <div class="tiles">
      ${tile("Distance this year", n0(cy.ytd.km), "km")}
      ${tile("Climbing this year", n0(cy.ytd.elev), "m")}
      ${tile("Time this year", n0(cy.ytd.h), "h")}
      ${tile("FTP", cy.ftp ? n0(cy.ftp) : "–", "W", esc(cy.ftp_source))}
      ${tile("Power-to-weight", wkg ? wkg.toFixed(2) : "–", "W/kg", cy.weight ? `at ${n1(cy.weight)} kg` : "weight unknown")}
      ${tile("Climbs detected", n0(cy.climb_count), "", "≥ 50 m gain, ≥ 3 %")}
    </div>
    <div class="grid">
      ${card("Power curve", `<div class="chart tall" id="ch-pc"></div>`, { span: 8, sub: "Best average power for each duration", right: seg("pc-mode", [["w", "W"], ["wkg", "W/kg"]], pm) + legend([["All time", c.s1, "line"], ["Last 12 months", c.s2, "line"], ["Last 90 days", c.s3, "line"]]) })}
      ${card("Estimated FTP", `<div class="chart tall" id="ch-eftp"></div>`, { span: 4, sub: "95 % of best 20-min power in the trailing 90 days" })}
      ${card("Weekly distance", `<div class="chart short" id="ch-wkm"></div>`, { span: 6, sub: "km per week" })}
      ${card("Weekly climbing", `<div class="chart short" id="ch-wel"></div>`, { span: 6, sub: "metres of elevation gain per week" })}
      ${card("Best climbs", climbTable(cy.climbs_top), { span: 12, sub: "Sorted by VAM (vertical metres per hour) – the climber's speed metric", right: seg("climb-sort", [["vam", "Fastest"], ["recent", "Recent"]], "vam") })}
      ${card("Climbing speed", `<div class="chart" id="ch-vam"></div>`, { span: 6, sub: "Best VAM per ride, climbs ≥ 150 m", right: legend([["Ride", c.ride], ["60-day average", c.text2, "line"]]) })}
      ${card("Power zones", `<div id="pz"></div>`, { span: 6, sub: cy.ftp ? `Last 28 days, based on FTP ${n0(cy.ftp)} W` : "Needs power data" })}
      ${card("Efficiency (power ÷ heart rate)", `<div class="chart" id="ch-ef"></div>`, { span: 6, sub: "Rides with power: higher means more watts for the same heart rate", right: legend([["Ride", c.ride], ["60-day average", c.text2, "line"]]) })}
      ${card("Outdoor speed", `<div class="chart" id="ch-spd"></div>`, { span: 6, sub: "Average speed per outdoor ride (hilly rides are slower)", right: legend([["Ride", c.ride], ["60-day average", c.text2, "line"]]) })}
      ${card("Recent rides", rideTable(cy.rides.slice(0, 25)), { span: 12 })}
    </div>`;

  const pzLabels = ["Z1 Recovery", "Z2 Endurance", "Z3 Tempo", "Z4 Threshold", "Z5 VO₂ max", "Z6 Anaerobic", "Z7 Sprint"];
  zoneBars($("#pz"), cy.power_zones_28d_h.map((h) => h * 3600), pzLabels, c.seq);

  const drawPC = (mode) => {
    const ex = charts.find((ch) => ch.canvas.parentNode?.id === "ch-pc");
    if (ex) { ex.destroy(); charts.splice(charts.indexOf(ex), 1); }
    const conv = (w) => (mode === "wkg" && cy.weight ? w / cy.weight : w);
    const fmtv = (v) => (mode === "wkg" ? v.toFixed(2) + " W/kg" : n0(v) + " W");
    const ds = [["All time", cy.curves.all, c.s1], ["Last 12 months", cy.curves["365"], c.s2], ["Last 90 days", cy.curves["90"], c.s3]].map(([l, pts, col]) =>
      line(l, pts.map((p) => ({ x: p.s, y: conv(p.w), date: p.date })), col, { tension: 0.3, fmt: (raw) => `${fmtv(raw.y)} <span class="muted">${fdate(raw.date, { day: "numeric", month: "short", year: "2-digit" })}</span>` }));
    mkChart("#ch-pc", { empty: "Needs rides with a power meter.",
      type: "line", data: { datasets: ds },
      options: {
        scales: { ...axes({ xType: "logarithmic", yBegin: true, yFmt: (v) => (mode === "wkg" ? v.toFixed(1) : v) }),
          x: { type: "logarithmic", min: 1, max: 7200, grid: { color: C().grid, drawTicks: false }, border: { color: C().axis }, afterBuildTicks: (ax) => { ax.ticks = [1, 5, 15, 60, 300, 1200, 3600].map((v) => ({ value: v })); }, ticks: { color: C().muted, callback: (v) => DUR_LABEL(v) } } },
        plugins: { tipTitle: (dp) => DUR_LABEL(dp.raw.x) },
      },
    });
  };

  const draw = (days) => {
    charts.splice(0).forEach((ch) => ch.destroy());
    const cut = daysAgo(+days);
    const unit = +days <= 120 ? "week" : "month";
    drawPC(store.get("pc-mode", "w"));
    mkChart("#ch-eftp", { empty: "Needs rides with a power meter.", type: "line", data: { datasets: [line("eFTP", cy.eftp.filter((p) => p.date >= cut).map((p) => ({ x: p.date, y: p.w })), c.ride, { tension: 0, fmt: (raw) => n0(raw.y) + " W" + (cy.weight ? ` · ${(raw.y / cy.weight).toFixed(2)} W/kg` : "") })] }, options: { scales: axes({ unit }) } });
    let weeksIdx = wk.weeks.map((w, i) => [w, i]).filter(([w]) => w >= cut);
    if (+days >= 9999) weeksIdx = weeksIdx.slice(emptyLead(weeksIdx.length, [weeksIdx.map(([, i]) => wk.data.ride.km[i]), weeksIdx.map(([, i]) => wk.data.ride.elev[i])]));
    const wopts = (fmt) => ({ scales: axes({ time: false, yBegin: true, xFmt: (v, i) => (i % Math.ceil(weeksIdx.length / 6) === 0 ? fdate(weeksIdx[i][0], { day: "numeric", month: "short" }) : "") }), plugins: { tipTitle: (dp) => "Week of " + fdate(weeksIdx[dp.dataIndex][0], { day: "numeric", month: "short" }) } });
    mkChart("#ch-wkm", { type: "bar", data: { labels: weeksIdx.map(([w]) => w), datasets: [bars("Distance", weeksIdx.map(([, i]) => wk.data.ride.km[i]), c.ride, { fmt: (v) => n1(v) + " km" })] }, options: wopts() });
    mkChart("#ch-wel", { type: "bar", data: { labels: weeksIdx.map(([w]) => w), datasets: [bars("Elevation", weeksIdx.map(([, i]) => wk.data.ride.elev[i]), c.ride, { fmt: (v) => n0(v) + " m" })] }, options: wopts() });
    const scatter = (sel, pts, key, fmt, label, empty) => {
      const p = pts.filter((x) => x.date >= cut);
      mkChart(sel, { type: "line", empty, data: { datasets: [dots(label, p.map((x) => ({ x: x.date, y: x[key], id: x.id, raw: x })), c.ride, { fmt }), line("60-day average", rolling(p, key, 60), c.text2, { fmt: (raw) => fmt({ y: raw.y }) })] },
        options: { interaction: { mode: "nearest", intersect: false, axis: "x" }, scales: axes({ unit }), onClick: (e, els) => { const el = els.find((x) => x.datasetIndex === 0); if (el) location.hash = "#/activity/" + p[el.index].id; } } });
    };
    scatter("#ch-vam", cy.vam_trend, "vam", (raw) => n0(raw.y) + " m/h" + (raw.raw ? ` · ${raw.raw.gain} m climb` : ""), "VAM", "No climbs in this period. Climbs come from rides with an activity file.");
    scatter("#ch-ef", cy.ef, "ef", (raw) => raw.y.toFixed(2) + " W/bpm", "Efficiency", "Needs rides with power and heart rate.");
    scatter("#ch-spd", cy.speed, "kmh", (raw) => n1(raw.y) + " km/h" + (raw.raw ? ` · ${n0(raw.raw.elev_per_km)} m/km` : ""), "Speed");
  };
  draw(rg);
  onSeg("pc-mode", (v) => { store.set("pc-mode", v); drawPC(v); });
  onSeg("climb-sort", (v) => { $("#climbs").outerHTML = climbTable(v === "vam" ? cy.climbs_top : cy.climbs_recent); });
}

function zoneBars(el, secs, labels, ramp, offset = 1) {
  if (!secs || !secs.some((x) => x > 0)) { el.innerHTML = '<p class="muted small">No data for this period.</p>'; return; }
  const max = Math.max(...secs), total = secs.reduce((a, b) => a + b, 0);
  const zl = labels.some((l) => l.length > 3) ? "112px" : "30px";
  el.innerHTML = secs.map((s, i) => `<div class="zonebar" style="--zl:${zl}"><span class="lbl">${labels[i]}</span><div><div class="bar" style="width:${(s / max) * 100}%;background:${ramp[Math.min(ramp.length - 1, i + offset - (labels.length > 5 ? 1 : 0))]}"></div></div><span class="val">${hm(s)} · ${Math.round((s / total) * 100)}%</span></div>`).join("");
}

function climbTable(climbs) {
  if (!climbs.length) return '<div id="climbs"><p class="muted small">No climbs detected yet.</p></div>';
  return `<div class="table-wrap" id="climbs"><table><thead><tr><th>Date</th><th>Ride</th><th class="num">Length</th><th class="num">Gain</th><th class="num">Grade</th><th class="num">Time</th><th class="num">VAM</th><th class="num">Power</th><th class="num">W/kg</th><th class="num">HR</th><th class="num">Top</th></tr></thead><tbody>
  ${climbs.map((k) => `<tr class="click" onclick="location.hash='#/activity/${k.id}'"><td class="muted">${fdate(k.date, { day: "numeric", month: "short", year: "2-digit" })}</td><td>${esc(k.name)} <span class="muted small">km ${n1(k.start_km)}</span></td><td class="num">${n1(k.length_m / 1000)} km</td><td class="num">${n0(k.gain_m)} m</td><td class="num">${n1(k.grade_pct)} %</td><td class="num">${dur(k.duration_s)}</td><td class="num"><b>${n0(k.vam)}</b></td><td class="num">${k.avg_power ? n0(k.avg_power) + " W" : "–"}</td><td class="num">${k.wkg ? k.wkg.toFixed(2) : "–"}</td><td class="num">${k.avg_hr ? n0(k.avg_hr) : "–"}</td><td class="num muted">${n0(k.top_alt)} m</td></tr>`).join("")}
  </tbody></table></div>`;
}

function rideTable(rides) {
  return `<div class="table-wrap"><table><thead><tr><th>Date</th><th>Name</th><th class="num">Distance</th><th class="num">Time</th><th class="num">Speed</th><th class="num">Elev.</th><th class="num">NP</th><th class="num">TSS</th><th class="num">HR</th></tr></thead><tbody>
  ${rides.map((a) => `<tr class="click" onclick="location.hash='#/activity/${a.id}'"><td class="muted">${fdate(a.date, { day: "numeric", month: "short", year: "2-digit" })}</td><td>${esc(a.name)}${a.indoor ? ' <span class="muted small">indoor</span>' : ""}</td><td class="num">${n1(a.km)} km</td><td class="num">${dur(a.secs)}</td><td class="num">${n1(a.speed_kmh)}</td><td class="num">${n0(a.elev)} m</td><td class="num">${a.np ? a.np + " W" : "–"}</td><td class="num">${a.tss ?? "–"}</td><td class="num">${a.hr ?? "–"}</td></tr>`).join("")}
  </tbody></table></div>`;
}

// ------------------------------------------------------------------ activities
async function renderActivities() {
  const st = { sport: store.get("act-sport", ""), q: "", offset: 0 };
  app.innerHTML = `
    <div class="page-head"><div><h1>Activities</h1><p class="sub" id="act-count"></p></div>
      <div class="controls">${seg("act-sport", [["", "All"], ["run", "Runs"], ["ride", "Rides"], ["other", "Other"]], st.sport)}<input type="search" id="act-q" placeholder="Search name, place or date" aria-label="Search activities"></div></div>
    <section class="card"><div class="act-list" id="act-list"></div><div style="text-align:center;margin-top:12px"><button class="btn" id="act-more" hidden>Load more</button></div></section>`;
  const load = async (append = false) => {
    const d = await api(`/api/activities?sport=${st.sport}&q=${encodeURIComponent(st.q)}&limit=50&offset=${st.offset}`);
    $("#act-count").textContent = `${d.total.toLocaleString("de-CH")} activities`;
    const html = d.items.map(actRow).join("") || '<div class="empty">Nothing found.</div>';
    $("#act-list").innerHTML = append ? $("#act-list").innerHTML + html : html;
    $("#act-more").hidden = st.offset + 50 >= d.total;
  };
  onSeg("act-sport", (v) => { st.sport = v; st.offset = 0; store.set("act-sport", v); load(); });
  let t;
  $("#act-q").addEventListener("input", (e) => { clearTimeout(t); t = setTimeout(() => { st.q = e.target.value.trim(); st.offset = 0; load(); }, 250); });
  $("#act-more").addEventListener("click", () => { st.offset += 50; load(true); });
  await load();
}

async function renderActivity(id) {
  const a = await api("/api/activity/" + id);
  const c = C(), col = c[a.sport], m = a.metrics || {}, s = a.streams || {};
  const isRun = a.sport === "run";
  const hasGps = s.lat && s.lat.some((x) => x != null);
  // Distance on the x-axis only when the activity covers ground: a stair stepper or trainer file can carry a
  // distance field that stays at 0, which would stack every point at x = 0 (empty-looking charts).
  const distMax = (s.dist || []).reduce((mx, v) => (v != null && v > mx ? v : mx), 0);
  const xKey = s.dist && distMax > 0.05 ? "dist" : "t";
  // Board "Activity detail": big numbers with the unit, label underneath.
  const stat = (label, value, unit = "", note = "") => (value == null || value === "–" ? "" : `<div class="av-stat"><b class="u-num">${value}${unit ? `<small>${unit}</small>` : ""}</b><span>${label}${note ? `<em>${note}</em>` : ""}</span></div>`);
  const ts = [
    a.km ? stat("Distance", n1(a.km), "km") : "",
    stat("Moving time", dur(a.secs), "", a.elapsed && a.elapsed - a.secs > 60 ? `elapsed ${dur(a.elapsed)}` : ""),
    a.km ? (isRun ? stat("Pace", pace(a.pace), "/km") : stat("Speed", n1(a.speed_kmh), "km/h")) : "",
    a.elev ? stat("Climbed", n0(a.elev), "m") : "",
    a.hr ? stat("Heart rate", Math.round(a.hr), "bpm", a.max_hr ? `max ${Math.round(a.max_hr)}` : "") : "",
    a.np || a.power ? stat(a.np ? "Norm. power" : "Power", a.np ?? a.power, "W", a.np && a.power ? `average ${a.power} W` : "") : "",
    a.tss ? stat("TSS", a.tss, "", a.if ? `IF ${a.if.toFixed(2)}` : "") : "",
    a.load ? stat("Training load", n0(a.load), "", a.te ? `aerobic effect ${n1(a.te)}` : "") : "",
    m.ef ? stat("Efficiency", m.ef.toFixed(2), "", m.decoupling_pct != null ? `HR drift ${n1(m.decoupling_pct)} %` : m.ef_basis === "power" ? "W per bpm" : "m/min per bpm") : "",
    isRun && a.running_dyn?.cad ? stat("Cadence", a.running_dyn.cad, "spm", a.running_dyn.stride ? `stride ${a.running_dyn.stride} m` : "") : "",
  ].join("");
  const streams = [
    ["hr", "Heart rate", "bpm", c.critical, (v) => n0(v) + " bpm"],
    isRun ? ["pace", "Pace", "/km", col, (v) => pace(v) + "/km"] : ["speed", "Speed", "km/h", col, (v) => n1(v) + " km/h"],
    ["power", "Power", "W", c.s7, (v) => n0(v) + " W"],
    ["alt", "Elevation", "m", c.muted, (v) => n0(v) + " m"],
    ["cadence", "Cadence", isRun ? "spm" : "rpm", c.s3, (v) => n0(v)],
  ].filter(([k]) => (k === "pace" ? s.speed : s[k]) && (k === "pace" ? s.speed : s[k]).some((x) => x != null));
  const climbs = (m.climbs || []);
  const eff = m.best_efforts ? Object.entries(m.best_efforts) : [];
  const when = [fdate(a.start || a.date, { weekday: "long", day: "numeric", month: "long" }), a.start && a.start.length > 10 ? a.start.slice(11, 16) : "", a.location || ""].filter(Boolean).join(", ");
  pageHead(a.name || "Activity", { sub: when, back: "#/activities", backLabel: "Activities" });
  // One bar of time per zone, the main zone named in words (board: "58 % in zone 2").
  const zoneCard = (title, secs, sub) => {
    const tot = secs.reduce((p, q) => p + (q || 0), 0);
    if (!tot) return "";
    const pct = secs.map((v) => Math.round(((v || 0) / tot) * 100)), top = pct.indexOf(Math.max(...pct));
    const cols = c.seq || [];
    return `<div class="u-card av-zones"><div class="av-zh"><b>${title}</b><span class="u-c2">${sub}</span></div>
      <p class="av-zbig u-num">${pct[top]} % in zone ${top + 1}</p>
      <div class="av-zbar" aria-hidden="true">${pct.map((p, z) => (p ? `<i style="flex:${p};background:${cols[Math.min(z, cols.length - 1)] || "var(--u-ink2)"}"></i>` : "")).join("")}</div>
      <div class="av-zkey">${secs.map((v, z) => `<span><i style="background:${cols[Math.min(z, cols.length - 1)] || "var(--u-ink2)"}"></i>Z${z + 1} <b class="u-num">${dur(v || 0)}</b></span>`).join("")}</div></div>`;
  };
  const zoneHTML = (a.hr_zones_s ? zoneCard("Heart rate", a.hr_zones_s, a.max_hr ? `max ${Math.round(a.max_hr)} bpm` : "") : "")
    + (a.power_zones_s ? zoneCard("Power", a.power_zones_s, a.ftp ? `FTP ${n0(a.ftp)} W` : "") : "");
  app.innerHTML = `
    <div class="u-card av-stats">${ts}</div>${zoneHTML}
    <div class="grid">
      ${hasGps ? card("Route", `<div id="map"></div>`, { span: 12 }) : ""}
      ${streams.length ? card("Data", `<div class="stack-charts">${streams.map(([k, l, u, cl]) => `<div class="row-label"><i class="key line" style="background:${cl}"></i>${l} <span class="muted">${u}</span></div><div class="chart" id="st-${k}"></div>`).join("")}</div>`, { span: 8, sub: `x-axis: ${xKey === "dist" ? "distance (km)" : "time"}` }) : (a.has_file ? "" : card("Data", '<p class="muted small">The activity file has not been downloaded yet.</p>', { span: 8 }))}
      ${a.curve_vs_best ? card("Power curve", `<div class="chart" id="ch-apc"></div>`, { span: 6, sub: "This ride vs. your all-time best", right: legend([["This ride", col, "line"], ["All-time best", c.muted, "line"]]) }) : ""}
      ${climbs.length ? card("Climbs", `<div class="table-wrap"><table><thead><tr><th>Start</th><th class="num">Length</th><th class="num">Gain</th><th class="num">Grade</th><th class="num">Time</th><th class="num">VAM</th><th class="num">Power</th><th class="num">HR</th></tr></thead><tbody>${climbs.map((k) => `<tr><td>km ${n1(k.start_km)}</td><td class="num">${n1(k.length_m / 1000)} km</td><td class="num">${n0(k.gain_m)} m</td><td class="num">${n1(k.grade_pct)} %</td><td class="num">${dur(k.duration_s)}</td><td class="num"><b>${n0(k.vam)}</b></td><td class="num">${k.avg_power ? n0(k.avg_power) + " W" : "–"}</td><td class="num">${k.avg_hr ? n0(k.avg_hr) : "–"}</td></tr>`).join("")}</tbody></table></div>`, { span: 6, sub: "VAM = vertical metres per hour" }) : ""}
      ${eff.length ? card("Best efforts in this activity", `<div class="table-wrap"><table><thead><tr><th>Distance</th><th class="num">Time</th><th class="num">${isRun ? "Pace" : "Speed"}</th></tr></thead><tbody>${eff.map(([l, e]) => `<tr><td>${l}</td><td class="num">${dur(e.seconds)}</td><td class="num">${isRun ? pace(e.seconds / (e.meters / 1000)) + "/km" : n1(e.meters / e.seconds * 3.6) + " km/h"}</td></tr>`).join("")}</tbody></table></div>`, { span: 6 }) : ""}
      ${a.laps.length > 1 ? card("Laps", `<div class="table-wrap"><table><thead><tr><th>#</th><th class="num">Distance</th><th class="num">Time</th><th class="num">${isRun ? "Pace" : "Speed"}</th><th class="num">HR</th><th class="num">Max HR</th>${a.laps.some((l) => l.avg_power) ? '<th class="num">Power</th>' : ""}<th class="num">Ascent</th></tr></thead><tbody>${a.laps.map((l, i) => `<tr><td>${i + 1}</td><td class="num">${l.dist_m ? n1(l.dist_m / 1000) + " km" : "–"}</td><td class="num">${dur(l.timer_s)}</td><td class="num">${l.dist_m && l.timer_s ? (isRun ? pace(l.timer_s / (l.dist_m / 1000)) : n1(l.dist_m / l.timer_s * 3.6)) : "–"}</td><td class="num">${l.avg_hr ? n0(l.avg_hr) : "–"}</td><td class="num">${l.max_hr ? n0(l.max_hr) : "–"}</td>${a.laps.some((x) => x.avg_power) ? `<td class="num">${l.avg_power ? n0(l.avg_power) + " W" : "–"}</td>` : ""}<td class="num">${l.ascent != null ? n0(l.ascent) + " m" : "–"}</td></tr>`).join("")}</tbody></table></div>`, { span: 12 }) : ""}
    </div>`;


  // synced stream charts
  const xs = s[xKey] || [];
  const synced = [];
  for (const [k, l, , cl, fmt] of streams) {
    let ys = k === "pace" ? s.speed.map((v) => (v && v > 0.5 ? 1000 / v : null)) : k === "speed" ? s.speed.map((v) => (v == null ? null : v * 3.6)) : s[k];
    const data = xs.map((x, i) => ({ x, y: ys[i] }));
    const vals = ys.filter((v) => v != null).sort((p, q) => p - q);
    const lo = vals[Math.floor(vals.length * 0.02)], hi = vals[Math.floor(vals.length * 0.98)];
    const ch = mkChart("#st-" + k, {
      type: "line",
      data: { datasets: [line(l, data, cl, { tension: 0.15, pointHoverRadius: 4, fmt: (r) => fmt(r.y), fill: k === "alt" ? { target: "start", above: "rgba(137,135,129,.12)" } : false })] },
      options: {
        interaction: { mode: "index", intersect: false },
        scales: { ...axes({ xType: "linear", yReverse: k === "pace", yMin: k === "pace" ? lo * 0.97 : k === "alt" ? Math.floor((vals[0] - 30) / 50) * 50 : undefined, yMax: k === "pace" ? hi * 1.05 : undefined, yFmt: k === "pace" ? (v) => pace(v) : undefined, xFmt: xKey === "dist" ? (v) => v + " km" : (v) => dur(v) }), x: { type: "linear", min: xs[0], max: xs[xs.length - 1], grid: { display: false }, border: { color: c.axis }, ticks: { color: c.muted, maxTicksLimit: innerWidth < 600 ? 5 : 9, callback: xKey === "dist" ? (v) => (Math.round(v * 10) / 10) + " km" : (v) => dur(v) } } },
        plugins: { tipTitle: (dp) => (xKey === "dist" ? `${n1(dp.raw.x)} km · ${dur(s.t[dp.dataIndex])}` : dur(dp.raw.x)) },
        onHover: (e, els) => { if (els.length) syncTo(els[0].index, ch); },
      },
    });
    if (ch) synced.push(ch);
  }
  let marker = null;
  function syncTo(i, src) {
    for (const ch of synced) {
      if (ch === src) continue;
      ch.setActiveElements([{ datasetIndex: 0, index: i }]);
      ch.draw();
    }
    if (map && s.lat?.[i] != null) {
      if (!marker) marker = L.circleMarker([s.lat[i], s.lon[i]], { radius: 7, color: c.surface, weight: 2, fillColor: col, fillOpacity: 1 }).addTo(map);
      else marker.setLatLng([s.lat[i], s.lon[i]]);
    }
  }
  $(".stack-charts")?.addEventListener("mouseleave", () => { synced.forEach((ch) => { ch.setActiveElements([]); ch.draw(); }); });

  if (hasGps) {
    const pts = s.lat.map((la, i) => [la, s.lon[i]]).filter((p) => p[0] != null && p[1] != null);
    map = L.map("map", { scrollWheelZoom: false, attributionControl: true });
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 18, attribution: "© OpenStreetMap" }).addTo(map);
    const pl = L.polyline(pts, { color: col, weight: 4, opacity: 0.9 }).addTo(map);
    L.circleMarker(pts[0], { radius: 6, color: c.surface, weight: 2, fillColor: c.good, fillOpacity: 1 }).addTo(map).bindTooltip("Start");
    L.circleMarker(pts[pts.length - 1], { radius: 6, color: c.surface, weight: 2, fillColor: c.critical, fillOpacity: 1 }).addTo(map).bindTooltip("Finish");
    map.fitBounds(pl.getBounds(), { padding: [20, 20] });
  }

  if (a.curve_vs_best) {
    mkChart("#ch-apc", {
      type: "line",
      data: { datasets: [line("This ride", a.curve_vs_best.map((p) => ({ x: p.s, y: p.w })), col, { fmt: (r) => n0(r.y) + " W" }), line("All-time best", a.curve_vs_best.map((p) => ({ x: p.s, y: p.best })), c.muted, { fmt: (r) => n0(r.y) + " W" })] },
      options: { scales: { ...axes({ yBegin: true }), x: { type: "logarithmic", grid: { color: c.grid, drawTicks: false }, border: { color: c.axis }, afterBuildTicks: (ax) => { ax.ticks = [1, 5, 15, 60, 300, 1200, 3600].filter((v) => v <= ax.max).map((v) => ({ value: v })); }, ticks: { color: c.muted, callback: (v) => DUR_LABEL(v) } } }, plugins: { tipTitle: (dp) => DUR_LABEL(dp.raw.x) } },
    });
  }
}

route();
