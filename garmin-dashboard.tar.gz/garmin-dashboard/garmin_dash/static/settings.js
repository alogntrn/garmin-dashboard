/* Settings sheet (spec section 5): opens over the current page at #/settings, sub-pages at #/settings/<name>.
   Everything from the old "Sync & settings" page, plus training targets, gym setup, local AI and the method. */
(function () {
  "use strict";

  const TITLES = { log: "Sync log", data: "Data", heart: "Heart rate and zones", targets: "Training targets", tests: "Tests", rules: "Rules", ai: "Local AI", method: "How suggestions are made" };
  const COVER = { steps: "Steps", resting_hr: "Resting HR", stress_avg: "Stress", bb_high: "Body Battery", sleep_s: "Sleep", sleep_score: "Sleep score", hrv_night: "HRV", weight_kg: "Weight" };
  const S = { panel: null, sub: null, dirty: false, seq: 0 };
  const ic = (n) => (window.UIC && window.UIC[n]) || "";
  const chev = () => ic("chev").replace("u-ic", "u-ic chev");
  const pad2 = (x) => String(x).padStart(2, "0");
  const localIso = (d = new Date()) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;

  const isOpen = () => !!S.panel && !$("#sheet").hidden && $("#sheet").classList.contains("st-open");

  function frame(title, body, sub) {
    return `<div class="st-head">${sub ? `<a class="st-back" href="#/settings">${ic("chevl")}<span>Settings</span></a>` : "<span></span>"}
      <h2>${esc(title)}</h2><button type="button" class="st-done">Done</button></div>
      <div class="st-body">${body}</div>`;
  }
  const row = (href, title, sub = "", right = "", cls = "") => `<a class="u-row ${cls}" href="${href}"><span class="rt"><b>${esc(title)}</b>${sub ? `<span>${sub}</span>` : ""}</span>${right ? `<span class="rr">${right}</span>` : ""}${chev()}</a>`;
  const group = (title, rows, foot = "") => `<h3 class="st-gh">${esc(title)}</h3><div class="u-list st-list">${rows.join("")}</div>${foot ? `<p class="u-foot">${foot}</p>` : ""}`;

  function aiShort(st) {
    if (!st) return "Status unavailable";
    if (!st.enabled) return "Switched off in config.ini";
    if (!st.reachable) return "Not running on the Pi";
    if (!st.model_ready) return "Model not downloaded yet";
    return st.busy ? "Busy with a description" : "Ready";
  }
  function blockText() {
    const G = window.GYM && window.GYM.get();
    if (!G) return "";
    const i = window.GYM.idxOf(localIso());
    return i < 0 ? `Starts ${fdate(window.GYM.start(), { day: "numeric", month: "short" })}` : i > 27 ? "Block finished" : `Day ${i + 1} of 28, week ${Math.floor(i / 7) + 1}`;
  }

  // ------------------------------------------------------------ pages
  async function rootHTML() {
    const [st, co, ai] = await Promise.all([api("/api/status", true), api("/api/coach").catch(() => null), api("/api/gym/ai", true).catch(() => null), window.loadGym ? window.loadGym(true) : null]);
    const at = st.athlete || {}, cx = co?.context || {};
    const syncSub = st.syncing ? "Syncing now…" : syncedLabel(st.last_sync);
    const G = window.GYM && window.GYM.get();
    return `<div class="st-root">
      ${group("Garmin", [
        `<button type="button" class="u-row st-sync"><span class="rt"><b>Sync now</b><span>${esc(syncSub)}</span></span><span class="rr">${ic("sync")}</span></button>`,
        row("#/settings/log", "Sync log", "", (st.log || []).some((l) => l.level === "error") ? `<span class="st-warn">${ic("bang")} errors</span>` : ""),
        row("#/settings/data", "Data", "", `${n0(st.daily_days)} days`),
      ], "Syncs also run on their own every hour. On a phone, pull down on any tab to sync.")}
      ${group("You", [
        row("#/settings/heart", "Heart rate and zones", "", at.max_hr ? `max ${n0(at.max_hr)} bpm` : ""),
        row("#/settings/targets", "Training targets", "", cx.vdot ? `VDOT ${esc(cx.vdot)}` : ""),
      ])}
      ${G ? group("Gym", [
        `<label class="u-row st-block"><span class="rt"><b>Block start</b><span>${esc(blockText())}</span></span><span class="rr"><input type="date" name="start" value="${esc(window.GYM.start())}" aria-label="Day 1 of the 28-day block"></span></label>`,
        row(`#/progress/strength/${localIso()}`, "Workouts and exercises", "Your own sessions and exercises", "", "st-lib"),
        row("#/settings/tests", "Tests", "Day 5 and 25 strength, day 1 and 28 tape"),
        row("#/settings/rules", "Rules", "Knee pain, effort and when to add weight"),
      ]) : ""}
      ${group("Local AI", [row("#/settings/ai", "Describe a session in words", esc(aiShort(ai)))])}
      ${group("About", [row("#/settings/method", "How suggestions are made", "The checks, the limits and the studies behind them")])}
    </div>`;
  }

  async function subHTML(sub) {
    if (sub === "log" || sub === "data") {
      const st = await api("/api/status", true);
      if (sub === "log") {
        return `<div class="u-list st-log">${(st.log || []).map((l) => `<div class="st-li ${l.level === "error" ? "err" : ""}">${l.level === "error" ? `<span class="st-warn">${ic("bang")}</span>` : ""}<span class="u-c2 u-num">${esc(String(l.ts).replace("T", " ").slice(0, 16))}</span><span>${esc(l.message)}</span></div>`).join("") || '<p class="st-p u-c2">No entries yet.</p>'}</div>`;
      }
      const fs = st.file_status || {};
      const total = Object.values(fs).reduce((a, b) => a + b, 0);
      return `<div class="st-data">
        ${group("Activities", [
          `<div class="u-row"><span class="rt"><b>Activities</b></span><span class="rr">${n0(total)}</span></div>`,
          `<div class="u-row"><span class="rt"><b>Analysed from their FIT file</b></span><span class="rr">${n0(fs.ok || 0)}</span></div>`,
          st.files_pending ? `<div class="u-row"><span class="rt"><b>Files still downloading</b></span><span class="rr">${n0(st.files_pending)}</span></div>` : "",
          fs.error ? `<div class="u-row"><span class="rt"><b>Files that failed</b></span><span class="rr">${n0(fs.error)}</span></div>` : "",
          fs.nofit ? `<div class="u-row"><span class="rt"><b>Without a FIT file</b></span><span class="rr">${n0(fs.nofit)}</span></div>` : "",
        ])}
        ${group("Wellness", [
          `<div class="u-row"><span class="rt"><b>Days</b>${st.daily_range?.[0] ? `<span>${fdate(st.daily_range[0])} – ${fdate(st.daily_range[1])}</span>` : ""}</span><span class="rr">${n0(st.daily_days)}</span></div>`,
          ...Object.entries(st.coverage || {}).map(([k, v]) => `<div class="u-row"><span class="rt"><b>${esc(COVER[k] || k)}</b></span><span class="rr">${v ? `${n0(v)} days` : '<span class="u-c2">not in your Garmin data</span>'}</span></div>`),
        ])}</div>`;
    }
    if (sub === "heart") {
      const at = (await api("/api/status", true)).athlete || {};
      const z = (at.zones && at.zones.run) || [];
      const zr = z.map((lo, i) => `<div class="u-row"><span class="rt"><b>Zone ${i + 1}</b></span><span class="rr u-num">${n0(lo)}${i < z.length - 1 ? `–${n0(z[i + 1] - 1)}` : at.max_hr ? `–${n0(at.max_hr)}` : "+"} bpm</span></div>`);
      return `<div class="st-heart">
        ${group("Values used", [
          `<div class="u-row"><span class="rt"><b>Max heart rate</b></span><span class="rr">${at.max_hr ? n0(at.max_hr) + " bpm" : "–"}</span></div>`,
          `<div class="u-row"><span class="rt"><b>Resting heart rate</b></span><span class="rr">${at.rest_hr ? n0(at.rest_hr) + " bpm" : "–"}</span></div>`,
          `<div class="u-row"><span class="rt"><b>Lactate threshold</b></span><span class="rr">${at.lthr ? n0(at.lthr) + " bpm" : "–"}</span></div>`,
          `<div class="u-row"><span class="rt"><b>Weight</b></span><span class="rr">${at.weight ? n1(at.weight) + " kg" : "–"}</span></div>`,
        ])}
        ${z.length ? group(`Heart-rate zones (${at.zones_source || "Garmin"})`, zr) : ""}
        <p class="u-foot">To change any of these, set them in <code>config.ini</code> on the Pi, section <code>[athlete]</code>.</p></div>`;
    }
    if (sub === "targets") {
      const co = await api("/api/coach");
      const rt = co.run?.targets || {}, ct = co.ride?.targets || {}, cx = co.context || {};
      const t = (label, run, ride) => `<div class="st-trow"><b>${label}</b><span><i>Run</i>${esc(run || "–")}</span><span><i>Ride</i>${esc(ride || "–")}</span></div>`;
      const j = (...xs) => xs.filter(Boolean).join(" · ");
      return `<div class="st-targets"><div class="u-list st-tlist">
        ${t("Recovery", rt.recovery_hr, j(ct.recovery_w, ct.recovery_hr))}
        ${t("Easy, endurance", j(rt.easy_pace, rt.easy_hr), j(ct.endurance_w, ct.easy_hr))}
        ${t("Threshold", j(rt.threshold_pace, rt.threshold_hr), j(ct.threshold_w, ct.threshold_hr))}
        ${t("VO₂max", j(rt.vo2_pace, rt.vo2_hr), ct.vo2_w ? "30/15 work " + ct.vo2_w : "very hard, about 9/10")}
      </div><p class="u-foot">${cx.vdot ? `Paces from VDOT ${esc(cx.vdot)}${cx.vdot_src ? ` (${esc(cx.vdot_src)})` : ""}.` : "No recent run of 3 km or more, so running targets use heart rate only."}
        ${cx.ftp ? `Power from FTP ${n0(cx.ftp)} W${cx.ftp_src ? ` (${esc(cx.ftp_src)})` : ""}.` : "No power data, so cycling targets use heart rate."} On hilly routes go by heart rate, not pace.</p></div>`;
    }
    if (sub === "tests") {
      if (window.loadGym) await window.loadGym(true);
      return `<div class="u-card st-card">${window.GYM.testsHTML()}</div><p class="u-foot">Saved on the Pi as you type.</p>`;
    }
    if (sub === "rules") return `<div class="u-card st-card">${window.GYM.rulesHTML()}</div>`;
    if (sub === "ai") {
      const st = await api("/api/gym/ai", true).catch(() => null);
      const short = (m) => String(m || "").replace(/-instruct.*$/i, "").replace(":", " ");
      return `<div class="st-ai">${group("Status", [
        `<div class="u-row"><span class="rt"><b>${esc(aiShort(st))}</b>${st?.error ? `<span>${esc(st.error)}</span>` : ""}</span></div>`,
        st?.model ? `<div class="u-row"><span class="rt"><b>Model</b></span><span class="rr">${esc(short(st.model))}</span></div>` : "",
        st?.queued ? `<div class="u-row"><span class="rt"><b>Waiting</b></span><span class="rr">${n0(st.queued)}</span></div>` : "",
      ])}
      <p class="u-foot">Describe a session in words (in Workout mode, from the session overview) and the AI on the Pi turns it into sets. Nothing leaves the Pi.${st && (!st.reachable || !st.model_ready) ? " To set it up, run <code>./setup-ai.sh</code> on the Pi once." : ""}</p></div>`;
    }
    if (sub === "method") {
      const co = await api("/api/coach").catch(() => null);
      return `<div class="st-method u-card st-card"><ol class="method">
        <li><b>Recovery check.</b> HRV is compared as a 7-day rolling average of ln(HRV) against your own baseline ± 0.5 SD (the smallest worthwhile change), as in HRV-guided training studies. Resting HR 3–5 bpm above baseline, short sleep and very negative form also count. One flag means an easy day; two or more, a recovery day.</li>
        <li><b>Hard day gate.</b> Intervals only if everything is green, at least 48 h have passed since your last hard session, you've had fewer than 2 hard sessions this week (3 if your fitness is high), and less than 20 % of your recent training time was in zones 4–5.</li>
        <li><b>Session type.</b> Hard days alternate between threshold and VO₂max work; after a break you restart with a short threshold session. Otherwise a long session if none in 6 days, else easy aerobic volume.</li>
        <li><b>Dose.</b> A run is never longer than your longest run of the last 30 days (+5 % at most on long-run days). Weekly running stays below 1.3 × your 4-week average. Rides are capped at +10 % on your longest ride.</li>
        <li><b>Targets.</b> Running paces from your VDOT (Daniels), heart rate from your Garmin zones, cycling power from your FTP (Coggan zones).</li>
      </ol>
      ${co?.refs ? `<h3 class="st-gh">References</h3><ul class="refs">${Object.values(co.refs).map((r) => `<li><b>${esc(r.cite)}</b><br>${esc(r.finding)}</li>`).join("")}</ul>` : ""}
      <p class="u-foot">Suggestions from your data, not medical advice. If something hurts or feels wrong, switch to easy: how you feel beats the numbers.</p></div>`;
    }
    return "";
  }

  // ------------------------------------------------------------ open, render, close
  async function open(sub) {
    if (!isOpen()) {
      S.panel = openSheet(frame("Settings", '<div class="loading">Loading…</div>'), onClose);
      $("#sheet").classList.add("st-open");
      S.panel.setAttribute("aria-label", "Settings");
      S.dirty = false;
    }
    S.sub = sub || null;
    const seq = ++S.seq;
    let body;
    try {
      body = sub ? await subHTML(sub) : await rootHTML();
    } catch (e) {
      body = `<p class="st-p">Couldn't load this (${esc(e.message)}).</p>`;
    }
    if (seq !== S.seq || !isOpen()) return;
    S.panel.innerHTML = `<div class="sheet-grab" aria-hidden="true"></div>${frame(sub ? TITLES[sub] : "Settings", body, !!sub)}`;
    S.panel.scrollTop = 0;
    if (!S.panel.contains(document.activeElement)) S.panel.focus({ preventScroll: true });
    wire();
  }

  function wire() {
    const p = S.panel;
    p.querySelector(".st-done")?.addEventListener("click", () => closeSheet());
    p.querySelector(".st-sync")?.addEventListener("click", (e) => { S.dirty = true; e.currentTarget.querySelector(".rt span").textContent = "Syncing now…"; window.syncNow(); });
    p.querySelector("input[name=start]")?.addEventListener("change", async (e) => {
      if (!e.target.value) return;
      await window.GYM.post("/api/gym/settings", { start: e.target.value });
      S.dirty = true;
      if (window.loadGym) await window.loadGym(true);
      const s = p.querySelector(".st-block .rt span");
      if (s) s.textContent = blockText();
    });
    p.querySelectorAll("input[data-t]").forEach((inp) => inp.addEventListener("change", async () => {
      const G = window.GYM.get();
      const tests = { ...(G.tests || {}), [inp.dataset.t]: inp.value };
      G.tests = (await window.GYM.post("/api/gym/settings", { tests })).tests;
      S.dirty = true;
    }));
    p.querySelector("a.st-lib")?.addEventListener("click", () => { shell.scrollTo = "g-mgmtcard"; });
  }

  // Closing goes back to the page underneath; it is only reloaded when something here changed it.
  function onClose() {
    $("#sheet").classList.remove("st-open");
    S.panel = null; S.seq++;
    if (!location.hash.startsWith("#/settings")) return;   // a link inside the sheet already navigated
    if (!S.dirty && app.dataset.page && app.dataset.page !== "settings") shell.keep = shell.last;
    location.hash = shell.last || "#/today";
  }

  window.Settings = { open, isOpen, refresh: () => { S.dirty = true; return open(S.sub); } };
})();
