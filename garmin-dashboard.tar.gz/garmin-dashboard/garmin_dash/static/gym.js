/* Gym tab: 4-week knee-smart block, your own workouts and exercises, a set-by-set logger and stats.
   Loaded after gym-lib.js and before app.js; uses app.js helpers ($, card, tile, mkChart, css …) only inside functions. */
(function () {
  "use strict";
  const { MUSCLES, LEGS, CATS, KINDS, MIN_PER_SET, LIB, RIRT, WARM, REST, PH, PHN, PLAN, PALETTE } = window.GYMDATA;
  const DEFAULT_START = "2026-11-19";
  const LEGSET = new Set(LEGS);
  const LIBBY = Object.fromEntries(LIB.map((e) => [e.id, e]));
  const KNAME = Object.fromEntries(KINDS);
  const COLV = { A: "var(--gA)", B: "var(--gB)", C: "var(--gC)", R: "var(--gR)", F: "var(--series-7)" };
  const SNAME = { A: PLAN.A.name, B: PLAN.B.name, C: PLAN.C.name, R: "Rest day", F: "Free workout" };

  // ------------------------------------------------------------ small helpers
  const at = (v, i) => (Array.isArray(v) ? v[i] : v);
  const pad = (x) => String(x).padStart(2, "0");
  const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const pd = (s) => { const [y, m, d] = s.split("-").map(Number); return new Date(y, m - 1, d); };
  const addD = (s, n) => { const d = pd(s); d.setDate(d.getDate() + n); return iso(d); };
  const diffD = (a, b) => Math.round((pd(b) - pd(a)) / 864e5);
  const todayIso = () => iso(new Date());
  const fd = (s, o = { weekday: "short", day: "numeric", month: "short" }) => pd(s).toLocaleDateString("en-GB", o);
  const parseSets = (s) => { const t = String(s ?? "").match(/[RL]\s*\d+/g); if (t) { const r = {}; t.forEach((x) => { r[x[0]] = +x.match(/\d+/)[0]; }); return r; } const n = parseInt(s, 10); return Number.isFinite(n) && n > 0 ? { all: n } : null; };
  const e1rm = (s) => (s.kg > 0 && s.reps >= 1 && s.reps <= 30 ? s.kg * (1 + s.reps / 30) : null);
  const g1 = (v) => (Math.round(v * 10) / 10).toLocaleString("de-CH");
  const plural = (n, w) => `${n} ${w}${n === 1 ? "" : "s"}`;
  const colorOf = (c) => { let v = c; for (let i = 0; i < 4 && v && v.startsWith("var("); i++) v = css(v.slice(4, -1).trim()); return v || "#8a8f98"; };
  const sum = (a) => a.reduce((x, y) => x + y, 0);

  let G = null;      // server state
  let CUS = {};      // your exercises by id
  const UI = { swap: null, editSet: null, ed: null, tool: null, msg: null, map: null, sel: null, ai: null, aiDraft: "", refresh: null };

  // ------------------------------------------------------------ exercises
  function def(id, fallbackName) {
    if (LIBBY[id]) return LIBBY[id];
    const c = CUS[id];
    if (c) return { id, n: c.name, cat: c.cat || "Other", kind: c.kind, uni: !!c.uni, pair: !!c.pair, mus: c.mus || {}, note: c.note || "", custom: true, archived: c.archived };
    // logged before it had a definition: infer what we can from its sets
    const ss = G.sets.filter((s) => s.ex === id);
    const kind = ss.some((s) => s.mins != null) ? "min" : ss.some((s) => s.secs != null && s.reps == null) ? (ss.some((s) => s.kg > 0) ? "hold" : "secs") : ss.length && ss.every((s) => !s.kg) ? "reps" : "kg";
    return { id, n: fallbackName || ss[0]?.name || id.replace(/^x-/, "").replace(/-/g, " "), cat: "Other", kind, uni: ss.some((s) => s.side), mus: {}, custom: true, unknown: true };
  }
  const allDefs = () => [...LIB.filter((e) => e.kind !== "info"), ...Object.values(CUS).filter((c) => !c.archived).map((c) => def(c.id))];
  function exOptions(selected, alts = [], withNew = true) {
    const defs = allDefs();
    const opt = (e) => `<option value="${e.id}" ${e.id === selected ? "selected" : ""}>${esc(e.n)}</option>`;
    let h = alts.length ? `<optgroup label="Suggested swaps">${alts.map((a) => def(a)).map(opt).join("")}</optgroup>` : "";
    const mine = defs.filter((e) => e.custom);
    if (mine.length) h += `<optgroup label="Your exercises">${mine.map(opt).join("")}</optgroup>`;
    for (const c of CATS) { const l = defs.filter((e) => !e.custom && e.cat === c); if (l.length) h += `<optgroup label="${c}">${l.map(opt).join("")}</optgroup>`; }
    return h + (withNew ? '<option value="__new">+ New exercise…</option>' : "");
  }
  function metric(dfn) {
    if (dfn.kind === "kg") return { v: (s) => e1rm(s), label: "est. 1RM", unit: "kg", agg: "max" };
    if (dfn.kind === "reps") return { v: (s) => s.reps ?? null, label: "reps", unit: "reps", agg: "max" };
    if (dfn.kind === "hold") return { v: (s) => (s.kg > 0 ? s.kg : null), label: "load", unit: "kg", agg: "max" };
    if (dfn.kind === "secs") return { v: (s) => s.secs ?? null, label: "longest hold", unit: "s", agg: "max" };
    if (dfn.kind === "min") return { v: (s) => s.mins ?? null, label: "minutes", unit: "min", agg: "sum" };
    return { v: () => null, label: "", unit: "", agg: "max" };
  }

  // ------------------------------------------------------------ plan & sessions
  const start = () => G.start || DEFAULT_START;
  const idxOf = (d) => diffD(start(), d);
  const weekOf = (d) => Math.min(4, Math.max(1, Math.floor(idxOf(d) / 7) + 1));
  const isW = (s) => /^W\d+$/.test(s || "");
  const wById = (id) => (G.workouts || []).find((w) => w.id === +id);
  // A day's workout is the one you chose; nothing is planned by date. Older days without a day record keep the
  // session their sets were logged under. Days without a choice log as a free session.
  const chosen = (d) => G.days[d]?.session || G.sets.find((s) => s.date === d && s.session)?.session || null;
  const sessOf = (d) => chosen(d) || "F";
  const sessName = (s) => (isW(s) ? wById(s.slice(1))?.name || "Deleted workout" : SNAME[s] || s);
  const sessColor = (s) => (isW(s) ? wById(s.slice(1))?.color || PALETTE[0] : COLV[s] || COLV.F);
  const sessLetter = (s) => (isW(s) ? (wById(s.slice(1))?.name || "W").trim().charAt(0).toUpperCase() : s === "R" ? "rest" : s);
  const darkText = (s) => s === "C";
  const setsOn = (d) => G.sets.filter((s) => s.date === d);
  const slotOf = (s) => s.slot || s.ex;

  function slotsFor(d) {
    const s = sessOf(d), w = weekOf(d);
    if (PLAN[s]) return PLAN[s].ex.map((x) => ({
      slot: x.id, base: x.id, plan: true, n: x.n, tag: x.tag, alts: x.alts || [],
      sets: at(x.sets, w - 1), reps: at(x.reps, w - 1),
      rir: x.rir === "eff" ? ["effort", RIRT.eff[w - 1]] : RIRT[x.rir] ? ["RIR", RIRT[x.rir][w - 1]] : null,
      rest: x.rest, tempo: at(x.tempo, w - 1), note: x.note ? at(x.note, w - 1) : "", cue: x.cue, why: x.why,
    }));
    if (isW(s)) {
      const wo = wById(s.slice(1));
      return (wo?.items || []).map((it) => ({ slot: "t-" + it.k, base: it.ex, plan: false, alts: LIBBY[it.ex] ? altsFor(it.ex) : [], sets: it.sets ? String(it.sets) : "", reps: it.reps, rir: null, rest: it.rest, tempo: "", note: it.note, cue: "", why: "" }));
    }
    return [];
  }
  function altsFor(exId) {
    for (const p of Object.values(PLAN)) for (const x of p.ex) if (x.id === exId) return x.alts || [];
    return [];
  }
  const effEx = (d, sl) => G.days[d]?.swaps?.[sl.slot] || (sl.plan ? G.swaps?.[sl.slot] : null) || sl.base;
  function extraIds(d, slots) {
    const known = new Set(slots.map((x) => x.slot)), ids = [];
    for (const s of setsOn(d)) { const k = slotOf(s); if (!known.has(k) && !ids.includes(k)) ids.push(k); }
    for (const k of G.days[d]?.extras || []) if (!known.has(k) && !ids.includes(k)) ids.push(k);
    return ids;
  }
  function blocksFor(d) {
    const slots = slotsFor(d);
    return [...slots, ...extraIds(d, slots).map((k) => ({ slot: k, base: k, extra: true, alts: [], sets: "", reps: "", rir: null, rest: "", tempo: "", note: "", cue: "", why: "" }))];
  }
  function prevSets(exId, d) {
    let best = null;
    for (const s of G.sets) if (s.ex === exId && s.date < d && (!best || s.date > best)) best = s.date;
    return best ? { date: best, sets: G.sets.filter((s) => s.ex === exId && s.date === best) } : null;
  }

  // ------------------------------------------------------------ counting
  const countable = (dfn) => dfn.count !== false && dfn.kind !== "info";
  const setWeight = (s, dfn) => (!countable(dfn) ? 0 : dfn.kind === "min" ? (s.mins || 0) / MIN_PER_SET : 1);
  function addMus(acc, dfn, side, w) {
    if (!w) return;
    for (const [m, mw] of Object.entries(dfn.mus || {})) {
      if (LEGSET.has(m)) {
        if (side !== "L") acc[m + "R"] = (acc[m + "R"] || 0) + w * mw;
        if (side !== "R") acc[m + "L"] = (acc[m + "L"] || 0) + w * mw;
      } else acc[m] = (acc[m] || 0) + (side ? 0.5 : 1) * w * mw;
    }
  }
  function loggedMuscles(sets) {
    const acc = {};
    for (const s of sets) { const dfn = def(s.ex, s.name); addMus(acc, dfn, s.side || "", setWeight(s, dfn)); }
    return acc;
  }
  function plannedMuscles(d) {
    const acc = {};
    for (const sl of slotsFor(d)) {
      const dfn = def(effEx(d, sl)), p = parseSets(sl.sets);
      if (!p || !countable(dfn)) continue;
      if (p.all != null) { if (dfn.uni) { addMus(acc, dfn, "R", p.all); addMus(acc, dfn, "L", p.all); } else addMus(acc, dfn, "", p.all); }
      else { addMus(acc, dfn, "R", p.R || 0); addMus(acc, dfn, "L", p.L || 0); }
    }
    return acc;
  }
  function plannedEntries(d) {
    let n = 0;
    for (const sl of slotsFor(d)) {
      const dfn = def(effEx(d, sl)), p = parseSets(sl.sets);
      if (!p || !countable(dfn)) continue;
      n += p.all != null ? p.all * (dfn.uni ? 2 : 1) : (p.R || 0) + (p.L || 0);
    }
    return n;
  }
  function slotProgress(sl, dfn, logged) {
    const p = parseSets(sl.sets);
    const c = (sd) => logged.filter((s) => (s.side || "") === sd).length;
    const both = c(""), cR = c("R") + both, cL = c("L") + both;
    if (!p || dfn.kind === "info") return { text: logged.length ? plural(logged.length, "set") : "", done: false, next: dfn.uni ? (cR <= cL ? "R" : "L") : "" };
    if (p.all != null) {
      const n = dfn.uni ? Math.min(cR, cL) : logged.length;
      return { text: dfn.uni ? `R ${cR}/${p.all} · L ${cL}/${p.all}` : `${n}/${p.all}`, done: n >= p.all, next: dfn.uni ? (cR <= cL ? "R" : "L") : "" };
    }
    const done = ["R", "L"].every((sd) => p[sd] == null || (sd === "R" ? cR : cL) >= p[sd]);
    let next = "R";
    if (dfn.uni) next = cR <= cL && cR < (p.R || 0) ? "R" : cL < (p.L || 0) ? "L" : cR < (p.R || 0) ? "R" : "R";
    return { text: ["R", "L"].filter((sd) => p[sd] != null).map((sd) => `${sd} ${sd === "R" ? cR : cL}/${p[sd]}`).join(" · "), done, next: dfn.uni ? next : "" };
  }

  // ------------------------------------------------------------ stats for one session
  function sessionStats(d) {
    const ss = setsOn(d);
    let vol = 0, reps = 0, timed = 0, hard = 0;
    for (const s of ss) {
      const dfn = def(s.ex, s.name);
      if (s.kg > 0 && s.reps) vol += s.kg * s.reps * (dfn.pair ? 2 : 1); // per-arm weights: both arms lifted it
      if (s.reps) reps += s.reps;
      if (s.secs) timed += s.secs / 60;
      if (s.mins) timed += s.mins;
      if (countable(dfn)) hard += 1;
    }
    const gm = G.garmin[d] || [];
    let mins = sum(gm.map((x) => x.min || 0)) || null, minsSrc = mins ? "watch" : "";
    if (!mins && ss.length >= 2) {
      const t = ss.map((s) => Date.parse(s.created_at)).filter(Number.isFinite).sort((a, b) => a - b);
      const span = t.length > 1 ? (t[t.length - 1] - t[0]) / 6e4 : 0;
      if (span >= 10 && span <= 240) { mins = Math.round(span + 3); minsSrc = "from your log"; }
    }
    const prs = [];
    const groups = {};
    for (const s of ss) (groups[s.ex + "|" + (s.side || "")] = groups[s.ex + "|" + (s.side || "")] || []).push(s);
    for (const [k, list] of Object.entries(groups)) {
      const [ex, side] = k.split("|"), dfn = def(ex, list[0].name), M = metric(dfn);
      const best = (arr) => { const v = arr.map(M.v).filter((x) => x != null); return v.length ? Math.max(...v) : null; };
      const today = best(list), prev = best(G.sets.filter((s) => s.ex === ex && (s.side || "") === side && s.date < d));
      if (today != null && prev != null && today > prev + 1e-9 && M.agg === "max") prs.push({ n: dfn.n, side, label: M.label, unit: M.unit, today, prev });
    }
    const code = sessOf(d);
    const prevDates = [...new Set(G.sets.filter((x) => x.date < d).map((x) => x.date))].filter((x) => sessOf(x) === code).sort();
    const pDate = prevDates[prevDates.length - 1] || null;
    const pVol = pDate ? sum(setsOn(pDate).map((s) => (s.kg > 0 && s.reps ? s.kg * s.reps : 0))) : null;
    return { n: ss.length, hard, vol, reps, timed, mins, minsSrc, prs, pDate, pVol, mus: loggedMuscles(ss), garmin: gm };
  }

  function statsHTML(d) {
    const st = sessionStats(d);
    if (!st.n) return "";
    const box = (v, l) => `<div><b>${v}</b><span>${l}</span></div>`;
    const top = Object.entries(st.mus).filter(([, v]) => v >= 0.5).sort((a, b) => b[1] - a[1]).slice(0, 8);
    const hr = st.garmin.find((g) => g.hr);
    const vs = st.pVol != null && st.pVol > 0 && st.vol > 0 ? Math.round((st.vol / st.pVol - 1) * 100) : null;
    return `<div class="g-statbox">
      <div class="g-stats">${box(st.vol ? Math.round(st.vol).toLocaleString("de-CH") : "–", "kg lifted")}${box(st.hard, plural(st.hard, "hard set").replace(/^\d+ /, ""))}${box(st.reps || "–", "reps")}${st.timed ? box(g1(st.timed), "min timed work") : ""}${st.mins ? box(st.mins, `min (${st.minsSrc})`) : ""}${hr ? box(hr.hr, "bpm avg (watch)") : ""}</div>
      ${vs != null ? `<p class="g-vs">${vs >= 0 ? "▲" : "▼"} ${Math.abs(vs)}% ${vs >= 0 ? "more" : "less"} volume than your last ${esc(sessName(sessOf(d)))} (${fd(st.pDate)})</p>` : ""}
      ${st.prs.length ? `<ul class="g-prs">${st.prs.slice(0, 5).map((p) => `<li><span class="g-pr">PR</span> ${esc(p.n)}${p.side ? ` (${p.side})` : ""}: ${p.label} <b>${g1(p.today)} ${p.unit}</b> <span class="muted">was ${g1(p.prev)}</span></li>`).join("")}</ul>` : ""}
      ${top.length ? `<div class="g-mus"><span class="muted">Muscles worked (hard sets):</span>${top.map(([m, v]) => `<span class="g-mchip g-c${binOf(v)}">${musLabel(m)} <b>${halves(v)}</b></span>`).join("")}</div>` : ""}
    </div>`;
  }
  const musRaw = (k) => { const leg = /[RL]$/.test(k) && LEGSET.has(k.slice(0, -1)); const base = leg ? k.slice(0, -1) : k; return (MUSCLES.find((m) => m[0] === base) || [0, base])[1] + (leg ? ` ${k.slice(-1)}` : ""); };
  const musLabel = (k) => esc(musRaw(k));

  // ------------------------------------------------------------ rack
  function rackHTML(sel) {
    const t = todayIso();
    let h = "";
    for (let w = 0; w < 4; w++) {
      h += `<div class="g-wk"><b>W${w + 1}</b><span>${PH[w]}</span></div>`;
      for (let k = 0; k < 7; k++) {
        const i = w * 7 + k, d = addD(start(), i), c = chosen(d), s = c || "F", done = G.days[d]?.done || setsOn(d).length;
        const shown = !!c && (c !== "F" || done);                 // nothing is planned: only workouts you chose or did
        h += `<a class="g-day${d === sel ? " sel" : ""}${d === t ? " today" : ""}" href="#/progress/strength/${d}" aria-label="Day ${i + 1}, ${fd(d, { weekday: "long", day: "numeric", month: "long" })}, ${shown ? esc(sessName(s)) : "no workout"}">
          <span class="g-disc${s === "R" ? " rest" : ""}${shown ? "" : " g-none"}" style="${shown ? `background:${sessColor(s)}${darkText(s) ? ";color:#141414" : ""}` : ""}">${shown ? esc(sessLetter(s)) : ""}${done ? '<i class="g-tick">✓</i>' : ""}${isTestDay(d) ? '<i class="g-test">test</i>' : ""}</span>
          <span class="g-dt">${d === t ? "Today" : `<span class="g-wd">${fd(d, { weekday: "short" })} </span>${pd(d).getDate()}`}</span></a>`;
      }
    }
    return `<div class="g-rack">${h}</div>`;
  }

  // ------------------------------------------------------------ one exercise block
  function fieldsHTML(dfn, ref, prefix = "") {
    const v = (k) => (ref && ref[k] != null ? ref[k] : "");
    const inp = (name, label, mode) => `<label>${label}<input name="${prefix}${name}" inputmode="${mode}" autocomplete="off" value="${v(name)}"></label>`;
    const rir = `<label>RIR<select name="${prefix}rir"><option value=""></option>${[0, 1, 2, 3, 4, 5].map((x) => `<option ${String(v("rir")) === String(x) ? "selected" : ""}>${x}</option>`).join("")}</select></label>`;
    switch (dfn.kind) {
      case "reps": return inp("reps", "reps", "numeric") + inp("kg", "+kg", "decimal") + rir;
      case "secs": return inp("secs", "sec", "numeric");
      case "hold": return inp("kg", "kg", "decimal") + inp("secs", "sec", "numeric");
      case "min": return inp("mins", "min", "decimal");
      default: return inp("kg", dfn.pair ? "kg each" : "kg", "decimal") + inp("reps", "reps", "numeric") + rir;
    }
  }
  const sideSeg = (dfn, cur) => (dfn.uni ? `<div class="seg g-side">${[["R", "R"], ["L", "L"], ["", "Both"]].map(([v, l]) => `<button type="button" data-act="side" data-side="${v}" class="${v === cur ? "on" : ""}">${l}</button>`).join("")}</div>` : "");

  function setTxt(s) {
    const p = [];
    if (s.kg > 0) p.push(`${g1(s.kg)} kg${s.ex && def(s.ex, s.name).pair ? " each" : ""}`);
    if (s.reps != null) p.push(s.kg > 0 ? `× ${s.reps}` : `${s.reps} reps`);
    if (s.secs != null) p.push(`${s.kg > 0 ? "· " : ""}${s.secs} s`);
    if (s.mins != null) p.push(`${g1(s.mins)} min`);
    return p.join(" ");
  }

  function blockHTML(d, sl, num) {
    const exId = sl.extra ? (G.days[d]?.swaps?.[sl.slot] || setsOn(d).find((s) => slotOf(s) === sl.slot)?.ex || sl.slot) : effEx(d, sl);
    const logged = setsOn(d).filter((s) => slotOf(s) === sl.slot);
    const dfn = def(exId, logged[0]?.name);
    const swapped = !sl.extra && exId !== sl.base;
    const name = !swapped && sl.n ? sl.n : dfn.n;
    const prog = slotProgress(sl, dfn, logged);
    const prev = prevSets(exId, d);
    const ref = [...logged].reverse().find((s) => (s.side || "") === prog.next) || prev?.sets.find((s) => (s.side || "") === prog.next) || logged[logged.length - 1] || prev?.sets[0];
    const col = sl.extra ? "var(--text-muted)" : sessColor(sessOf(d));
    const p = parseSets(sl.sets);
    const presc = sl.extra ? `<span class="muted">Extra · ${esc(KNAME[dfn.kind] || "")}</span>`
      : [p ? `<b>${esc(sl.sets)}</b> ${p.all === 1 ? "set" : "sets"}${sl.reps ? ` × <b>${esc(sl.reps)}</b>` : ""}` : sl.reps ? `<b>${esc(sl.reps)}</b>` : "",
        sl.rir ? `${sl.rir[0]} <b>${esc(sl.rir[1])}</b>` : "", sl.rest ? `rest ${esc(sl.rest)}` : "", sl.tempo ? esc(sl.tempo) : ""].filter(Boolean).join(" · ");
    const prevTxt = prev ? `Last time (${fd(prev.date)}): ${["R", "L", ""].map((sd) => { const l = prev.sets.filter((s) => (s.side || "") === sd); return l.length ? `${sd ? sd + " " : l.length && prev.sets.some((s) => s.side) ? "Both " : ""}${l.map(setTxt).join(", ")}` : ""; }).filter(Boolean).join(" · ")}` : dfn.kind === "info" ? "" : dfn.kind === "kg" || dfn.kind === "hold" ? "First time – start light and find the weight that matches the target." : "First time – nothing earlier to compare with yet.";
    const chips = logged.map((s, k) => UI.editSet === s.id ? setEditHTML(s, dfn) :
      `<span class="g-set"><button type="button" class="g-setbtn" data-act="eset" data-id="${s.id}" title="Edit"><b>${k + 1}</b>${s.src && s.src.startsWith("ai:") ? '<i class="g-aib" title="Logged by the local AI from your description">AI</i>' : ""}${s.side ? `<i class="g-sd ${s.side}">${s.side}</i>` : dfn.uni ? '<i class="g-sd">Both</i>' : ""}${setTxt(s)}${s.rir != null ? ` <span class="muted">RIR ${g1(s.rir)}</span>` : ""}</button><button type="button" data-act="del" data-id="${s.id}" aria-label="Delete set">×</button></span>`).join("");
    const form = dfn.kind === "info" ? "" : `<form class="g-add" data-form="add" data-slot="${esc(sl.slot)}" data-ex="${esc(exId)}" data-name="${esc(dfn.n)}">${sideSeg(dfn, prog.next)}${fieldsHTML(dfn, ref)}<button class="btn primary" type="submit">Add set</button></form>`;
    const tools = `<div class="g-btools">${dfn.kind === "info" ? "" : `<button type="button" class="g-link" data-act="swap-open" data-slot="${esc(sl.slot)}">${swapped ? "Change" : "Swap"}</button>`}${dfn.custom && !dfn.unknown ? `<button type="button" class="g-link" data-act="ed-ex-edit" data-id="${esc(dfn.id)}" data-ctx="sess">Edit exercise</button>` : dfn.unknown ? `<button type="button" class="g-link" data-act="ed-ex-define" data-id="${esc(dfn.id)}" data-name="${esc(dfn.n)}">Set type &amp; muscles</button>` : ""}${sl.extra && !logged.length ? `<button type="button" class="g-link" data-act="rm-extra" data-slot="${esc(sl.slot)}">Remove</button>` : ""}</div>`;
    return `<div class="g-ex${prog.done ? " complete" : ""}" data-slot="${esc(sl.slot)}">
      <div class="g-ex-head"><span class="g-num" style="background:${col}${col === COLV.C ? ";color:#141414" : ""}">${num}</span>
        <div class="g-ex-main"><div class="g-ex-name">${esc(name)} ${sl.tag === "knee" && !swapped ? '<span class="g-tag knee">knee</span>' : `<span class="g-tag">${esc(dfn.cat || "")}</span>`}</div>
        ${swapped ? `<div class="g-swapnote">Swapped from ${esc(sl.n || def(sl.base).n)}</div>` : ""}
        ${presc ? `<div class="g-presc">${presc}</div>` : ""}${sl.note ? `<div class="g-note">${esc(sl.note)}</div>` : ""}</div>
        ${prog.text ? `<span class="g-count">${prog.done ? "✓ " : ""}${prog.text}</span>` : ""}</div>
      ${tools}
      ${UI.swap === sl.slot ? swapPanelHTML(d, sl, exId) : ""}
      ${prevTxt ? `<div class="g-last">${esc(prevTxt)}</div>` : ""}
      ${chips ? `<div class="g-sets">${chips}</div>` : ""}
      ${form}
      ${sl.cue ? `<details><summary>How &amp; why</summary><p>${esc(sl.cue)}</p><p class="muted">${esc(sl.why)}</p></details>` : dfn.note ? `<p class="g-last">${esc(dfn.note)}</p>` : ""}
    </div>`;
  }

  function setEditHTML(s, dfn) {
    return `<form class="g-add g-seted" data-form="eset" data-id="${s.id}">${dfn.uni ? `<div class="seg g-side">${[["R", "R"], ["L", "L"], ["", "Both"]].map(([v, l]) => `<button type="button" data-act="side" data-side="${v}" class="${(s.side || "") === v ? "on" : ""}">${l}</button>`).join("")}</div>` : ""}${fieldsHTML(dfn, s)}
      <button class="btn primary" type="submit">Save</button><button class="btn" type="button" data-act="eset-cancel">Cancel</button></form>`;
  }

  function swapPanelHTML(d, sl, cur) {
    const canBack = !sl.extra && cur !== sl.base;
    return `<form class="g-panel" data-form="swap" data-slot="${esc(sl.slot)}">
      <label class="g-wide">Do this instead<select name="ex">${exOptions(cur, sl.alts)}</select></label>
      ${sl.plan ? `<label class="g-chk"><input type="checkbox" name="persist" ${G.swaps?.[sl.slot] ? "checked" : ""}> Every time this exercise comes up</label>` : ""}
      <p class="small muted">Sets you already logged here move to the new exercise.</p>
      <div class="g-edbtns"><button class="btn primary" type="submit">Swap</button>${canBack ? `<button class="btn" type="button" data-act="swap-back" data-slot="${esc(sl.slot)}">Back to ${esc(sl.n || def(sl.base).n)}</button>` : ""}<button class="btn" type="button" data-act="swap-cancel">Cancel</button></div></form>`;
  }

  // ------------------------------------------------------------ session card
  // Knee test: on the first A session from day 5 to day 14, and on the first one from day 25 to day 28.
  function isTestDay(d) {
    const i = idxOf(d), win = i >= 4 && i <= 13 ? [4, 13] : i >= 24 && i <= 27 ? [24, 27] : null;
    if (!win || sessOf(d) !== "A") return false;
    for (let k = win[0]; k < i; k++) {
      const e = addD(start(), k);
      if (sessOf(e) === "A" && (setsOn(e).length || G.days[e]?.done)) return false;
    }
    return true;
  }

  function notesFor(d) {
    const s = sessOf(d), w = weekOf(d), i = idxOf(d), inPlan = i >= 0 && i < 28;
    const notes = [];
    if (isTestDay(d)) notes.push("<b>Test day.</b> After the warm-up and the isometric primer, test the single-leg extension (10-rep max each leg, 90° → 45°) and enter it under Tests below.");
    if (inPlan && i >= 24 && PLAN[s]) notes.push("<b>Taper:</b> drop one set from every exercise and keep legs at RIR 3.");
    if (inPlan && w === 2 && (s === "A" || s === "C")) notes.push("New this week: 2-up/1-down eccentrics. Lift with both legs, lower with one, slowly. Start lighter than you think.");
    return notes;
  }

  function sessHTML(d) {
    const s = sessOf(d), w = weekOf(d), i = idxOf(d), day = G.days[d] || {};
    const inPlan = i >= 0 && i < 28;
    const blocks = blocksFor(d);
    const notes = notesFor(d);
    const ws = G.workouts || [];
    const head = `<div class="card-head"><div><h2>${inPlan ? `Day ${i + 1} · ` : ""}${fd(d, { weekday: "long", day: "numeric", month: "long" })}</h2>
        <p class="sub">${inPlan ? `Week ${w}, ${PH[w - 1]}: ${PHN[w - 1]}` : "Outside the 4-week block – log anything you like."}</p></div>
        <div class="g-pick">${seg("g-stype", [["A", "A"], ["B", "B"], ["C", "C"], ["F", "Free"]], s)}
        ${ws.length ? `<select id="g-wsel" aria-label="Use one of your workouts"><option value="">My workouts…</option>${ws.map((x) => `<option value="W${x.id}" ${s === "W" + x.id ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select>` : ""}</div></div>`;
    const tools = `<div class="g-tools">${G.ai?.enabled && UI.ai !== d ? `<button type="button" class="g-link" data-act="ai-open">Describe it in words (AI)</button>` : ""}<button type="button" class="g-link" data-act="tool" data-tool="move">Move to another day</button>${setsOn(d).length ? `<button type="button" class="g-link" data-act="tool" data-tool="savewo">Save as one of my workouts</button>` : ""}<button type="button" class="g-link" data-act="ed-wo-new" data-ctx="sess">New workout</button></div>
      ${UI.tool === "move" ? `<form class="g-panel" data-form="move"><label>Move everything logged on this day to <input type="date" name="to" value="${d}"></label><div class="g-edbtns"><button class="btn primary" type="submit">Move</button><button class="btn" type="button" data-act="tool-cancel">Cancel</button></div></form>` : ""}
      ${UI.tool === "savewo" ? `<form class="g-panel" data-form="savewo"><label class="g-wide">Name<input name="name" maxlength="60" placeholder="e.g. Upper body, my way" required></label><p class="small muted">Saves the exercises you logged today, with today's set counts and rep ranges as targets. You can edit it afterwards.</p><div class="g-edbtns"><button class="btn primary" type="submit">Save workout</button><button class="btn" type="button" data-act="tool-cancel">Cancel</button></div></form>` : ""}
      ${UI.ed && UI.ed.ctx === "sess" ? editorHTML() : ""}`;
    const meta = `<div class="g-meta">
        <label class="g-chk"><input type="checkbox" id="g-done" ${day.done ? "checked" : ""}> Session done</label>
        <label>Knee pain <select id="g-pain"><option value=""></option>${[...Array(11).keys()].map((v) => `<option ${day.pain === v ? "selected" : ""}>${v}</option>`).join("")}</select></label>
        <label title="How hard the whole session felt, 0–10 – best rated about 30 minutes after">Session effort <select id="g-rpe"><option value=""></option>${[...Array(11).keys()].map((v) => `<option value="${v}" ${day.rpe === v ? "selected" : ""}>${v} · ${CR10[v]}</option>`).join("")}</select></label>
        <input id="g-note" placeholder="Note (how it felt, machine settings…)" value="${esc(day.note || "")}" maxlength="1000">
      </div>
      ${(G.garmin[d] || []).length ? `<p class="small muted" style="margin:6px 0 0">On your watch: ${G.garmin[d].map((a) => `<a href="#/activity/${a.id}">${esc(a.name)}</a> · ${a.min} min${a.hr ? ` · ${a.hr} bpm` : ""}${a.kcal ? ` · ${a.kcal} kcal` : ""}`).join(" · ")}</p>` : ""}`;
    let body;
    if (s === "R" && !blocks.length) {
      body = `<h3 class="g-h3">${SNAME.R}</h3><ul class="why">${REST.map((x) => `<li>${esc(x)}</li>`).join("")}</ul><p class="small muted">Trained anyway? Add an exercise below or switch to <b>Free</b>.</p>`;
    } else {
      const intro = PLAN[s] ? `<p class="g-focus"><i class="key" style="background:${sessColor(s)}"></i><b>${s} · ${esc(SNAME[s])}</b> – ${esc(PLAN[s].f)}</p><details class="g-warm"><summary>Warm-up</summary><ul class="why">${WARM[PLAN[s].warm].map((x) => `<li>${esc(x)}</li>`).join("")}</ul></details>`
        : isW(s) ? `<p class="g-focus"><i class="key" style="background:${sessColor(s)}"></i><b>${esc(sessName(s))}</b>${wById(s.slice(1))?.note ? ` – ${esc(wById(s.slice(1)).note)}` : ""} <button type="button" class="g-link" data-act="ed-wo-edit" data-id="${s.slice(1)}" data-ctx="sess">Edit workout</button></p>`
        : s === "F" ? `<p class="g-focus"><b>Free workout</b> – log any exercise from the library or your own.</p>` : "";
      body = `${intro}${notes.map((n) => `<div class="g-banner">${n}</div>`).join("")}<div class="g-exs">${blocks.map((b, k) => blockHTML(d, b, k + 1)).join("")}</div>`;
    }
    const addBar = `<form class="g-addex" data-form="addex"><select name="ex" aria-label="Add an exercise"><option value="">Add an exercise…</option>${exOptions("", [], true)}</select><button class="btn" type="submit">Add</button></form>
      <p class="small muted" style="margin:10px 0 0">R = right, L = left, Both = both legs together. Tap a logged set to edit it. Weights pre-fill from your last set.</p>`;
    return head + tools + meta + `<div id="g-jobs">${aiHTML(d)}</div>` + statsHTML(d) + body + addBar;
  }

  // ------------------------------------------------------------ editors (exercise / workout)
  function editorHTML() {
    const e = UI.ed;
    if (!e) return "";
    if (e.type === "ex") {
      const x = e.draft;
      return `<form class="g-editor" data-form="exed"><h3>${x.id && CUS[x.id] ? "Edit exercise" : "New exercise"}</h3>
        <div class="g-edgrid">
          <label class="g-wide">Name<input name="name" maxlength="60" value="${esc(x.name || "")}" required placeholder="e.g. Cable crunch"></label>
          <label>How you log it<select name="kind">${KINDS.map(([k, l]) => `<option value="${k}" ${x.kind === k ? "selected" : ""}>${l}</option>`).join("")}</select></label>
          <label>Category<select name="cat">${CATS.map((c) => `<option ${x.cat === c ? "selected" : ""}>${c}</option>`).join("")}</select></label>
          <label class="g-chk g-wide"><input type="checkbox" name="uni" ${x.uni ? "checked" : ""}> One side at a time (log left and right separately)</label>
          <label class="g-chk g-wide"><input type="checkbox" name="pair" ${x.pair ? "checked" : ""}> Weight per arm: two dumbbells, or one arm after the other. You enter one dumbbell; kg lifted counts both.</label>
        </div>
        <fieldset class="g-musf"><legend>Muscles trained – tap once for main target, again for helper, again to clear</legend>
          <div class="g-mgrid">${MUSCLES.map(([m, l]) => { const w = x.mus?.[m]; return `<button type="button" data-act="mcycle" data-m="${m}" class="g-mbtn ${w >= 1 ? "main" : w ? "help" : ""}">${l}${w >= 1 ? " ●" : w ? " ◐" : ""}</button>`; }).join("")}</div>
          <p class="small muted">Main counts as 1 set for that muscle, helper as ½. Duration exercises count one set per ${MIN_PER_SET} minutes.</p></fieldset>
        <label class="g-wide">Notes<input name="note" maxlength="500" value="${esc(x.note || "")}" placeholder="Machine settings, cues…"></label>
        <div class="g-edbtns"><button class="btn primary" type="submit">Save</button><button class="btn" type="button" data-act="ed-cancel">Cancel</button>${x.id && CUS[x.id] ? `<button class="btn g-danger" type="button" data-act="ed-ex-del" data-id="${esc(x.id)}">Delete</button>` : ""}</div></form>`;
    }
    const x = e.draft;
    return `<form class="g-editor" data-form="woed"><h3>${x.id ? "Edit workout" : "New workout"}</h3>
      <div class="g-edgrid"><label class="g-wide">Name<input name="name" maxlength="60" value="${esc(x.name || "")}" required placeholder="e.g. Abs finisher"></label>
        <div class="g-wide"><span class="small muted">Colour</span><div class="g-cols">${PALETTE.map((c) => `<button type="button" data-act="col" data-c="${c}" class="${x.color === c ? "on" : ""}" style="background:${c}" aria-label="Colour ${c}"></button>`).join("")}</div></div>
        <label class="g-wide">Note<input name="note" maxlength="500" value="${esc(x.note || "")}" placeholder="Optional"></label></div>
      <div class="g-items">${x.items.map((it, k) => `<div class="g-item" data-i="${k}">
          <select data-f="ex" aria-label="Exercise">${exOptions(it.ex, [], false)}</select>
          <input data-f="sets" inputmode="numeric" value="${it.sets || ""}" placeholder="sets" aria-label="Sets">
          <input data-f="reps" value="${esc(it.reps || "")}" placeholder="reps / time" aria-label="Reps or time">
          <input data-f="rest" value="${esc(it.rest || "")}" placeholder="rest" aria-label="Rest">
          <input data-f="note" value="${esc(it.note || "")}" placeholder="note" aria-label="Note">
          <span class="g-itbtns"><button type="button" data-act="it-up" aria-label="Move up">↑</button><button type="button" data-act="it-down" aria-label="Move down">↓</button><button type="button" data-act="it-rm" aria-label="Remove">×</button></span></div>`).join("")}</div>
      <button type="button" class="g-link" data-act="it-add">+ Add exercise</button>
      <p class="small muted">Single-leg exercises: sets are per side. Need an exercise that isn't listed? Create it under “Your exercises” first.</p>
      <div class="g-edbtns"><button class="btn primary" type="submit">Save workout</button><button class="btn" type="button" data-act="ed-cancel">Cancel</button>${x.id ? `<button class="btn g-danger" type="button" data-act="ed-wo-del" data-id="${x.id}">Delete</button>` : ""}</div></form>`;
  }

  function mgmtHTML() {
    const ws = G.workouts || [], ex = Object.values(CUS).filter((c) => !c.archived);
    const musTxt = (m) => Object.entries(m || {}).sort((a, b) => b[1] - a[1]).map(([k, w]) => (MUSCLES.find((x) => x[0] === k) || [0, k])[1] + (w < 1 ? " (helper)" : "")).join(", ");
    return `<div class="g-mgmt">
      <div><h3 class="g-h3">Workouts</h3>${ws.length ? `<ul class="g-list">${ws.map((w) => `<li><i class="key" style="background:${w.color || PALETTE[0]}"></i><span><b>${esc(w.name)}</b><br><span class="small muted">${w.items.map((it) => esc(def(it.ex).n)).join(" · ")}</span></span><button type="button" class="g-link" data-act="ed-wo-edit" data-id="${w.id}" data-ctx="mgmt">Edit</button></li>`).join("")}</ul>` : '<p class="small muted">None yet. Make one here, or log a session and use “Save as one of my workouts”.</p>'}
        <button type="button" class="btn" data-act="ed-wo-new" data-ctx="mgmt">New workout</button></div>
      <div><h3 class="g-h3">Your exercises</h3>${ex.length ? `<ul class="g-list">${ex.map((c) => `<li><span><b>${esc(c.name)}</b><br><span class="small muted">${esc(KNAME[c.kind] || c.kind)}${c.uni ? " · one side at a time" : ""}${Object.keys(c.mus || {}).length ? " · " + esc(musTxt(c.mus)) : " · no muscles set"}</span></span><button type="button" class="g-link" data-act="ed-ex-edit" data-id="${esc(c.id)}" data-ctx="mgmt">Edit</button></li>`).join("")}</ul>` : '<p class="small muted">The library has 60+ exercises. Add your own for anything missing.</p>'}
        <button type="button" class="btn" data-act="ed-ex-new" data-ctx="mgmt">New exercise</button></div>
    </div>${UI.ed && UI.ed.ctx === "mgmt" ? editorHTML() : ""}`;
  }

  // ------------------------------------------------------------ page
  async function renderGym(arg) {
    G = await api("/api/gym", true);
    CUS = Object.fromEntries((G.exercises || []).map((e) => [e.id, e]));
    UI.swap = UI.editSet = UI.tool = null;
    UI.map = UI.map || store.get("g-map", "session");
    if (UI.ed && UI.ed.ctx === "sess") UI.ed = null;
    const t = todayIso(), st = start(), ti = idxOf(t), end = addD(st, 27);
    const sel = arg && /^\d{4}-\d{2}-\d{2}$/.test(arg) ? arg : ti < 0 ? st : ti > 27 ? end : t;
    // Progress → Strength without a day: the analytics only. A day (#/progress/strength/<date>) opens the full page.
    const analytics = !(arg && /^\d{4}-\d{2}-\d{2}$/.test(arg));
    if (UI.ai !== sel) { UI.ai = null; UI.aiDraft = ""; }
    const anchor = t < st ? st : t > end ? end : t;
    const wNow = weekOf(anchor), wkStart = addD(st, (wNow - 1) * 7), wkEnd = addD(wkStart, 6);
    const wkDays = [...Array(7).keys()].map((k) => addD(wkStart, k));
    const wkSets = G.sets.filter((s) => s.date >= wkStart && s.date <= wkEnd);
    const plannedMus = {}; wkDays.forEach((d) => { for (const [k, v] of Object.entries(plannedMuscles(d))) plannedMus[k] = (plannedMus[k] || 0) + v; });
    const loggedMus = loggedMuscles(wkSets);
    const plannedN = sum(wkDays.map(plannedEntries)), loggedN = wkSets.filter((s) => countable(def(s.ex, s.name))).length;
    const wkVol = sum(wkSets.map((s) => (s.kg > 0 && s.reps ? s.kg * s.reps * (def(s.ex, s.name).pair ? 2 : 1) : 0)));
    const doneDates = new Set([...G.sets.filter((s) => s.date >= st && s.date <= end).map((s) => s.date), ...Object.values(G.days).filter((x) => x.done && x.date >= st && x.date <= end).map((x) => x.date)]);
    const pains = Object.values(G.days).filter((x) => x.pain != null).sort((a, b) => a.date.localeCompare(b.date));
    const last3 = pains.slice(-3), painAvg = last3.length ? sum(last3.map((x) => x.pain)) / last3.length : null;
    const pressId = G.sets.some((s) => s.ex === "bench") ? "bench" : G.sets.some((s) => s.ex === "dbbench") ? "dbbench" : "bench";
    const pressH = hist(pressId)[""] || [];
    const T = G.tests || {};
    const lsi = T.lr1 && T.ll1 ? T.lr1 / T.ll1 * 100 : T.lr0 && T.ll0 ? T.lr0 / T.ll0 * 100 : null;
    const blockTxt = ti < 0 ? `starts in ${plural(-ti, "day")}` : ti > 27 ? "block finished" : `day ${ti + 1} of 28 · week ${weekOf(t)}, ${PH[weekOf(t) - 1]}`;
    const progEx = [...new Set(G.sets.map((s) => s.ex))].map((id) => def(id)).filter((e) => metric(e).label);
    const strSel = progEx.some((e) => e.id === store.get("g-str", "bench")) ? store.get("g-str", "bench") : progEx[0]?.id || "";

    app.innerHTML = `<div id="g-root">
      <div class="page-head"><div><h1>Gym</h1><p class="sub">Knee-smart 4-week block · ${blockTxt}</p></div>
        <label class="g-start">Day 1 <input type="date" id="g-startin" value="${st}"></label></div>
      ${analytics ? `<p class="g-blocklink"><a class="u-btn" href="#/progress/strength/${t}">Open the 28-day block</a><span class="u-c2">Log or change a past day there. Today's session runs in Workout mode.</span></p>` : ""}
      <div class="tiles">
        ${tile("Sessions done", `${doneDates.size}`, "", "in this block")}
        ${tile("Sets this week", n0(loggedN), "", `week ${wNow}: ${PH[wNow - 1]}`)}
        ${tile("Lifted this week", wkVol ? Math.round(wkVol).toLocaleString("de-CH") : "–", "kg", "weight × reps, all sets")}
        ${tile("Knee pain", painAvg == null ? "–" : n1(painAvg), "/ 10", last3.length ? `average of last ${plural(last3.length, "entry").replace("entrys", "entries")}` : "rate it after each session")}
        ${tile(pressId === "dbbench" ? "DB bench, est. 1RM" : "Bench, est. 1RM", pressH.length ? n1(pressH[pressH.length - 1].y) : "–", "kg", pressH.length > 1 ? `${pressH[pressH.length - 1].y >= pressH[0].y ? "▲" : "▼"} ${n1(Math.abs(pressH[pressH.length - 1].y - pressH[0].y))} kg since ${fd(pressH[0].x, { day: "numeric", month: "short" })}` : "from your best set")}
        ${tile("Quad symmetry", lsi ? Math.round(lsi) : "–", lsi ? "%" : "", lsi ? "right ÷ left · target 90%+" : "physio test: 80% · first A session from day 5")}
      </div>
      <div class="grid">
        ${analytics ? "" : card("28-day block", rackHTML(sel) + `<div class="legend" style="margin-top:12px">${["A", "B", "C"].map((s) => `<span><i class="key" style="background:${COLV[s]}"></i>${s + " · " + SNAME[s]}</span>`).join("")}${(G.workouts || []).map((w) => `<span><i class="key" style="background:${w.color || PALETTE[0]}"></i>${esc(w.name)}</span>`).join("")}</div>`, { span: 12, sub: "Each day shows the workout you chose. Tap a day to see it or log it." })}
        <section class="card span-12 g-sess" id="g-sess"${analytics ? ' style="display:none"' : ""}>${sessHTML(sel)}</section>
        ${card("Workout stats", G.sets.length ? `<div class="chart" id="g-volch"></div><p class="small muted" style="margin:8px 0 0">Kilos lifted per session (weight × reps; a weight per arm counts for both arms). Tap a bar for sets and reps.</p>` : '<p class="muted small">Log a session and its totals appear here.</p>', { span: 6, sub: "Every session, coloured by workout" })}
        <section class="card span-6" id="g-effcard"${analytics ? ' style="display:none"' : ""}><div class="card-head"><div><h2>Effort check</h2><p class="sub">${fd(sel, { weekday: "long", day: "numeric", month: "short" })} · was it the right amount?</p></div></div><div id="g-eff">${effortHTML(sel)}</div></section>
        ${card("Muscles worked", `<div id="g-map">${bodyMapHTML(sel)}</div>`, { span: 6, sub: "Hard sets per muscle · helpers count ½ · legs per side", right: seg("g-mapmode", [["session", "Session"], ["week", "Week"]], UI.map) })}
        ${card("Sets this week vs plan", musBars(plannedMus, loggedMus), { span: 6, sub: `${fd(wkStart, { day: "numeric", month: "short" })} – ${fd(wkEnd, { day: "numeric", month: "short" })} · hard sets per muscle, helpers count ½` })}
        ${card("Knee pain", pains.length ? `<div class="chart" id="g-painch"></div>` : '<p class="muted small">Rate your knee 0–10 after each session (top of the session card) and the trend appears here.</p>', { span: 6, sub: "0–2 train as written · 3–4 hold, go shallower · 5+ stop that exercise" })}
        ${card("Strength progress", progEx.length ? `<div class="chart" id="g-strch"></div><p class="small muted" style="margin:8px 0 0">Best set per day: estimated 1-rep max for weighted lifts (kg × (1 + reps ÷ 30)), reps for bodyweight, seconds for holds. 2-up/1-down sets make the right leg extension and left leg curl jump – that's the method.</p>` : '<p class="muted small">Log a few sessions and your trend per exercise appears here.</p>', { span: 6, right: progEx.length ? `<select id="g-strsel">${progEx.map((e) => `<option value="${e.id}" ${e.id === strSel ? "selected" : ""}>${esc(e.n)}</option>`).join("")}</select>` : "" })}
        <section class="card span-12" id="g-mgmtcard"><div class="card-head"><div><h2>Your workouts and exercises</h2><p class="sub">Build your own sessions from the library or from exercises you create</p></div></div><div id="g-mgmt">${mgmtHTML()}</div></section>
        ${card("Tests", testsHTML(), { span: 6, sub: "Day 5 and day 25 (strength), day 1 and day 28 (tape). Saved on the Pi." })}
        ${card("Rules", rulesHTML(), { span: 6 })}
        ${analytics ? "" : card("History", historyHTML(), { span: 12 })}
      </div></div>`;

    if (pains.length) drawPain(pains);
    if (progEx.length) drawStr(strSel);
    if (G.sets.length) drawVol();
    UI.sel = sel;
    wire($("#g-root"), sel);
    onSeg("g-mapmode", (v) => { UI.map = v; store.set("g-map", v); drawMap(sel); });
    loadEffort(sel);
    pollJobs(sel);
    if (arg) setTimeout(() => $("#g-sess")?.scrollIntoView({ block: "start" }), 30);
  }

  function hist(exId) {
    const dfn = def(exId), M = metric(dfn), by = {};
    for (const s of G.sets) {
      if (s.ex !== exId) continue;
      const v = M.v(s); if (v == null) continue;
      const k = s.side || "";
      by[k] = by[k] || {};
      by[k][s.date] = M.agg === "sum" ? (by[k][s.date] || 0) + v : Math.max(by[k][s.date] ?? -Infinity, v);
    }
    const out = {};
    for (const [k, m] of Object.entries(by)) out[k] = Object.entries(m).sort().map(([x, y]) => ({ x, y }));
    return out;
  }

  function musBars(planned, logged) {
    const keys = [];
    for (const [m] of MUSCLES) { if (LEGSET.has(m)) keys.push(m + "R", m + "L"); else keys.push(m); }
    const rows = keys.filter((k) => (planned[k] || 0) >= 0.5 || (logged[k] || 0) >= 0.5);
    if (!rows.length) return '<p class="muted small">Nothing planned or logged this week yet.</p>';
    const max = Math.max(1, ...rows.map((k) => Math.max(planned[k] || 0, logged[k] || 0)));
    return `<div class="g-bars">${rows.map((k) => { const p = planned[k] || 0, d = logged[k] || 0;
      return `<div class="g-bar"><span>${musLabel(k)}</span><div class="g-track"><i class="pl" style="width:${p / max * 100}%"></i><i class="dn${p && d >= p ? " full" : ""}" style="width:${Math.min(d, max) / max * 100}%"></i></div><span class="num">${g1(d)} / ${g1(p)}</span></div>`; }).join("")}</div>
      <p class="small muted" style="margin:8px 0 0">Pale bar = planned in the workouts you chose this week, solid = logged. Legs are counted per side; a both-legs set counts for each.</p>`;
  }

  // ------------------------------------------------------------ body map
  // outline regions (window.BODYPATHS, from body-muscles) -> the 18 muscles counted above; unlisted regions are just body
  const REGION = {
    "chest-upper": "chest", "chest-lower": "chest", "shoulder-front": "frontDelt", "shoulder-side": "sideDelt", "deltoid-rear": "rearDelt",
    biceps: "biceps", "triceps-lateral": "triceps", "triceps-long": "triceps", forearm: "forearms", "forearm-extensors": "forearms", "forearm-flexors": "forearms",
    "lats-upper": "lats", "lats-mid": "lats", "lats-lower": "lats", "traps-upper": "upperBack", "traps-mid": "upperBack", "traps-lower": "upperBack",
    "lower-back-erectors": "lowerBack", "lower-back-ql": "lowerBack", "abs-upper": "abs", "abs-lower": "abs", obliques: "obliques",
    "gluteus-maximus": "glutes", "gluteus-medius": "abductors", adductors: "adductors", quads: "quads",
    "hamstrings-lateral": "hamstrings", "hamstrings-medial": "hamstrings", "calves-gastroc-lateral": "calves", "calves-gastroc-medial": "calves", "calves-soleus": "calves",
  };
  // hard-set bins: one session vs one week (10+ sets a week per muscle is the usual growth landmark)
  const MAPEDGE = { session: [1, 3, 5, 7], week: [2, 5, 10, 15] };
  const MAPLBL = { session: ["<1", "1–2½", "3–4½", "5–6½", "7+"], week: ["<2", "2–4½", "5–9½", "10–14½", "15+"] };
  const binOf = (v, mode = "session") => { if (!(v >= 0.25)) return 0; let b = 1; for (const e of MAPEDGE[mode]) if (v >= e) b++; return b; };
  const halves = (v) => { const r = Math.round(v * 2) / 2, w = Math.floor(r); return r % 1 ? (w ? `${w}½` : "½") : String(r); };
  let MAP = { mus: {}, mode: "session" };
  function regionVal(id) {
    const side = id.endsWith("-right") ? "R" : id.endsWith("-left") ? "L" : "";
    const m = REGION[side ? id.slice(0, id.lastIndexOf("-")) : id];
    if (!m) return null;
    const leg = LEGSET.has(m);
    return { m, side: leg ? side : "", v: (leg ? MAP.mus[m + side] : MAP.mus[m]) || 0 };
  }
  function regionTxt(r) {
    const name = esc((MUSCLES.find((x) => x[0] === r.m) || [0, r.m])[1]) + (r.side ? ` · ${r.side === "R" ? "right" : "left"} leg` : "");
    const when = MAP.mode === "session" ? "this session" : "this week";
    return r.v >= 0.25 ? `${name}: ${halves(r.v)} hard ${r.v > 0.75 && r.v < 1.25 ? "set" : "sets"} ${when}` : `${name}: nothing ${when}`;
  }
  function mapRange(sel, mode) {
    const o = { day: "numeric", month: "short" };
    if (mode === "session") return { from: sel, to: sel, label: fd(sel, { weekday: "long", day: "numeric", month: "short" }) };
    const i = idxOf(sel);
    if (i >= 0 && i < 28) { const a = addD(start(), Math.floor(i / 7) * 7); return { from: a, to: addD(a, 6), label: `Plan week ${Math.floor(i / 7) + 1} · ${fd(a, o)} – ${fd(addD(a, 6), o)}` }; }
    return { from: addD(sel, -6), to: sel, label: `7 days to ${fd(sel, o)}` };
  }
  function bodyMapHTML(sel) {
    const mode = UI.map, r = mapRange(sel, mode);
    const ss = G.sets.filter((s) => s.date >= r.from && s.date <= r.to);
    MAP = { mus: loggedMuscles(ss), mode };
    const pains = Object.values(G.days).filter((x) => x.date >= r.from && x.date <= r.to && x.pain != null).map((x) => x.pain);
    const pain = pains.length ? Math.max(...pains) : null;
    const P = window.BODYPATHS;
    if (!P) return '<p class="muted small">The body outline file did not load.</p>';
    const kneeCls = pain >= 5 ? " g-knee5" : pain >= 3 ? " g-knee3" : "";
    const el = ([id, d]) => {
      const rv = regionVal(id);
      if (!rv) return `<path d="${d}" class="g-bp${kneeCls && (id === "knee-right" || id === "knee-back-right") ? kneeCls : ""}"/>`;
      return `<path d="${d}" class="g-m g-m${binOf(rv.v, mode)}" data-r="${id}" data-m="${rv.m}" data-s="${rv.side}"><title>${regionTxt(rv)}</title></path>`;
    };
    const top = Object.entries(MAP.mus).filter(([, v]) => v >= 0.25).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([k, v]) => `${musRaw(k)} ${halves(v)}`).join(", ");
    const kneeTxt = pain == null ? "" : pain >= 3 ? `<span><i style="background:var(${pain >= 5 ? "--critical" : "--warning"})"></i>Right knee: pain ${pain}/10${mode === "week" && pains.length > 1 ? " (worst day)" : ""}</span>` : `<span>Knee pain ${pain}/10 · green</span>`;
    return `<div class="g-mapwrap">
      <p class="small muted" style="margin:0">${esc(r.label)}${ss.length ? "" : " · nothing logged yet"}</p>
      <svg class="g-body" viewBox="-1 -1 71 101" role="img" aria-label="Front and back body view. ${top ? "Most work: " + esc(top) : "No sets logged"}.">
        ${P.front.map(el).join("")}${P.back.map(el).join("")}
        <text x="3" y="8" class="g-side">R</text><text x="28.6" y="8" text-anchor="end" class="g-side">L</text><text x="15.8" y="98" text-anchor="middle">Front</text>
        <text x="39.6" y="8" class="g-side">L</text><text x="65.4" y="8" text-anchor="end" class="g-side">R</text><text x="52.5" y="98" text-anchor="middle">Back</text>
      </svg>
      <p class="g-mcap" id="g-mcap">${ss.length ? '<span class="muted">Tap a muscle for its number.</span>' : ""}</p>
      <div class="g-mleg"><span><i style="background:var(--m0)"></i>none</span>
        <span class="g-ramp">${[1, 2, 3, 4, 5].map((b) => `<span><i style="background:var(--m${b})"></i>${MAPLBL[mode][b - 1]}</span>`).join("")}</span>
        <span>hard sets</span>${kneeTxt}</div>
    </div>`;
  }
  function drawMap(sel) {
    const el = $("#g-map");
    if (el) el.innerHTML = bodyMapHTML(sel);
  }
  function pickRegion(path) {
    const svg = path.closest("svg"), m = path.dataset.m, s = path.dataset.s;
    svg.querySelectorAll(".g-m.sel").forEach((p) => p.classList.remove("sel"));
    svg.querySelectorAll(`.g-m[data-m="${m}"]`).forEach((p) => { if (!s || p.dataset.s === s) p.classList.add("sel"); });
    const cap = $("#g-mcap");
    if (cap) cap.innerHTML = regionTxt(regionVal(path.dataset.r));
  }

  // ------------------------------------------------------------ effort check
  // Verdict = reps in reserve vs the plan's target + your 0–10 session rating (both validated for lifting).
  // The watch's heart rate only says something about pace/rest and overall strain, so it can't make the call alone.
  const EFF = {};                      // /api/gym/effort per date (watch recording + HR analysis)
  let hrChart = null;
  const RPEBAND = [[4, 6], [5, 7], [6, 8], [6, 8]];   // session rating targets by plan week (follows the RIR targets)
  const CR10 = ["rest", "very, very easy", "easy", "moderate", "somewhat hard", "hard", "hard", "very hard", "very hard", "very, very hard", "maximal"];
  const parseRIR = (t) => { const n = (String(t).match(/\d+(?:[.,]\d+)?/g) || []).map((x) => +x.replace(",", ".")); return n.length ? [Math.min(...n), Math.max(...n)] : null; };

  function rirCheck(d) {
    const blocks = blocksFor(d);
    const ss = setsOn(d).filter((s) => s.rir != null && countable(def(s.ex, s.name)));
    if (!ss.length) return null;
    let easy = 0, hard = 0, knee = 0;
    const tg = new Set();
    for (const s of ss) {
      const sl = blocks.find((b) => b.slot === slotOf(s));
      const r = (sl?.rir && sl.rir[0] === "RIR" && parseRIR(sl.rir[1])) || [1, 3];
      tg.add(r[0] === r[1] ? `${r[0]}` : `${r[0]}–${r[1]}`);
      if (sl?.tag === "knee" && s.rir < 2) { knee++; hard++; }
      else if (s.rir < r[0] - 1) hard++;
      else if (s.rir > r[1] + 1) easy++;
    }
    const n = ss.length, st = knee ? "knee" : hard / n >= 0.3 ? "high" : easy / n >= 0.5 ? "low" : "ok";
    return {
      st, few: n < 3 && !knee, txt: `${n - easy - hard} of ${plural(n, "set")} with RIR in the target range (${[...tg].join(" / ")}, ±1)${easy ? ` · ${easy} easier` : ""}${hard ? ` · ${hard} harder` : ""}.`,
      tip: st === "knee" ? `${plural(knee, "knee set")} went below RIR 2 – knee exercises always stop with 2+ clean reps left.`
        : n < 3 ? "Too few sets with RIR to judge the whole session – add it to a few more next time."
        : st === "high" ? "Several sets went closer to failure than this week asks for." : st === "low" ? "Most sets stopped well short of the target – add weight or reps next time." : "",
    };
  }
  function rpeCheck(d) {
    const rpe = G.days[d]?.rpe, i = idxOf(d), inPlan = i >= 0 && i < 28 && !!PLAN[sessOf(d)];
    const band = inPlan ? (i >= 24 ? [5, 7] : RPEBAND[weekOf(d) - 1]) : [5, 7];
    if (rpe == null) return { st: null, band };
    const st = rpe >= 9 || rpe > band[1] ? "high" : rpe < band[0] ? "low" : "ok";
    return { st, band, txt: `${g1(rpe)}/10, ${CR10[Math.round(rpe)]} · target ${band[0]}–${band[1]}${inPlan ? ` in week ${weekOf(d)}${i >= 24 ? " (taper)" : ""}` : ""}.` };
  }
  function paceCheck(d, e) {
    const s = sessionStats(d), hr = e?.hr, bits = [];
    let st = null;
    if (s.mins && s.hard >= 6) {
      const mps = s.mins / s.hard;
      bits.push(`${s.mins} min for ${s.hard} hard sets ≈ ${g1(mps)} min per set incl. rest`);
      st = mps < 1.6 ? "high" : mps > 5 ? "low" : "ok";
    }
    if (hr?.pct_avg) {
      bits.push(`average ${hr.avg} bpm = ${Math.round(hr.pct_avg * 100)}% of your max${e.usual_pct ? ` (usual for your gym sessions: ${Math.round(e.usual_pct * 100)}%)` : ""}`);
      if (hr.pct_avg >= 0.78) st = "high"; else st = st || "ok";
    }
    if (!st) return null;
    const tip = st === "high" ? "Circuit pace: short rests keep the heart rate high and cost strength on the big lifts – rest 2–3 min on compounds."
      : st === "low" ? "Long gaps between sets – fine for heavy work, it just makes the session long." : "Rest and pace look right for strength and size work.";
    return { st, txt: bits.join(" · ") + ".", tip };
  }
  function kneeCheck(d) {
    const p = G.days[d]?.pain;
    if (p == null) return null;
    return p >= 5 ? { st: "knee", txt: `${p}/10 – red.`, tip: "Stop that exercise today. Swelling, locking, giving way or night pain → stop leg training and call your physio." }
      : p >= 3 ? { st: "knee", amber: true, txt: `${p}/10 – amber.`, tip: "Next time keep the weight, go shallower or drop a set; no progression." }
      : { st: "ok", txt: `${p}/10 – green.` };
  }
  function verdict(rir, rpe, pace, knee) {
    if (knee?.st === "knee") return ["knee", "!", "Too much for the knee", knee.amber ? "Knee pain 3–4: hold weight and depth next leg session." : "Knee pain 5+: stop that exercise and check in with your physio if it stays."];
    if (rir?.st === "knee") return ["knee", "!", "Knee work went too close to failure", "Keep knee exercises at RIR 2 or more."];
    const prim = [rir && !rir.few ? rir.st : null, rpe?.st].filter(Boolean);
    if (!prim.length) return ["none", "?", "Not enough to judge yet", "Rate the session 0–10 at the top of the session card, or add RIR to a few sets."];
    const hi = prim.includes("high"), lo = prim.includes("low");
    if (hi && lo) return ["high", "±", "Mixed signals", "The sets and your overall rating disagree – a short night, little food or stress can make easy sets feel hard."];
    if (hi) return ["high", "↑", "Harder than planned", "Fine once in a while. If it keeps happening, take a set off or use a bit less weight."];
    if (lo) return ["low", "↓", "Easier than planned", "There's room: add weight or reps on the main lifts next time."];
    return ["ok", "✓", "In your effort range", pace?.st === "high" ? "Right effort – but the pace was rushed, rest a little longer on the big lifts." : "Right where this week of the plan wants you."];
  }
  function effortHTML(d) {
    const e = EFF[d], rir = rirCheck(d), rpe = rpeCheck(d), knee = kneeCheck(d), pace = paceCheck(d, e);
    const [cls, ico, title, sub] = verdict(rir, rpe, pace, knee);
    const mark = { ok: "✓", low: "↓", high: "↑", knee: "!" };
    const row = (st, label, body, tip) => `<li><span class="st ${st || "na"}" aria-hidden="true">${mark[st] || "–"}</span><div><b>${label}:</b> ${body}</div>${tip ? `<p>${tip}</p>` : ""}</li>`;
    const hr = e?.hr, a = e?.activity;
    let watch;
    if (!e) watch = row(null, "Watch", '<span class="muted">loading…</span>');
    else if (!a) watch = row(pace?.st, "Pace", pace ? pace.txt : '<span class="muted">nothing to measure yet.</span>', `${pace ? pace.tip + " " : ""}No watch recording found for this day – record the session on the watch (Strength, Cardio, HIIT or Other) to add heart rate.`);
    else {
      const zs = hr?.zones_s, zt = zs ? sum(zs) : 0;
      const zbar = zt ? `<span class="small muted">Time in heart-rate zones, easy → hard from left to right</span><div class="g-zbar" title="Time below zone 1 and in zones 1–5">${zs.map((v, k) => (v ? `<i style="flex:${v};background:var(${k ? "--m" + k : "--m0"})" title="${k ? "Zone " + k : "Below zone 1"}: ${Math.round(v / 60)} min"></i>` : "")).join("")}</div>` : "";
      const rhythm = hr?.peaks >= 4 ? ` Roughly ${hr.peaks} heart-rate peaks (≈ sets)${hr.cycle_min ? `, about ${g1(hr.cycle_min)} min apart` : ""} – wrist HR is rough in the gym.` : "";
      watch = row(pace?.st, "Pace & heart rate", `${pace ? pace.txt : ""} <span class="muted">From <a href="#/activity/${a.id}">${esc(a.name)}</a>${a.start ? ` at ${a.start}` : ""}.</span>`, `${pace ? pace.tip : ""}${rhythm}`)
        + (hr?.series ? `<li style="display:block">${zbar}<div class="g-hrch" id="g-hrch"></div></li>` : "");
    }
    return `<div class="g-verdict ${cls}"><span class="ico" aria-hidden="true">${ico}</span><div><b>${title}</b><span>${sub}</span></div></div>
      <ul class="g-eff">
        ${row(rir?.st, "Sets", rir ? rir.txt : '<span class="muted">no RIR logged.</span>', rir ? rir.tip : "Add RIR (reps you had left) to a few sets – it's the best measure of effort in the gym.")}
        ${row(rpe.st, "Session rating", rpe.st ? rpe.txt : `<span class="muted">not rated · target ${rpe.band[0]}–${rpe.band[1]}.</span>`, rpe.st ? "" : "Pick 0–10 at the top of the session card, ideally ~30 min after you finish.")}
        ${watch}
        ${knee ? row(knee.st, "Knee", knee.txt, knee.tip) : ""}
      </ul>
      <p class="small muted" style="margin:10px 0 0">Heart rate in the gym mostly shows rest length and overall strain, not how close to failure your sets were – so RIR and your 0–10 rating make the call.</p>`;
  }
  async function loadEffort(d) {
    try { EFF[d] = await api(`/api/gym/effort?date=${d}`, true); } catch { EFF[d] = { error: true }; }
    drawEffort(d);
  }
  function drawEffort(d) {
    const el = $("#g-eff");
    if (!el) return;
    if (hrChart) { try { hrChart.destroy(); } catch { /* gone */ } const k = charts.indexOf(hrChart); if (k >= 0) charts.splice(k, 1); hrChart = null; }
    el.innerHTML = effortHTML(d);
    const hr = EFF[d]?.hr;
    if (!hr?.series || !$("#g-hrch")) return;
    const c = C(), mx = EFF[d].hrmax;
    hrChart = mkChart("#g-hrch", {
      type: "line",
      data: { datasets: [
        line("Heart rate", hr.series.map(([x, y]) => ({ x, y })), c.critical, { tension: 0.2, fmt: (r) => `${r.y} bpm${mx ? ` · ${Math.round(r.y / mx * 100)}%` : ""}` }),
        dots("HR peak", (hr.peak_pts || []).map(([x, y]) => ({ x, y })), c.text2, { fmt: (r) => `${r.y} bpm` }),
      ] },
      options: {
        interaction: { mode: "nearest", axis: "x", intersect: false },
        scales: { ...axes({ xType: "linear" }), x: { type: "linear", min: 0, grid: { display: false }, border: { color: c.axis }, ticks: { color: c.muted, maxTicksLimit: 7, callback: (v) => `${Math.round(v)} min` } } },
        plugins: { tipTitle: (dp) => `${n1(dp.raw.x)} min` },
      },
    });
  }

  // ------------------------------------------------------------ describe it in words (local AI on the Pi)
  function aiCtx(d) {
    const catalog = allDefs().filter((e) => e.kind !== "info" && !e.unknown).map((e) => ({ id: e.id, n: e.n, kind: e.kind, uni: !!e.uni, cat: e.cat || "Other" }));
    const slots = slotsFor(d).filter((sl) => def(sl.base).kind !== "info").map((sl) => ({ slot: sl.slot, base: sl.base, alts: (sl.alts || []).filter((x) => LIBBY[x] || CUS[x]), plan: !!sl.plan, n: sl.n || def(sl.base).n }));
    const s = sessOf(d);
    return { catalog, slots, session: s, sname: sessName(s) };
  }
  const shortModel = (m) => String(m || "").replace(/-q\d\w*$/i, "");
  const mmss = (sec) => (sec >= 60 ? `${Math.floor(sec / 60)} min ${String(Math.round(sec % 60)).padStart(2, "0")} s` : `${Math.round(sec)} s`);
  const since = (t) => Math.max(0, (Date.now() - Date.parse(t)) / 1000);
  // "60 kg × 10 (2 sets), 60 kg × 9": consecutive identical sets grouped.
  function setsTxt(sets) {
    const out = [];
    for (const x of sets || []) {
      const t = setTxt(x) + (x.rir != null ? `, RIR ${g1(x.rir)}` : "");
      if (out.length && out[out.length - 1].t === t) out[out.length - 1].n++;
      else out.push({ t, n: 1 });
    }
    return out.map((g) => (g.n > 1 ? `${g.t} (${g.n} sets)` : g.t)).join(", ");
  }
  // One describe-session job (Workout mode's sheet and the 28-day block page): status with a symbol, what it
  // understood, and the actions as buttons.
  function jobHTML(j) {
    const r = j.result || {}, items = r.items || [];
    const UI_ = window.UIC || {};
    const quote = `<p class="g-jq">“${esc(j.text.length > 180 ? j.text.slice(0, 177) + "…" : j.text)}”</p>`;
    const rows = items.map((it) => `<div><b>${esc(it.name)}${it.side ? ` (${it.side === "L" ? "left" : it.side === "R" ? "right" : esc(it.side)})` : ""}${it.new ? ' <span class="g-tag">new</span>' : ""}</b><span>${esc(setsTxt(it.sets))}</span></div>`);
    if (r.rpe != null) rows.push(`<div><b>Session effort</b><span>${g1(r.rpe)}/10</span></div>`);
    if (r.pain != null) rows.push(`<div><b>Knee pain</b><span>${r.pain}/10</span></div>`);
    const list = rows.length ? `<div class="g-jl">${rows.join("")}</div>` : "";
    const secs = sum((r.passes || []).map((x) => x.s || 0));
    const took = secs ? `Took ${mmss(secs)}${(r.passes || []).length > 1 ? ", 2 passes" : ""}.` : "";
    const notes = (r.notes || []).length ? `<p class="g-jm">${r.notes.map(esc).join(" ")}</p>` : "";
    const btn = (act, label, cls = "") => `<button type="button" class="u-btn ${cls}" data-act="ai-${act}" data-id="${j.id}">${label}</button>`;
    const head = (cls, icon, title, meta = "") => `<div class="g-jh"><span class="g-js">${icon}<b>${title}</b></span></div>${meta ? `<p class="g-jm">${meta}</p>` : ""}`;
    const status = (c, ic) => `<span class="u-status ${c}">${UI_[ic] || ""}</span>`;
    const spin = '<span class="g-spin" aria-hidden="true"></span>';
    const acts = (...b) => `<div class="g-jb">${b.join("")}</div>`;
    if (j.status === "queued") return `<div class="g-job is-queued">${head("", spin, "Waiting for the Pi…")}${quote}${acts(btn("discard", "Cancel"))}</div>`;
    if (j.status === "running") {
      const meta = `${esc(j.stage ? j.stage.charAt(0).toUpperCase() + j.stage.slice(1) : "Working")}${j.started_at ? `, <span data-since="${esc(j.started_at)}">${mmss(since(j.started_at))}</span>` : ""}.`;
      return `<div class="g-job is-running">${head("", spin, "Analysing on the Pi", meta)}${quote}
        <p class="g-jm">${j.stage === "careful pass" ? "The first answer didn't fully add up, so it's taking a second, more careful look." : "Usually a few minutes."} You can close the page; it finishes on its own.</p></div>`;
    }
    if (j.status === "done") return `<div class="g-job is-done">${head("", status("green", "check"), esc(j.message || "Logged"), took)}${quote}${list}${notes}${acts(btn("undo", "Undo"))}</div>`;
    if (j.status === "review") {
      return `<div class="g-job is-review">${head("", status("amber", "bang"), "Check this before it's logged", took)}${quote}
        <ul class="g-ji">${(r.issues || []).map((x) => `<li>${esc(x)}</li>`).join("")}</ul>
        ${list ? `<p class="g-jm">What it understood:</p>${list}` : ""}${notes}
        ${acts(items.length ? btn("confirm", "Log these sets", "ink") : "", btn("edit", "Edit my text"), btn("discard", "Dismiss", "plain"))}</div>`;
    }
    if (j.status === "error") return `<div class="g-job is-error">${head("", status("red", "bang"), "Didn't work", esc(j.message || ""))}${quote}${acts(btn("retry", "Try again"), btn("discard", "Dismiss", "plain"))}</div>`;
    if (j.status === "undone") return `<div class="g-job is-undone">${head("", "", "Undone")}${quote}${acts(btn("edit", "Edit and send again"))}</div>`;
    return "";
  }
  function aiHTML(d) {
    const A = G.ai || {};
    if (!A.enabled) return "";
    const jobs = (A.jobs || []).filter((j) => j.date === d && j.status !== "discarded").slice(0, 4);
    const box = UI.ai === d ? `<form class="g-ai" data-form="ai">
        <div class="g-airow"><b>Describe your workout</b><span class="small muted">The Pi's own model (${esc(shortModel(A.model))}) turns it into sets. Takes a few minutes – you can close the page.</span></div>
        <textarea name="text" maxlength="2000" required placeholder="e.g. bench 3x8 60kg, last set to failure · leg press both legs 3x12 120 · leg extension right 3x10 25, left 2x12 30 · 10 min abs · felt 7/10, knee 2">${esc(UI.aiDraft || "")}</textarea>
        <div class="g-airow"><button class="btn primary" type="submit">Analyse on the Pi</button><button class="btn" type="button" data-act="ai-close">Close</button><span class="small muted" id="g-aistat"></span></div>
      </form>` : "";
    return box + jobs.map(jobHTML).join("");
  }
  function drawJobs(d) {
    const el = $("#g-jobs");
    if (!el) return;
    const ta = el.querySelector("textarea"), focused = ta && document.activeElement === ta;
    el.innerHTML = aiHTML(d);
    if (focused) { const t = el.querySelector("textarea"); t?.focus(); if (t) t.selectionStart = t.selectionEnd = t.value.length; }
  }
  async function aiStatus() {
    const el = $("#g-aistat");
    if (!el) return;
    try {
      const st = await api("/api/gym/ai", true);
      el.innerHTML = !st.reachable ? '<span class="warn">The local AI isn\'t running on the Pi yet – run <code>./setup-ai.sh</code> there once.</span>'
        : !st.model_ready ? `<span class="warn">The model ${esc(shortModel(st.model))} isn't downloaded yet – run <code>./setup-ai.sh</code> on the Pi.</span>`
        : st.busy ? "The Pi is busy with another description; yours waits in line."
        : `Ready · ${esc(shortModel(st.model))}${st.keep_loaded ? (st.primed ? " · loaded, instructions already read" : " · the first description after a restart takes longer (the model reads its instructions once)") : ""}${st.careful_model && st.careful_model !== st.model ? (st.careful_ready ? ` · careful pass ${esc(shortModel(st.careful_model))}` : ` · careful-pass model missing – run <code>./setup-ai.sh</code>`) : ""}`;
    } catch { el.textContent = ""; }
  }
  let pollT = null, tickT = null;
  const liveJobs = (d) => (G.ai?.jobs || []).some((j) => j.date === d && (j.status === "queued" || j.status === "running"));
  function pollJobs(d) {
    clearTimeout(pollT);
    clearInterval(tickT);
    if (!liveJobs(d)) return;
    tickT = setInterval(() => {
      const els = document.querySelectorAll("#g-jobs [data-since]");
      if (!els.length || !$("#g-root")) { clearInterval(tickT); return; }
      els.forEach((x) => { if (x.dataset.since) x.textContent = mmss(since(x.dataset.since)); });
    }, 1000);
    pollT = setTimeout(async function tick() {
      if (!$("#g-root") || UI.sel !== d) return;
      let jobs;
      try { jobs = await api(`/api/gym/ai/jobs?date=${d}`, true); } catch { pollT = setTimeout(tick, 15000); return; }
      const before = new Map((G.ai.jobs || []).filter((j) => j.date === d).map((j) => [j.id, j.status]));
      const logged = jobs.some((j) => j.status === "done" && before.get(j.id) !== "done");
      G.ai.jobs = [...jobs, ...(G.ai.jobs || []).filter((j) => j.date !== d)];
      if (logged) await reloadState();
      else drawJobs(d);
      if (liveJobs(d)) pollT = setTimeout(tick, 5000);
      else clearInterval(tickT);
    }, 5000);
  }
  async function reloadState() {
    const keepJobs = G.ai?.jobs;
    G = await api("/api/gym", true);
    if (!G.ai) G.ai = { jobs: keepJobs || [] };
    CUS = Object.fromEntries((G.exercises || []).map((e) => [e.id, e]));
    const busy = document.activeElement && document.activeElement.closest?.("#g-sess form:not([data-form=ai])");
    if (UI.refresh && !busy) UI.refresh(); else drawJobs(UI.sel);
  }

  function testsHTML() {
    const T = G.tests || {};
    const f = (k, l) => `<label>${l}<input data-t="${k}" inputmode="decimal" value="${T[k] ?? ""}"></label>`;
    const lsi = (r, l) => (T[r] && T[l] ? `<b>${Math.round(T[r] / T[l] * 100)}%</b>` : "–");
    const e = (w, r) => (T[w] && T[r] ? `<b>${n1(T[w] * (1 + T[r] / 30))} kg</b>` : "–");
    const gap = (r, l) => (T[r] && T[l] ? `<b>${n1(T[l] - T[r])} cm</b>` : "–");
    return `<div class="g-tests">
      <div><b>Quad symmetry</b><p class="small muted">Single-leg extension 90° → 45°, heaviest weight for 10 clean reps (stop if pain hits 3).</p>
        <div class="g-tin">${f("lr0", "Day 5 R kg")}${f("ll0", "Day 5 L kg")}${f("lr1", "Day 25 R kg")}${f("ll1", "Day 25 L kg")}</div>
        <p class="small">Symmetry: ${lsi("lr0", "ll0")} → ${lsi("lr1", "ll1")}</p></div>
      <div><b>Bench press</b><p class="small muted">Best working set.</p>
        <div class="g-tin">${f("bw0", "Day 5 kg")}${f("br0", "Day 5 reps")}${f("bw1", "Day 25 kg")}${f("br1", "Day 25 reps")}</div>
        <p class="small">Est. 1RM: ${e("bw0", "br0")} → ${e("bw1", "br1")}</p></div>
      <div><b>Tape</b><p class="small muted">Morning, before eating. Thigh 15 cm above the kneecap.</p>
        <div class="g-tin">${f("tr0", "Day 1 thigh R")}${f("tl0", "Day 1 thigh L")}${f("tr1", "Day 28 thigh R")}${f("tl1", "Day 28 thigh L")}${f("c0", "Day 1 chest")}${f("c1", "Day 28 chest")}</div>
        <p class="small">Thigh gap (L − R): ${gap("tr0", "tl0")} → ${gap("tr1", "tl1")}</p></div></div>`;
  }

  function rulesHTML() {
    return `<div class="g-rules">
      <div><b>Pain traffic light</b><ul class="why"><li><b>0–2 / 10</b>, back to normal next morning: train as written, progress when reps allow.</li><li><b>3–4</b>, or more morning stiffness: keep the weight, go shallower or drop a set; no progression next time.</li><li><b>5+</b>, sharp or catching pain: stop that exercise today. Swelling, locking, giving way or night pain → stop leg training and call your physio.</li></ul></div>
      <div><b>How hard and when to add weight</b><ul class="why"><li>RIR 2 = stop with 2 clean reps left. Knee exercises never below RIR 2.</li><li>All sets at the top of the rep range at the target RIR → add next time: barbell +2.5 kg, dumbbells +1–2 kg, machines +1 plate.</li><li>Knee exercises only after a green session and a green next morning; open the range ~10–15° a week while green.</li></ul></div></div>`;
  }

  function historyHTML() {
    const dates = [...new Set([...G.sets.map((s) => s.date), ...Object.values(G.days).filter((x) => x.pain != null || x.done || x.note).map((x) => x.date)])].sort().reverse();
    if (!dates.length) return '<p class="muted small">Nothing logged yet. Open today in the plan above and add your first set.</p>';
    return `<div class="table-wrap"><table><thead><tr><th>Date</th><th>Workout</th><th class="num">Sets</th><th class="num">Reps</th><th class="num">Lifted</th><th class="num">Time</th><th class="num">Knee</th><th>Note</th></tr></thead><tbody>
      ${dates.slice(0, 80).map((d) => { const st = sessionStats(d), s = sessOf(d), dy = G.days[d] || {};
        return `<tr class="click" data-go="${d}"><td class="muted">${fd(d)}</td><td><i class="key" style="background:${sessColor(s)}"></i> ${PLAN[s] ? s + " · " : ""}${esc(sessName(s))}</td><td class="num">${st.n}</td><td class="num">${st.reps || "–"}</td><td class="num">${st.vol ? n0(st.vol) + " kg" : "–"}</td><td class="num">${st.mins ? st.mins + " min" : "–"}</td><td class="num">${dy.pain ?? "–"}</td><td class="g-notecell">${esc(dy.note || "")}</td></tr>`; }).join("")}
    </tbody></table></div>`;
  }

  // ------------------------------------------------------------ charts
  function drawPain(pains) {
    const c = C();
    mkChart("#g-painch", {
      type: "line",
      data: { datasets: [line("Knee pain", pains.map((p) => ({ x: p.date, y: p.pain })), c.critical, { tension: 0, pointRadius: 4, pointBackgroundColor: c.critical, fmt: (r) => `${r.y} / 10` })] },
      options: { scales: axes({ unit: "day", yMin: 0, yMax: 10 }), plugins: { bands: { items: [{ from: 0, to: 2.5, color: "rgba(12,163,12,.08)", label: "train" }, { from: 2.5, to: 4.5, color: "rgba(250,178,25,.12)", label: "hold" }, { from: 4.5, to: 10, color: "rgba(208,59,59,.08)", label: "stop" }] } } },
    });
  }
  function drawStr(exId) {
    const old = charts.find((ch) => ch.canvas.parentNode?.id === "g-strch");
    if (old) { old.destroy(); charts.splice(charts.indexOf(old), 1); }
    const c = C(), h = hist(exId), M = metric(def(exId)), f = (r) => `${g1(r.y)} ${M.unit}`;
    const ds = [];
    if (h.R) ds.push(line("Right", h.R, c.critical, { tension: 0.2, pointRadius: 3.5, pointBackgroundColor: c.critical, fmt: f }));
    if (h.L) ds.push(line("Left", h.L, c.text2, { tension: 0.2, pointRadius: 3.5, pointBackgroundColor: c.text2, fmt: f }));
    if (h[""]) ds.push(line(h.R || h.L ? "Both" : M.label, h[""], c.s1, { tension: 0.2, pointRadius: 3.5, pointBackgroundColor: c.s1, fmt: f }));
    mkChart("#g-strch", { type: "line", data: { datasets: ds }, options: { scales: axes({ unit: "day", yFmt: (v) => `${v} ${M.unit}` }) } });
  }
  function drawVol() {
    const dates = [...new Set(G.sets.map((s) => s.date))].sort().slice(-40);
    const rows = dates.map((d) => ({ d, st: sessionStats(d), s: sessOf(d) }));
    mkChart("#g-volch", {
      type: "bar",
      data: { labels: rows.map((r) => fd(r.d, { day: "numeric", month: "short" })), datasets: [bars("Lifted", rows.map((r) => Math.round(r.st.vol)), rows.map((r) => colorOf(sessColor(r.s))), { fmt: (raw, dp) => { const x = rows[dp.dataIndex]; return x ? `${n0(x.st.vol)} kg · ${plural(x.st.n, "set")} · ${x.st.reps} reps · ${sessName(x.s)}` : ""; } })] },
      options: { scales: axes({ time: false, yBegin: true, yFmt: (v) => `${Math.round(v / 100) / 10}k` }), plugins: { legend: { display: false } } },
    });
  }

  // ------------------------------------------------------------ server calls
  async function post(url, body, method = "POST") {
    const r = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || `error ${r.status}`);
    return j;
  }
  function flash(el, msg) {
    let n = el.querySelector(":scope > .g-err");
    if (!n) { n = document.createElement("p"); n.className = "g-err"; el.appendChild(n); }
    n.textContent = msg;
    setTimeout(() => n.remove(), 5000);
  }
  const readNum = (f, n) => (f.elements[n] ? f.elements[n].value.trim() : undefined);
  function setBody(f, prefix = "") {
    const b = {};
    for (const k of ["kg", "reps", "secs", "mins", "rir"]) { const v = readNum(f, prefix + k); if (v !== undefined) b[k] = v; }
    const side = f.querySelector(".g-side .on");
    if (side) b.side = side.dataset.side;
    return b;
  }

  // ------------------------------------------------------------ events
  function wire(root, sel) {
    const rs = () => { const el = $("#g-sess"); if (!el) return; el.innerHTML = sessHTML(sel); onSeg("g-stype", changeSess); };
    const rr = () => { const r = $(".g-rack", root); if (r) r.outerHTML = rackHTML(sel); };
    const rm = () => { const m = $("#g-mgmt"); if (m) m.innerHTML = mgmtHTML(); };
    const rerenderEditors = () => { if (UI.ed?.ctx === "mgmt") rm(); else rs(); };
    const saveDay = async (body) => { G.days[sel] = await post("/api/gym/day", { date: sel, ...body }); };
    const changeSess = async (v) => { await saveDay({ session: v }); UI.swap = null; rs(); rr(); side(); };
    const side = () => { drawMap(sel); drawEffort(sel); };
    UI.refresh = () => { rs(); rr(); side(); pollJobs(sel); };
    onSeg("g-stype", changeSess);
    const aiAct = async (b, action) => {
      const j = await post(`/api/gym/ai/jobs/${b.dataset.id}/${action}`, {});
      G.ai.jobs = (G.ai.jobs || []).map((x) => (x.id === j.id ? j : x));
      if (action === "undo" || action === "confirm") await reloadState(); else drawJobs(sel);
      if (action === "retry") pollJobs(sel);
    };

    $("#g-startin").addEventListener("change", async (e) => { if (!e.target.value) return; await post("/api/gym/settings", { start: e.target.value }); if (location.hash === "#/progress/strength") route(); else location.hash = "#/progress/strength"; });
    $("#g-strsel")?.addEventListener("change", (e) => { store.set("g-str", e.target.value); drawStr(e.target.value); });

    const openExEditor = (ctx, draft, after) => { UI.ed = { type: "ex", ctx, draft: { kind: "kg", cat: "Other", uni: false, pair: false, mus: {}, ...draft }, after }; rerenderEditors(); $(".g-editor input[name=name]")?.focus(); };
    const openWoEditor = (ctx, w) => {
      UI.ed = { type: "wo", ctx, draft: w ? JSON.parse(JSON.stringify(w)) : { name: "", color: PALETTE[(G.workouts || []).length % PALETTE.length], note: "", items: [{ ex: "crunch", sets: 3, reps: "12–15", rest: "", note: "" }] } };
      rerenderEditors();
      $(".g-editor")?.scrollIntoView({ block: "center" });
    };
    const syncWoDraft = (form) => {
      const x = UI.ed.draft;
      x.name = form.elements.name.value; x.note = form.elements.note.value;
      form.querySelectorAll(".g-item").forEach((row) => { const it = x.items[+row.dataset.i]; row.querySelectorAll("[data-f]").forEach((el) => { it[el.dataset.f] = el.value; }); });
    };
    const syncExDraft = (form) => { const x = UI.ed.draft; x.name = form.elements.name.value; x.kind = form.elements.kind.value; x.cat = form.elements.cat.value; x.uni = form.elements.uni.checked; x.pair = form.elements.pair.checked; x.note = form.elements.note.value; };

    root.addEventListener("click", async (e) => {
      const b = e.target.closest("[data-act]");
      if (!b) {
        const rg = e.target.closest("#g-map [data-r]");
        if (rg) { pickRegion(rg); return; }
        const go = e.target.closest("[data-go]"); if (go && !e.target.closest("a")) location.hash = "#/progress/strength/" + go.dataset.go; return;
      }
      const act = b.dataset.act;
      try {
        if (act === "side") { b.parentNode.querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b)); return; }
        if (act === "del") {
          if (!b.classList.contains("confirm")) { b.classList.add("confirm"); b.textContent = "delete?"; setTimeout(() => { if (b.isConnected) { b.classList.remove("confirm"); b.textContent = "×"; } }, 3000); return; }
          await post("/api/gym/set/" + b.dataset.id, null, "DELETE");
          G.sets = G.sets.filter((s) => s.id !== +b.dataset.id); rs(); rr(); side(); return;
        }
        if (act === "eset") { UI.editSet = +b.dataset.id; rs(); return; }
        if (act === "ai-open") { UI.ai = sel; rs(); $("#g-jobs textarea")?.focus(); aiStatus(); return; }
        if (act === "ai-close") { UI.ai = null; rs(); return; }
        if (act === "ai-edit") { const j = (G.ai.jobs || []).find((x) => x.id === +b.dataset.id); UI.ai = sel; UI.aiDraft = j ? j.text : ""; rs(); $("#g-jobs textarea")?.focus(); aiStatus(); return; }
        if (act === "ai-undo" || act === "ai-confirm") { if (!b.classList.contains("confirm")) { b.classList.add("confirm"); b.textContent = act === "ai-undo" ? "Undo – sure?" : "Log them?"; return; } await aiAct(b, act.slice(3)); return; }
        if (act === "ai-retry" || act === "ai-discard") { await aiAct(b, act.slice(3)); return; }
        if (act === "eset-cancel") { UI.editSet = null; rs(); return; }
        if (act === "swap-open") { UI.swap = UI.swap === b.dataset.slot ? null : b.dataset.slot; rs(); return; }
        if (act === "swap-cancel") { UI.swap = null; rs(); return; }
        if (act === "swap-back") {
          const sl = blocksFor(sel).find((x) => x.slot === b.dataset.slot);
          await doSwap(sl, sl.base, true); return;
        }
        if (act === "rm-extra") { await saveDay({ extras: (G.days[sel]?.extras || []).filter((x) => x !== b.dataset.slot) }); rs(); return; }
        if (act === "tool") { UI.tool = UI.tool === b.dataset.tool ? null : b.dataset.tool; rs(); return; }
        if (act === "tool-cancel") { UI.tool = null; rs(); return; }
        if (act === "ed-ex-new") { openExEditor(b.dataset.ctx || "mgmt", {}); return; }
        if (act === "ed-ex-edit") { const c = CUS[b.dataset.id]; openExEditor(b.dataset.ctx || "mgmt", { id: c.id, name: c.name, kind: c.kind, cat: c.cat || "Other", uni: !!c.uni, pair: !!c.pair, mus: { ...(c.mus || {}) }, note: c.note || "" }); return; }
        if (act === "ed-ex-define") { const dfn = def(b.dataset.id, b.dataset.name); openExEditor("sess", { id: dfn.id, name: dfn.n, kind: dfn.kind, uni: dfn.uni, pair: !!dfn.pair, mus: {} }); return; }
        if (act === "ed-wo-new") { openWoEditor(b.dataset.ctx || "mgmt", null); return; }
        if (act === "ed-wo-edit") { openWoEditor(b.dataset.ctx || "mgmt", wById(b.dataset.id)); return; }
        if (act === "ed-cancel") { const ctx = UI.ed?.ctx; UI.ed = null; if (ctx === "mgmt") rm(); else rs(); return; }
        if (act === "mcycle") {
          syncExDraft(b.closest("form"));
          const m = b.dataset.m, mus = UI.ed.draft.mus, w = mus[m];
          if (!w) mus[m] = 1; else if (w >= 1) mus[m] = 0.5; else delete mus[m];
          rerenderEditors(); return;
        }
        if (act === "col") { syncWoDraft(b.closest("form")); UI.ed.draft.color = b.dataset.c; rerenderEditors(); return; }
        if (act.startsWith("it-")) {
          const form = b.closest("form"); syncWoDraft(form);
          const items = UI.ed.draft.items, i = +(b.closest(".g-item")?.dataset.i ?? -1);
          if (act === "it-add") items.push({ ex: items[items.length - 1]?.ex || "crunch", sets: 3, reps: "", rest: "", note: "" });
          if (act === "it-rm") items.splice(i, 1);
          if (act === "it-up" && i > 0) [items[i - 1], items[i]] = [items[i], items[i - 1]];
          if (act === "it-down" && i < items.length - 1) [items[i + 1], items[i]] = [items[i], items[i + 1]];
          rerenderEditors(); return;
        }
        if (act === "ed-ex-del" || act === "ed-wo-del") {
          if (!b.classList.contains("confirm")) { b.classList.add("confirm"); b.textContent = "Tap again to delete"; return; }
          if (act === "ed-ex-del") { await post("/api/gym/exercise/" + b.dataset.id, null, "DELETE"); CUS[b.dataset.id].archived = true; }
          else { await post("/api/gym/workout/" + b.dataset.id, null, "DELETE"); G.workouts = G.workouts.filter((w) => w.id !== +b.dataset.id); }
          const ctx = UI.ed?.ctx; UI.ed = null; rm(); if (ctx === "sess") rs(); rr(); return;
        }
      } catch (err) { flash(b.closest("form, .g-ex, .card") || root, err.message); }
    });

    async function doSwap(sl, ex, clear, persist) {
      const dfn = def(ex);
      const body = { date: sel, slot: sl.slot, ex, name: dfn.n, session: sessOf(sel), clear: !!clear };
      if (persist !== undefined) body.persist = persist;
      else if (clear && sl.plan && G.swaps?.[sl.slot]) body.persist = false;
      const res = await post("/api/gym/swap", body);
      G.days[sel] = res.day; G.swaps = res.swaps;
      G.sets.forEach((s) => { if (s.date === sel && slotOf(s) === sl.slot) { s.ex = ex; s.name = dfn.n; s.slot = sl.slot; } });
      UI.swap = null; rs(); side();
    }

    root.addEventListener("submit", async (e) => {
      e.preventDefault();
      const f = e.target, kind = f.dataset.form, btn = f.querySelector("[type=submit]");
      if (btn) btn.disabled = true;
      try {
        if (kind === "add") {
          const row = await post("/api/gym/set", { date: sel, session: sessOf(sel), ex: f.dataset.ex, slot: f.dataset.slot, name: f.dataset.name, ...setBody(f) });
          G.sets.push(row);
          if (!G.days[sel]) G.days[sel] = { date: sel, session: sessOf(sel), swaps: {}, extras: [] };
          const slot = f.dataset.slot; rs(); rr(); side();
          $(`.g-ex[data-slot="${CSS.escape(slot)}"] .g-add input`)?.focus({ preventScroll: true });
        } else if (kind === "eset") {
          const row = await post("/api/gym/set/" + f.dataset.id, setBody(f), "PUT");
          const s = G.sets.find((x) => x.id === +f.dataset.id); Object.assign(s, row);
          UI.editSet = null; rs(); side();
        } else if (kind === "ai") {
          const text = f.elements.text.value.trim();
          if (!text) return;
          const j = await post("/api/gym/ai/jobs", { date: sel, text, ctx: aiCtx(sel) });
          G.ai.jobs = [j, ...(G.ai.jobs || [])];
          UI.ai = null; UI.aiDraft = ""; rs(); pollJobs(sel);
        } else if (kind === "swap") {
          const sl = blocksFor(sel).find((x) => x.slot === f.dataset.slot);
          const ex = f.elements.ex.value;
          if (ex === "__new") { openExEditor("sess", {}, async (newId) => { await doSwap(sl, newId, false); }); return; }
          await doSwap(sl, ex, false, f.elements.persist ? f.elements.persist.checked : undefined);
        } else if (kind === "addex") {
          const ex = f.elements.ex.value;
          if (!ex) return;
          if (ex === "__new") { openExEditor("sess", {}, async (newId) => { await saveDay({ extras: [...(G.days[sel]?.extras || []), newId] }); }); return; }
          const known = blocksFor(sel).some((b) => b.slot === ex);
          if (!known) await saveDay({ extras: [...(G.days[sel]?.extras || []), ex] });
          rs();
          $(`.g-ex[data-slot="${CSS.escape(ex)}"]`)?.scrollIntoView({ block: "center" });
        } else if (kind === "move") {
          const to = f.elements.to.value;
          await post("/api/gym/move", { from: sel, to });
          UI.tool = null; location.hash = "#/progress/strength/" + to;
        } else if (kind === "savewo") {
          const items = [];
          for (const b of blocksFor(sel)) {
            const logged = setsOn(sel).filter((s) => slotOf(s) === b.slot);
            if (!logged.length) continue;
            const dfn = def(logged[0].ex, logged[0].name);
            const per = dfn.uni ? Math.max(logged.filter((s) => s.side !== "L").length, logged.filter((s) => s.side !== "R").length) : logged.length;
            const vals = logged.map((s) => s.reps ?? s.secs ?? s.mins).filter((v) => v != null);
            const unit = logged[0].reps != null ? "" : logged[0].secs != null ? " s" : " min";
            const lo = Math.min(...vals), hi = Math.max(...vals);
            items.push({ ex: dfn.id, sets: per, reps: vals.length ? (lo === hi ? `${g1(lo)}${unit}` : `${g1(lo)}–${g1(hi)}${unit}`) : "", rest: b.rest || "", note: "" });
          }
          const w = await post("/api/gym/workout", { name: f.elements.name.value, color: PALETTE[(G.workouts || []).length % PALETTE.length], items });
          G.workouts = [...(G.workouts || []), w];
          UI.tool = null; rs(); rm(); rr();
        } else if (kind === "exed") {
          syncExDraft(f);
          const x = UI.ed.draft;
          const saved = await post("/api/gym/exercise", { id: x.id && (CUS[x.id] || x.id.startsWith("x-")) ? x.id : undefined, name: x.name, kind: x.kind, cat: x.cat, uni: x.uni, pair: !!x.pair, mus: x.mus, note: x.note, rename_sets: true });
          CUS[saved.id] = saved;
          G.sets.forEach((s) => { if (s.ex === saved.id) s.name = saved.name; });
          const after = UI.ed.after, ctx = UI.ed.ctx;
          UI.ed = null;
          if (after) await after(saved.id);
          rm(); rs(); if (ctx === "mgmt") $("#g-mgmtcard")?.scrollIntoView({ block: "nearest" });
        } else if (kind === "woed") {
          syncWoDraft(f);
          const x = UI.ed.draft;
          const saved = await post("/api/gym/workout", { id: x.id, name: x.name, color: x.color, note: x.note, items: x.items });
          G.workouts = [...(G.workouts || []).filter((w) => w.id !== saved.id), saved];
          UI.ed = null; rm(); rs(); rr();
        }
      } catch (err) { flash(f, err.message); }
      finally { if (btn && btn.isConnected) btn.disabled = false; }
    });

    root.addEventListener("input", (e) => { if (e.target.closest("[data-form=ai]") && e.target.name === "text") UI.aiDraft = e.target.value; });

    root.addEventListener("change", async (e) => {
      const t = e.target;
      try {
        if (t.id === "g-wsel" && t.value) { await changeSess(t.value); return; }
        if (t.id === "g-done") await saveDay({ session: sessOf(sel), done: t.checked });
        if (t.id === "g-pain") { await saveDay({ session: sessOf(sel), pain: t.value }); side(); }
        if (t.id === "g-rpe") { await saveDay({ session: sessOf(sel), rpe: t.value }); drawEffort(sel); }
        if (t.id === "g-note") await saveDay({ session: sessOf(sel), note: t.value });
        if (t.id === "g-done" || t.id === "g-pain") rr();
        if (t.dataset.t) { G.tests = { ...(G.tests || {}), [t.dataset.t]: t.value }; G.tests = (await post("/api/gym/settings", { tests: G.tests })).tests; }
      } catch (err) { flash(t.closest("form, .card") || root, err.message); }
    });
  }

  // ------------------------------------------------------------ overview card
  function gymToday(g) {
    if (!g) return "";
    G = g; CUS = Object.fromEntries((G.exercises || []).map((e) => [e.id, e]));
    const t = todayIso(), i = idxOf(t);
    if ((i < -7 || i > 27) && !G.days[t]) return "";
    const s = sessOf(t), n = setsOn(t).length;
    const label = i < 0 && !G.days[t] ? `Gym block starts ${fd(start(), { weekday: "long", day: "numeric", month: "short" })}` : s === "R" ? "Gym: rest day" : `Gym · ${PLAN[s] ? s : esc(sessName(s))}`;
    const sub = i < 0 && !G.days[t] ? "Day 1: A · Quads & chest" : s === "R" ? "Easy bike or walk; rate your knee" : sessName(s);
    const hint = s === "A" || s === "C" ? "Leg day – keep any ride or run easy today." : s === "B" ? "No knee load in the gym today." : "";
    const col = i < 0 && !G.days[t] ? COLV.A : sessColor(s);
    return `<a class="wo-mini" href="#/gym">
      <div class="wo-top"><span class="ic" style="background:${col};${s === "C" ? "color:#141414" : ""}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 7v10M18 7v10M3 10v4M21 10v4M6 12h12"/></svg></span>
        <div style="min-width:0"><div class="wo-sport">${i >= 0 && i < 28 ? `Day ${i + 1} of 28 · week ${weekOf(t)}` : "Gym"}</div><div class="wo-title">${label}</div></div></div>
      <div class="wo-meta">${esc(sub)}${n ? ` · ${plural(n, "set")} logged` : ""}</div>
      ${hint ? `<div class="wo-target">${hint}</div>` : ""}</a>`;
  }

  // ------------------------------------------------------------ model for Today and Workout mode
  window.GYM = {
    use(state) {
      G = state;
      if (!G.ai) G.ai = { jobs: [] };
      CUS = Object.fromEntries((G.exercises || []).map((e) => [e.id, e]));
      return G;
    },
    get: () => G,
    todayIso, start, idxOf, weekOf, chosen, sessOf, sessName, isW, blocksFor, effEx, setsOn, slotOf, def, prevSets,
    slotProgress, parseSets, setTxt, sessionStats, rirCheck, rpeCheck, kneeCheck, verdict, aiCtx, jobHTML, exOptions, post, notesFor,
    testsHTML, rulesHTML, setsTxt,
    CR10, PH, PHN, PLAN, REST, SNAME,
  };

  window.renderGym = renderGym;
  window.gymToday = gymToday;
})();
