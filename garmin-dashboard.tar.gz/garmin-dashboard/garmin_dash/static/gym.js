/* Gym tab: 4-week knee-smart block, your own workouts and exercises, a set-by-set logger and stats.
   Loaded after gym-lib.js and before app.js; uses app.js helpers ($, card, tile, mkChart, css …) only inside functions. */
(function () {
  "use strict";
  const { MUSCLES, LEGS, CATS, KINDS, MIN_PER_SET, LIB, RIRT, WARM, REST, PH, PHN, PLAN, PALETTE } = window.GYMDATA;
  const DEFAULT_START = "2026-11-19";
  const LEGSET = new Set(LEGS);
  const LIBBY = Object.fromEntries(LIB.map((e) => [e.id, e]));
  const KNAME = Object.fromEntries(KINDS);
  const COLV = { A: "var(--gA)", B: "var(--gB)", C: "var(--gC)", R: "var(--gR)", F: "var(--series-7)" };
  const SNAME = { A: PLAN.A.name, B: PLAN.B.name, C: PLAN.C.name, R: "Rest day", F: "Free workout" };

  // ------------------------------------------------------------ small helpers
  const at = (v, i) => (Array.isArray(v) ? v[i] : v);
  const pad = (x) => String(x).padStart(2, "0");
  const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const pd = (s) => { const [y, m, d] = s.split("-").map(Number); return new Date(y, m - 1, d); };
  const addD = (s, n) => { const d = pd(s); d.setDate(d.getDate() + n); return iso(d); };
  const diffD = (a, b) => Math.round((pd(b) - pd(a)) / 864e5);
  const todayIso = () => iso(new Date());
  const fd = (s, o = { weekday: "short", day: "numeric", month: "short" }) => pd(s).toLocaleDateString("en-GB", o);
  const parseSets = (s) => { const t = String(s ?? "").match(/[RL]\s*\d+/g); if (t) { const r = {}; t.forEach((x) => { r[x[0]] = +x.match(/\d+/)[0]; }); return r; } const n = parseInt(s, 10); return Number.isFinite(n) && n > 0 ? { all: n } : null; };
  const e1rm = (s) => (s.kg > 0 && s.reps >= 1 && s.reps <= 30 ? s.kg * (1 + s.reps / 30) : null);
  const g1 = (v) => (Math.round(v * 10) / 10).toLocaleString("de-CH");
  const plural = (n, w) => `${n} ${w}${n === 1 ? "" : "s"}`;
  const colorOf = (c) => { let v = c; for (let i = 0; i < 4 && v && v.startsWith("var("); i++) v = css(v.slice(4, -1).trim()); return v || "#8a8f98"; };
  const sum = (a) => a.reduce((x, y) => x + y, 0);

  let G = null;      // server state
  let CUS = {};      // your exercises by id
  const UI = { swap: null, editSet: null, ed: null, tool: null, msg: null };

  // ------------------------------------------------------------ exercises
  function def(id, fallbackName) {
    if (LIBBY[id]) return LIBBY[id];
    const c = CUS[id];
    if (c) return { id, n: c.name, cat: c.cat || "Other", kind: c.kind, uni: !!c.uni, mus: c.mus || {}, note: c.note || "", custom: true, archived: c.archived };
    // logged before it had a definition: infer what we can from its sets
    const ss = G.sets.filter((s) => s.ex === id);
    const kind = ss.some((s) => s.mins != null) ? "min" : ss.some((s) => s.secs != null && s.reps == null) ? (ss.some((s) => s.kg > 0) ? "hold" : "secs") : ss.length && ss.every((s) => !s.kg) ? "reps" : "kg";
    return { id, n: fallbackName || ss[0]?.name || id.replace(/^x-/, "").replace(/-/g, " "), cat: "Other", kind, uni: ss.some((s) => s.side), mus: {}, custom: true, unknown: true };
  }
  const allDefs = () => [...LIB.filter((e) => e.kind !== "info"), ...Object.values(CUS).filter((c) => !c.archived).map((c) => def(c.id))];
  function exOptions(selected, alts = [], withNew = true) {
    const defs = allDefs();
    const opt = (e) => `<option value="${e.id}" ${e.id === selected ? "selected" : ""}>${esc(e.n)}</option>`;
    let h = alts.length ? `<optgroup label="Suggested swaps">${alts.map((a) => def(a)).map(opt).join("")}</optgroup>` : "";
    const mine = defs.filter((e) => e.custom);
    if (mine.length) h += `<optgroup label="Your exercises">${mine.map(opt).join("")}</optgroup>`;
    for (const c of CATS) { const l = defs.filter((e) => !e.custom && e.cat === c); if (l.length) h += `<optgroup label="${c}">${l.map(opt).join("")}</optgroup>`; }
    return h + (withNew ? '<option value="__new">+ New exercise…</option>' : "");
  }
  function metric(dfn) {
    if (dfn.kind === "kg") return { v: (s) => e1rm(s), label: "est. 1RM", unit: "kg", agg: "max" };
    if (dfn.kind === "reps") return { v: (s) => s.reps ?? null, label: "reps", unit: "reps", agg: "max" };
    if (dfn.kind === "hold") return { v: (s) => (s.kg > 0 ? s.kg : null), label: "load", unit: "kg", agg: "max" };
    if (dfn.kind === "secs") return { v: (s) => s.secs ?? null, label: "longest hold", unit: "s", agg: "max" };
    if (dfn.kind === "min") return { v: (s) => s.mins ?? null, label: "minutes", unit: "min", agg: "sum" };
    return { v: () => null, label: "", unit: "", agg: "max" };
  }

  // ------------------------------------------------------------ plan & sessions
  const start = () => G.start || DEFAULT_START;
  const idxOf = (d) => diffD(start(), d);
  const planType = (d) => { const i = idxOf(d); return i >= 0 && i < 28 ? "ABCR"[i % 4] : null; };
  const weekOf = (d) => Math.min(4, Math.max(1, Math.floor(idxOf(d) / 7) + 1));
  const isW = (s) => /^W\d+$/.test(s || "");
  const wById = (id) => (G.workouts || []).find((w) => w.id === +id);
  const sessOf = (d) => G.days[d]?.session || planType(d) || "F";
  const sessName = (s) => (isW(s) ? wById(s.slice(1))?.name || "Deleted workout" : SNAME[s] || s);
  const sessColor = (s) => (isW(s) ? wById(s.slice(1))?.color || PALETTE[0] : COLV[s] || COLV.F);
  const sessLetter = (s) => (isW(s) ? (wById(s.slice(1))?.name || "W").trim().charAt(0).toUpperCase() : s === "R" ? "rest" : s);
  const darkText = (s) => s === "C";
  const setsOn = (d) => G.sets.filter((s) => s.date === d);
  const slotOf = (s) => s.slot || s.ex;

  function slotsFor(d) {
    const s = sessOf(d), w = weekOf(d);
    if (PLAN[s]) return PLAN[s].ex.map((x) => ({
      slot: x.id, base: x.id, plan: true, n: x.n, tag: x.tag, alts: x.alts || [],
      sets: at(x.sets, w - 1), reps: at(x.reps, w - 1),
      rir: x.rir === "eff" ? ["effort", RIRT.eff[w - 1]] : RIRT[x.rir] ? ["RIR", RIRT[x.rir][w - 1]] : null,
      rest: x.rest, tempo: at(x.tempo, w - 1), note: x.note ? at(x.note, w - 1) : "", cue: x.cue, why: x.why,
    }));
    if (isW(s)) {
      const wo = wById(s.slice(1));
      return (wo?.items || []).map((it) => ({ slot: "t-" + it.k, base: it.ex, plan: false, alts: LIBBY[it.ex] ? altsFor(it.ex) : [], sets: it.sets ? String(it.sets) : "", reps: it.reps, rir: null, rest: it.rest, tempo: "", note: it.note, cue: "", why: "" }));
    }
    return [];
  }
  function altsFor(exId) {
    for (const p of Object.values(PLAN)) for (const x of p.ex) if (x.id === exId) return x.alts || [];
    return [];
  }
  const effEx = (d, sl) => G.days[d]?.swaps?.[sl.slot] || (sl.plan ? G.swaps?.[sl.slot] : null) || sl.base;
  function extraIds(d, slots) {
    const known = new Set(slots.map((x) => x.slot)), ids = [];
    for (const s of setsOn(d)) { const k = slotOf(s); if (!known.has(k) && !ids.includes(k)) ids.push(k); }
    for (const k of G.days[d]?.extras || []) if (!known.has(k) && !ids.includes(k)) ids.push(k);
    return ids;
  }
  function blocksFor(d) {
    const slots = slotsFor(d);
    return [...slots, ...extraIds(d, slots).map((k) => ({ slot: k, base: k, extra: true, alts: [], sets: "", reps: "", rir: null, rest: "", tempo: "", note: "", cue: "", why: "" }))];
  }
  function prevSets(exId, d) {
    let best = null;
    for (const s of G.sets) if (s.ex === exId && s.date < d && (!best || s.date > best)) best = s.date;
    return best ? { date: best, sets: G.sets.filter((s) => s.ex === exId && s.date === best) } : null;
  }

  // ------------------------------------------------------------ counting
  const countable = (dfn) => dfn.count !== false && dfn.kind !== "info";
  const setWeight = (s, dfn) => (!countable(dfn) ? 0 : dfn.kind === "min" ? (s.mins || 0) / MIN_PER_SET : 1);
  function addMus(acc, dfn, side, w) {
    if (!w) return;
    for (const [m, mw] of Object.entries(dfn.mus || {})) {
      if (LEGSET.has(m)) {
        if (side !== "L") acc[m + "R"] = (acc[m + "R"] || 0) + w * mw;
        if (side !== "R") acc[m + "L"] = (acc[m + "L"] || 0) + w * mw;
      } else acc[m] = (acc[m] || 0) + (side ? 0.5 : 1) * w * mw;
    }
  }
  function loggedMuscles(sets) {
    const acc = {};
    for (const s of sets) { const dfn = def(s.ex, s.name); addMus(acc, dfn, s.side || "", setWeight(s, dfn)); }
    return acc;
  }
  function plannedMuscles(d) {
    const acc = {};
    for (const sl of slotsFor(d)) {
      const dfn = def(effEx(d, sl)), p = parseSets(sl.sets);
      if (!p || !countable(dfn)) continue;
      if (p.all != null) { if (dfn.uni) { addMus(acc, dfn, "R", p.all); addMus(acc, dfn, "L", p.all); } else addMus(acc, dfn, "", p.all); }
      else { addMus(acc, dfn, "R", p.R || 0); addMus(acc, dfn, "L", p.L || 0); }
    }
    return acc;
  }
  function plannedEntries(d) {
    let n = 0;
    for (const sl of slotsFor(d)) {
      const dfn = def(effEx(d, sl)), p = parseSets(sl.sets);
      if (!p || !countable(dfn)) continue;
      n += p.all != null ? p.all * (dfn.uni ? 2 : 1) : (p.R || 0) + (p.L || 0);
    }
    return n;
  }
  function slotProgress(sl, dfn, logged) {
    const p = parseSets(sl.sets);
    const c = (sd) => logged.filter((s) => (s.side || "") === sd).length;
    const both = c(""), cR = c("R") + both, cL = c("L") + both;
    if (!p || dfn.kind === "info") return { text: logged.length ? plural(logged.length, "set") : "", done: false, next: dfn.uni ? (cR <= cL ? "R" : "L") : "" };
    if (p.all != null) {
      const n = dfn.uni ? Math.min(cR, cL) : logged.length;
      return { text: dfn.uni ? `R ${cR}/${p.all} · L ${cL}/${p.all}` : `${n}/${p.all}`, done: n >= p.all, next: dfn.uni ? (cR <= cL ? "R" : "L") : "" };
    }
    const done = ["R", "L"].every((sd) => p[sd] == null || (sd === "R" ? cR : cL) >= p[sd]);
    let next = "R";
    if (dfn.uni) next = cR <= cL && cR < (p.R || 0) ? "R" : cL < (p.L || 0) ? "L" : cR < (p.R || 0) ? "R" : "R";
    return { text: ["R", "L"].filter((sd) => p[sd] != null).map((sd) => `${sd} ${sd === "R" ? cR : cL}/${p[sd]}`).join(" · "), done, next: dfn.uni ? next : "" };
  }

  // ------------------------------------------------------------ stats for one session
  function sessionStats(d) {
    const ss = setsOn(d);
    let vol = 0, reps = 0, timed = 0, hard = 0;
    for (const s of ss) {
      const dfn = def(s.ex, s.name);
      if (s.kg > 0 && s.reps) vol += s.kg * s.reps;
      if (s.reps) reps += s.reps;
      if (s.secs) timed += s.secs / 60;
      if (s.mins) timed += s.mins;
      if (countable(dfn)) hard += 1;
    }
    const gm = G.garmin[d] || [];
    let mins = sum(gm.map((x) => x.min || 0)) || null, minsSrc = mins ? "watch" : "";
    if (!mins && ss.length >= 2) {
      const t = ss.map((s) => Date.parse(s.created_at)).filter(Number.isFinite).sort((a, b) => a - b);
      const span = t.length > 1 ? (t[t.length - 1] - t[0]) / 6e4 : 0;
      if (span >= 10 && span <= 240) { mins = Math.round(span + 3); minsSrc = "from your log"; }
    }
    const prs = [];
    const groups = {};
    for (const s of ss) (groups[s.ex + "|" + (s.side || "")] = groups[s.ex + "|" + (s.side || "")] || []).push(s);
    for (const [k, list] of Object.entries(groups)) {
      const [ex, side] = k.split("|"), dfn = def(ex, list[0].name), M = metric(dfn);
      const best = (arr) => { const v = arr.map(M.v).filter((x) => x != null); return v.length ? Math.max(...v) : null; };
      const today = best(list), prev = best(G.sets.filter((s) => s.ex === ex && (s.side || "") === side && s.date < d));
      if (today != null && prev != null && today > prev + 1e-9 && M.agg === "max") prs.push({ n: dfn.n, side, label: M.label, unit: M.unit, today, prev });
    }
    const code = sessOf(d);
    const prevDates = [...new Set(G.sets.filter((x) => x.date < d).map((x) => x.date))].filter((x) => sessOf(x) === code).sort();
    const pDate = prevDates[prevDates.length - 1] || null;
    const pVol = pDate ? sum(setsOn(pDate).map((s) => (s.kg > 0 && s.reps ? s.kg * s.reps : 0))) : null;
    return { n: ss.length, hard, vol, reps, timed, mins, minsSrc, prs, pDate, pVol, mus: loggedMuscles(ss), garmin: gm };
  }

  function statsHTML(d) {
    const st = sessionStats(d);
    if (!st.n) return "";
    const box = (v, l) => `<div><b>${v}</b><span>${l}</span></div>`;
    const top = Object.entries(st.mus).filter(([, v]) => v >= 0.5).sort((a, b) => b[1] - a[1]).slice(0, 8);
    const max = Math.max(1, ...top.map(([, v]) => v));
    const hr = st.garmin.find((g) => g.hr);
    const vs = st.pVol != null && st.pVol > 0 && st.vol > 0 ? Math.round((st.vol / st.pVol - 1) * 100) : null;
    return `<div class="g-statbox">
      <div class="g-stats">${box(st.vol ? Math.round(st.vol).toLocaleString("de-CH") : "–", "kg lifted")}${box(st.hard, plural(st.hard, "hard set").replace(/^\d+ /, ""))}${box(st.reps || "–", "reps")}${st.timed ? box(g1(st.timed), "min timed work") : ""}${st.mins ? box(st.mins, `min (${st.minsSrc})`) : ""}${hr ? box(hr.hr, "bpm avg (watch)") : ""}</div>
      ${vs != null ? `<p class="g-vs">${vs >= 0 ? "▲" : "▼"} ${Math.abs(vs)}% ${vs >= 0 ? "more" : "less"} volume than your last ${esc(sessName(sessOf(d)))} (${fd(st.pDate)})</p>` : ""}
      ${st.prs.length ? `<ul class="g-prs">${st.prs.slice(0, 5).map((p) => `<li><span class="g-pr">PR</span> ${esc(p.n)}${p.side ? ` (${p.side})` : ""}: ${p.label} <b>${g1(p.today)} ${p.unit}</b> <span class="muted">was ${g1(p.prev)}</span></li>`).join("")}</ul>` : ""}
      ${top.length ? `<div class="g-mus"><span class="muted">Muscles worked (hard sets):</span>${top.map(([m, v]) => `<span class="g-mchip" style="--a:${0.18 + 0.62 * (v / max)}">${musLabel(m)} <b>${g1(v)}</b></span>`).join("")}</div>` : ""}
    </div>`;
  }
  const musLabel = (k) => { const leg = /[RL]$/.test(k) && LEGSET.has(k.slice(0, -1)); const base = leg ? k.slice(0, -1) : k; return esc((MUSCLES.find((m) => m[0] === base) || [0, base])[1]) + (leg ? ` ${k.slice(-1)}` : ""); };

  // ------------------------------------------------------------ rack
  function rackHTML(sel) {
    const t = todayIso();
    let h = "";
    for (let w = 0; w < 4; w++) {
      h += `<div class="g-wk"><b>W${w + 1}</b><span>${PH[w]}</span></div>`;
      for (let k = 0; k < 7; k++) {
        const i = w * 7 + k, d = addD(start(), i), s = sessOf(d), done = G.days[d]?.done || setsOn(d).length;
        h += `<a class="g-day${d === sel ? " sel" : ""}${d === t ? " today" : ""}" href="#/gym/${d}" aria-label="Day ${i + 1}, ${fd(d, { weekday: "long", day: "numeric", month: "long" })}, ${esc(sessName(s))}">
          <span class="g-disc${s === "R" ? " rest" : ""}" style="background:${sessColor(s)}${darkText(s) ? ";color:#141414" : ""}">${esc(sessLetter(s))}${done ? '<i class="g-tick">✓</i>' : ""}${i === 4 || i === 24 ? '<i class="g-test">test</i>' : ""}</span>
          <span class="g-dt">${d === t ? "Today" : `<span class="g-wd">${fd(d, { weekday: "short" })} </span>${pd(d).getDate()}`}</span></a>`;
      }
    }
    return `<div class="g-rack">${h}</div>`;
  }

  // ------------------------------------------------------------ one exercise block
  function fieldsHTML(dfn, ref, prefix = "") {
    const v = (k) => (ref && ref[k] != null ? ref[k] : "");
    const inp = (name, label, mode) => `<label>${label}<input name="${prefix}${name}" inputmode="${mode}" autocomplete="off" value="${v(name)}"></label>`;
    const rir = `<label>RIR<select name="${prefix}rir"><option value=""></option>${[0, 1, 2, 3, 4, 5].map((x) => `<option ${String(v("rir")) === String(x) ? "selected" : ""}>${x}</option>`).join("")}</select></label>`;
    switch (dfn.kind) {
      case "reps": return inp("reps", "reps", "numeric") + inp("kg", "+kg", "decimal") + rir;
      case "secs": return inp("secs", "sec", "numeric");
      case "hold": return inp("kg", "kg", "decimal") + inp("secs", "sec", "numeric");
      case "min": return inp("mins", "min", "decimal");
      default: return inp("kg", "kg", "decimal") + inp("reps", "reps", "numeric") + rir;
    }
  }
  const sideSeg = (dfn, cur) => (dfn.uni ? `<div class="seg g-side">${[["R", "R"], ["L", "L"], ["", "Both"]].map(([v, l]) => `<button type="button" data-act="side" data-side="${v}" class="${v === cur ? "on" : ""}">${l}</button>`).join("")}</div>` : "");

  function setTxt(s) {
    const p = [];
    if (s.kg > 0) p.push(`${g1(s.kg)} kg`);
    if (s.reps != null) p.push(s.kg > 0 ? `× ${s.reps}` : `${s.reps} reps`);
    if (s.secs != null) p.push(`${s.kg > 0 ? "· " : ""}${s.secs} s`);
    if (s.mins != null) p.push(`${g1(s.mins)} min`);
    return p.join(" ");
  }

  function blockHTML(d, sl, num) {
    const exId = sl.extra ? (G.days[d]?.swaps?.[sl.slot] || setsOn(d).find((s) => slotOf(s) === sl.slot)?.ex || sl.slot) : effEx(d, sl);
    const logged = setsOn(d).filter((s) => slotOf(s) === sl.slot);
    const dfn = def(exId, logged[0]?.name);
    const swapped = !sl.extra && exId !== sl.base;
    const name = !swapped && sl.n ? sl.n : dfn.n;
    const prog = slotProgress(sl, dfn, logged);
    const prev = prevSets(exId, d);
    const ref = [...logged].reverse().find((s) => (s.side || "") === prog.next) || prev?.sets.find((s) => (s.side || "") === prog.next) || logged[logged.length - 1] || prev?.sets[0];
    const col = sl.extra ? "var(--text-muted)" : sessColor(sessOf(d));
    const p = parseSets(sl.sets);
    const presc = sl.extra ? `<span class="muted">Extra · ${esc(KNAME[dfn.kind] || "")}</span>`
      : [p ? `<b>${esc(sl.sets)}</b> ${p.all === 1 ? "set" : "sets"}${sl.reps ? ` × <b>${esc(sl.reps)}</b>` : ""}` : sl.reps ? `<b>${esc(sl.reps)}</b>` : "",
        sl.rir ? `${sl.rir[0]} <b>${esc(sl.rir[1])}</b>` : "", sl.rest ? `rest ${esc(sl.rest)}` : "", sl.tempo ? esc(sl.tempo) : ""].filter(Boolean).join(" · ");
    const prevTxt = prev ? `Last time (${fd(prev.date)}): ${["R", "L", ""].map((sd) => { const l = prev.sets.filter((s) => (s.side || "") === sd); return l.length ? `${sd ? sd + " " : l.length && prev.sets.some((s) => s.side) ? "Both " : ""}${l.map(setTxt).join(", ")}` : ""; }).filter(Boolean).join(" · ")}` : dfn.kind === "info" ? "" : dfn.kind === "kg" || dfn.kind === "hold" ? "First time – start light and find the weight that matches the target." : "First time – nothing earlier to compare with yet.";
    const chips = logged.map((s, k) => UI.editSet === s.id ? setEditHTML(s, dfn) :
      `<span class="g-set"><button type="button" class="g-setbtn" data-act="eset" data-id="${s.id}" title="Edit"><b>${k + 1}</b>${s.side ? `<i class="g-sd ${s.side}">${s.side}</i>` : dfn.uni ? '<i class="g-sd">Both</i>' : ""}${setTxt(s)}${s.rir != null ? ` <span class="muted">RIR ${g1(s.rir)}</span>` : ""}</button><button type="button" data-act="del" data-id="${s.id}" aria-label="Delete set">×</button></span>`).join("");
    const form = dfn.kind === "info" ? "" : `<form class="g-add" data-form="add" data-slot="${esc(sl.slot)}" data-ex="${esc(exId)}" data-name="${esc(dfn.n)}">${sideSeg(dfn, prog.next)}${fieldsHTML(dfn, ref)}<button class="btn primary" type="submit">Add set</button></form>`;
    const tools = `<div class="g-btools">${dfn.kind === "info" ? "" : `<button type="button" class="g-link" data-act="swap-open" data-slot="${esc(sl.slot)}">${swapped ? "Change" : "Swap"}</button>`}${dfn.custom && !dfn.unknown ? `<button type="button" class="g-link" data-act="ed-ex-edit" data-id="${esc(dfn.id)}" data-ctx="sess">Edit exercise</button>` : dfn.unknown ? `<button type="button" class="g-link" data-act="ed-ex-define" data-id="${esc(dfn.id)}" data-name="${esc(dfn.n)}">Set type &amp; muscles</button>` : ""}${sl.extra && !logged.length ? `<button type="button" class="g-link" data-act="rm-extra" data-slot="${esc(sl.slot)}">Remove</button>` : ""}</div>`;
    return `<div class="g-ex${prog.done ? " complete" : ""}" data-slot="${esc(sl.slot)}">
      <div class="g-ex-head"><span class="g-num" style="background:${col}${col === COLV.C ? ";color:#141414" : ""}">${num}</span>
        <div class="g-ex-main"><div class="g-ex-name">${esc(name)} ${sl.tag === "knee" && !swapped ? '<span class="g-tag knee">knee</span>' : `<span class="g-tag">${esc(dfn.cat || "")}</span>`}</div>
        ${swapped ? `<div class="g-swapnote">Swapped from ${esc(sl.n || def(sl.base).n)}</div>` : ""}
        ${presc ? `<div class="g-presc">${presc}</div>` : ""}${sl.note ? `<div class="g-note">${esc(sl.note)}</div>` : ""}</div>
        ${prog.text ? `<span class="g-count">${prog.done ? "✓ " : ""}${prog.text}</span>` : ""}</div>
      ${tools}
      ${UI.swap === sl.slot ? swapPanelHTML(d, sl, exId) : ""}
      ${prevTxt ? `<div class="g-last">${esc(prevTxt)}</div>` : ""}
      ${chips ? `<div class="g-sets">${chips}</div>` : ""}
      ${form}
      ${sl.cue ? `<details><summary>How &amp; why</summary><p>${esc(sl.cue)}</p><p class="muted">${esc(sl.why)}</p></details>` : dfn.note ? `<p class="g-last">${esc(dfn.note)}</p>` : ""}
    </div>`;
  }

  function setEditHTML(s, dfn) {
    return `<form class="g-add g-seted" data-form="eset" data-id="${s.id}">${dfn.uni ? `<div class="seg g-side">${[["R", "R"], ["L", "L"], ["", "Both"]].map(([v, l]) => `<button type="button" data-act="side" data-side="${v}" class="${(s.side || "") === v ? "on" : ""}">${l}</button>`).join("")}</div>` : ""}${fieldsHTML(dfn, s)}
      <button class="btn primary" type="submit">Save</button><button class="btn" type="button" data-act="eset-cancel">Cancel</button></form>`;
  }

  function swapPanelHTML(d, sl, cur) {
    const canBack = !sl.extra && cur !== sl.base;
    return `<form class="g-panel" data-form="swap" data-slot="${esc(sl.slot)}">
      <label class="g-wide">Do this instead<select name="ex">${exOptions(cur, sl.alts)}</select></label>
      ${sl.plan ? `<label class="g-chk"><input type="checkbox" name="persist" ${G.swaps?.[sl.slot] ? "checked" : ""}> Every time this exercise comes up</label>` : ""}
      <p class="small muted">Sets you already logged here move to the new exercise.</p>
      <div class="g-edbtns"><button class="btn primary" type="submit">Swap</button>${canBack ? `<button class="btn" type="button" data-act="swap-back" data-slot="${esc(sl.slot)}">Back to ${esc(sl.n || def(sl.base).n)}</button>` : ""}<button class="btn" type="button" data-act="swap-cancel">Cancel</button></div></form>`;
  }

  // ------------------------------------------------------------ session card
  function sessHTML(d) {
    const s = sessOf(d), w = weekOf(d), i = idxOf(d), day = G.days[d] || {};
    const inPlan = i >= 0 && i < 28;
    const blocks = blocksFor(d);
    const notes = [];
    if (s === "A" && (i === 4 || i === 24)) notes.push("<b>Test day.</b> After the warm-up and the isometric primer, test the single-leg extension (10-rep max each leg, 90° → 45°) and enter it under Tests below.");
    if (inPlan && i >= 24 && PLAN[s]) notes.push("<b>Taper:</b> drop one set from every exercise and keep legs at RIR 3.");
    if (inPlan && w === 2 && (s === "A" || s === "C")) notes.push("New this week: 2-up/1-down eccentrics. Lift with both legs, lower with one, slowly. Start lighter than you think.");
    const ws = G.workouts || [];
    const head = `<div class="card-head"><div><h2>${inPlan ? `Day ${i + 1} · ` : ""}${fd(d, { weekday: "long", day: "numeric", month: "long" })}</h2>
        <p class="sub">${inPlan ? `Week ${w}, ${PH[w - 1]}: ${PHN[w - 1]}` : "Outside the 4-week block – log anything you like."}</p></div>
        <div class="g-pick">${seg("g-stype", [["A", "A"], ["B", "B"], ["C", "C"], ["R", "Rest"], ["F", "Free"]], s)}
        ${ws.length ? `<select id="g-wsel" aria-label="Use one of your workouts"><option value="">My workouts…</option>${ws.map((x) => `<option value="W${x.id}" ${s === "W" + x.id ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select>` : ""}</div></div>`;
    const tools = `<div class="g-tools"><button type="button" class="g-link" data-act="tool" data-tool="move">Move to another day</button>${setsOn(d).length ? `<button type="button" class="g-link" data-act="tool" data-tool="savewo">Save as one of my workouts</button>` : ""}<button type="button" class="g-link" data-act="ed-wo-new" data-ctx="sess">New workout</button></div>
      ${UI.tool === "move" ? `<form class="g-panel" data-form="move"><label>Move everything logged on this day to <input type="date" name="to" value="${d}"></label><div class="g-edbtns"><button class="btn primary" type="submit">Move</button><button class="btn" type="button" data-act="tool-cancel">Cancel</button></div></form>` : ""}
      ${UI.tool === "savewo" ? `<form class="g-panel" data-form="savewo"><label class="g-wide">Name<input name="name" maxlength="60" placeholder="e.g. Upper body, my way" required></label><p class="small muted">Saves the exercises you logged today, with today's set counts and rep ranges as targets. You can edit it afterwards.</p><div class="g-edbtns"><button class="btn primary" type="submit">Save workout</button><button class="btn" type="button" data-act="tool-cancel">Cancel</button></div></form>` : ""}
      ${UI.ed && UI.ed.ctx === "sess" ? editorHTML() : ""}`;
    const meta = `<div class="g-meta">
        <label class="g-chk"><input type="checkbox" id="g-done" ${day.done ? "checked" : ""}> Session done</label>
        <label>Knee pain <select id="g-pain"><option value=""></option>${[...Array(11).keys()].map((v) => `<option ${day.pain === v ? "selected" : ""}>${v}</option>`).join("")}</select></label>
        <input id="g-note" placeholder="Note (how it felt, machine settings…)" value="${esc(day.note || "")}" maxlength="1000">
      </div>
      ${(G.garmin[d] || []).length ? `<p class="small muted" style="margin:6px 0 0">On your watch: ${G.garmin[d].map((a) => `<a href="#/activity/${a.id}">${esc(a.name)}</a> · ${a.min} min${a.hr ? ` · ${a.hr} bpm` : ""}${a.kcal ? ` · ${a.kcal} kcal` : ""}`).join(" · ")}</p>` : ""}`;
    let body;
    if (s === "R" && !blocks.length) {
      body = `<h3 class="g-h3">${SNAME.R}</h3><ul class="why">${REST.map((x) => `<li>${esc(x)}</li>`).join("")}</ul><p class="small muted">Trained anyway? Add an exercise below or switch to <b>Free</b>.</p>`;
    } else {
      const intro = PLAN[s] ? `<p class="g-focus"><i class="key" style="background:${sessColor(s)}"></i><b>${s} · ${esc(SNAME[s])}</b> – ${esc(PLAN[s].f)}</p><details class="g-warm"><summary>Warm-up</summary><ul class="why">${WARM[PLAN[s].warm].map((x) => `<li>${esc(x)}</li>`).join("")}</ul></details>`
        : isW(s) ? `<p class="g-focus"><i class="key" style="background:${sessColor(s)}"></i><b>${esc(sessName(s))}</b>${wById(s.slice(1))?.note ? ` – ${esc(wById(s.slice(1)).note)}` : ""} <button type="button" class="g-link" data-act="ed-wo-edit" data-id="${s.slice(1)}" data-ctx="sess">Edit workout</button></p>`
        : s === "F" ? `<p class="g-focus"><b>Free workout</b> – log any exercise from the library or your own.</p>` : "";
      body = `${intro}${notes.map((n) => `<div class="g-banner">${n}</div>`).join("")}<div class="g-exs">${blocks.map((b, k) => blockHTML(d, b, k + 1)).join("")}</div>`;
    }
    const addBar = `<form class="g-addex" data-form="addex"><select name="ex" aria-label="Add an exercise"><option value="">Add an exercise…</option>${exOptions("", [], true)}</select><button class="btn" type="submit">Add</button></form>
      <p class="small muted" style="margin:10px 0 0">R = right, L = left, Both = both legs together. Tap a logged set to edit it. Weights pre-fill from your last set.</p>`;
    return head + tools + meta + statsHTML(d) + body + addBar;
  }

  // ------------------------------------------------------------ editors (exercise / workout)
  function editorHTML() {
    const e = UI.ed;
    if (!e) return "";
    if (e.type === "ex") {
      const x = e.draft;
      return `<form class="g-editor" data-form="exed"><h3>${x.id && CUS[x.id] ? "Edit exercise" : "New exercise"}</h3>
        <div class="g-edgrid">
          <label class="g-wide">Name<input name="name" maxlength="60" value="${esc(x.name || "")}" required placeholder="e.g. Cable crunch"></label>
          <label>How you log it<select name="kind">${KINDS.map(([k, l]) => `<option value="${k}" ${x.kind === k ? "selected" : ""}>${l}</option>`).join("")}</select></label>
          <label>Category<select name="cat">${CATS.map((c) => `<option ${x.cat === c ? "selected" : ""}>${c}</option>`).join("")}</select></label>
          <label class="g-chk g-wide"><input type="checkbox" name="uni" ${x.uni ? "checked" : ""}> One side at a time (log left and right separately)</label>
        </div>
        <fieldset class="g-musf"><legend>Muscles trained – tap once for main target, again for helper, again to clear</legend>
          <div class="g-mgrid">${MUSCLES.map(([m, l]) => { const w = x.mus?.[m]; return `<button type="button" data-act="mcycle" data-m="${m}" class="g-mbtn ${w >= 1 ? "main" : w ? "help" : ""}">${l}${w >= 1 ? " ●" : w ? " ◐" : ""}</button>`; }).join("")}</div>
          <p class="small muted">Main counts as 1 set for that muscle, helper as ½. Duration exercises count one set per ${MIN_PER_SET} minutes.</p></fieldset>
        <label class="g-wide">Notes<input name="note" maxlength="500" value="${esc(x.note || "")}" placeholder="Machine settings, cues…"></label>
        <div class="g-edbtns"><button class="btn primary" type="submit">Save</button><button class="btn" type="button" data-act="ed-cancel">Cancel</button>${x.id && CUS[x.id] ? `<button class="btn g-danger" type="button" data-act="ed-ex-del" data-id="${esc(x.id)}">Delete</button>` : ""}</div></form>`;
    }
    const x = e.draft;
    return `<form class="g-editor" data-form="woed"><h3>${x.id ? "Edit workout" : "New workout"}</h3>
      <div class="g-edgrid"><label class="g-wide">Name<input name="name" maxlength="60" value="${esc(x.name || "")}" required placeholder="e.g. Abs finisher"></label>
        <div class="g-wide"><span class="small muted">Colour</span><div class="g-cols">${PALETTE.map((c) => `<button type="button" data-act="col" data-c="${c}" class="${x.color === c ? "on" : ""}" style="background:${c}" aria-label="Colour ${c}"></button>`).join("")}</div></div>
        <label class="g-wide">Note<input name="note" maxlength="500" value="${esc(x.note || "")}" placeholder="Optional"></label></div>
      <div class="g-items">${x.items.map((it, k) => `<div class="g-item" data-i="${k}">
          <select data-f="ex" aria-label="Exercise">${exOptions(it.ex, [], false)}</select>
          <input data-f="sets" inputmode="numeric" value="${it.sets || ""}" placeholder="sets" aria-label="Sets">
          <input data-f="reps" value="${esc(it.reps || "")}" placeholder="reps / time" aria-label="Reps or time">
          <input data-f="rest" value="${esc(it.rest || "")}" placeholder="rest" aria-label="Rest">
          <input data-f="note" value="${esc(it.note || "")}" placeholder="note" aria-label="Note">
          <span class="g-itbtns"><button type="button" data-act="it-up" aria-label="Move up">↑</button><button type="button" data-act="it-down" aria-label="Move down">↓</button><button type="button" data-act="it-rm" aria-label="Remove">×</button></span></div>`).join("")}</div>
      <button type="button" class="g-link" data-act="it-add">+ Add exercise</button>
      <p class="small muted">Single-leg exercises: sets are per side. Need an exercise that isn't listed? Create it under “Your exercises” first.</p>
      <div class="g-edbtns"><button class="btn primary" type="submit">Save workout</button><button class="btn" type="button" data-act="ed-cancel">Cancel</button>${x.id ? `<button class="btn g-danger" type="button" data-act="ed-wo-del" data-id="${x.id}">Delete</button>` : ""}</div></form>`;
  }

  function mgmtHTML() {
    const ws = G.workouts || [], ex = Object.values(CUS).filter((c) => !c.archived);
    const musTxt = (m) => Object.entries(m || {}).sort((a, b) => b[1] - a[1]).map(([k, w]) => (MUSCLES.find((x) => x[0] === k) || [0, k])[1] + (w < 1 ? " (helper)" : "")).join(", ");
    return `<div class="g-mgmt">
      <div><h3 class="g-h3">Workouts</h3>${ws.length ? `<ul class="g-list">${ws.map((w) => `<li><i class="key" style="background:${w.color || PALETTE[0]}"></i><span><b>${esc(w.name)}</b><br><span class="small muted">${w.items.map((it) => esc(def(it.ex).n)).join(" · ")}</span></span><button type="button" class="g-link" data-act="ed-wo-edit" data-id="${w.id}" data-ctx="mgmt">Edit</button></li>`).join("")}</ul>` : '<p class="small muted">None yet. Make one here, or log a session and use “Save as one of my workouts”.</p>'}
        <button type="button" class="btn" data-act="ed-wo-new" data-ctx="mgmt">New workout</button></div>
      <div><h3 class="g-h3">Your exercises</h3>${ex.length ? `<ul class="g-list">${ex.map((c) => `<li><span><b>${esc(c.name)}</b><br><span class="small muted">${esc(KNAME[c.kind] || c.kind)}${c.uni ? " · one side at a time" : ""}${Object.keys(c.mus || {}).length ? " · " + esc(musTxt(c.mus)) : " · no muscles set"}</span></span><button type="button" class="g-link" data-act="ed-ex-edit" data-id="${esc(c.id)}" data-ctx="mgmt">Edit</button></li>`).join("")}</ul>` : '<p class="small muted">The library has 60+ exercises. Add your own for anything missing.</p>'}
        <button type="button" class="btn" data-act="ed-ex-new" data-ctx="mgmt">New exercise</button></div>
    </div>${UI.ed && UI.ed.ctx === "mgmt" ? editorHTML() : ""}`;
  }

  // ------------------------------------------------------------ page
  async function renderGym(arg) {
    G = await api("/api/gym", true);
    CUS = Object.fromEntries((G.exercises || []).map((e) => [e.id, e]));
    UI.swap = UI.editSet = UI.tool = null;
    if (UI.ed && UI.ed.ctx === "sess") UI.ed = null;
    const t = todayIso(), st = start(), ti = idxOf(t), end = addD(st, 27);
    const sel = arg && /^\d{4}-\d{2}-\d{2}$/.test(arg) ? arg : ti < 0 ? st : ti > 27 ? end : t;
    const anchor = t < st ? st : t > end ? end : t;
    const wNow = weekOf(anchor), wkStart = addD(st, (wNow - 1) * 7), wkEnd = addD(wkStart, 6);
    const wkDays = [...Array(7).keys()].map((k) => addD(wkStart, k));
    const wkSets = G.sets.filter((s) => s.date >= wkStart && s.date <= wkEnd);
    const plannedMus = {}; wkDays.forEach((d) => { for (const [k, v] of Object.entries(plannedMuscles(d))) plannedMus[k] = (plannedMus[k] || 0) + v; });
    const loggedMus = loggedMuscles(wkSets);
    const plannedN = sum(wkDays.map(plannedEntries)), loggedN = wkSets.filter((s) => countable(def(s.ex, s.name))).length;
    const wkVol = sum(wkSets.map((s) => (s.kg > 0 && s.reps ? s.kg * s.reps : 0)));
    const until = t < end ? t : end;
    const plannedSoFar = [...Array(28).keys()].map((k) => addD(st, k)).filter((d) => d <= until && sessOf(d) !== "R" && sessOf(d) !== "F").length;
    const doneDates = new Set([...G.sets.filter((s) => s.date >= st && s.date <= end).map((s) => s.date), ...Object.values(G.days).filter((x) => x.done && x.date >= st && x.date <= end).map((x) => x.date)]);
    const pains = Object.values(G.days).filter((x) => x.pain != null).sort((a, b) => a.date.localeCompare(b.date));
    const last3 = pains.slice(-3), painAvg = last3.length ? sum(last3.map((x) => x.pain)) / last3.length : null;
    const pressId = G.sets.some((s) => s.ex === "bench") ? "bench" : G.sets.some((s) => s.ex === "dbbench") ? "dbbench" : "bench";
    const pressH = hist(pressId)[""] || [];
    const T = G.tests || {};
    const lsi = T.lr1 && T.ll1 ? T.lr1 / T.ll1 * 100 : T.lr0 && T.ll0 ? T.lr0 / T.ll0 * 100 : null;
    const blockTxt = ti < 0 ? `starts in ${plural(-ti, "day")}` : ti > 27 ? "block finished" : `day ${ti + 1} of 28 · week ${weekOf(t)}, ${PH[weekOf(t) - 1]}`;
    const progEx = [...new Set(G.sets.map((s) => s.ex))].map((id) => def(id)).filter((e) => metric(e).label);
    const strSel = progEx.some((e) => e.id === store.get("g-str", "bench")) ? store.get("g-str", "bench") : progEx[0]?.id || "";

    app.innerHTML = `<div id="g-root">
      <div class="page-head"><div><h1>Gym</h1><p class="sub">Knee-smart 4-week block · ${blockTxt}</p></div>
        <label class="g-start">Day 1 <input type="date" id="g-startin" value="${st}"></label></div>
      <div class="tiles">
        ${tile("Sessions done", `${doneDates.size}`, `/ ${plannedSoFar}`, "planned so far")}
        ${tile("Sets this week", n0(loggedN), `/ ${plannedN}`, `plan week ${wNow}`)}
        ${tile("Lifted this week", wkVol ? Math.round(wkVol).toLocaleString("de-CH") : "–", "kg", "weight × reps, all sets")}
        ${tile("Knee pain", painAvg == null ? "–" : n1(painAvg), "/ 10", last3.length ? `average of last ${plural(last3.length, "entry").replace("entrys", "entries")}` : "rate it after each session")}
        ${tile(pressId === "dbbench" ? "DB bench, est. 1RM" : "Bench, est. 1RM", pressH.length ? n1(pressH[pressH.length - 1].y) : "–", "kg", pressH.length > 1 ? `${pressH[pressH.length - 1].y >= pressH[0].y ? "▲" : "▼"} ${n1(Math.abs(pressH[pressH.length - 1].y - pressH[0].y))} kg since ${fd(pressH[0].x, { day: "numeric", month: "short" })}` : "from your best set")}
        ${tile("Quad symmetry", lsi ? Math.round(lsi) : "–", lsi ? "%" : "", lsi ? "right ÷ left · target 90%+" : "physio test: 80% · test on day 5")}
      </div>
      <div class="grid">
        ${card("28-day plan", rackHTML(sel) + `<div class="legend" style="margin-top:12px">${["A", "B", "C", "R"].map((s) => `<span><i class="key" style="background:${COLV[s]}"></i>${s === "R" ? "Rest" : s + " · " + SNAME[s]}</span>`).join("")}${(G.workouts || []).map((w) => `<span><i class="key" style="background:${w.color || PALETTE[0]}"></i>${esc(w.name)}</span>`).join("")}</div>`, { span: 12, sub: "A → B → C → rest. Tap a day to log it. Took an extra rest day? Switch the next day to the letter you missed." })}
        <section class="card span-12 g-sess" id="g-sess">${sessHTML(sel)}</section>
        ${card("Sets this week vs plan", musBars(plannedMus, loggedMus), { span: 6, sub: `${fd(wkStart, { day: "numeric", month: "short" })} – ${fd(wkEnd, { day: "numeric", month: "short" })} · hard sets per muscle, helpers count ½` })}
        ${card("Workout stats", G.sets.length ? `<div class="chart" id="g-volch"></div><p class="small muted" style="margin:8px 0 0">Kilos lifted per session (weight × reps). Tap a bar for sets and reps.</p>` : '<p class="muted small">Log a session and its totals appear here.</p>', { span: 6, sub: "Every session, coloured by workout" })}
        ${card("Knee pain", pains.length ? `<div class="chart" id="g-painch"></div>` : '<p class="muted small">Rate your knee 0–10 after each session (top of the session card) and the trend appears here.</p>', { span: 6, sub: "0–2 train as written · 3–4 hold, go shallower · 5+ stop that exercise" })}
        ${card("Strength progress", progEx.length ? `<div class="chart" id="g-strch"></div><p class="small muted" style="margin:8px 0 0">Best set per day: estimated 1-rep max for weighted lifts (kg × (1 + reps ÷ 30)), reps for bodyweight, seconds for holds. 2-up/1-down sets make the right leg extension and left leg curl jump – that's the method.</p>` : '<p class="muted small">Log a few sessions and your trend per exercise appears here.</p>', { span: 6, right: progEx.length ? `<select id="g-strsel">${progEx.map((e) => `<option value="${e.id}" ${e.id === strSel ? "selected" : ""}>${esc(e.n)}</option>`).join("")}</select>` : "" })}
        <section class="card span-12" id="g-mgmtcard"><div class="card-head"><div><h2>Your workouts and exercises</h2><p class="sub">Build your own sessions from the library or from exercises you create</p></div></div><div id="g-mgmt">${mgmtHTML()}</div></section>
        ${card("Tests", testsHTML(), { span: 6, sub: "Day 5 and day 25 (strength), day 1 and day 28 (tape). Saved on the Pi." })}
        ${card("Rules", rulesHTML(), { span: 6 })}
        ${card("History", historyHTML(), { span: 12 })}
      </div></div>`;

    if (pains.length) drawPain(pains);
    if (progEx.length) drawStr(strSel);
    if (G.sets.length) drawVol();
    wire($("#g-root"), sel);
    if (arg) setTimeout(() => $("#g-sess")?.scrollIntoView({ block: "start" }), 30);
  }

  function hist(exId) {
    const dfn = def(exId), M = metric(dfn), by = {};
    for (const s of G.sets) {
      if (s.ex !== exId) continue;
      const v = M.v(s); if (v == null) continue;
      const k = s.side || "";
      by[k] = by[k] || {};
      by[k][s.date] = M.agg === "sum" ? (by[k][s.date] || 0) + v : Math.max(by[k][s.date] ?? -Infinity, v);
    }
    const out = {};
    for (const [k, m] of Object.entries(by)) out[k] = Object.entries(m).sort().map(([x, y]) => ({ x, y }));
    return out;
  }

  function musBars(planned, logged) {
    const keys = [];
    for (const [m] of MUSCLES) { if (LEGSET.has(m)) keys.push(m + "R", m + "L"); else keys.push(m); }
    const rows = keys.filter((k) => (planned[k] || 0) >= 0.5 || (logged[k] || 0) >= 0.5);
    if (!rows.length) return '<p class="muted small">Nothing planned or logged this week yet.</p>';
    const max = Math.max(1, ...rows.map((k) => Math.max(planned[k] || 0, logged[k] || 0)));
    return `<div class="g-bars">${rows.map((k) => { const p = planned[k] || 0, d = logged[k] || 0;
      return `<div class="g-bar"><span>${musLabel(k)}</span><div class="g-track"><i class="pl" style="width:${p / max * 100}%"></i><i class="dn${p && d >= p ? " full" : ""}" style="width:${Math.min(d, max) / max * 100}%"></i></div><span class="num">${g1(d)} / ${g1(p)}</span></div>`; }).join("")}</div>
      <p class="small muted" style="margin:8px 0 0">Pale bar = planned for this plan week, solid = logged. Legs are counted per side; a both-legs set counts for each.</p>`;
  }

  function testsHTML() {
    const T = G.tests || {};
    const f = (k, l) => `<label>${l}<input data-t="${k}" inputmode="decimal" value="${T[k] ?? ""}"></label>`;
    const lsi = (r, l) => (T[r] && T[l] ? `<b>${Math.round(T[r] / T[l] * 100)}%</b>` : "–");
    const e = (w, r) => (T[w] && T[r] ? `<b>${n1(T[w] * (1 + T[r] / 30))} kg</b>` : "–");
    const gap = (r, l) => (T[r] && T[l] ? `<b>${n1(T[l] - T[r])} cm</b>` : "–");
    return `<div class="g-tests">
      <div><b>Quad symmetry</b><p class="small muted">Single-leg extension 90° → 45°, heaviest weight for 10 clean reps (stop if pain hits 3).</p>
        <div class="g-tin">${f("lr0", "Day 5 R kg")}${f("ll0", "Day 5 L kg")}${f("lr1", "Day 25 R kg")}${f("ll1", "Day 25 L kg")}</div>
        <p class="small">Symmetry: ${lsi("lr0", "ll0")} → ${lsi("lr1", "ll1")}</p></div>
      <div><b>Bench press</b><p class="small muted">Best working set.</p>
        <div class="g-tin">${f("bw0", "Day 5 kg")}${f("br0", "Day 5 reps")}${f("bw1", "Day 25 kg")}${f("br1", "Day 25 reps")}</div>
        <p class="small">Est. 1RM: ${e("bw0", "br0")} → ${e("bw1", "br1")}</p></div>
      <div><b>Tape</b><p class="small muted">Morning, before eating. Thigh 15 cm above the kneecap.</p>
        <div class="g-tin">${f("tr0", "Day 1 thigh R")}${f("tl0", "Day 1 thigh L")}${f("tr1", "Day 28 thigh R")}${f("tl1", "Day 28 thigh L")}${f("c0", "Day 1 chest")}${f("c1", "Day 28 chest")}</div>
        <p class="small">Thigh gap (L − R): ${gap("tr0", "tl0")} → ${gap("tr1", "tl1")}</p></div></div>`;
  }

  function rulesHTML() {
    return `<div class="g-rules">
      <div><b>Pain traffic light</b><ul class="why"><li><b>0–2 / 10</b>, back to normal next morning: train as written, progress when reps allow.</li><li><b>3–4</b>, or more morning stiffness: keep the weight, go shallower or drop a set; no progression next time.</li><li><b>5+</b>, sharp or catching pain: stop that exercise today. Swelling, locking, giving way or night pain → stop leg training and call your physio.</li></ul></div>
      <div><b>How hard and when to add weight</b><ul class="why"><li>RIR 2 = stop with 2 clean reps left. Knee exercises never below RIR 2.</li><li>All sets at the top of the rep range at the target RIR → add next time: barbell +2.5 kg, dumbbells +1–2 kg, machines +1 plate.</li><li>Knee exercises only after a green session and a green next morning; open the range ~10–15° a week while green.</li></ul></div></div>`;
  }

  function historyHTML() {
    const dates = [...new Set([...G.sets.map((s) => s.date), ...Object.values(G.days).filter((x) => x.pain != null || x.done || x.note).map((x) => x.date)])].sort().reverse();
    if (!dates.length) return '<p class="muted small">Nothing logged yet. Open today in the plan above and add your first set.</p>';
    return `<div class="table-wrap"><table><thead><tr><th>Date</th><th>Workout</th><th class="num">Sets</th><th class="num">Reps</th><th class="num">Lifted</th><th class="num">Time</th><th class="num">Knee</th><th>Note</th></tr></thead><tbody>
      ${dates.slice(0, 80).map((d) => { const st = sessionStats(d), s = sessOf(d), dy = G.days[d] || {};
        return `<tr class="click" data-go="${d}"><td class="muted">${fd(d)}</td><td><i class="key" style="background:${sessColor(s)}"></i> ${PLAN[s] ? s + " · " : ""}${esc(sessName(s))}</td><td class="num">${st.n}</td><td class="num">${st.reps || "–"}</td><td class="num">${st.vol ? n0(st.vol) + " kg" : "–"}</td><td class="num">${st.mins ? st.mins + " min" : "–"}</td><td class="num">${dy.pain ?? "–"}</td><td class="g-notecell">${esc(dy.note || "")}</td></tr>`; }).join("")}
    </tbody></table></div>`;
  }

  // ------------------------------------------------------------ charts
  function drawPain(pains) {
    const c = C();
    mkChart("#g-painch", {
      type: "line",
      data: { datasets: [line("Knee pain", pains.map((p) => ({ x: p.date, y: p.pain })), c.critical, { tension: 0, pointRadius: 4, pointBackgroundColor: c.critical, fmt: (r) => `${r.y} / 10` })] },
      options: { scales: axes({ unit: "day", yMin: 0, yMax: 10 }), plugins: { bands: { items: [{ from: 0, to: 2.5, color: "rgba(12,163,12,.08)", label: "train" }, { from: 2.5, to: 4.5, color: "rgba(250,178,25,.12)", label: "hold" }, { from: 4.5, to: 10, color: "rgba(208,59,59,.08)", label: "stop" }] } } },
    });
  }
  function drawStr(exId) {
    const old = charts.find((ch) => ch.canvas.parentNode?.id === "g-strch");
    if (old) { old.destroy(); charts.splice(charts.indexOf(old), 1); }
    const c = C(), h = hist(exId), M = metric(def(exId)), f = (r) => `${g1(r.y)} ${M.unit}`;
    const ds = [];
    if (h.R) ds.push(line("Right", h.R, c.critical, { tension: 0.2, pointRadius: 3.5, pointBackgroundColor: c.critical, fmt: f }));
    if (h.L) ds.push(line("Left", h.L, c.text2, { tension: 0.2, pointRadius: 3.5, pointBackgroundColor: c.text2, fmt: f }));
    if (h[""]) ds.push(line(h.R || h.L ? "Both" : M.label, h[""], c.s1, { tension: 0.2, pointRadius: 3.5, pointBackgroundColor: c.s1, fmt: f }));
    mkChart("#g-strch", { type: "line", data: { datasets: ds }, options: { scales: axes({ unit: "day", yFmt: (v) => `${v} ${M.unit}` }) } });
  }
  function drawVol() {
    const dates = [...new Set(G.sets.map((s) => s.date))].sort().slice(-40);
    const rows = dates.map((d) => ({ d, st: sessionStats(d), s: sessOf(d) }));
    mkChart("#g-volch", {
      type: "bar",
      data: { labels: rows.map((r) => fd(r.d, { day: "numeric", month: "short" })), datasets: [bars("Lifted", rows.map((r) => Math.round(r.st.vol)), rows.map((r) => colorOf(sessColor(r.s))), { fmt: (raw, dp) => { const x = rows[dp.dataIndex]; return x ? `${n0(x.st.vol)} kg · ${plural(x.st.n, "set")} · ${x.st.reps} reps · ${sessName(x.s)}` : ""; } })] },
      options: { scales: axes({ time: false, yBegin: true, yFmt: (v) => `${Math.round(v / 100) / 10}k` }), plugins: { legend: { display: false } } },
    });
  }

  // ------------------------------------------------------------ server calls
  async function post(url, body, method = "POST") {
    const r = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || `error ${r.status}`);
    return j;
  }
  function flash(el, msg) {
    let n = el.querySelector(":scope > .g-err");
    if (!n) { n = document.createElement("p"); n.className = "g-err"; el.appendChild(n); }
    n.textContent = msg;
    setTimeout(() => n.remove(), 5000);
  }
  const readNum = (f, n) => (f.elements[n] ? f.elements[n].value.trim() : undefined);
  function setBody(f, prefix = "") {
    const b = {};
    for (const k of ["kg", "reps", "secs", "mins", "rir"]) { const v = readNum(f, prefix + k); if (v !== undefined) b[k] = v; }
    const side = f.querySelector(".g-side .on");
    if (side) b.side = side.dataset.side;
    return b;
  }

  // ------------------------------------------------------------ events
  function wire(root, sel) {
    const rs = () => { const el = $("#g-sess"); if (!el) return; el.innerHTML = sessHTML(sel); onSeg("g-stype", changeSess); };
    const rr = () => { const r = $(".g-rack", root); if (r) r.outerHTML = rackHTML(sel); };
    const rm = () => { const m = $("#g-mgmt"); if (m) m.innerHTML = mgmtHTML(); };
    const rerenderEditors = () => { if (UI.ed?.ctx === "mgmt") rm(); else rs(); };
    const saveDay = async (body) => { G.days[sel] = await post("/api/gym/day", { date: sel, ...body }); };
    const changeSess = async (v) => { await saveDay({ session: v }); UI.swap = null; rs(); rr(); };
    onSeg("g-stype", changeSess);

    $("#g-startin").addEventListener("change", async (e) => { if (!e.target.value) return; await post("/api/gym/settings", { start: e.target.value }); if (location.hash === "#/gym") route(); else location.hash = "#/gym"; });
    $("#g-strsel")?.addEventListener("change", (e) => { store.set("g-str", e.target.value); drawStr(e.target.value); });

    const openExEditor = (ctx, draft, after) => { UI.ed = { type: "ex", ctx, draft: { kind: "kg", cat: "Other", uni: false, mus: {}, ...draft }, after }; rerenderEditors(); $(".g-editor input[name=name]")?.focus(); };
    const openWoEditor = (ctx, w) => {
      UI.ed = { type: "wo", ctx, draft: w ? JSON.parse(JSON.stringify(w)) : { name: "", color: PALETTE[(G.workouts || []).length % PALETTE.length], note: "", items: [{ ex: "crunch", sets: 3, reps: "12–15", rest: "", note: "" }] } };
      rerenderEditors();
      $(".g-editor")?.scrollIntoView({ block: "center" });
    };
    const syncWoDraft = (form) => {
      const x = UI.ed.draft;
      x.name = form.elements.name.value; x.note = form.elements.note.value;
      form.querySelectorAll(".g-item").forEach((row) => { const it = x.items[+row.dataset.i]; row.querySelectorAll("[data-f]").forEach((el) => { it[el.dataset.f] = el.value; }); });
    };
    const syncExDraft = (form) => { const x = UI.ed.draft; x.name = form.elements.name.value; x.kind = form.elements.kind.value; x.cat = form.elements.cat.value; x.uni = form.elements.uni.checked; x.note = form.elements.note.value; };

    root.addEventListener("click", async (e) => {
      const b = e.target.closest("[data-act]");
      if (!b) { const go = e.target.closest("[data-go]"); if (go && !e.target.closest("a")) location.hash = "#/gym/" + go.dataset.go; return; }
      const act = b.dataset.act;
      try {
        if (act === "side") { b.parentNode.querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b)); return; }
        if (act === "del") {
          if (!b.classList.contains("confirm")) { b.classList.add("confirm"); b.textContent = "delete?"; setTimeout(() => { if (b.isConnected) { b.classList.remove("confirm"); b.textContent = "×"; } }, 3000); return; }
          await post("/api/gym/set/" + b.dataset.id, null, "DELETE");
          G.sets = G.sets.filter((s) => s.id !== +b.dataset.id); rs(); rr(); return;
        }
        if (act === "eset") { UI.editSet = +b.dataset.id; rs(); return; }
        if (act === "eset-cancel") { UI.editSet = null; rs(); return; }
        if (act === "swap-open") { UI.swap = UI.swap === b.dataset.slot ? null : b.dataset.slot; rs(); return; }
        if (act === "swap-cancel") { UI.swap = null; rs(); return; }
        if (act === "swap-back") {
          const sl = blocksFor(sel).find((x) => x.slot === b.dataset.slot);
          await doSwap(sl, sl.base, true); return;
        }
        if (act === "rm-extra") { await saveDay({ extras: (G.days[sel]?.extras || []).filter((x) => x !== b.dataset.slot) }); rs(); return; }
        if (act === "tool") { UI.tool = UI.tool === b.dataset.tool ? null : b.dataset.tool; rs(); return; }
        if (act === "tool-cancel") { UI.tool = null; rs(); return; }
        if (act === "ed-ex-new") { openExEditor(b.dataset.ctx || "mgmt", {}); return; }
        if (act === "ed-ex-edit") { const c = CUS[b.dataset.id]; openExEditor(b.dataset.ctx || "mgmt", { id: c.id, name: c.name, kind: c.kind, cat: c.cat || "Other", uni: !!c.uni, mus: { ...(c.mus || {}) }, note: c.note || "" }); return; }
        if (act === "ed-ex-define") { const dfn = def(b.dataset.id, b.dataset.name); openExEditor("sess", { id: dfn.id, name: dfn.n, kind: dfn.kind, uni: dfn.uni, mus: {} }); return; }
        if (act === "ed-wo-new") { openWoEditor(b.dataset.ctx || "mgmt", null); return; }
        if (act === "ed-wo-edit") { openWoEditor(b.dataset.ctx || "mgmt", wById(b.dataset.id)); return; }
        if (act === "ed-cancel") { const ctx = UI.ed?.ctx; UI.ed = null; if (ctx === "mgmt") rm(); else rs(); return; }
        if (act === "mcycle") {
          syncExDraft(b.closest("form"));
          const m = b.dataset.m, mus = UI.ed.draft.mus, w = mus[m];
          if (!w) mus[m] = 1; else if (w >= 1) mus[m] = 0.5; else delete mus[m];
          rerenderEditors(); return;
        }
        if (act === "col") { syncWoDraft(b.closest("form")); UI.ed.draft.color = b.dataset.c; rerenderEditors(); return; }
        if (act.startsWith("it-")) {
          const form = b.closest("form"); syncWoDraft(form);
          const items = UI.ed.draft.items, i = +(b.closest(".g-item")?.dataset.i ?? -1);
          if (act === "it-add") items.push({ ex: items[items.length - 1]?.ex || "crunch", sets: 3, reps: "", rest: "", note: "" });
          if (act === "it-rm") items.splice(i, 1);
          if (act === "it-up" && i > 0) [items[i - 1], items[i]] = [items[i], items[i - 1]];
          if (act === "it-down" && i < items.length - 1) [items[i + 1], items[i]] = [items[i], items[i + 1]];
          rerenderEditors(); return;
        }
        if (act === "ed-ex-del" || act === "ed-wo-del") {
          if (!b.classList.contains("confirm")) { b.classList.add("confirm"); b.textContent = "Tap again to delete"; return; }
          if (act === "ed-ex-del") { await post("/api/gym/exercise/" + b.dataset.id, null, "DELETE"); CUS[b.dataset.id].archived = true; }
          else { await post("/api/gym/workout/" + b.dataset.id, null, "DELETE"); G.workouts = G.workouts.filter((w) => w.id !== +b.dataset.id); }
          const ctx = UI.ed?.ctx; UI.ed = null; rm(); if (ctx === "sess") rs(); rr(); return;
        }
      } catch (err) { flash(b.closest("form, .g-ex, .card") || root, err.message); }
    });

    async function doSwap(sl, ex, clear, persist) {
      const dfn = def(ex);
      const body = { date: sel, slot: sl.slot, ex, name: dfn.n, session: sessOf(sel), clear: !!clear };
      if (persist !== undefined) body.persist = persist;
      else if (clear && sl.plan && G.swaps?.[sl.slot]) body.persist = false;
      const res = await post("/api/gym/swap", body);
      G.days[sel] = res.day; G.swaps = res.swaps;
      G.sets.forEach((s) => { if (s.date === sel && slotOf(s) === sl.slot) { s.ex = ex; s.name = dfn.n; s.slot = sl.slot; } });
      UI.swap = null; rs();
    }

    root.addEventListener("submit", async (e) => {
      e.preventDefault();
      const f = e.target, kind = f.dataset.form, btn = f.querySelector("[type=submit]");
      if (btn) btn.disabled = true;
      try {
        if (kind === "add") {
          const row = await post("/api/gym/set", { date: sel, session: sessOf(sel), ex: f.dataset.ex, slot: f.dataset.slot, name: f.dataset.name, ...setBody(f) });
          G.sets.push(row);
          if (!G.days[sel]) G.days[sel] = { date: sel, session: sessOf(sel), swaps: {}, extras: [] };
          const slot = f.dataset.slot; rs(); rr();
          $(`.g-ex[data-slot="${CSS.escape(slot)}"] .g-add input`)?.focus({ preventScroll: true });
        } else if (kind === "eset") {
          const row = await post("/api/gym/set/" + f.dataset.id, setBody(f), "PUT");
          const s = G.sets.find((x) => x.id === +f.dataset.id); Object.assign(s, row);
          UI.editSet = null; rs();
        } else if (kind === "swap") {
          const sl = blocksFor(sel).find((x) => x.slot === f.dataset.slot);
          const ex = f.elements.ex.value;
          if (ex === "__new") { openExEditor("sess", {}, async (newId) => { await doSwap(sl, newId, false); }); return; }
          await doSwap(sl, ex, false, f.elements.persist ? f.elements.persist.checked : undefined);
        } else if (kind === "addex") {
          const ex = f.elements.ex.value;
          if (!ex) return;
          if (ex === "__new") { openExEditor("sess", {}, async (newId) => { await saveDay({ extras: [...(G.days[sel]?.extras || []), newId] }); }); return; }
          const known = blocksFor(sel).some((b) => b.slot === ex);
          if (!known) await saveDay({ extras: [...(G.days[sel]?.extras || []), ex] });
          rs();
          $(`.g-ex[data-slot="${CSS.escape(ex)}"]`)?.scrollIntoView({ block: "center" });
        } else if (kind === "move") {
          const to = f.elements.to.value;
          await post("/api/gym/move", { from: sel, to });
          UI.tool = null; location.hash = "#/gym/" + to;
        } else if (kind === "savewo") {
          const items = [];
          for (const b of blocksFor(sel)) {
            const logged = setsOn(sel).filter((s) => slotOf(s) === b.slot);
            if (!logged.length) continue;
            const dfn = def(logged[0].ex, logged[0].name);
            const per = dfn.uni ? Math.max(logged.filter((s) => s.side !== "L").length, logged.filter((s) => s.side !== "R").length) : logged.length;
            const vals = logged.map((s) => s.reps ?? s.secs ?? s.mins).filter((v) => v != null);
            const unit = logged[0].reps != null ? "" : logged[0].secs != null ? " s" : " min";
            const lo = Math.min(...vals), hi = Math.max(...vals);
            items.push({ ex: dfn.id, sets: per, reps: vals.length ? (lo === hi ? `${g1(lo)}${unit}` : `${g1(lo)}–${g1(hi)}${unit}`) : "", rest: b.rest || "", note: "" });
          }
          const w = await post("/api/gym/workout", { name: f.elements.name.value, color: PALETTE[(G.workouts || []).length % PALETTE.length], items });
          G.workouts = [...(G.workouts || []), w];
          UI.tool = null; rs(); rm(); rr();
        } else if (kind === "exed") {
          syncExDraft(f);
          const x = UI.ed.draft;
          const saved = await post("/api/gym/exercise", { id: x.id && (CUS[x.id] || x.id.startsWith("x-")) ? x.id : undefined, name: x.name, kind: x.kind, cat: x.cat, uni: x.uni, mus: x.mus, note: x.note, rename_sets: true });
          CUS[saved.id] = saved;
          G.sets.forEach((s) => { if (s.ex === saved.id) s.name = saved.name; });
          const after = UI.ed.after, ctx = UI.ed.ctx;
          UI.ed = null;
          if (after) await after(saved.id);
          rm(); rs(); if (ctx === "mgmt") $("#g-mgmtcard")?.scrollIntoView({ block: "nearest" });
        } else if (kind === "woed") {
          syncWoDraft(f);
          const x = UI.ed.draft;
          const saved = await post("/api/gym/workout", { id: x.id, name: x.name, color: x.color, note: x.note, items: x.items });
          G.workouts = [...(G.workouts || []).filter((w) => w.id !== saved.id), saved];
          UI.ed = null; rm(); rs(); rr();
        }
      } catch (err) { flash(f, err.message); }
      finally { if (btn && btn.isConnected) btn.disabled = false; }
    });

    root.addEventListener("change", async (e) => {
      const t = e.target;
      try {
        if (t.id === "g-wsel" && t.value) { await changeSess(t.value); return; }
        if (t.id === "g-done") await saveDay({ session: sessOf(sel), done: t.checked });
        if (t.id === "g-pain") await saveDay({ session: sessOf(sel), pain: t.value });
        if (t.id === "g-note") await saveDay({ session: sessOf(sel), note: t.value });
        if (t.id === "g-done" || t.id === "g-pain") rr();
        if (t.dataset.t) { G.tests = { ...(G.tests || {}), [t.dataset.t]: t.value }; G.tests = (await post("/api/gym/settings", { tests: G.tests })).tests; }
      } catch (err) { flash(t.closest("form, .card") || root, err.message); }
    });
  }

  // ------------------------------------------------------------ overview card
  function gymToday(g) {
    if (!g) return "";
    G = g; CUS = Object.fromEntries((G.exercises || []).map((e) => [e.id, e]));
    const t = todayIso(), i = idxOf(t);
    if ((i < -7 || i > 27) && !G.days[t]) return "";
    const s = sessOf(t), n = setsOn(t).length;
    const label = i < 0 && !G.days[t] ? `Gym block starts ${fd(start(), { weekday: "long", day: "numeric", month: "short" })}` : s === "R" ? "Gym: rest day" : `Gym · ${PLAN[s] ? s : esc(sessName(s))}`;
    const sub = i < 0 && !G.days[t] ? "Day 1: A · Quads & chest" : s === "R" ? "Easy bike or walk; rate your knee" : sessName(s);
    const hint = s === "A" || s === "C" ? "Leg day – keep any ride or run easy today." : s === "B" ? "No knee load in the gym today." : "";
    const col = i < 0 && !G.days[t] ? COLV.A : sessColor(s);
    return `<a class="wo-mini" href="#/gym">
      <div class="wo-top"><span class="ic" style="background:${col};${s === "C" ? "color:#141414" : ""}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 7v10M18 7v10M3 10v4M21 10v4M6 12h12"/></svg></span>
        <div style="min-width:0"><div class="wo-sport">${i >= 0 && i < 28 ? `Day ${i + 1} of 28 · week ${weekOf(t)}` : "Gym"}</div><div class="wo-title">${label}</div></div></div>
      <div class="wo-meta">${esc(sub)}${n ? ` · ${plural(n, "set")} logged` : ""}</div>
      ${hint ? `<div class="wo-target">${hint}</div>` : ""}</a>`;
  }

  window.renderGym = renderGym;
  window.gymToday = gymToday;
})();
