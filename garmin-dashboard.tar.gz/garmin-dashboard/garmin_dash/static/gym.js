/* Gym tab: 4-week knee-smart block (A → B → C → rest) and a set-by-set logger.
   Loaded before app.js; it only uses app.js helpers ($, card, tile, mkChart, …) inside functions. */
(function () {
  "use strict";

  const DEFAULT_START = "2026-11-19";
  const PH = ["Calibrate", "Build", "Push", "Peak & test"];
  const PHN = [
    "RIR 3 everywhere. Learn the movements, find working weights and pain-free ranges; legs start shallow.",
    "Sets go up. Right-leg 2-up/1-down extensions and left-leg eccentric curls begin.",
    "Upper body to RIR 1 (last set of isolation lifts may reach failure). Leg ranges may deepen while pain stays green.",
    "Hold week-3 loads. Retest on day 25, then drop one set from every exercise for the last three sessions.",
  ];
  const RIRT = { comp: ["3", "2", "1–2", "1–2"], iso: ["3", "2", "1, last set 0", "1, last set 0"], knee: ["3", "3", "2", "2"], hinge: ["3", "2", "2", "2"], eff: ["60–70%", "70–80%", "80%", "80%"] };
  const COLV = { A: "var(--gA)", B: "var(--gB)", C: "var(--gC)", R: "var(--gR)", F: "var(--series-7)" };
  const SNAME = { A: "Quads & chest", B: "Back, shoulders, arms", C: "Hips, hamstrings & upper chest", R: "Rest day", F: "Free workout" };
  const WARM = {
    leg: ["Bike 5 min, easy to moderate", "Band terminal knee extension: right 15, left 10", "Glute bridge × 12", "Banded lateral walk, 10 steps each way", "Ramp-up sets on the first heavy lift (≈50 → 70 → 85%, fewer reps)"],
    up: ["Bike or rower 5 min", "Band pull-aparts × 15", "Arm circles, 10 each way", "Easy push-ups × 8–10", "Ramp-up sets on the first lift"],
  };
  // kind: kg = weight × reps · hold = weight + seconds · secs = seconds only · info = nothing to log
  const PLAN = {
    A: { f: "Right quad: heavy concentric and eccentric work in knee-friendly ranges. Bench press is the first upper-body lift.", warm: "leg", ex: [
      { id: "iso", n: "Isometric leg extension at 60°", tag: "knee", m: "quad", count: false, uni: true, kind: "hold", sets: ["R 3 · L 2", "R 4 · L 2", "R 4 · L 2", "R 4 · L 2"], reps: ["30 s hold", "40 s hold", "45 s hold", "45 s hold"], rir: "eff", rest: "60 s", tempo: "hold, breathe", cue: "Load the leg extension heavier than you can lift with one leg. Start with the knee bent about 60°. Push into the pad to the effort target and hold; nothing should move. Right first, alternate legs.", why: "Your right quad's biggest deficit is maximal force through the middle of the bend. Isometrics let you push hard right there with very low joint stress – a primer before heavier work." },
      { id: "bench", n: "Barbell bench press", tag: "chest", m: "chest", kind: "kg", sets: ["3", "4", "4", "4"], reps: "6–10", rir: "comp", rest: "2–3 min", tempo: "2–3 s down, touch, press", cue: "Shoulder blades back and down, feet flat, slight arch. Bar to the bottom of the chest, forearms vertical, touch without bouncing. Ramp up: bar × 10, ~50% × 6, ~70% × 4, ~85% × 2.", why: "Main chest builder and your clearest progress marker; early in the session because chest is the upper-body priority." },
      { id: "lp", n: "Single-leg leg press", tag: "knee", m: "quad", uni: true, kind: "kg", sets: ["R 3 · L 2", "R 3 · L 3", "R 4 · L 3", "R 4 · L 3"], reps: "8–12", rir: "knee", rest: "60–90 s between legs", tempo: "3 s down, 1 s up", note: ["Depth: to about 60° knee bend", "Depth: to about 60° knee bend", "Depth: up to 75–90° if last week stayed green", "Depth: up to 75–90° if green"], cue: "Foot mid-platform, knee over the 2nd–3rd toe. Lower slowly only as deep as this week allows; press up without snapping the knee locked. Right first; the left matches the right's reps, never more.", why: "Closed-chain strength for the right leg, pressing and slow lowering – your physio's two quad goals. Single-leg stops the strong left leg taking over." },
      { id: "le", n: "Leg extension, 90° → 45°", tag: "knee", m: "quad", uni: true, kind: "kg", sets: ["R 3 · L 2", "R 3 · L 2", "R 3 · L 2", "R 3 · L 2"], reps: ["10–15 each leg", "R 8–10 · L 10–15", "R 8–10 · L 10–15", "R 8–10 · L 10–15"], rir: "knee", rest: "60–90 s", tempo: ["2 s up, 3 s down", "R: up with both, 4 s down with right only", "R: 2-up/1-down, 4 s down", "R: 2-up/1-down, 4 s down"], note: ["Single-leg, both sides, to learn the range", "Right = 2-up/1-down. Start about 1.3× your right single-leg weight", "Right = 2-up/1-down", "Right = 2-up/1-down"], cue: "Start fully bent (90°) and extend only about halfway, stopping ~45° short of straight. Don't lock out.", why: "This range stresses the kneecap joint least and is the stretched half that grows the quads best. 2-up/1-down gives the right quad heavy eccentric load." },
      { id: "fly", n: "Cable fly or pec deck", tag: "chest", m: "chest", kind: "kg", sets: ["2", "2", "3", "3"], reps: "12–15", rir: "iso", rest: "60–90 s", tempo: "2 s in, 3 s out", cue: "Elbows slightly bent and fixed. Open wide to a deep chest stretch, bring the handles together at chest height.", why: "Loads the chest hardest in its stretched position with little joint strain." },
      { id: "lat", n: "Lateral raise", tag: "shoulders", m: "shoulders", kind: "kg", sets: ["2", "3", "3", "3"], reps: "12–20", rir: "iso", rest: "60 s", tempo: "controlled, no swing", cue: "Raise to shoulder height leading with the elbows, slight forward lean.", why: "Side delts give the upper body width; small muscle, recovers fast." },
    ] },
    B: { f: "A full knee rest day: nothing loads the knee. Superset curls and triceps to save time.", warm: "up", ex: [
      { id: "pd", n: "Lat pulldown or assisted pull-up", tag: "back", m: "back", kind: "kg", sets: ["3", "3", "4", "4"], reps: "8–12", rir: "comp", rest: "2 min", tempo: "1 s pull, 2–3 s up", cue: "Grip just outside the shoulders, chest up, drive the elbows down to your ribs. Full stretch at the top.", why: "Back width and the counterweight to all the pressing." },
      { id: "row", n: "Chest-supported row", tag: "back", m: "back", kind: "kg", sets: ["3", "3", "4", "4"], reps: "8–12", rir: "comp", rest: "2 min", tempo: "1 s pause at the top", cue: "Machine, or dumbbells face-down on a 30° bench. Elbows back past the torso, squeeze, lower to a full stretch.", why: "Mid-back thickness without bracing through legs or lower back." },
      { id: "lat", n: "Lateral raise", tag: "shoulders", m: "shoulders", kind: "kg", sets: ["3", "3", "3", "3"], reps: "12–20", rir: "iso", rest: "60 s", tempo: "controlled", cue: "As on day A; try a cable, one arm at a time.", why: "Second weekly dose for shoulder width." },
      { id: "rd", n: "Reverse pec deck or face pull", tag: "shoulders", m: "shoulders", kind: "kg", sets: ["2", "2", "3", "3"], reps: "12–20", rir: "iso", rest: "60 s", tempo: "1 s squeeze", cue: "Arms long, pull wide and back, squeeze between the shoulder blades.", why: "Rear delts and upper back balance a chest-heavy plan." },
      { id: "curl", n: "Dumbbell curl", tag: "arms", m: "arms", kind: "kg", sets: ["2", "2", "3", "3"], reps: "10–15", rir: "iso", rest: "superset", tempo: "3 s down", cue: "Elbows pinned at your sides, full stretch at the bottom, no swinging.", why: "Direct biceps work on top of the pulling." },
      { id: "tri", n: "Overhead cable triceps extension", tag: "arms", m: "arms", kind: "kg", sets: ["2", "2", "3", "3"], reps: "10–15", rir: "iso", rest: "60–90 s after the pair", tempo: "3 s down", cue: "Face away from the cable, rope behind the head, elbows forward. Stretch deep, extend fully.", why: "The overhead position stretches the long head, which grew clearly more in training studies." },
      { id: "calf", n: "Standing calf raise", tag: "calves", m: "calves", kind: "kg", sets: ["3", "3", "3", "3"], reps: "10–15", rir: "hinge", rest: "60–90 s", tempo: "2 s pause in the bottom stretch", cue: "Knees straight; from deep stretch to full tiptoe.", why: "Completes the leg chain with minimal knee load." },
      { id: "pal", n: "Pallof press", tag: "core", m: "core", uni: true, kind: "kg", sets: ["2", "2", "2", "2"], reps: "10 each side", rir: "hinge", rest: "45 s", tempo: "2 s hold arms out", cue: "Side-on to a cable at chest height, press straight out and resist the twist.", why: "Anti-rotation core strength." },
      { id: "flush", n: "Knee flush (optional)", tag: "knee", kind: "info", count: false, sets: ["1", "1", "1", "1"], reps: "10 min bike + TKE 2 × 15 right", rir: "easy", rest: "–", tempo: "easy", cue: "Easy spin, then band terminal knee extensions, squeezing the quad hard at full straightening.", why: "Moves the knee without load on its rest day." },
    ] },
    C: { f: "Posterior chain and hips, left-hamstring eccentrics and a small dose of right-quad control. Upper chest is the second chest session.", warm: "leg", ex: [
      { id: "rdl", n: "Romanian deadlift", tag: "hinge", m: "ham", kind: "kg", sets: ["3", "3", "3", "3"], reps: "8–10", rir: "hinge", rest: "2–3 min", tempo: "3 s down, 1 s up", cue: "Soft knees that keep the same bend, hips back, bar close, flat back. Lower to a strong hamstring stretch, drive the hips forward.", why: "Heavy eccentric hamstring and glute work while the knee angle barely changes." },
      { id: "inc", n: "Incline dumbbell press, 30°", tag: "chest", m: "chest", kind: "kg", sets: ["3", "3", "3", "3"], reps: "8–12", rir: "comp", rest: "2 min", tempo: "3 s down", cue: "Bench ~30°. Lower to the outside of the upper chest for a deep stretch, press up and slightly in.", why: "A low incline shifts work to the upper chest." },
      { id: "ht", n: "Hip thrust", tag: "glutes", m: "glutes", kind: "kg", sets: ["3", "3", "3", "3"], reps: "8–12", rir: "hinge", rest: "2 min", tempo: "1 s squeeze at the top", cue: "Upper back on a bench, shins vertical at the top, ribs down, squeeze 1 s. Knee complains → feet a little further out.", why: "Strong glutes take load off the quads and knee." },
      { id: "curlL", n: "Seated leg curl, left eccentric", tag: "hamstrings", m: "ham", uni: true, kind: "kg", sets: ["L 3 · R 2", "L 3 · R 2", "L 3 · R 2", "L 3 · R 2"], reps: ["10–12 each leg", "L 8–10 · R 10–12", "L 8–10 · R 10–12", "L 8–10 · R 10–12"], rir: "knee", rest: "60–90 s", tempo: ["2 s down", "L: curl with both, 4 s return with left only", "L: 2-up/1-down", "L: 2-up/1-down"], note: ["Single-leg both sides", "Left = 2-up/1-down from now on", "Left = 2-up/1-down", "Left = 2-up/1-down"], cue: "Pad just above the ankles, thigh pad snug. From week 2: curl with both legs, return with the left alone over 4 s.", why: "Your left hamstrings lag your strong left quad (ratio 0.82 vs ~1.0); the physio asked for left eccentric work." },
      { id: "sd", n: "Lateral step-down", tag: "knee", m: "quad", uni: true, kind: "kg", sets: ["R 2 · L 2", "R 2 · L 2", "R 3 · L 2", "R 3 · L 2"], reps: ["8 each", "10 each", "10 each", "10 each"], rir: "knee", rest: "60 s", tempo: "3 s down, tap, up", note: ["Step height 10–15 cm", "Step height 15–20 cm", "Step height 20 cm", "20 cm, light dumbbell if green"], cue: "Side-on on a step, other foot hanging. Lower the free heel to tap in 3 s, stand up. Pelvis level, knee over the 2nd toe. Log 0 kg for bodyweight.", why: "Slow single-leg lowering trains eccentric quad and hip control in a real-life position." },
      { id: "abd", n: "Hip abduction machine", tag: "glutes", m: "glutes", kind: "kg", sets: ["2", "3", "3", "3"], reps: "15–20", rir: "iso", rest: "60 s", tempo: "1 s hold out", cue: "Push the pads out, hold, return slowly. No machine: side-lying band abduction.", why: "The glute medius stops the knee caving inward." },
      { id: "sp", n: "Side plank", tag: "core", m: "core", uni: true, kind: "secs", sets: ["2", "2", "2", "2"], reps: ["30 s each side", "35 s each side", "40 s each side", "45 s each side"], rir: "hinge", rest: "30 s", tempo: "hold", cue: "Elbow under the shoulder, body in one line, hips high.", why: "Lateral core and hip stability for single-leg control." },
    ] },
  };
  const REST = ["Easy bike 30–60 min (seated, relaxed cadence) or a walk, or nothing.", "Rate your knee 0–10 this morning. Higher than usual? Use the amber rule at the next leg session.", "Optional 10 min: band TKE 2 × 15 right, glute bridge 2 × 12, calf stretch.", "Protein and sleep are the training today."];
  const GROUPS = [["chest", "Chest"], ["back", "Back"], ["shoulders", "Shoulders"], ["arms", "Arms"], ["quadR", "Quads, right"], ["quadL", "Quads, left"], ["hamR", "Hamstrings, right"], ["hamL", "Hamstrings, left"], ["glutes", "Glutes & hip"], ["calves", "Calves"], ["core", "Core"]];
  const ALLEX = Object.entries(PLAN).flatMap(([s, p]) => p.ex.map((e) => ({ ...e, s })));
  const EXBY = Object.fromEntries(ALLEX.filter((e, i, a) => a.findIndex((x) => x.id === e.id) === i).map((e) => [e.id, e]));

  // ------------------------------------------------------------ helpers
  const at = (v, i) => (Array.isArray(v) ? v[i] : v);
  const pad = (x) => String(x).padStart(2, "0");
  const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const pd = (s) => { const [y, m, d] = s.split("-").map(Number); return new Date(y, m - 1, d); };
  const addD = (s, n) => { const d = pd(s); d.setDate(d.getDate() + n); return iso(d); };
  const diffD = (a, b) => Math.round((pd(b) - pd(a)) / 864e5);
  const todayIso = () => iso(new Date());
  const fd = (s, o = { weekday: "short", day: "numeric", month: "short" }) => pd(s).toLocaleDateString("en-GB", o);
  const parseSets = (s) => { const t = String(s).match(/[RL]\s*\d+/g); if (t) { const r = {}; t.forEach((x) => { r[x[0]] = +x.match(/\d+/)[0]; }); return r; } return { all: parseInt(s, 10) || 0 }; };
  const perSide = (ex) => ex.uni && parseSets(at(ex.sets, 0)).all != null;
  const gfor = (ex, side) => (!ex.m || ex.count === false ? [] : ex.m === "quad" || ex.m === "ham" ? (side === "R" ? [ex.m + "R"] : side === "L" ? [ex.m + "L"] : [ex.m + "R", ex.m + "L"]) : [ex.m]);
  const e1rm = (s) => (s.kg > 0 && s.reps >= 1 && s.reps <= 30 ? s.kg * (1 + s.reps / 30) : null);
  const slug = (t) => "x-" + t.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40);
  const setTxt = (s) => (s.kg != null && s.kg > 0 ? `${n1g(s.kg)} kg` : "") + (s.reps != null ? `${s.kg > 0 ? " × " : ""}${s.reps}${s.kg > 0 ? "" : " reps"}` : "") + (s.secs != null ? `${s.kg > 0 ? " · " : ""}${s.secs} s` : "") + (s.rir != null ? ` <span class="muted">RIR ${s.rir}</span>` : "");
  const n1g = (v) => (Math.round(v * 10) / 10).toLocaleString("de-CH");

  let G = null;          // server state
  const extras = {};     // date -> [custom exercise ids added but not yet logged]

  const start = () => G.start || DEFAULT_START;
  const idxOf = (d) => diffD(start(), d);
  const planType = (d) => { const i = idxOf(d); return i >= 0 && i < 28 ? "ABCR"[i % 4] : null; };
  const weekOf = (d) => Math.min(4, Math.max(1, Math.floor(idxOf(d) / 7) + 1));
  const sessOf = (d) => G.days[d]?.session || planType(d) || "F";
  const setsOn = (d) => G.sets.filter((s) => s.date === d);
  const exInfo = (id, name) => EXBY[id] || { id, n: name || id, tag: "extra", kind: "kg", custom: true, sets: [""], reps: "", rir: "", rest: "", tempo: "" };

  async function post(url, body, method = "POST") {
    const r = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || r.status);
    return j;
  }

  function plannedGroups(sess, w) {
    const g = {};
    for (const ex of PLAN[sess]?.ex || []) {
      const p = parseSets(at(ex.sets, w - 1));
      if (p.all != null) gfor(ex, "").forEach((k) => { g[k] = (g[k] || 0) + p.all; });
      else ["R", "L"].forEach((sd) => gfor(ex, sd).forEach((k) => { g[k] = (g[k] || 0) + (p[sd] || 0); }));
    }
    return g;
  }
  function loggedGroups(sets) {
    const g = {}, by = {};
    for (const s of sets) (by[s.date + "|" + s.ex] = by[s.date + "|" + s.ex] || []).push(s);
    for (const list of Object.values(by)) {
      const ex = EXBY[list[0].ex];
      if (!ex) continue;
      const cnt = (sd) => list.filter((s) => s.side === sd).length;
      const add = (keys, n) => keys.forEach((k) => { g[k] = (g[k] || 0) + n; });
      if (perSide(ex)) add(gfor(ex, ""), Math.max(cnt("R"), cnt("L"), cnt("")));
      else if (ex.uni) { add(gfor(ex, "R"), cnt("R")); add(gfor(ex, "L"), cnt("L")); add(gfor(ex, ""), cnt("")); }
      else add(gfor(ex, ""), list.length);
    }
    return g;
  }
  function prevSets(exId, d) {
    let best = null;
    for (const s of G.sets) if (s.ex === exId && s.date < d && (!best || s.date > best)) best = s.date;
    return best ? { date: best, sets: G.sets.filter((s) => s.ex === exId && s.date === best) } : null;
  }

  // ------------------------------------------------------------ rack (28-day plan)
  function rackHTML(sel) {
    const t = todayIso();
    let h = "";
    for (let w = 0; w < 4; w++) {
      h += `<div class="g-wk"><b>W${w + 1}</b><span>${PH[w]}</span></div>`;
      for (let k = 0; k < 7; k++) {
        const i = w * 7 + k, d = addD(start(), i), s = sessOf(d), done = G.days[d]?.done || setsOn(d).length;
        h += `<a class="g-day${d === sel ? " sel" : ""}${d === t ? " today" : ""}" href="#/gym/${d}" aria-label="Day ${i + 1}, ${fd(d, { weekday: "long", day: "numeric", month: "long" })}, ${SNAME[s]}">
          <span class="g-disc" style="background:${COLV[s]}${s === "C" ? ";color:#141414" : ""}">${s === "R" ? "rest" : s}${done ? '<i class="g-tick">✓</i>' : ""}${i === 4 || i === 24 ? '<i class="g-test">test</i>' : ""}</span>
          <span class="g-dt">${d === t ? "Today" : `<span class="g-wd">${fd(d, { weekday: "short" })} </span>${pd(d).getDate()}`}</span></a>`;
      }
    }
    return `<div class="g-rack">${h}</div>`;
  }

  // ------------------------------------------------------------ session logger
  function exBlock(ex, d, w, num, col) {
    const i = w - 1, logged = setsOn(d).filter((s) => s.ex === ex.id);
    const prev = prevSets(ex.id, d);
    const p = ex.custom ? null : parseSets(at(ex.sets, i));
    const cnt = (sd) => logged.filter((s) => s.side === sd).length;
    const cR = cnt("R"), cL = cnt("L");
    let count = "", doneAll = false, nextSide = "";
    if (p && ex.kind !== "info") {
      if (p.all != null) {
        const n = perSide(ex) ? Math.max(cR, cL, cnt("")) : logged.length;
        count = `${n}/${p.all}`; doneAll = n >= p.all;
        if (ex.uni) nextSide = cR <= cL ? "R" : "L";
      } else {
        count = ["R", "L"].filter((sd) => p[sd] != null).map((sd) => `${sd} ${cnt(sd)}/${p[sd]}`).join(" · ");
        doneAll = ["R", "L"].every((sd) => p[sd] == null || cnt(sd) >= p[sd]);
        nextSide = cR <= cL && cR < (p.R || 0) ? "R" : cL < (p.L || 0) ? "L" : cR < (p.R || 0) ? "R" : "R";
      }
    } else if (ex.custom) count = `${logged.length} set${logged.length === 1 ? "" : "s"}`;
    const lastSide = logged.length ? logged[logged.length - 1].side : "";
    const ref = [...logged].reverse().find((s) => s.side === nextSide) || prev?.sets.find((s) => s.side === nextSide) || logged[logged.length - 1] || prev?.sets[0];
    const rir = RIRT[ex.rir] ? RIRT[ex.rir][i] : ex.rir;
    const prevTxt = prev ? `Last time (${fd(prev.date)}): ${["R", "L", ""].map((sd) => { const l = prev.sets.filter((s) => s.side === sd); return l.length ? `${sd ? sd + " " : ""}${l.map((s) => setTxt(s).replace(/ <span.*<\/span>/, "")).join(", ")}` : ""; }).filter(Boolean).join(" · ")}` : ex.custom ? "" : "First time – start light and find the weight that matches the RIR target.";
    const presc = ex.custom ? "Extra exercise" : `<b>${esc(at(ex.sets, i))}</b> sets × <b>${esc(at(ex.reps, i))}</b> · ${ex.rir === "eff" ? "effort" : RIRT[ex.rir] ? "RIR" : "effort"} <b>${esc(rir)}</b> · rest ${esc(ex.rest)} · ${esc(at(ex.tempo, i))}`;
    const kgIn = `<label>kg<input name="kg" inputmode="decimal" autocomplete="off" value="${ref?.kg ?? ""}" placeholder="0"></label>`;
    const repsIn = `<label>reps<input name="reps" inputmode="numeric" autocomplete="off" value="${ref?.reps ?? ""}"></label>`;
    const secsIn = `<label>sec<input name="secs" inputmode="numeric" autocomplete="off" value="${ref?.secs ?? ""}"></label>`;
    const fields = ex.kind === "hold" ? kgIn + secsIn : ex.kind === "secs" ? secsIn : kgIn + repsIn;
    const form = ex.kind === "info" ? "" : `<form class="g-add" data-ex="${ex.id}" data-name="${esc(ex.n)}">
      ${ex.uni || ex.custom ? `<div class="seg g-side">${(ex.custom ? ["", "R", "L"] : ["R", "L"]).map((sd) => `<button type="button" data-side="${sd}" class="${sd === (ex.custom ? lastSide : nextSide) ? "on" : ""}">${sd || "Both"}</button>`).join("")}</div>` : ""}
      ${fields}
      ${ex.kind === "kg" ? `<label>RIR<select name="rir"><option value=""></option>${[0, 1, 2, 3, 4, 5].map((v) => `<option ${String(ref?.rir ?? "") === String(v) ? "selected" : ""}>${v}</option>`).join("")}</select></label>` : ""}
      <button class="btn primary" type="submit">Add set</button></form>`;
    return `<div class="g-ex${doneAll ? " complete" : ""}" data-ex="${ex.id}">
      <div class="g-ex-head"><span class="g-num" style="background:${col}${col === COLV.C ? ";color:#141414" : ""}">${num}</span>
        <div class="g-ex-main"><div class="g-ex-name">${esc(ex.n)} <span class="g-tag ${ex.tag === "knee" ? "knee" : ""}">${esc(ex.tag)}</span></div>
        <div class="g-presc">${presc}</div>${ex.note ? `<div class="g-note">This week: ${esc(at(ex.note, i))}</div>` : ""}</div>
        ${count ? `<span class="g-count">${doneAll ? "✓ " : ""}${count}</span>` : ""}</div>
      ${prevTxt ? `<div class="g-last">${esc(prevTxt)}</div>` : ""}
      ${logged.length ? `<div class="g-sets">${logged.map((s, k) => `<span class="g-set"><b>${k + 1}</b>${s.side ? `<i class="g-sd ${s.side}">${s.side}</i>` : ""}${setTxt(s)}<button type="button" data-del="${s.id}" aria-label="Delete set">×</button></span>`).join("")}</div>` : ""}
      ${form}
      ${ex.cue ? `<details><summary>How &amp; why</summary><p>${esc(ex.cue)}</p><p class="muted">${esc(ex.why)}</p></details>` : ""}
    </div>`;
  }

  function sessHTML(d) {
    const s = sessOf(d), w = weekOf(d), i = idxOf(d), day = G.days[d] || {};
    const inPlan = i >= 0 && i < 28;
    const planEx = PLAN[s]?.ex || [];
    const loggedIds = [...new Set(setsOn(d).map((x) => x.ex))];
    const others = [...new Set([...loggedIds.filter((id) => !planEx.some((e) => e.id === id)), ...(extras[d] || [])])];
    const garmin = G.garmin[d] || [];
    const notes = [];
    if (s === "A" && (i === 4 || i === 24)) notes.push("<b>Test day.</b> After the warm-up and the isometric primer, test the single-leg extension (10-rep max each leg, 90° → 45°) and enter it under Tests below. Log bench as normal.");
    if (inPlan && i >= 24 && s !== "R" && s !== "F") notes.push("<b>Taper:</b> drop one set from every exercise and keep legs at RIR 3.");
    if (inPlan && w === 2 && (s === "A" || s === "C")) notes.push("New this week: 2-up/1-down eccentrics. Lift with both legs, lower with one, slowly. Start lighter than you think.");
    const col = COLV[s];
    const head = `<div class="card-head"><div><h2>${inPlan ? `Day ${i + 1} · ` : ""}${fd(d, { weekday: "long", day: "numeric", month: "long" })}</h2>
        <p class="sub">${inPlan ? `Week ${w}, ${PH[w - 1]}: ${PHN[w - 1]}` : "Outside the 4-week block – log anything you like."}</p></div>
        ${seg("g-stype", [["A", "A"], ["B", "B"], ["C", "C"], ["R", "Rest"], ["F", "Free"]], s)}</div>`;
    const meta = `<div class="g-meta">
        <label class="g-chk"><input type="checkbox" id="g-done" ${day.done ? "checked" : ""}> Session done</label>
        <label>Knee pain <select id="g-pain"><option value=""></option>${[...Array(11).keys()].map((v) => `<option ${day.pain === v ? "selected" : ""}>${v}</option>`).join("")}</select></label>
        <input id="g-note" placeholder="Note (how it felt, machine settings…)" value="${esc(day.note || "")}" maxlength="1000">
      </div>
      ${garmin.length ? `<p class="small muted" style="margin:6px 0 0">On your watch: ${garmin.map((a) => `<a href="#/activity/${a.id}">${esc(a.name)}</a> · ${a.min} min${a.hr ? ` · ${a.hr} bpm` : ""}`).join(" · ")}</p>` : ""}`;
    let body = "";
    if (s === "R") {
      body = `<h3 class="g-h3" style="color:var(--text-primary)">${SNAME.R}</h3><ul class="why">${REST.map((x) => `<li>${esc(x)}</li>`).join("")}</ul><p class="small muted">Trained anyway? Switch to <b>Free</b> to log it.</p>`;
    } else {
      body = `${s !== "F" ? `<p class="g-focus"><i class="key" style="background:${col}"></i><b>${s} · ${SNAME[s]}</b> – ${esc(PLAN[s].f)}</p>
        <details class="g-warm"><summary>Warm-up</summary><ul class="why">${WARM[PLAN[s].warm].map((x) => `<li>${esc(x)}</li>`).join("")}</ul></details>` : `<p class="g-focus"><b>Free workout</b> – log any exercise from the plan or your own.</p>`}
        ${notes.map((n) => `<div class="g-banner">${n}</div>`).join("")}
        <div class="g-exs">${planEx.map((e, k) => exBlock(e, d, w, k + 1, col)).join("")}
        ${others.map((id, k) => exBlock(exInfo(id, setsOn(d).find((x) => x.ex === id)?.name || id.slice(2).replace(/-/g, " ")), d, w, planEx.length + k + 1, "var(--text-muted)")).join("")}</div>
        <form class="g-addex"><select id="g-pick"><option value="">Add an exercise…</option>${Object.values(EXBY).filter((e) => e.kind !== "info").map((e) => `<option value="${e.id}">${esc(e.n)}</option>`).join("")}<option value="__new">New exercise…</option></select>
          <input id="g-newname" placeholder="Name, e.g. Push-ups" maxlength="60" hidden><button class="btn" type="submit">Add</button></form>
        <p class="small muted" style="margin:10px 0 0">R = right, L = left. Start each single-leg exercise with the right; the left matches its reps. Weights pre-fill from your last set.</p>`;
    }
    return head + meta + body;
  }

  // ------------------------------------------------------------ page
  async function renderGym(arg) {
    G = await api("/api/gym", true);
    const t = todayIso(), st = start(), ti = idxOf(t), end = addD(st, 27);
    let sel = arg && /^\d{4}-\d{2}-\d{2}$/.test(arg) ? arg : ti < 0 ? st : ti > 27 ? end : t;
    const wNow = weekOf(t <= end ? (t < st ? st : t) : end);
    const wkStart = addD(st, (wNow - 1) * 7), wkEnd = addD(wkStart, 6);
    const plannedWk = {}; const sessWk = [];
    for (let k = 0; k < 7; k++) { const d = addD(wkStart, k), s = sessOf(d); if (PLAN[s]) { sessWk.push(d); const g = plannedGroups(s, wNow); for (const [x, v] of Object.entries(g)) plannedWk[x] = (plannedWk[x] || 0) + v; } }
    const wkSets = G.sets.filter((s) => s.date >= wkStart && s.date <= wkEnd);
    const loggedWk = loggedGroups(wkSets);
    const countable = (id) => (EXBY[id] ? EXBY[id].count !== false && EXBY[id].kind !== "info" : true);
    const loggedEntries = wkSets.filter((s) => countable(s.ex)).length;
    const plannedEntries = sessWk.reduce((a, d) => a + (PLAN[sessOf(d)]?.ex || []).filter((e) => e.count !== false && e.kind !== "info").reduce((b, e) => { const p = parseSets(at(e.sets, wNow - 1)); return b + (p.all != null ? p.all * (perSide(e) ? 2 : 1) : (p.R || 0) + (p.L || 0)); }, 0), 0);
    const until = t < end ? t : end;
    const plannedSoFar = [...Array(28).keys()].map((k) => addD(st, k)).filter((d) => d <= until && PLAN[sessOf(d)]).length;
    const doneDates = new Set([...G.sets.filter((s) => s.date >= st && s.date <= end).map((s) => s.date), ...Object.values(G.days).filter((x) => x.done && x.date >= st && x.date <= end).map((x) => x.date)]);
    const pains = Object.values(G.days).filter((x) => x.pain != null).sort((a, b) => a.date.localeCompare(b.date));
    const last3 = pains.slice(-3), painAvg = last3.length ? last3.reduce((a, b) => a + b.pain, 0) / last3.length : null;
    const benchHist = hist("bench")[""] || [];
    const T = G.tests || {};
    const lsi = T.lr1 && T.ll1 ? T.lr1 / T.ll1 * 100 : T.lr0 && T.ll0 ? T.lr0 / T.ll0 * 100 : null;
    const blockTxt = ti < 0 ? `starts in ${-ti} day${ti === -1 ? "" : "s"}` : ti > 27 ? "block finished" : `day ${ti + 1} of 28`;
    const usedEx = Object.values(EXBY).filter((e) => e.kind === "kg" && G.sets.some((s) => s.ex === e.id));
    const strSel = usedEx.some((e) => e.id === store.get("g-str", "bench")) ? store.get("g-str", "bench") : usedEx[0]?.id || "bench";

    app.innerHTML = `<div id="g-root">
      <div class="page-head"><div><h1>Gym</h1><p class="sub">Knee-smart 4-week block · ${blockTxt}${ti >= 0 && ti <= 27 ? ` · week ${weekOf(t)}, ${PH[weekOf(t) - 1]}` : ""}</p></div>
        <label class="g-start">Day 1 <input type="date" id="g-startin" value="${st}"></label></div>
      <div class="tiles">
        ${tile("Sessions done", `${doneDates.size}`, `/ ${plannedSoFar}`, "planned so far")}
        ${tile("Sets this week", n0(loggedEntries), `/ ${plannedEntries}`, `plan week ${wNow} · ${sessWk.length} sessions`)}
        ${tile("Knee pain", painAvg == null ? "–" : n1(painAvg), "/ 10", last3.length ? `average of last ${last3.length} entr${last3.length === 1 ? "y" : "ies"}` : "rate it after each session")}
        ${tile("Bench, est. 1RM", benchHist.length ? n1(benchHist[benchHist.length - 1].y) : "–", "kg", benchHist.length > 1 ? `${benchHist[benchHist.length - 1].y >= benchHist[0].y ? "▲" : "▼"} ${n1(Math.abs(benchHist[benchHist.length - 1].y - benchHist[0].y))} kg since ${fd(benchHist[0].x, { day: "numeric", month: "short" })}` : "from your best set")}
        ${tile("Quad symmetry", lsi ? Math.round(lsi) : "–", lsi ? "%" : "", lsi ? "right ÷ left · target 90%+" : "physio test: 80% · test on day 5")}
      </div>
      <div class="grid">
        ${card("28-day plan", rackHTML(sel) + `<div class="legend" style="margin-top:12px">${["A", "B", "C", "R"].map((s) => `<span><i class="key" style="background:${COLV[s]}"></i>${s === "R" ? "Rest" : s + " · " + SNAME[s]}</span>`).join("")}</div>`, { span: 12, sub: "A → B → C → rest. Tap a day to log it. Need an extra rest day? Take it, then switch the next day to the letter you missed." })}
        <section class="card span-12 g-sess" id="g-sess">${sessHTML(sel)}</section>
        ${card("Sets this week vs plan", groupBars(plannedWk, loggedWk), { span: 6, sub: `${fd(wkStart, { day: "numeric", month: "short" })} – ${fd(wkEnd, { day: "numeric", month: "short" })} · hard sets per muscle (isometric holds not counted)` })}
        ${card("Knee pain", pains.length ? `<div class="chart" id="g-painch"></div>` : '<p class="muted small">Rate your knee 0–10 after each session (top of the session card) and the trend appears here.</p>', { span: 6, sub: "0–2 train as written · 3–4 hold, go shallower · 5+ stop that exercise" })}
        ${card("Strength progress", usedEx.length ? `<div class="chart" id="g-strch"></div><p class="small muted" style="margin:8px 0 0">Estimated 1-rep max from your best set each day (kg × (1 + reps ÷ 30)). From week 2, 2-up/1-down sets make the right leg extension and left leg curl jump – that's the method, not a miracle.</p>` : '<p class="muted small">Log a few sessions and your strength trend per exercise appears here.</p>', { span: 6, right: usedEx.length ? `<select id="g-strsel">${usedEx.map((e) => `<option value="${e.id}" ${e.id === strSel ? "selected" : ""}>${esc(e.n)}</option>`).join("")}</select>` : "" })}
        ${card("Tests", testsHTML(), { span: 6, sub: "Day 5 and day 25 (strength), day 1 and day 28 (tape). Saved on the Pi." })}
        ${card("History", historyHTML(), { span: 12 })}
        ${card("Rules", `<div class="g-rules">
          <div><b>Pain traffic light</b><ul class="why"><li><b>0–2 / 10</b>, back to normal next morning: train as written, progress when reps allow.</li><li><b>3–4</b>, or more morning stiffness: keep the weight, go shallower or drop a set; no progression next time.</li><li><b>5+</b>, sharp or catching pain: stop that exercise today; next time go back to your last green weight. Swelling, locking, giving way or night pain → stop leg training and call your physio.</li></ul></div>
          <div><b>How hard</b><ul class="why"><li>RIR 2 = stop with 2 clean reps left.</li><li>Week 1: RIR 3 everywhere. Upper body then RIR 2 → 1; knee exercises never below RIR 2.</li><li>Rest 2–3 min on big lifts, 60–90 s on small ones.</li></ul></div>
          <div><b>When to add weight</b><ul class="why"><li>All sets at the top of the rep range at the target RIR → add next time: barbell +2.5 kg, dumbbells +1–2 kg, machines +1 plate.</li><li>Knee exercises only after a green session and a green next morning; open the range ~10–15° a week while green.</li></ul></div>
        </div>`, { span: 12 })}
      </div></div>`;

    const root = $("#g-root");
    if (pains.length) drawPain(pains);
    if (usedEx.length) drawStr(strSel);
    wire(root, sel);
    if (arg) setTimeout(() => { const el = $("#g-sess"); if (el) el.scrollIntoView({ block: "start" }); }, 30);
  }

  function hist(exId) {
    const by = {};
    for (const s of G.sets) {
      if (s.ex !== exId) continue;
      const v = e1rm(s); if (v == null) continue;
      const k = s.side || "";
      by[k] = by[k] || {};
      if (!by[k][s.date] || v > by[k][s.date]) by[k][s.date] = v;
    }
    const out = {};
    for (const [k, m] of Object.entries(by)) out[k] = Object.entries(m).sort().map(([x, y]) => ({ x, y }));
    return out;
  }

  function groupBars(planned, logged) {
    const max = Math.max(1, ...GROUPS.map(([k]) => Math.max(planned[k] || 0, logged[k] || 0)));
    const rows = GROUPS.filter(([k]) => planned[k] || logged[k]);
    if (!rows.length) return '<p class="muted small">No sets planned this week.</p>';
    return `<div class="g-bars">${rows.map(([k, l]) => { const p = planned[k] || 0, d = logged[k] || 0;
      return `<div class="g-bar"><span>${l}</span><div class="g-track"><i class="pl" style="width:${p / max * 100}%"></i><i class="dn${d >= p && p ? " full" : ""}" style="width:${Math.min(d, max) / max * 100}%"></i></div><span class="num">${d} / ${p}</span></div>`; }).join("")}</div>
      <p class="small muted" style="margin:8px 0 0">Pale bar = planned for this plan week, solid = logged. Bilateral hinges count for both hamstrings.</p>`;
  }

  function testsHTML() {
    const T = G.tests || {};
    const f = (k, l) => `<label>${l}<input data-t="${k}" inputmode="decimal" value="${T[k] ?? ""}"></label>`;
    const lsi = (r, l) => (T[r] && T[l] ? `<b>${Math.round(T[r] / T[l] * 100)}%</b>` : "–");
    const e = (w, r) => (T[w] && T[r] ? `<b>${n1(T[w] * (1 + T[r] / 30))} kg</b>` : "–");
    const gap = (r, l) => (T[r] && T[l] ? `<b>${n1(T[l] - T[r])} cm</b>` : "–");
    return `<div class="g-tests">
      <div><b>Quad symmetry</b><p class="small muted">Single-leg extension 90° → 45°, heaviest weight for 10 clean reps (stop if pain hits 3).</p>
        <div class="g-tin">${f("lr0", "Day 5 R kg")}${f("ll0", "Day 5 L kg")}${f("lr1", "Day 25 R kg")}${f("ll1", "Day 25 L kg")}</div>
        <p class="small">Symmetry: ${lsi("lr0", "ll0")} → ${lsi("lr1", "ll1")}</p></div>
      <div><b>Bench press</b><p class="small muted">Best working set.</p>
        <div class="g-tin">${f("bw0", "Day 5 kg")}${f("br0", "Day 5 reps")}${f("bw1", "Day 25 kg")}${f("br1", "Day 25 reps")}</div>
        <p class="small">Est. 1RM: ${e("bw0", "br0")} → ${e("bw1", "br1")}</p></div>
      <div><b>Tape</b><p class="small muted">Morning, before eating. Thigh 15 cm above the kneecap.</p>
        <div class="g-tin">${f("tr0", "Day 1 thigh R")}${f("tl0", "Day 1 thigh L")}${f("tr1", "Day 28 thigh R")}${f("tl1", "Day 28 thigh L")}${f("c0", "Day 1 chest")}${f("c1", "Day 28 chest")}</div>
        <p class="small">Thigh gap (L − R): ${gap("tr0", "tl0")} → ${gap("tr1", "tl1")}</p></div></div>`;
  }

  function historyHTML() {
    const dates = [...new Set([...G.sets.map((s) => s.date), ...Object.values(G.days).filter((x) => x.pain != null || x.done || x.note).map((x) => x.date)])].sort().reverse();
    if (!dates.length) return '<p class="muted small">Nothing logged yet. Open today in the plan above and add your first set.</p>';
    return `<div class="table-wrap"><table><thead><tr><th>Date</th><th>Session</th><th class="num">Sets</th><th class="num">Volume</th><th class="num">Knee</th><th>Note</th><th>Watch</th></tr></thead><tbody>
      ${dates.slice(0, 60).map((d) => { const l = setsOn(d), s = sessOf(d), vol = l.reduce((a, x) => a + (x.kg || 0) * (x.reps || 0), 0), dy = G.days[d] || {}, gm = G.garmin[d] || [];
        return `<tr class="click" data-go="${d}"><td class="muted">${fd(d, { weekday: "short", day: "numeric", month: "short" })}</td><td><i class="key" style="background:${COLV[s]}"></i> ${s === "R" ? "Rest" : s === "F" ? "Free" : s + " · " + SNAME[s]}</td><td class="num">${l.length}</td><td class="num">${vol ? n0(vol) + " kg" : "–"}</td><td class="num">${dy.pain ?? "–"}</td><td class="g-notecell">${esc(dy.note || "")}</td><td>${gm.map((a) => `${a.min} min${a.hr ? ` · ${a.hr} bpm` : ""}`).join(", ")}</td></tr>`; }).join("")}
    </tbody></table></div>`;
  }

  function drawPain(pains) {
    const c = C();
    mkChart("#g-painch", {
      type: "line",
      data: { datasets: [line("Knee pain", pains.map((p) => ({ x: p.date, y: p.pain })), c.critical, { tension: 0, pointRadius: 4, pointBackgroundColor: c.critical, fmt: (r) => `${r.y} / 10` })] },
      options: { scales: axes({ unit: "day", yMin: 0, yMax: 10 }), plugins: { bands: { items: [{ from: 0, to: 2.5, color: "rgba(12,163,12,.08)", label: "train" }, { from: 2.5, to: 4.5, color: "rgba(250,178,25,.12)", label: "hold" }, { from: 4.5, to: 10, color: "rgba(208,59,59,.08)", label: "stop" }] } } },
    });
  }

  function drawStr(exId) {
    const ex = charts.find((ch) => ch.canvas.parentNode?.id === "g-strch");
    if (ex) { ex.destroy(); charts.splice(charts.indexOf(ex), 1); }
    const c = C(), h = hist(exId);
    const ds = [];
    if (h.R) ds.push(line("Right", h.R, c.critical, { tension: 0.2, pointRadius: 3.5, pointBackgroundColor: c.critical, fmt: (r) => n1(r.y) + " kg" }));
    if (h.L) ds.push(line("Left", h.L, c.text2, { tension: 0.2, pointRadius: 3.5, pointBackgroundColor: c.text2, fmt: (r) => n1(r.y) + " kg" }));
    if (h[""]) ds.push(line("Est. 1RM", h[""], c.s1, { tension: 0.2, pointRadius: 3.5, pointBackgroundColor: c.s1, fmt: (r) => n1(r.y) + " kg" }));
    mkChart("#g-strch", { type: "line", data: { datasets: ds }, options: { scales: axes({ unit: "day", yFmt: (v) => v + " kg" }) } });
  }

  // ------------------------------------------------------------ events
  function wire(root, sel) {
    const refreshSess = () => { $("#g-sess").innerHTML = sessHTML(sel); onSeg("g-stype", changeSess); };
    const refreshRack = () => { const r = $(".g-rack", root); if (r) r.outerHTML = rackHTML(sel); };
    const changeSess = async (v) => { G.days[sel] = { ...(G.days[sel] || { date: sel }), ...(await post("/api/gym/day", { date: sel, session: v })) }; refreshSess(); refreshRack(); };
    onSeg("g-stype", changeSess);

    $("#g-startin").addEventListener("change", async (e) => { if (!e.target.value) return; await post("/api/gym/settings", { start: e.target.value }); if (location.hash === "#/gym") route(); else location.hash = "#/gym"; });
    $("#g-strsel")?.addEventListener("change", (e) => { store.set("g-str", e.target.value); drawStr(e.target.value); });

    root.addEventListener("click", async (e) => {
      const sd = e.target.closest("[data-side]");
      if (sd) { sd.parentNode.querySelectorAll("button").forEach((b) => b.classList.toggle("on", b === sd)); return; }
      const del = e.target.closest("[data-del]");
      if (del) {
        if (!del.classList.contains("confirm")) { del.classList.add("confirm"); del.textContent = "delete?"; setTimeout(() => { if (del.isConnected) { del.classList.remove("confirm"); del.textContent = "×"; } }, 3000); return; }
        await post("/api/gym/set/" + del.dataset.del, null, "DELETE");
        G.sets = G.sets.filter((s) => s.id !== +del.dataset.del);
        refreshSess(); refreshRack(); return;
      }
      const go = e.target.closest("[data-go]");
      if (go && !e.target.closest("a")) location.hash = "#/gym/" + go.dataset.go;
    });

    root.addEventListener("submit", async (e) => {
      e.preventDefault();
      const f = e.target;
      if (f.classList.contains("g-add")) {
        const side = f.querySelector(".g-side .on")?.dataset.side || "";
        const val = (n) => f.elements[n]?.value.trim() ?? "";
        const btn = f.querySelector("[type=submit]");
        btn.disabled = true;
        try {
          const row = await post("/api/gym/set", { date: sel, session: sessOf(sel), ex: f.dataset.ex, name: f.dataset.name, side, kg: val("kg"), reps: val("reps"), secs: val("secs"), rir: val("rir") });
          G.sets.push(row);
          if (!G.days[sel]) G.days[sel] = { date: sel, session: sessOf(sel) };
          const exId = f.dataset.ex;
          refreshSess(); refreshRack();
          $(`.g-ex[data-ex="${exId}"] .g-add input`)?.focus({ preventScroll: true });
        } catch (err) { btn.disabled = false; alertIn(f, err.message); }
      } else if (f.classList.contains("g-addex")) {
        const pick = $("#g-pick").value;
        let id = pick;
        if (pick === "__new") { const nm = $("#g-newname").value.trim(); if (!nm) return; id = slug(nm); EXBY[id] = EXBY[id] || exInfo(id, nm); }
        if (!id) return;
        (extras[sel] = extras[sel] || []).includes(id) || extras[sel].push(id);
        refreshSess();
        $(`.g-ex[data-ex="${id}"]`)?.scrollIntoView({ block: "center" });
      }
    });

    root.addEventListener("change", async (e) => {
      const t = e.target;
      if (t.id === "g-pick") { $("#g-newname").hidden = t.value !== "__new"; if (t.value === "__new") $("#g-newname").focus(); }
      if (t.id === "g-done" || t.id === "g-pain" || t.id === "g-note") {
        const body = { date: sel, session: sessOf(sel) };
        if (t.id === "g-done") body.done = t.checked;
        if (t.id === "g-pain") body.pain = t.value;
        if (t.id === "g-note") body.note = t.value;
        G.days[sel] = await post("/api/gym/day", body);
        refreshRack();
      }
      if (t.dataset.t) {
        G.tests = { ...(G.tests || {}), [t.dataset.t]: t.value };
        const res = await post("/api/gym/settings", { tests: G.tests });
        G.tests = res.tests;
      }
    });
  }

  function alertIn(form, msg) {
    let el = form.querySelector(".g-err");
    if (!el) { el = document.createElement("span"); el.className = "g-err"; form.appendChild(el); }
    el.textContent = msg;
    setTimeout(() => el.remove(), 4000);
  }

  // ------------------------------------------------------------ overview card
  function gymToday(g) {
    if (!g) return "";
    G = g;
    const t = todayIso(), i = idxOf(t);
    if (i < -7 || i > 27) return "";
    const s = sessOf(t), n = setsOn(t).length;
    const label = i < 0 ? `Gym block starts ${fd(start(), { weekday: "long", day: "numeric", month: "short" })}` : s === "R" ? "Gym: rest day" : `Gym · ${s === "F" ? "Free" : s}`;
    const sub = i < 0 ? "Day 1: A · Quads & chest" : s === "R" ? "Easy bike or walk; rate your knee" : SNAME[s];
    const hint = i >= 0 && (s === "A" || s === "C") ? "Leg day – keep any ride or run easy today." : i >= 0 && s === "B" ? "No knee load in the gym today." : "";
    return `<a class="wo-mini" href="#/gym">
      <div class="wo-top"><span class="ic" style="background:${COLV[s === "F" ? "F" : i < 0 ? "A" : s]};${s === "C" && i >= 0 ? "color:#141414" : ""}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 7v10M18 7v10M3 10v4M21 10v4M6 12h12"/></svg></span>
        <div style="min-width:0"><div class="wo-sport">${i >= 0 ? `Day ${i + 1} of 28 · week ${weekOf(t)}` : "Gym"}</div><div class="wo-title">${esc(label)}</div></div></div>
      <div class="wo-meta">${esc(sub)}${n ? ` · ${n} sets logged` : ""}</div>
      ${hint ? `<div class="wo-target">${hint}</div>` : ""}</a>`;
  }

  window.renderGym = renderGym;
  window.gymToday = gymToday;
})();
