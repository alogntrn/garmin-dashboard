/* Recovery tab (board "Recovery"): six cards against your normal range, tap one for its full chart, and the patterns
   in your data. HRV, resting HR and sleep use the coach's checks, so this page and Today agree. */
(function () {
  "use strict";

  const REC_RANGES = [[30, "1 month"], [90, "3 months"], [180, "6 months"], [365, "1 year"], [730, "2 years"]];
  const RKEY = "rec-range", RDEF = 90;
  const M = {
    hrv: { name: "HRV", icon: "pulse", key: "hrv_night", factor: "HRV", out: "▼ Low" },
    rhr: { name: "Resting HR", icon: "heart", key: "resting_hr", factor: "Resting HR", out: "▲ High" },
    sleep: { name: "Sleep", icon: "moon", key: "sleep_s", factor: "Sleep", out: "▼ Short" },
    bb: { name: "Body Battery", icon: "bolt", key: "bb_high" },
    stress: { name: "Stress", icon: "wave", key: "stress_avg" },
    steps: { name: "Steps", icon: "steps", key: "steps" },
  };
  const ORDER = ["hrv", "rhr", "sleep", "bb", "stress", "steps"];
  const STAGES = [["Deep", "deep_s"], ["Light", "light_s"], ["REM", "rem_s"]];
  const ABOUT = {
    hrv: "Heart rate variability while you sleep. Near or above your usual means recovered; several low nights in a row often mean fatigue, stress or illness. Shaded: Garmin's baseline range.",
    rhr: "Lower is generally better. A rise of 3–5 bpm over a few days often means fatigue or illness.",
    sleep: "Hours per night by stage, and Garmin's sleep score.",
    bb: "Each day from its lowest to its highest Body Battery.",
    stress: "Average stress per day, from Garmin (0–100).",
    steps: "Steps per day.",
  };
  const NO_DATA = { hrv: "No HRV data from Garmin yet.", rhr: "No resting heart rate yet.", sleep: "No sleep recorded yet.", bb: "No Body Battery data from Garmin yet.", stress: "No stress data from Garmin yet.", steps: "No step data from Garmin yet." };

  const pad2 = (x) => String(x).padStart(2, "0");
  const localIso = (d = new Date()) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
  const hmin = (s) => { const m = Math.round(s / 60); return `${Math.floor(m / 60)} h ${pad2(m % 60)}`; };
  const ic = (n) => (window.UIC && window.UIC[n]) || "";
  const lastOf = (rows, key) => { for (let i = rows.length - 1; i >= 0; i--) if (rows[i][key] != null) return rows[i]; return null; };
  const tail = (rows, n) => rows.slice(Math.max(0, rows.length - n));

  // ------------------------------------------------------------ small inline charts for the cards
  // The SVG stretches to the card (preserveAspectRatio none); strokes and the end dot keep their size.
  // minSpan keeps a 1-bpm wobble from filling the whole card.
  function spark(vals, band, minSpan = 0) {
    const w = 200, h = 56, pts = vals.map((v, i) => [i, v]).filter(([, v]) => v != null);
    if (pts.length < 2) return "";
    const ys = pts.map(([, v]) => v).concat(band ? [band.lo, band.hi] : []);
    let lo = Math.min(...ys), hi = Math.max(...ys);
    if (hi - lo < minSpan) { const mid = (hi + lo) / 2; lo = mid - minSpan / 2; hi = mid + minSpan / 2; }
    const pd = (hi - lo) * 0.18 || 1; lo -= pd; hi += pd;
    const X = (i) => 3 + (i / Math.max(1, vals.length - 1)) * (w - 6), Y = (v) => h - 3 - ((v - lo) / (hi - lo)) * (h - 6);
    let d = "", prev = -2;
    for (const [i, v] of pts) { d += `${i === prev + 1 ? "L" : "M"}${X(i).toFixed(1)} ${Y(v).toFixed(1)}`; prev = i; }
    const [li, lv] = pts[pts.length - 1];
    const bd = band ? `<rect class="bd" x="0" y="${Y(band.hi).toFixed(1)}" width="${w}" height="${Math.max(2, Y(band.lo) - Y(band.hi)).toFixed(1)}"/>` : "";
    return `<svg class="rc-svg" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true">${bd}<path class="ln" d="${d}"/><path class="dt" d="M${X(li).toFixed(1)} ${Y(lv).toFixed(1)}h.01"/></svg>`;
  }
  function stackBars(rows) {
    const w = 200, h = 56, n = rows.length, gap = 6, bw = (w - gap * (n - 1)) / n;
    const tot = (r) => STAGES.reduce((a, [, k]) => a + (r[k] || 0), 0);
    const max = Math.max(...rows.map(tot), 1);
    const out = rows.map((r, i) => {
      let y = h;
      return STAGES.map(([, k], si) => {
        const hh = ((r[k] || 0) / max) * (h - 2);
        y -= hh;
        return hh > 0 ? `<rect class="s${si}" x="${(i * (bw + gap)).toFixed(1)}" y="${y.toFixed(1)}" width="${bw.toFixed(1)}" height="${Math.max(0, hh - 1).toFixed(1)}"/>` : "";
      }).join("");
    });
    return `<svg class="rc-svg" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true">${out.join("")}</svg>`;
  }
  function plainBars(vals, band) {
    const w = 200, h = 56, n = vals.length, gap = 4, bw = (w - gap * (n - 1)) / n;
    const max = Math.max(...vals.filter((v) => v != null), band ? band.hi : 0, 1);
    const Y = (v) => h - (v / max) * (h - 2);
    const bd = band ? `<rect class="bd" x="0" y="${Y(band.hi).toFixed(1)}" width="${w}" height="${Math.max(2, Y(band.lo) - Y(band.hi)).toFixed(1)}"/>` : "";
    const bs = vals.map((v, i) => (v == null ? "" : `<rect class="br${i === n - 1 ? " last" : ""}" x="${(i * (bw + gap)).toFixed(1)}" y="${Y(v).toFixed(1)}" width="${bw.toFixed(1)}" height="${(h - Y(v)).toFixed(1)}"/>`)).join("");
    return `<svg class="rc-svg" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true">${bd}${bs}</svg>`;
  }

  // ------------------------------------------------------------ what each card says
  const chip = (cls, text) => `<span class="rc-chip ${cls}">${text}</span>`;
  const usualChip = (st) => (st === "above" ? chip("", "▲ Above your usual") : st === "below" ? chip("", "▼ Below your usual") : "");
  const coachChip = (f, m) => (f && (f.status === "amber" || f.status === "red") ? chip(f.status === "red" ? "bad" : "warn", m.out) : "");

  function info(id, rows, factors, today) {
    const m = M[id], f = (factors || []).find((x) => x.name === m.factor);
    const base = { id, m, f, chip: "", viz: "" };
    if (id === "steps") {
      const last = lastOf(rows.filter((r) => r.date < today), "steps") || lastOf(rows, "steps");
      if (!last) return { ...base, empty: true };
      const nr = window.RL.normal(rows.filter((r) => r.date < today), "steps");
      return { ...base, last, value: n0(last.steps), unit: "", line: [last.date === today ? "today so far" : last.date === localIso(new Date(Date.now() - 864e5)) ? "yesterday" : fdate(last.date, { day: "numeric", month: "short" }), nr ? `usual ${n0(nr.lo)}–${n0(nr.hi)}` : ""].filter(Boolean).join(", "),
        chip: last.date === today ? "" : usualChip(window.RL.status(last.steps, nr)), viz: plainBars(tail(rows.filter((r) => r.date <= last.date), 14).map((r) => r.steps), nr) };
    }
    const last = lastOf(rows, m.key);
    if (!last) return { ...base, empty: true };
    const upto = rows.filter((r) => r.date <= last.date);
    if (id === "hrv") {
      const band = f && f.lo != null ? { lo: f.lo, hi: f.hi } : last.hrv_low ? { lo: last.hrv_low, hi: last.hrv_high } : null;
      const line = f && f.value != null ? `7-day ${n0(f.value)}, normal ${n0(f.lo)}–${n0(f.hi)}` : last.hrv_low ? `Garmin baseline ${n0(last.hrv_low)}–${n0(last.hrv_high)}` : "Normal range after about three weeks of nights";
      return { ...base, last, value: n0(last.hrv_night), unit: "ms", line, chip: coachChip(f, m), viz: spark(tail(upto, 30).map((r) => r.hrv_night), band, 16) };
    }
    if (id === "rhr") {
      const band = f && f.lo != null ? { lo: f.lo, hi: f.hi } : null;
      const line = f && f.value != null ? `7-day ${n0(f.value)}, normal ${n0(f.lo)}–${n0(f.hi)}` : "Normal range after about three weeks";
      return { ...base, last, value: n0(last.resting_hr), unit: "bpm", line, chip: coachChip(f, m), viz: spark(tail(upto, 30).map((r) => r.resting_hr), band, 8) };
    }
    if (id === "sleep") {
      const line = [last.sleep_score != null ? `score ${n0(last.sleep_score)}` : "", "normal 6–9 h"].filter(Boolean).join(", ");
      const nights = tail(upto.filter((r) => r.sleep_s != null), 7);
      return { ...base, last, value: hmin(last.sleep_s), unit: "", line, chip: coachChip(f, m),
        viz: nights.some((r) => r.deep_s != null) ? `${stackBars(nights)}<span class="rc-key">${STAGES.map(([l], i) => `<span><i class="s${i}"></i>${l}</span>`).join("")}</span>` : "" };
    }
    if (id === "bb") {
      const lo = last.bb_low ?? last.bb_high, hi = last.bb_high;
      const line = last.bb_charged != null ? `charged ${n0(last.bb_charged)} overnight` : "daily high";
      return { ...base, last, value: n0(hi), unit: "", line,
        viz: `<span class="u-range rc-bb" aria-hidden="true"><i class="tr"></i><i class="bd" style="left:${lo}%;width:${Math.max(1, hi - lo)}%"></i><i class="dt" style="left:${hi}%"></i></span><span class="rc-ends"><span>low ${n0(lo)}</span><span>high ${n0(hi)}</span></span>` };
    }
    // stress
    const nr = window.RL.normal(rows, "stress_avg");
    return { ...base, last, value: n0(last.stress_avg), unit: "", line: nr ? `usual ${n0(nr.lo)}–${n0(nr.hi)}` : "average for the day", chip: usualChip(window.RL.status(last.stress_avg, nr)), viz: spark(tail(upto, 30).map((r) => r.stress_avg), nr, 20) };
  }

  function cardHTML(x) {
    const head = `<span class="rc-name">${ic(x.m.icon)}${esc(x.m.name)}</span>`;
    if (x.empty) return `<a class="u-card rc-card" href="#/recovery/${x.id}">${head}<p class="rc-none">${esc(NO_DATA[x.id])}</p></a>`;
    const label = `${x.m.name} ${x.value}${x.unit ? " " + x.unit : ""}, ${x.line}. Show chart.`;
    return `<a class="u-card rc-card" href="#/recovery/${x.id}" aria-label="${esc(label)}">${head}
      <b class="rc-val u-num">${x.value}${x.unit ? `<small>${x.unit}</small>` : ""}</b>
      <span class="rc-line">${esc(x.line)}</span>${x.chip}
      <span class="rc-viz">${x.viz}</span></a>`;
  }

  // ------------------------------------------------------------ pages
  async function renderRecoveryPage(arg) {
    const [rv, co] = await Promise.all([api("/api/recovery?days=730"), api("/api/coach", true).catch(() => null)]);
    const rows = rv.rows || [], today = localIso();
    const factors = co?.readiness?.factors || [];
    if (arg && M[arg]) return detail(arg, rv, factors, today);
    const latest = [...rows].reverse().find((r) => r.hrv_night != null || r.resting_hr != null || r.sleep_s != null);
    pageHead("Recovery", { sub: window.RL.fresh(latest?.date || null, today) });
    if (!rows.length) { app.innerHTML = '<div class="empty">No wellness data yet. It arrives with the next sync.</div>'; return; }
    const h = window.RL.headline(co ? factors : null);
    const pats = window.RL.patterns(rv.corr);
    app.innerHTML = `<section class="rc">
      <p class="rc-call">${esc(h.call)}</p>${h.why ? `<p class="rc-why">${esc(h.why)}</p>` : ""}
      <div class="rc-grid">${ORDER.map((id) => cardHTML(info(id, rows, factors, today))).join("")}</div>
      <section class="u-card rc-pat"><h2>Patterns in your data</h2>
        ${pats.length ? `<ul>${pats.map((p) => `<li>${ic("trend")}<span>${esc(p)}</span></li>`).join("")}</ul>` : '<p class="u-c2">Not enough data for patterns yet. They need a few months of nights.</p>'}
        <p class="rc-foot">Over the last two years. These are links in your data, not causes.</p></section></section>`;
  }

  function detail(id, rv, factors, today) {
    const m = M[id], rows = rv.rows || [], c = C();
    const x = info(id, rows, factors, today);
    pageHead(m.name, { back: "#/recovery", backLabel: "Recovery", right: rangeBtn(RKEY, REC_RANGES, RDEF) });
    $("#pagehead .pg-range")?.addEventListener("click", () => rangeSheet(RKEY, REC_RANGES, RDEF));
    const days = rangeGet(RKEY, REC_RANGES, RDEF);
    const stageCols = [css("--u-sl1"), css("--u-sl2"), css("--u-sl3"), css("--u-ink3")]; // same as the card
    const charts = {
      hrv: [card("Overnight HRV", `<div class="chart" id="ch-hrv"></div>`, { span: 12, sub: ABOUT.hrv, right: legend([["Night", c.s1], ["7-day average", c.text2, "line"], ["Baseline", c.grid]]) })],
      rhr: [card("Resting heart rate", `<div class="chart" id="ch-rhr"></div>`, { span: 12, sub: ABOUT.rhr, right: legend([["Day", c.s1], ["7-day average", c.text2, "line"]]) })],
      sleep: [card("Sleep stages", `<div class="chart" id="ch-sleep"></div>`, { span: 8, sub: ABOUT.sleep, right: legend([["Deep", stageCols[0]], ["Light", stageCols[1]], ["REM", stageCols[2]], ["Awake", stageCols[3]]]) }),
        card("Sleep score", `<div class="chart" id="ch-score"></div>`, { span: 4 })],
      bb: [card("Body Battery", `<div class="chart" id="ch-bb"></div>`, { span: 12, sub: ABOUT.bb })],
      stress: [card("Stress", `<div class="chart" id="ch-stress"></div>`, { span: 12, sub: ABOUT.stress })],
      steps: [card("Steps", `<div class="chart" id="ch-steps"></div>`, { span: 12, sub: ABOUT.steps })],
    };
    const sum = x.empty ? "" : `<section class="u-card rc-sum"><b class="rc-val u-num">${x.value}${x.unit ? `<small>${x.unit}</small>` : ""}</b><span class="rc-line">${esc(x.line)}</span>${x.chip}</section>`;
    app.innerHTML = `${sum}<div class="grid">${charts[id].join("")}</div>`;
    draw(id, rv, days, stageCols);
  }

  // Full charts (moved from the old Recovery page).
  function draw(id, rv, days, stageCols) {
    const c = C(), rows = rv.rows || [];
    const cut = daysAgo(+days);
    const i0 = rows.findIndex((r) => r.date >= cut);
    const R = rows.slice(i0 < 0 ? rows.length : i0);
    const off = rows.length - R.length;
    const unit = +days <= 45 ? "day" : +days <= 120 ? "week" : "month";
    const pt = (key, f = (v) => v) => R.map((r) => ({ x: r.date, y: r[key] == null ? null : f(r[key]) }));
    const avg7 = (arr) => R.map((r, i) => ({ x: r.date, y: (arr || [])[i + off] ?? null }));
    const small = R.length > 200 ? 2 : 3;
    const nearestX = { mode: "index", intersect: false };
    const xLab = (v, i) => (i % Math.ceil(R.length / 6) === 0 ? fdate(R[i].date, { day: "numeric", month: "short" }) : "");
    const tipDay = (dp) => fdate(R[dp.dataIndex].date, { weekday: "short", day: "numeric", month: "short" });
    const empty = NO_DATA[id].replace(" yet.", " for this period.");
    const none = (key) => !R.some((r) => r[key] != null);
    if (id === "hrv") {
      mkChart("#ch-hrv", { type: "line", empty: none("hrv_night") ? empty : undefined, data: { datasets: [
        line("Baseline high", pt("hrv_high"), "transparent", { noTip: true, pointHoverRadius: 0, fill: "+1", backgroundColor: css("--accent-wash"), tension: 0, borderWidth: 0 }),
        line("Baseline low", pt("hrv_low"), "transparent", { noTip: true, pointHoverRadius: 0, tension: 0, borderWidth: 0 }),
        dots("HRV", pt("hrv_night"), c.s1, { pointRadius: small, fmt: (r) => n0(r.y) + " ms" }), line("7-day average", avg7(rv.hrv7), c.text2, { fmt: (r) => n1(r.y) + " ms" })] }, options: { interaction: nearestX, scales: axes({ unit }) } });
    } else if (id === "rhr") {
      mkChart("#ch-rhr", { type: "line", empty: none("resting_hr") ? empty : undefined, data: { datasets: [dots("Resting HR", pt("resting_hr"), c.s1, { pointRadius: small, fmt: (r) => n0(r.y) + " bpm" }), line("7-day average", avg7(rv.rhr7), c.text2, { fmt: (r) => n1(r.y) + " bpm" })] }, options: { interaction: nearestX, scales: axes({ unit }) } });
    } else if (id === "sleep") {
      const st = [["Deep", "deep_s"], ["Light", "light_s"], ["REM", "rem_s"], ["Awake", "awake_s"]];
      mkChart("#ch-sleep", { type: "bar", empty: none("sleep_s") ? empty : undefined, data: { labels: R.map((r) => r.date), datasets: st.map(([l, key], i) => bars(l, R.map((r) => (r[key] == null ? null : r[key] / 3600)), stageCols[i], { stack: "s", fmt: (v) => hm(v * 3600), borderRadius: i === 3 ? { topLeft: 3, topRight: 3 } : 0, borderSkipped: false, borderColor: c.surface, borderWidth: { top: i ? (R.length > 120 ? 0 : 1) : 0, left: 0, right: 0, bottom: 0 }, categoryPercentage: 0.9, barPercentage: 1 })) },
        options: { scales: axes({ time: false, stacked: true, yBegin: true, yFmt: (v) => v + " h", xFmt: xLab }), plugins: { tipTitle: (dp) => "Night to " + tipDay(dp) } } });
      mkChart("#ch-score", { type: "line", empty: none("sleep_score") ? "No sleep score for this period." : undefined, data: { datasets: [dots("Sleep score", pt("sleep_score"), c.s1, { pointRadius: small, fmt: (r) => n0(r.y) }), line("7-day average", R.map((r, i) => { const w = R.slice(Math.max(0, i - 6), i + 1).map((q) => q.sleep_score).filter((q) => q != null); return { x: r.date, y: w.length ? w.reduce((a, b) => a + b, 0) / w.length : null }; }), c.text2, { fmt: (r) => n1(r.y) })] }, options: { interaction: nearestX, scales: axes({ unit, yMax: 100 }) } });
    } else if (id === "bb") {
      mkChart("#ch-bb", { type: "bar", empty: none("bb_high") ? empty : undefined, data: { labels: R.map((r) => r.date), datasets: [bars("Body Battery", R.map((r) => (r.bb_high == null ? null : [r.bb_low ?? r.bb_high, r.bb_high])), c.s1, { borderRadius: 4, borderSkipped: false, borderWidth: 0, categoryPercentage: 0.85, barPercentage: 1, fmt: (v) => (Array.isArray(v) ? `${v[0]} → ${v[1]}` : v) })] },
        options: { scales: axes({ time: false, yMin: 0, yMax: 100, xFmt: xLab }), plugins: { tipTitle: tipDay } } });
    } else {
      const key = id === "stress" ? "stress_avg" : "steps";
      mkChart(`#ch-${id}`, { type: "bar", empty: none(key) ? empty : undefined, data: { labels: R.map((r) => r.date), datasets: [bars(M[id].name, R.map((r) => r[key]), c.s1, { borderWidth: 0, categoryPercentage: 0.85, barPercentage: 1, fmt: (v) => n0(v) })] },
        options: { scales: axes({ time: false, yBegin: true, xFmt: xLab }), plugins: { tipTitle: tipDay } } });
    }
  }

  window.renderRecoveryPage = renderRecoveryPage;
})();
