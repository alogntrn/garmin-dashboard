/* Activities tab: one list of Garmin activities and gym sessions by week, filters, search and a month calendar.
   Uses app.js globals (app, api, esc, store, n1, dur, pace, fdate, pageHead, loadGym, openSheet, closeSheet) inside
   functions only. Logic lives in activities-logic.js (window.AL). */
(function () {
  "use strict";

  const PAGE = 50;
  const SEGS = [["", "All"], ["run", "Runs"], ["ride", "Rides"], ["gym", "Gym"]];
  const SPORT_VAR = { run: "var(--u-runT)", ride: "var(--u-rideT)", other: "var(--u-ink2)" };
  const S = { sport: "", q: "", offset: 0, garmin: [], total: 0, view: "list", ym: null, seq: 0, fseq: 0 };

  const chev = () => window.UIC.chev.replace("u-ic", "u-ic chev");
  const hhmm = (secs) => { const m = Math.round((secs || 0) / 60); return `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, "0")}`; };
  const kg = (v) => Math.round(v || 0).toLocaleString("de-CH");
  const todayIso = () => window.GYM.todayIso();

  function when(it, recent) {
    const time = it.start && it.start.length > 10 ? it.start.slice(11, 16) : "";
    const day = recent ? fdate(it.date, { weekday: "long" }) : fdate(it.date, { weekday: "short", day: "numeric", month: "short" });
    return [day, time, it.kind === "gym" && it.test ? "test day" : ""].filter(Boolean).join(", ");
  }

  function row(it, recent) {
    if (it.kind === "gym") {
      const disc = it.letter ? esc(it.letter) : window.UIC.dumbbell;
      return `<a class="u-row ac-row" href="#/gym-session/${it.date}"><span class="u-disc ac-disc" aria-hidden="true">${disc}</span>
        <span class="rt"><b>${esc(it.name)}</b><span>${esc(when(it, recent))}</span></span>
        <span class="rr">${it.sets} ${it.sets === 1 ? "set" : "sets"}<span>${it.kg ? `${kg(it.kg)} kg` : it.mins ? `${it.mins} min` : ""}</span></span>${chev()}</a>`;
    }
    const icon = window.UIC[it.sport] || window.UIC.other;
    const second = it.sport === "run" && it.pace ? `${pace(it.pace)} /km` : dur(it.secs);
    return `<a class="u-row ac-row" href="#/activity/${it.id}"><span class="u-tile" style="background:${SPORT_VAR[it.sport] || SPORT_VAR.other}">${icon}</span>
      <span class="rt"><b>${esc(it.name)}</b><span>${esc(when(it, recent))}</span></span>
      <span class="rr">${it.km ? `${n1(it.km)} km` : dur(it.secs)}<span>${it.km ? esc(second) : ""}</span></span>${chev()}</a>`;
  }

  function totals(w) {
    const parts = [];
    if (w.km >= 0.05) parts.push(`${n1(w.km)} km`);
    if (w.secs) parts.push(hhmm(w.secs));
    if (!parts.length) parts.push(`${w.items.length} ${w.items.length === 1 ? "session" : "sessions"}`);  // e.g. one gym session, no times
    return parts.join(", ");
  }

  // ------------------------------------------------------------ list
  // Only the newest request may fill the list (fast filter taps or typing can overlap).
  async function fetchGarmin(reset) {
    const seq = ++S.fseq;
    if (S.sport === "gym") { S.garmin = []; S.total = 0; return true; }
    if (reset) S.offset = 0;
    const sport = S.sport === "run" || S.sport === "ride" ? S.sport : "";
    const d = await api(`/api/activities?sport=${sport}&q=${encodeURIComponent(S.q)}&limit=${PAGE}&offset=${S.offset}`, true);
    if (seq !== S.fseq) return false;
    S.garmin = reset ? d.items : S.garmin.concat(d.items);
    S.total = d.total;
    return true;
  }

  function drawList() {
    const box = app.querySelector(".ac-body");
    if (!box) return;
    const more = S.sport !== "gym" && S.garmin.length < S.total;
    const until = more && S.garmin.length ? S.garmin[S.garmin.length - 1].date : null;
    const weeks = window.AL.merge(S.garmin, window.AL.gymSessions(window.GYM), { sport: S.sport, q: S.q, today: todayIso(), until });
    if (!weeks.length) {
      box.innerHTML = `<p class="ac-empty">${S.q ? `Nothing matches “${esc(S.q)}”.` : S.sport === "gym" ? "No gym sessions yet. Start one from Today." : "No activities yet. They appear after the next sync."}</p>`;
      return;
    }
    box.innerHTML = weeks.map((w, k) => `<section class="ac-week"><div class="u-h2row"><h2 class="u-h2">${esc(w.label)}</h2><span class="ac-tot u-c2 u-num">${totals(w)}</span></div>
        <div class="u-list ac-list">${w.items.map((it) => row(it, k < 2 && (w.label === "This week" || w.label === "Last week"))).join("")}</div></section>`).join("")
      + (more ? `<button type="button" class="u-btn ac-more">Show older</button>` : "");
    box.querySelector(".ac-more")?.addEventListener("click", async (e) => {
      e.currentTarget.disabled = true;
      S.offset += PAGE;
      if (await fetchGarmin(false)) drawList();
    });
  }

  // ------------------------------------------------------------ calendar
  async function drawCalendar() {
    const box = app.querySelector(".ac-body");
    if (!box) return;
    const [y, m] = S.ym;
    const seq = ++S.seq;
    const shell = window.AL.calendar(y, m, [], todayIso());
    const sport = S.sport === "run" || S.sport === "ride" ? S.sport : "";
    const d = S.sport === "gym" ? { items: [] } : await api(`/api/activities?sport=${sport}&q=${encodeURIComponent(S.q)}&start=${shell.cells[0].date}&end=${shell.last}&limit=500`, true);
    if (seq !== S.seq) return;
    const items = window.AL.merge(d.items, window.AL.gymSessions(window.GYM), { sport: S.sport, q: S.q, today: todayIso() }).flatMap((w) => w.items);
    const cal = window.AL.calendar(y, m, items, todayIso());
    const inMonth = items.filter((it) => it.date.slice(0, 7) === `${y}-${String(m).padStart(2, "0")}`);
    const km = inMonth.reduce((a, it) => a + (it.kind === "act" ? it.km || 0 : 0), 0);
    const secs = inMonth.reduce((a, it) => a + (it.kind === "act" ? it.secs || 0 : (it.mins || 0) * 60), 0);
    const cells = cal.cells.map((c) => `<button type="button" class="ac-cell${c.inMonth ? "" : " out"}${c.today ? " today" : ""}${c.sports.length ? " has" : ""}" data-date="${c.date}" ${c.sports.length ? "" : 'tabindex="-1"'} aria-label="${esc(fdate(c.date, { weekday: "long", day: "numeric", month: "long" }))}${c.sports.length ? `: ${c.sports.join(", ")}` : ""}">
        <span>${c.day}</span><em>${c.sports.slice(0, 3).map((sp) => `<i class="${sp}"></i>`).join("")}</em></button>`).join("");
    box.innerHTML = `<div class="u-card ac-cal">
        <div class="ac-calhead"><button type="button" class="gbtn" data-mv="-1" aria-label="Previous month">${window.UIC.chevl}</button>
          <b class="ac-month">${esc(cal.title)}</b><button type="button" class="gbtn" data-mv="1" aria-label="Next month">${window.UIC.chev}</button></div>
        <div class="ac-wd" aria-hidden="true">${["M", "T", "W", "T", "F", "S", "S"].map((x) => `<span>${x}</span>`).join("")}</div>
        <div class="ac-grid">${cells}</div>
        <p class="ac-calsum u-c2">${inMonth.length ? `${inMonth.length} ${inMonth.length === 1 ? "session" : "sessions"}${km >= 0.05 ? `, ${n1(km)} km` : ""}${secs ? `, ${hhmm(secs)}` : ""}` : "Nothing this month."}</p>
        <div class="ac-key u-c2"><span><i class="run"></i>Run</span><span><i class="ride"></i>Ride</span><span><i class="gym"></i>Gym</span><span><i class="other"></i>Other</span></div>
      </div>`;
    box.querySelectorAll("[data-mv]").forEach((b) => b.addEventListener("click", () => {
      const k = y * 12 + (m - 1) + +b.dataset.mv;
      S.ym = [Math.floor(k / 12), (k % 12) + 1];
      drawCalendar();
    }));
    box.querySelectorAll(".ac-cell.has").forEach((b) => b.addEventListener("click", () => {
      const day = items.filter((it) => it.date === b.dataset.date);
      openSheet(`<div class="sheet-head"><h2>${esc(fdate(b.dataset.date, { weekday: "long", day: "numeric", month: "long" }))}</h2>
        <button type="button" class="sheet-x" aria-label="Close" onclick="closeSheet()">${window.UIC.close}</button></div>
        <div class="u-list ac-list ac-day">${day.map((it) => row(it, true)).join("")}</div>`);
      document.querySelectorAll("#sheet .ac-day a").forEach((a) => a.addEventListener("click", () => closeSheet()));
    }));
  }

  // ------------------------------------------------------------ page
  function redraw() { return S.view === "calendar" ? drawCalendar() : drawList(); }

  async function renderActivitiesPage() {
    S.sport = store.get("act-sport", "");
    if (!SEGS.some(([v]) => v === S.sport)) S.sport = "";
    S.q = "";
    S.view = store.get("act-view", "list") === "calendar" ? "calendar" : "list";
    const t = new Date();
    S.ym = S.ym || [t.getFullYear(), t.getMonth() + 1];
    const toggle = () => `<button type="button" class="gbtn glass" data-act="view" aria-label="${S.view === "calendar" ? "List" : "Calendar"}">${S.view === "calendar" ? window.UIC.list : window.UIC.calendar}</button>`;
    pageHead("Activities", { right: toggle() });
    await Promise.all([loadGym(false).catch(() => null), S.view === "list" ? fetchGarmin(true) : null]);
    app.innerHTML = `<section class="ac">
      <label class="ac-search"><span class="sr-only">Search activities</span>${window.UIC.search}<input type="search" placeholder="Search name, place or date" autocomplete="off" enterkeyhint="search"></label>
      <div class="segc ac-seg" role="group" aria-label="Show">${SEGS.map(([v, l]) => `<button type="button" data-sport="${v}" aria-pressed="${S.sport === v}">${l}</button>`).join("")}</div>
      <div class="ac-body"></div></section>`;
    await redraw();
    const head = document.getElementById("pagehead");
    head.querySelector("[data-act=view]")?.addEventListener("click", async function onView() {
      S.view = S.view === "calendar" ? "list" : "calendar";
      store.set("act-view", S.view);
      const btn = head.querySelector("[data-act=view]");
      btn.outerHTML = toggle();
      head.querySelector("[data-act=view]").addEventListener("click", onView);
      if (S.view === "list") await fetchGarmin(true);
      redraw();
    });
    app.querySelectorAll(".ac-seg button").forEach((b) => b.addEventListener("click", async () => {
      S.sport = b.dataset.sport;
      store.set("act-sport", S.sport);
      app.querySelectorAll(".ac-seg button").forEach((x) => x.setAttribute("aria-pressed", String(x === b)));
      if (S.view === "list" && !(await fetchGarmin(true))) return;
      redraw();
    }));
    let timer;
    app.querySelector(".ac-search input").addEventListener("input", (e) => {
      clearTimeout(timer);
      timer = setTimeout(async () => {
        S.q = e.target.value.trim();
        if (S.view === "list" && !(await fetchGarmin(true))) return;
        redraw();
      }, 250);
    });
  }

  window.renderActivitiesPage = renderActivitiesPage;
})();
