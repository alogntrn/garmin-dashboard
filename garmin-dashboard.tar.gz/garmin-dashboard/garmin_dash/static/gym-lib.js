/* Gym data: muscles, built-in exercise library and the 4-week knee-smart plan.
   Muscle weights follow the "fractional sets" convention: 1 = main target, 0.5 = helper. */
window.GYMDATA = (function () {
  "use strict";

  const MUSCLES = [
    ["chest", "Chest"], ["frontDelt", "Front delts"], ["sideDelt", "Side delts"], ["rearDelt", "Rear delts"],
    ["biceps", "Biceps"], ["triceps", "Triceps"], ["forearms", "Forearms"], ["lats", "Lats"], ["upperBack", "Upper back & traps"],
    ["lowerBack", "Lower back"], ["abs", "Abs"], ["obliques", "Obliques"], ["glutes", "Glutes"], ["abductors", "Hip abductors"],
    ["adductors", "Adductors"], ["quads", "Quads"], ["hamstrings", "Hamstrings"], ["calves", "Calves"],
  ];
  const LEGS = ["glutes", "abductors", "adductors", "quads", "hamstrings", "calves"]; // tracked left/right
  const CATS = ["Chest", "Back", "Shoulders", "Arms", "Legs", "Glutes & hips", "Core", "Cardio", "Mobility", "Other"];
  const KINDS = [["kg", "Weight × reps"], ["reps", "Reps (bodyweight, extra kg optional)"], ["secs", "Time hold (seconds)"], ["hold", "Weight + time hold"], ["min", "Duration (minutes)"]];
  const MIN_PER_SET = 2; // a duration block counts as one hard set per 2 minutes of work

  const P = (chest, extra) => Object.assign({ chest: 1, frontDelt: 0.5, triceps: 0.5 }, extra);
  // id, name, category, kind, one side at a time, muscles
  const LIB = [
    ["bench", "Barbell bench press", "Chest", "kg", 0, P()],
    ["dbbench", "Dumbbell bench press", "Chest", "kg", 0, P()],
    ["smith", "Smith machine bench press", "Chest", "kg", 0, P()],
    ["mpress", "Machine chest press", "Chest", "kg", 0, P()],
    ["inc", "Incline dumbbell press, 30°", "Chest", "kg", 0, P()],
    ["incbb", "Incline barbell press", "Chest", "kg", 0, P()],
    ["fly", "Cable fly or pec deck", "Chest", "kg", 0, { chest: 1 }],
    ["dbfly", "Dumbbell fly", "Chest", "kg", 0, { chest: 1 }],
    ["pushup", "Push-up", "Chest", "reps", 0, P()],
    ["dip", "Dips", "Chest", "reps", 0, { chest: 1, triceps: 1, frontDelt: 0.5 }],
    ["pd", "Lat pulldown or assisted pull-up", "Back", "kg", 0, { lats: 1, upperBack: 0.5, biceps: 0.5 }],
    ["pullup", "Pull-up or chin-up", "Back", "reps", 0, { lats: 1, upperBack: 0.5, biceps: 0.5 }],
    ["row", "Chest-supported row", "Back", "kg", 0, { upperBack: 1, lats: 0.5, rearDelt: 0.5, biceps: 0.5 }],
    ["cablerow", "Seated cable row", "Back", "kg", 0, { upperBack: 1, lats: 0.5, rearDelt: 0.5, biceps: 0.5 }],
    ["dbrow", "One-arm dumbbell row", "Back", "kg", 1, { lats: 1, upperBack: 0.5, biceps: 0.5 }],
    ["bbrow", "Barbell row", "Back", "kg", 0, { upperBack: 1, lats: 0.5, lowerBack: 0.5, biceps: 0.5 }],
    ["backext", "Back extension", "Back", "reps", 0, { lowerBack: 1, glutes: 0.5, hamstrings: 0.5 }],
    ["lat", "Lateral raise", "Shoulders", "kg", 0, { sideDelt: 1 }],
    ["ohp", "Seated dumbbell shoulder press", "Shoulders", "kg", 0, { frontDelt: 1, sideDelt: 0.5, triceps: 0.5 }],
    ["rd", "Reverse pec deck or face pull", "Shoulders", "kg", 0, { rearDelt: 1, upperBack: 0.5 }],
    ["shrug", "Shrug", "Shoulders", "kg", 0, { upperBack: 1 }],
    ["curl", "Dumbbell curl", "Arms", "kg", 0, { biceps: 1 }],
    ["hammer", "Hammer curl", "Arms", "kg", 0, { biceps: 1, forearms: 0.5 }],
    ["ezcurl", "EZ-bar curl", "Arms", "kg", 0, { biceps: 1 }],
    ["tri", "Overhead cable triceps extension", "Arms", "kg", 0, { triceps: 1 }],
    ["pushdown", "Triceps pushdown", "Arms", "kg", 0, { triceps: 1 }],
    ["skull", "Skull crusher", "Arms", "kg", 0, { triceps: 1 }],
    ["iso", "Isometric leg extension at 60°", "Legs", "hold", 1, { quads: 1 }, { count: false }],
    ["lp", "Single-leg leg press", "Legs", "kg", 1, { quads: 1, glutes: 0.5, adductors: 0.5 }],
    ["lp2", "Leg press, both legs", "Legs", "kg", 0, { quads: 1, glutes: 0.5, adductors: 0.5 }],
    ["le", "Leg extension, 90° → 45°", "Legs", "kg", 1, { quads: 1 }],
    ["le2", "Leg extension, both legs", "Legs", "kg", 0, { quads: 1 }],
    ["sd", "Lateral step-down", "Legs", "kg", 1, { quads: 1, glutes: 0.5, abductors: 0.5 }],
    ["stepup", "Step-up", "Legs", "kg", 1, { quads: 1, glutes: 0.5 }],
    ["split", "Split squat", "Legs", "kg", 1, { quads: 1, glutes: 0.5, adductors: 0.5 }],
    ["goblet", "Goblet squat (shallow)", "Legs", "kg", 0, { quads: 1, glutes: 0.5, adductors: 0.5 }],
    ["wallsit", "Wall sit", "Legs", "secs", 0, { quads: 1 }],
    ["rdl", "Romanian deadlift", "Legs", "kg", 0, { hamstrings: 1, glutes: 1, lowerBack: 0.5, adductors: 0.5 }],
    ["curlL", "Seated leg curl, single-leg", "Legs", "kg", 1, { hamstrings: 1 }],
    ["curl2", "Seated leg curl, both legs", "Legs", "kg", 0, { hamstrings: 1 }],
    ["lycurl", "Lying leg curl", "Legs", "kg", 0, { hamstrings: 1 }],
    ["nordic", "Nordic curl", "Legs", "reps", 0, { hamstrings: 1 }],
    ["calf", "Standing calf raise", "Legs", "kg", 0, { calves: 1 }],
    ["scalf", "Seated calf raise", "Legs", "kg", 0, { calves: 1 }],
    ["ht", "Hip thrust", "Glutes & hips", "kg", 0, { glutes: 1, hamstrings: 0.5 }],
    ["bridge", "Glute bridge", "Glutes & hips", "reps", 0, { glutes: 1, hamstrings: 0.5 }],
    ["slbridge", "Single-leg glute bridge", "Glutes & hips", "reps", 1, { glutes: 1, hamstrings: 0.5 }],
    ["abd", "Hip abduction machine", "Glutes & hips", "kg", 0, { abductors: 1, glutes: 0.5 }],
    ["add", "Hip adduction machine", "Glutes & hips", "kg", 0, { adductors: 1 }],
    ["latwalk", "Banded lateral walk", "Glutes & hips", "reps", 0, { abductors: 1 }],
    ["pal", "Pallof press", "Core", "kg", 1, { obliques: 1, abs: 0.5 }],
    ["sp", "Side plank", "Core", "secs", 1, { obliques: 1, abductors: 0.5 }],
    ["plank", "Plank", "Core", "secs", 0, { abs: 1 }],
    ["crunch", "Crunch", "Core", "reps", 0, { abs: 1 }],
    ["cablecrunch", "Cable crunch", "Core", "kg", 0, { abs: 1 }],
    ["legraise", "Hanging knee or leg raise", "Core", "reps", 0, { abs: 1, obliques: 0.5 }],
    ["abwheel", "Ab wheel rollout", "Core", "reps", 0, { abs: 1, lats: 0.5 }],
    ["deadbug", "Dead bug", "Core", "reps", 0, { abs: 1 }],
    ["russian", "Russian twist", "Core", "reps", 0, { obliques: 1, abs: 0.5 }],
    ["abcircuit", "Ab circuit", "Core", "min", 0, { abs: 1, obliques: 0.5 }],
    ["bike", "Bike", "Cardio", "min", 0, {}],
    ["rower", "Rowing machine", "Cardio", "min", 0, {}],
    ["stairs", "Stair stepper", "Cardio", "min", 0, {}],
    ["xtrainer", "Cross trainer", "Cardio", "min", 0, {}],
    ["walk", "Treadmill walk", "Cardio", "min", 0, {}],
    ["mobility", "Stretching and mobility", "Mobility", "min", 0, {}],
    ["tke", "Band terminal knee extension", "Mobility", "reps", 1, { quads: 1 }, { count: false }],
    ["flush", "Knee flush (optional)", "Mobility", "info", 0, {}, { count: false }],
  ].map(([id, n, cat, kind, uni, mus, extra]) => Object.assign({ id, n, cat, kind, uni: !!uni, mus }, extra || {}));

  const RIRT = { comp: ["3", "2", "1–2", "1–2"], iso: ["3", "2", "1, last set 0", "1, last set 0"], knee: ["3", "3", "2", "2"], hinge: ["3", "2", "2", "2"], eff: ["60–70%", "70–80%", "80%", "80%"] };
  const WARM = {
    leg: ["Bike 5 min, easy to moderate", "Band terminal knee extension: right 15, left 10", "Glute bridge × 12", "Banded lateral walk, 10 steps each way", "Ramp-up sets on the first heavy lift (≈50 → 70 → 85%, fewer reps)"],
    up: ["Bike or rower 5 min", "Band pull-aparts × 15", "Arm circles, 10 each way", "Easy push-ups × 8–10", "Ramp-up sets on the first lift"],
  };
  const REST = ["Easy bike 30–60 min (seated, relaxed cadence) or a walk, or nothing.", "Rate your knee 0–10 this morning. Higher than usual? Use the amber rule at the next leg session.", "Optional 10 min: band TKE 2 × 15 right, glute bridge 2 × 12, calf stretch.", "Protein and sleep are the training today."];
  const PH = ["Calibrate", "Build", "Push", "Peak & test"];
  const PHN = [
    "RIR 3 everywhere. Learn the movements, find working weights and pain-free ranges; legs start shallow.",
    "Sets go up. Right-leg 2-up/1-down extensions and left-leg eccentric curls begin.",
    "Upper body to RIR 1 (last set of isolation lifts may reach failure). Leg ranges may deepen while pain stays green.",
    "Hold week-3 loads. Retest on day 25, then drop one set from every exercise for the last three sessions.",
  ];

  // plan slots: slot id = default exercise id (kept identical to the first release so old logs line up)
  const PLAN = {
    A: { name: "Quads & chest", f: "Right quad: heavy concentric and eccentric work in knee-friendly ranges. Bench press is the first upper-body lift.", warm: "leg", ex: [
      { id: "iso", tag: "knee", alts: ["wallsit"], sets: ["R 3 · L 2", "R 4 · L 2", "R 4 · L 2", "R 4 · L 2"], reps: ["30 s hold", "40 s hold", "45 s hold", "45 s hold"], rir: "eff", rest: "60 s", tempo: "hold, breathe", cue: "Load the leg extension heavier than you can lift with one leg. Start with the knee bent about 60°. Push into the pad to the effort target and hold; nothing should move. Right first, alternate legs.", why: "Your right quad's biggest deficit is maximal force through the middle of the bend. Isometrics let you push hard right there with very low joint stress – a primer before heavier work." },
      { id: "bench", alts: ["dbbench", "smith", "mpress", "pushup"], sets: ["3", "4", "4", "4"], reps: "6–10", rir: "comp", rest: "2–3 min", tempo: "2–3 s down, touch, press", cue: "Shoulder blades back and down, feet flat, slight arch. Bar to the bottom of the chest, forearms vertical, touch without bouncing. Ramp up: bar × 10, ~50% × 6, ~70% × 4, ~85% × 2.", why: "Main chest builder and your clearest progress marker; early in the session because chest is the upper-body priority." },
      { id: "lp", tag: "knee", alts: ["lp2", "stepup", "goblet"], sets: ["R 3 · L 2", "R 3 · L 3", "R 4 · L 3", "R 4 · L 3"], reps: "8–12", rir: "knee", rest: "60–90 s between legs", tempo: "3 s down, 1 s up", note: ["Depth: to about 60° knee bend", "Depth: to about 60° knee bend", "Depth: up to 75–90° if last week stayed green", "Depth: up to 75–90° if green"], cue: "Foot mid-platform, knee over the 2nd–3rd toe. Lower slowly only as deep as this week allows; press up without snapping the knee locked. Right first; the left matches the right's reps, never more.", why: "Closed-chain strength for the right leg, pressing and slow lowering – your physio's two quad goals. Single-leg stops the strong left leg taking over." },
      { id: "le", tag: "knee", alts: ["le2"], sets: ["R 3 · L 2", "R 3 · L 2", "R 3 · L 2", "R 3 · L 2"], reps: ["10–15 each leg", "R 8–10 · L 10–15", "R 8–10 · L 10–15", "R 8–10 · L 10–15"], rir: "knee", rest: "60–90 s", tempo: ["2 s up, 3 s down", "R: up with both, 4 s down with right only", "R: 2-up/1-down, 4 s down", "R: 2-up/1-down, 4 s down"], note: ["Single-leg, both sides, to learn the range", "Right = 2-up/1-down. Start about 1.3× your right single-leg weight", "Right = 2-up/1-down", "Right = 2-up/1-down"], cue: "Start fully bent (90°) and extend only about halfway, stopping ~45° short of straight. Don't lock out.", why: "This range stresses the kneecap joint least and is the stretched half that grows the quads best. 2-up/1-down gives the right quad heavy eccentric load." },
      { id: "fly", alts: ["dbfly", "pushup"], sets: ["2", "2", "3", "3"], reps: "12–15", rir: "iso", rest: "60–90 s", tempo: "2 s in, 3 s out", cue: "Elbows slightly bent and fixed. Open wide to a deep chest stretch, bring the handles together at chest height.", why: "Loads the chest hardest in its stretched position with little joint strain." },
      { id: "lat", alts: ["ohp"], sets: ["2", "3", "3", "3"], reps: "12–20", rir: "iso", rest: "60 s", tempo: "controlled, no swing", cue: "Raise to shoulder height leading with the elbows, slight forward lean.", why: "Side delts give the upper body width; small muscle, recovers fast." },
    ] },
    B: { name: "Back, shoulders, arms", f: "A full knee rest day: nothing loads the knee. Superset curls and triceps to save time.", warm: "up", ex: [
      { id: "pd", alts: ["pullup"], sets: ["3", "3", "4", "4"], reps: "8–12", rir: "comp", rest: "2 min", tempo: "1 s pull, 2–3 s up", cue: "Grip just outside the shoulders, chest up, drive the elbows down to your ribs. Full stretch at the top.", why: "Back width and the counterweight to all the pressing." },
      { id: "row", alts: ["cablerow", "dbrow", "bbrow"], sets: ["3", "3", "4", "4"], reps: "8–12", rir: "comp", rest: "2 min", tempo: "1 s pause at the top", cue: "Machine, or dumbbells face-down on a 30° bench. Elbows back past the torso, squeeze, lower to a full stretch.", why: "Mid-back thickness without bracing through legs or lower back." },
      { id: "lat", alts: ["ohp"], sets: ["3", "3", "3", "3"], reps: "12–20", rir: "iso", rest: "60 s", tempo: "controlled", cue: "As on day A; try a cable, one arm at a time.", why: "Second weekly dose for shoulder width." },
      { id: "rd", alts: [], sets: ["2", "2", "3", "3"], reps: "12–20", rir: "iso", rest: "60 s", tempo: "1 s squeeze", cue: "Arms long, pull wide and back, squeeze between the shoulder blades.", why: "Rear delts and upper back balance a chest-heavy plan." },
      { id: "curl", alts: ["hammer", "ezcurl"], sets: ["2", "2", "3", "3"], reps: "10–15", rir: "iso", rest: "superset", tempo: "3 s down", cue: "Elbows pinned at your sides, full stretch at the bottom, no swinging.", why: "Direct biceps work on top of the pulling." },
      { id: "tri", alts: ["pushdown", "skull"], sets: ["2", "2", "3", "3"], reps: "10–15", rir: "iso", rest: "60–90 s after the pair", tempo: "3 s down", cue: "Face away from the cable, rope behind the head, elbows forward. Stretch deep, extend fully.", why: "The overhead position stretches the long head, which grew clearly more in training studies." },
      { id: "calf", alts: ["scalf"], sets: ["3", "3", "3", "3"], reps: "10–15", rir: "hinge", rest: "60–90 s", tempo: "2 s pause in the bottom stretch", cue: "Knees straight; from deep stretch to full tiptoe.", why: "Completes the leg chain with minimal knee load." },
      { id: "pal", alts: ["plank", "deadbug"], sets: ["2", "2", "2", "2"], reps: "10 each side", rir: "hinge", rest: "45 s", tempo: "2 s hold arms out", cue: "Side-on to a cable at chest height, press straight out and resist the twist.", why: "Anti-rotation core strength." },
      { id: "flush", alts: [], sets: ["1", "1", "1", "1"], reps: "10 min bike + TKE 2 × 15 right", rir: "easy", rest: "–", tempo: "easy", cue: "Easy spin, then band terminal knee extensions, squeezing the quad hard at full straightening.", why: "Moves the knee without load on its rest day." },
    ] },
    C: { name: "Hips, hamstrings & upper chest", f: "Posterior chain and hips, left-hamstring eccentrics and a small dose of right-quad control. Upper chest is the second chest session.", warm: "leg", ex: [
      { id: "rdl", alts: ["backext"], sets: ["3", "3", "3", "3"], reps: "8–10", rir: "hinge", rest: "2–3 min", tempo: "3 s down, 1 s up", cue: "Soft knees that keep the same bend, hips back, bar close, flat back. Lower to a strong hamstring stretch, drive the hips forward.", why: "Heavy eccentric hamstring and glute work while the knee angle barely changes." },
      { id: "inc", alts: ["incbb", "mpress", "dbbench"], sets: ["3", "3", "3", "3"], reps: "8–12", rir: "comp", rest: "2 min", tempo: "3 s down", cue: "Bench ~30°. Lower to the outside of the upper chest for a deep stretch, press up and slightly in.", why: "A low incline shifts work to the upper chest." },
      { id: "ht", alts: ["bridge", "slbridge"], sets: ["3", "3", "3", "3"], reps: "8–12", rir: "hinge", rest: "2 min", tempo: "1 s squeeze at the top", cue: "Upper back on a bench, shins vertical at the top, ribs down, squeeze 1 s. Knee complains → feet a little further out.", why: "Strong glutes take load off the quads and knee." },
      { id: "curlL", n: "Seated leg curl, left eccentric", alts: ["curl2", "lycurl", "nordic"], sets: ["L 3 · R 2", "L 3 · R 2", "L 3 · R 2", "L 3 · R 2"], reps: ["10–12 each leg", "L 8–10 · R 10–12", "L 8–10 · R 10–12", "L 8–10 · R 10–12"], rir: "knee", rest: "60–90 s", tempo: ["2 s down", "L: curl with both, 4 s return with left only", "L: 2-up/1-down", "L: 2-up/1-down"], note: ["Single-leg both sides", "Left = 2-up/1-down from now on", "Left = 2-up/1-down", "Left = 2-up/1-down"], cue: "Pad just above the ankles, thigh pad snug. From week 2: curl with both legs, return with the left alone over 4 s.", why: "Your left hamstrings lag your strong left quad (ratio 0.82 vs ~1.0); the physio asked for left eccentric work." },
      { id: "sd", tag: "knee", alts: ["stepup", "split"], sets: ["R 2 · L 2", "R 2 · L 2", "R 3 · L 2", "R 3 · L 2"], reps: ["8 each", "10 each", "10 each", "10 each"], rir: "knee", rest: "60 s", tempo: "3 s down, tap, up", note: ["Step height 10–15 cm", "Step height 15–20 cm", "Step height 20 cm", "20 cm, light dumbbell if green"], cue: "Side-on on a step, other foot hanging. Lower the free heel to tap in 3 s, stand up. Pelvis level, knee over the 2nd toe. Log 0 kg for bodyweight.", why: "Slow single-leg lowering trains eccentric quad and hip control in a real-life position." },
      { id: "abd", alts: ["latwalk"], sets: ["2", "3", "3", "3"], reps: "15–20", rir: "iso", rest: "60 s", tempo: "1 s hold out", cue: "Push the pads out, hold, return slowly. No machine: side-lying band abduction.", why: "The glute medius stops the knee caving inward." },
      { id: "sp", alts: ["plank"], sets: ["2", "2", "2", "2"], reps: ["30 s each side", "35 s each side", "40 s each side", "45 s each side"], rir: "hinge", rest: "30 s", tempo: "hold", cue: "Elbow under the shoulder, body in one line, hips high.", why: "Lateral core and hip stability for single-leg control." },
    ] },
  };

  const PALETTE = ["#0f9d8a", "#7a5af5", "#e0457b", "#f07b1a", "#2e9e4f", "#5b6b7c"];
  return { MUSCLES, LEGS, CATS, KINDS, MIN_PER_SET, LIB, RIRT, WARM, REST, PH, PHN, PLAN, PALETTE };
})();
