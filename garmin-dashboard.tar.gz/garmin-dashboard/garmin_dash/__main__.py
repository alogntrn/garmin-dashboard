"""Command line:  ./garmin-dash <command>

  set-key      store your Garmin Personal API key (asked for, not echoed)
  test         check the key and show what Garmin returns
  sync         fetch new data (add --full to re-fetch everything)
  reprocess    recompute all activity analysis from the stored FIT files
  inspect      print the *structure* of each Garmin response (no values) – for troubleshooting
  serve        run the web dashboard
"""
from __future__ import annotations

import argparse
import getpass
import json
import logging
import sys
from datetime import date, timedelta


def main(argv=None):
    p = argparse.ArgumentParser(prog="garmin-dash")
    sp = p.add_subparsers(dest="cmd", required=True)
    sp.add_parser("set-key")
    sp.add_parser("test")
    s = sp.add_parser("sync")
    s.add_argument("--full", action="store_true", help="re-fetch the complete history")
    s.add_argument("--budget", type=float, default=None, help="max seconds for file downloads in this run")
    sp.add_parser("reprocess")
    sp.add_parser("inspect")
    sp.add_parser("serve")
    a = p.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", datefmt="%H:%M:%S")

    from . import api, config

    if a.cmd == "set-key":
        key = getpass.getpass("Paste your Garmin Personal API key (input hidden): ").strip()
        if not key:
            sys.exit("No key entered.")
        try:
            api.GarminClient(key).token(force=True)
        except api.GarminError as e:
            sys.exit(f"Garmin did not accept the key: {e}")
        path = api.save_api_key(key)
        print(f"Key works and is saved to {path} (readable only by you).")

    elif a.cmd == "test":
        c = api.GarminClient()
        c.token(force=True)
        print("✓ Key accepted, access token received")
        acts = c.search_activities(limit=5)
        from .extract import activity_row, as_list
        for x in as_list(acts, "activityId"):
            r = activity_row(x)
            print(f"  {r['start_local']}  {r['sport']:5}  {r['name']}  {(r['distance_m'] or 0) / 1000:.1f} km")
        print("✓ Activities readable")

    elif a.cmd == "sync":
        from .sync import run_locked
        run_locked(full=a.full, fit_budget_s=a.budget)

    elif a.cmd == "reprocess":
        from .sync import Sync
        s = Sync.__new__(Sync)
        from . import db
        s.con = db.connect()
        s.reprocess()
        print("Done.")

    elif a.cmd == "inspect":
        from .extract import shape
        c = api.GarminClient()
        today = date.today()
        wk = today - timedelta(days=6)
        calls = {
            "profile_settings": c.profile_settings,
            "heart_rate_zones": c.heart_rate_zones,
            "activities (1)": lambda: c.search_activities(limit=1),
            "daily_summaries (7d)": lambda: c.daily_summaries(wk, today),
            "sleep_summaries (7d)": lambda: c.sleep_summaries(wk, today),
            "daily_sleep (yesterday)": lambda: c.daily_sleep(today - timedelta(days=1)),
            "hrv_summaries (7d)": lambda: c.hrv_summaries(wk, today),
            "body_battery (7d)": lambda: c.body_battery(wk, today),
            "weight (90d)": lambda: c.weight(today - timedelta(days=90), today),
        }
        out = {}
        for name, fn in calls.items():
            try:
                out[name] = shape(fn())
            except api.GarminError as e:
                out[name] = f"ERROR {e.status}"
        print(json.dumps(out, indent=1))
        print("\n(Only field names and types are shown – none of your values.)")

    elif a.cmd == "serve":
        from .web import serve
        serve()


if __name__ == "__main__":
    main()
