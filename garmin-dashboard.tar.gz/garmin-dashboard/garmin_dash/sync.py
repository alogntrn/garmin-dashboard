"""Pull data from Garmin into SQLite. First run backfills everything; later runs
are incremental (new activities + the last 10 days of wellness data)."""
from __future__ import annotations

import fcntl
import json
import logging
import time
from datetime import date, datetime, timedelta

from . import activity_metrics, config, db, extract, fitfile
from .api import GarminClient, GarminError

log = logging.getLogger("garmin.sync")


def _chunks(start: date, end: date, days: int):
    cur = start
    while cur <= end:
        last = min(cur + timedelta(days=days - 1), end)
        yield cur, last
        cur = last + timedelta(days=1)


class Sync:
    def __init__(self, client: GarminClient | None = None):
        self.c = client or GarminClient()
        self.con = db.connect()

    def info(self, msg):
        log.info(msg)
        db.log(self.con, "info", msg)

    def warn(self, msg):
        log.warning(msg)
        db.log(self.con, "warn", msg)

    # -------------------------------------------------------------- athlete
    def athlete(self):
        last = db.kv_get(self.con, "athlete_fetched")
        if last == date.today().isoformat():
            return
        for key, fn in (("profile", self.c.profile_settings), ("hr_zones", self.c.heart_rate_zones)):
            try:
                db.kv_set(self.con, key, fn())
            except GarminError as e:
                self.warn(f"Could not fetch {key}: {e}")
        db.kv_set(self.con, "athlete_fetched", date.today().isoformat())
        self.con.commit()

    # ----------------------------------------------------------- activities
    def activities(self, full: bool = False) -> int:
        newest = self.con.execute("SELECT max(date) FROM activities").fetchone()[0]
        since = None
        if newest and not full:
            since = date.fromisoformat(newest) - timedelta(days=7)
        start, n_new = 0, 0
        while True:
            page = self.c.search_activities(start=start, limit=50, start_date=since,
                                            end_date=date.today() + timedelta(days=1) if since else None)
            items = extract.as_list(page, "activityId")
            if not items:
                break
            for a in items:
                row = extract.activity_row(a)
                exists = self.con.execute("SELECT 1 FROM activities WHERE id=?", (row["id"],)).fetchone()
                row["raw"] = json.dumps(a)
                row["updated_at"] = datetime.now().isoformat(timespec="seconds")
                cols = ",".join(row)
                if exists:
                    sets = ",".join(f"{k}=?" for k in row if k != "id")
                    self.con.execute(f"UPDATE activities SET {sets} WHERE id=?",
                                     (*[v for k, v in row.items() if k != "id"], row["id"]))
                else:
                    self.con.execute(f"INSERT INTO activities({cols}) VALUES({','.join('?' * len(row))})",
                                     tuple(row.values()))
                    n_new += 1
            self.con.commit()
            if len(items) < 50:
                break
            start += 50
            if start % 500 == 0:
                self.info(f"Activity list: {start} fetched so far…")
        return n_new

    def weight_kg(self):
        if config.WEIGHT_KG:
            return config.WEIGHT_KG
        row = self.con.execute("SELECT weight_kg FROM daily WHERE weight_kg IS NOT NULL ORDER BY date DESC LIMIT 1").fetchone()
        if row:
            return row[0]
        prof = db.kv_get(self.con, "profile") or {}
        w = extract.find_num(prof, ["userData.weight", "weight"])
        return (w / 1000 if w and w > 300 else w) or None

    def process_activity(self, act_id: int, sport: str, fit_bytes: bytes):
        grid = fitfile.parse(fit_bytes)
        metrics, streams = activity_metrics.compute(grid, sport, self.weight_kg())
        metrics["session"] = grid.get("session", {})
        self.con.execute("INSERT OR REPLACE INTO activity_detail(id,streams,laps,metrics,processed_at) VALUES(?,?,?,?,?)",
                         (act_id, db.pack(streams), json.dumps(grid.get("laps", [])), json.dumps(metrics),
                          datetime.now().isoformat(timespec="seconds")))

    def fit_files(self, budget_s: float | None = None, retry_errors: bool = False) -> int:
        attempts = db.kv_get(self.con, "fit_attempts", {})
        rows = [r for r in self.con.execute(
            "SELECT id, sport, fit_status FROM activities WHERE fit_status IN ('pending','error') ORDER BY date DESC")
            if r["fit_status"] == "pending" or retry_errors or attempts.get(str(r["id"]), 0) < 3]
        if rows:
            self.info(f"Downloading {len(rows)} activity files…")
        t0, done = time.time(), 0
        for r in rows:
            if budget_s and time.time() - t0 > budget_s:
                self.info(f"Time budget reached; {len(rows) - done} files left for the next run.")
                break
            path = config.FIT_DIR / f"{r['id']}.fit"
            status = "ok"
            try:
                if not path.exists():
                    blob = self.c.download_activity(r["id"])
                    fit = fitfile.extract_fit(blob) if blob else None
                    if fit is None:
                        status = "nofit"
                    else:
                        path.write_bytes(fit)
                if status == "ok":
                    self.process_activity(r["id"], r["sport"], path.read_bytes())
            except GarminError as e:
                status = "missing" if e.status == 404 else "error"
                self.warn(f"Activity {r['id']}: {e}")
            except Exception as e:  # corrupt file etc.
                status = "error"
                self.warn(f"Activity {r['id']}: could not parse ({e})")
            if status == "error":
                attempts[str(r["id"])] = attempts.get(str(r["id"]), 0) + 1
                db.kv_set(self.con, "fit_attempts", attempts)
            self.con.execute("UPDATE activities SET fit_status=? WHERE id=?", (status, r["id"]))
            self.con.commit()
            done += 1
            if done % 25 == 0:
                self.info(f"Processed {done}/{len(rows)} activity files")
        return done

    def reprocess(self):
        rows = self.con.execute("SELECT id, sport FROM activities WHERE fit_status='ok'").fetchall()
        for i, r in enumerate(rows, 1):
            p = config.FIT_DIR / f"{r['id']}.fit"
            if p.exists():
                try:
                    self.process_activity(r["id"], r["sport"], p.read_bytes())
                except Exception as e:
                    self.warn(f"Reprocess {r['id']}: {e}")
            if i % 50 == 0:
                self.con.commit()
                self.info(f"Reprocessed {i}/{len(rows)}")
        self.con.commit()

    # --------------------------------------------------------------- daily
    def _store(self, source: str, resp, fields_fn):
        n = 0
        for rec in extract.day_records(resp):
            d = extract.record_date(rec)
            self.con.execute("INSERT OR REPLACE INTO raw_daily(date,source,data) VALUES(?,?,?)", (d, source, json.dumps(rec)))
            db.upsert_daily(self.con, d, fields_fn(rec))
            n += 1
        return n

    def daily(self, full: bool = False):
        today = date.today()
        last = db.kv_get(self.con, "daily_synced_to")
        if last and not full:
            start = date.fromisoformat(last) - timedelta(days=10)
        else:
            first = self.con.execute("SELECT min(date) FROM activities").fetchone()[0]
            floor = today - timedelta(days=int(365 * config.WELLNESS_YEARS))
            start = max(date.fromisoformat(first), floor) if first else today - timedelta(days=365)
            self.info(f"Backfilling wellness data from {start}")

        jobs = [
            ("summary", self.c.daily_summaries, 180, extract.daily_summary_fields),
            ("hrv", self.c.hrv_summaries, 180, extract.hrv_fields),
            ("sleep", self.c.sleep_summaries, 28, extract.sleep_fields),
            ("bodybattery", self.c.body_battery, 28, extract.body_battery_fields),
        ]
        for source, fn, span, fields_fn in jobs:
            got, failed = 0, 0
            for a, b in _chunks(start, today, span):
                try:
                    got += self._store(source, fn(a, b), fields_fn)
                except GarminError as e:
                    failed += 1
                    if failed <= 2:
                        self.warn(f"{source} {a}–{b}: {e}")
                self.con.commit()
            log.info("%s: %d days", source, got)

        # Detailed sleep for the most recent nights (score/stages if summaries lack them)
        for i in range(3):
            d = today - timedelta(days=i)
            try:
                resp = self.c.daily_sleep(d)
                if resp:
                    self.con.execute("INSERT OR REPLACE INTO raw_daily VALUES(?,?,?)", (d.isoformat(), "sleep_detail", json.dumps(resp)))
                    f = extract.sleep_fields(resp)
                    db.upsert_daily(self.con, d.isoformat(), {k: v for k, v in f.items() if v is not None})
            except GarminError:
                pass

        for a, b in _chunks(start, today, 365):
            try:
                resp = self.c.weight(a, b)
                for rec in extract.day_records(resp):
                    w = extract.find_num(rec, ["weight", "weightInGrams"], deep=False)
                    if w:
                        db.upsert_daily(self.con, extract.record_date(rec), {"weight_kg": w / 1000 if w > 300 else w})
            except GarminError:
                pass
        db.kv_set(self.con, "daily_synced_to", today.isoformat())
        self.con.commit()

    # ---------------------------------------------------------------- run
    def run(self, full: bool = False, fit_budget_s: float | None = None):
        t0 = time.time()
        self.info("Sync started" + (" (full)" if full else ""))
        self.athlete()
        n_new = self.activities(full=full)
        self.info(f"{n_new} new activities")
        first_run = db.kv_get(self.con, "daily_synced_to") is None
        if first_run:
            # get wellness first so the dashboard is useful while files download
            self.daily(full=True)
            self.fit_files(budget_s=fit_budget_s, retry_errors=full)
        else:
            self.fit_files(budget_s=fit_budget_s, retry_errors=full)
            self.daily(full=full)
        db.kv_set(self.con, "last_sync", datetime.now().isoformat(timespec="seconds"))
        self.con.commit()
        self.info(f"Sync finished in {time.time() - t0:.0f}s ({self.c.calls} API calls)")


def run_locked(**kw):
    config.ensure_dirs()
    lock = open(config.DATA_DIR / "sync.lock", "w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        log.info("Another sync is already running")
        return False
    try:
        Sync().run(**kw)
        return True
    except GarminError as e:
        con = db.connect()
        db.log(con, "error", str(e))
        raise
    finally:
        fcntl.flock(lock, fcntl.LOCK_UN)
