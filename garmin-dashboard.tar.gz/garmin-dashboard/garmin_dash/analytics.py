"""Aggregate analysis for the dashboard. Everything is computed from SQLite on
request and cached until the database changes."""
from __future__ import annotations

import json
import math
import statistics
from collections import defaultdict
from datetime import date, datetime, timedelta
from functools import wraps

from . import config, db, extract
from .activity_metrics import POWER_DURATIONS

RIEGEL = 1.06
_cache: dict = {}


def _db_version():
    v = 0.0
    for suffix in ("", "-wal"):
        p = config.DB_PATH.with_name(config.DB_PATH.name + suffix)
        if p.exists():
            v += p.stat().st_mtime
    return v


def cached(fn):
    @wraps(fn)
    def wrapper(*args):
        key = (fn.__name__, args)
        ver = _db_version()
        hit = _cache.get(key)
        if hit and hit[0] == ver and hit[1] == date.today():
            return hit[2]
        val = fn(*args)
        _cache[key] = (ver, date.today(), val)
        return val
    return wrapper


def _r(x, n=1):
    return None if x is None or (isinstance(x, float) and math.isnan(x)) else round(x, n)


def _mean(xs):
    xs = [x for x in xs if x is not None]
    return sum(xs) / len(xs) if xs else None


def _median(xs):
    xs = [x for x in xs if x is not None]
    return statistics.median(xs) if xs else None


def _week(d: date) -> date:
    return d - timedelta(days=d.weekday())


# ------------------------------------------------------------------ athlete
@cached
def athlete():
    con = db.connect()
    profile = db.kv_get(con, "profile") or {}
    zones_raw = db.kv_get(con, "hr_zones")
    zones = {}
    for z in extract.as_list(zones_raw, "zone1Floor") if zones_raw else []:
        floors = [extract.find_num(z, [f"zone{i}Floor"], deep=False) for i in range(1, 6)]
        if all(floors):
            zones[(z.get("sport") or "DEFAULT").upper()] = {
                "floors": floors,
                "max": extract.find_num(z, ["maxHeartRateUsed", "maxHeartRate"], deep=False),
                "lthr": extract.find_num(z, ["lactateThresholdHeartRateUsed"], deep=False),
                "rest": extract.find_num(z, ["restingHeartRateUsed"], deep=False),
            }
    default_zone = zones.get("DEFAULT") or (next(iter(zones.values())) if zones else None)

    max_hr = config.MAX_HR or (default_zone or {}).get("max")
    if not max_hr:
        vals = sorted(r[0] for r in con.execute("SELECT max_hr FROM activities WHERE max_hr IS NOT NULL"))
        max_hr = vals[int(len(vals) * 0.99)] if vals else 190
    since = (date.today() - timedelta(days=30)).isoformat()
    rest = config.RESTING_HR or _median([r[0] for r in con.execute("SELECT resting_hr FROM daily WHERE date>=? ", (since,))]) \
        or (default_zone or {}).get("rest") or 50

    def floors_for(sport):
        key = {"run": "RUNNING", "ride": "CYCLING"}.get(sport, "DEFAULT")
        z = zones.get(key) or default_zone
        if z:
            return z["floors"]
        return [round(max_hr * f) for f in (0.5, 0.6, 0.7, 0.8, 0.9)]

    weight = config.WEIGHT_KG
    if not weight:
        row = con.execute("SELECT weight_kg FROM daily WHERE weight_kg IS NOT NULL ORDER BY date DESC LIMIT 1").fetchone()
        weight = row[0] if row else None
    if not weight:
        w = extract.find_num(profile, ["userData.weight", "weight"])
        weight = (w / 1000 if w and w > 300 else w) or None
    gender = (extract.find_str(profile, ["userData.gender", "gender"]) or "MALE").upper()
    profile_ftp = extract.find_num(profile, ["userData.functionalThresholdPower", "functionalThresholdPower", "ftp"])
    lthr = extract.find_num(profile, ["userData.lactateThresholdHeartRate", "lactateThresholdHeartRate"]) \
        or (default_zone or {}).get("lthr")
    return {"max_hr": max_hr, "rest_hr": rest, "zones": {s: floors_for(s) for s in ("run", "ride", "other")},
            "zones_source": "Garmin" if zones else "estimated (% of max HR)",
            "weight": weight, "gender": gender, "profile_ftp": profile_ftp, "lthr": lthr}


# --------------------------------------------------------------- activities
def _trimp_from_hist(hist, rest, mx, female):
    a, b = (0.86, 1.67) if female else (0.64, 1.92)
    total = 0.0
    for i, secs in enumerate(hist):
        if not secs:
            continue
        hrr = min(1.0, max(0.0, (40 + i - rest) / (mx - rest)))
        total += secs / 60 * hrr * a * math.exp(b * hrr)
    return total


@cached
def activities():
    con = db.connect()
    ath = athlete()
    female = ath["gender"].startswith("F")
    rows = con.execute("""SELECT a.*, d.metrics, d.laps FROM activities a
                          LEFT JOIN activity_detail d ON d.id=a.id ORDER BY a.start_local""").fetchall()
    out = []
    for r in rows:
        a = {k: r[k] for k in r.keys() if k not in ("raw", "metrics", "laps")}
        m = json.loads(r["metrics"]) if r["metrics"] else {}
        a["m"] = m
        if m.get("hr_hist"):
            a["trimp"] = _trimp_from_hist(m["hr_hist"], ath["rest_hr"], ath["max_hr"], female)
        elif a["avg_hr"] and a["duration_s"]:
            hrr = min(1, max(0, (a["avg_hr"] - ath["rest_hr"]) / (ath["max_hr"] - ath["rest_hr"])))
            k, e = (0.86, 1.67) if female else (0.64, 1.92)
            a["trimp"] = a["duration_s"] / 60 * hrr * k * math.exp(e * hrr)
        else:
            a["trimp"] = None
        a["load"] = a["training_load"] if a["training_load"] is not None else a["trimp"]
        if a["norm_power"] is None and m.get("np"):
            a["norm_power"] = m["np"]
        if a["avg_power"] is None and m.get("avg_power"):
            a["avg_power"] = m["avg_power"]
        if not a["date"]:
            continue
        a["d"] = date.fromisoformat(a["date"])
        out.append(a)
    return out


def _public(a, ftp=None):
    secs = a["moving_s"] or a["duration_s"]
    pace = (secs / (a["distance_m"] / 1000)) if a["sport"] == "run" and a["distance_m"] and secs else None
    np_ = a["norm_power"]
    tss = None
    if np_ and ftp and secs:
        intensity = np_ / ftp
        tss = secs * np_ * intensity / (ftp * 3600) * 100
    return {
        "id": a["id"], "date": a["date"], "start": a["start_local"], "name": a["name"], "sport": a["sport"],
        "type": a["type_key"], "indoor": bool(a["indoor"]),
        "km": _r((a["distance_m"] or 0) / 1000, 2), "secs": _r(secs, 0), "elapsed": _r(a["duration_s"], 0),
        "elev": _r(a["elev_gain"], 0), "speed_kmh": _r((a["avg_speed"] or 0) * 3.6, 1),
        "pace": _r(pace, 0), "hr": _r(a["avg_hr"], 0), "max_hr": _r(a["max_hr"], 0),
        "power": _r(a["avg_power"], 0), "np": _r(np_, 0), "tss": _r(tss, 0), "load": _r(a["load"], 0),
        "te": _r(a["aerobic_te"], 1), "ate": _r(a["anaerobic_te"], 1), "cal": _r(a["calories"], 0),
        "location": a["location"], "has_file": a["fit_status"] == "ok",
    }


# ---------------------------------------------------------------- training load
@cached
def load_series():
    acts = activities()
    if not acts:
        return {"days": [], "ctl": [], "atl": [], "tsb": [], "load": []}
    daily = defaultdict(float)
    for a in acts:
        if a["d"] and a["load"]:
            daily[a["d"]] += a["load"]
    start, end = min(daily) if daily else date.today(), date.today()
    ctl = atl = 0.0
    out = {"days": [], "ctl": [], "atl": [], "tsb": [], "load": []}
    d = start
    kc, ka = 1 - math.exp(-1 / 42), 1 - math.exp(-1 / 7)
    while d <= end:
        tsb = ctl - atl
        ld = daily.get(d, 0.0)
        ctl += (ld - ctl) * kc
        atl += (ld - atl) * ka
        out["days"].append(d.isoformat()); out["load"].append(round(ld, 1))
        out["ctl"].append(round(ctl, 1)); out["atl"].append(round(atl, 1)); out["tsb"].append(round(tsb, 1))
        d += timedelta(days=1)
    return out


# ------------------------------------------------------------------ weekly
@cached
def weekly(weeks: int = 52):
    acts = activities()
    first = _week(date.today()) - timedelta(weeks=weeks - 1)
    keys = [(first + timedelta(weeks=i)) for i in range(weeks)]
    agg = {k: {s: {"km": 0.0, "h": 0.0, "elev": 0.0, "n": 0, "load": 0.0} for s in ("run", "ride", "other")} for k in keys}
    for a in acts:
        if not a["d"] or a["d"] < first:
            continue
        w = agg[_week(a["d"])][a["sport"]]
        w["km"] += (a["distance_m"] or 0) / 1000
        w["h"] += (a["moving_s"] or a["duration_s"] or 0) / 3600
        w["elev"] += a["elev_gain"] or 0
        w["n"] += 1
        w["load"] += a["load"] or 0
    return {"weeks": [k.isoformat() for k in keys],
            "data": {s: {f: [round(agg[k][s][f], 1) for k in keys] for f in ("km", "h", "elev", "n", "load")}
                     for s in ("run", "ride", "other")}}


@cached
def heatmap():
    acts = activities()
    start = _week(date.today()) - timedelta(weeks=52)
    days = defaultdict(lambda: {"load": 0.0, "sports": set(), "km": 0.0})
    for a in acts:
        if a["d"] and a["d"] >= start:
            x = days[a["d"]]
            x["load"] += a["load"] or 0; x["sports"].add(a["sport"]); x["km"] += (a["distance_m"] or 0) / 1000
    return {"start": start.isoformat(),
            "days": {d.isoformat(): {"load": round(v["load"]), "km": round(v["km"], 1), "sports": sorted(v["sports"])} for d, v in days.items()}}


# ------------------------------------------------------------------ zones
def zone_seconds(hist, floors):
    z = [0] * 5
    for i, secs in enumerate(hist or []):
        bpm = 40 + i
        k = sum(1 for f in floors if bpm >= f) - 1
        z[max(0, k)] += secs
    return z


def power_zone_seconds(hist, ftp):
    bounds = [0.55, 0.75, 0.90, 1.05, 1.20, 1.50]
    z = [0] * 7
    for i, secs in enumerate(hist or []):
        w = i * 10 + 5
        k = sum(1 for b in bounds if w >= b * ftp)
        z[k] += secs
    return z


@cached
def zones_weekly(weeks: int = 16):
    ath, acts = athlete(), activities()
    first = _week(date.today()) - timedelta(weeks=weeks - 1)
    keys = [first + timedelta(weeks=i) for i in range(weeks)]
    out = {k: [0] * 5 for k in keys}
    for a in acts:
        if a["d"] and a["d"] >= first and a["m"].get("hr_hist"):
            zs = zone_seconds(a["m"]["hr_hist"], ath["zones"][a["sport"]])
            out[_week(a["d"])] = [x + y for x, y in zip(out[_week(a["d"])], zs)]
    return {"weeks": [k.isoformat() for k in keys], "zones": [[round(v[i] / 3600, 2) for k, v in out.items()] for i in range(5)]}


# ------------------------------------------------------------------ cycling
def _best_curve(acts, since=None, wkg=False):
    best = {}
    for a in acts:
        if since and a["d"] < since:
            continue
        curve = a["m"].get("power_curve_wkg" if wkg else "power_curve") or {}
        for k, v in curve.items():
            if v and (k not in best or v > best[k][0]):
                best[k] = (v, a["date"], a["id"])
    return [{"s": int(k), "w": best[k][0], "date": best[k][1], "id": best[k][2]}
            for k in sorted(best, key=int)]


@cached
def ftp_now():
    ath = athlete()
    if config.FTP:
        return config.FTP, "your setting"
    if ath["profile_ftp"]:
        return ath["profile_ftp"], "Garmin profile"
    rides = [a for a in activities() if a["sport"] == "ride" and a["m"].get("power_curve")]
    for days in (90, 365, 100000):
        since = date.today() - timedelta(days=days)
        vals = [a["m"]["power_curve"].get("1200") for a in rides if a["d"] >= since]
        vals = [v for v in vals if v]
        if vals:
            return round(max(vals) * 0.95), f"estimated (95% of best 20 min, last {days if days < 1000 else 'all'} days)"
    return None, "no power data"


@cached
def cycling():
    ath = athlete()
    acts = activities()
    rides = [a for a in acts if a["sport"] == "ride"]
    ftp, ftp_src = ftp_now()
    today = date.today()
    pr = [a for a in rides if a["m"].get("power_curve")]
    curves = {
        "all": _best_curve(pr),
        "365": _best_curve(pr, today - timedelta(days=365)),
        "90": _best_curve(pr, today - timedelta(days=90)),
        "28": _best_curve(pr, today - timedelta(days=28)),
    }
    # eFTP trend: rolling 90-day best 20-min power, sampled weekly
    eftp = []
    if pr:
        d = _week(min(a["d"] for a in pr))
        while d <= today:
            vals = [a["m"]["power_curve"].get("1200") for a in pr if d - timedelta(days=90) < a["d"] <= d]
            vals = [v for v in vals if v]
            if vals:
                eftp.append({"date": d.isoformat(), "w": round(max(vals) * 0.95)})
            d += timedelta(weeks=1)
    climbs = []
    for a in rides:
        for c in a["m"].get("climbs", []):
            c = dict(c, date=a["date"], id=a["id"], name=a["name"])
            if c.get("avg_power") and ath["weight"]:
                c["wkg"] = round(c["avg_power"] / ath["weight"], 2)
            climbs.append(c)
    vam_trend = []
    for a in rides:
        cs = [c for c in a["m"].get("climbs", []) if c["gain_m"] >= 150 and c.get("vam")]
        if cs:
            best = max(cs, key=lambda c: c["vam"])
            vam_trend.append({"date": a["date"], "vam": best["vam"], "gain": best["gain_m"], "id": a["id"]})
    pzones = [0] * 7
    if ftp:
        for a in rides:
            if a["d"] >= today - timedelta(days=28):
                pzones = [x + y for x, y in zip(pzones, power_zone_seconds(a["m"].get("power_hist"), ftp))]
    ef = [{"date": a["date"], "ef": a["m"]["ef"], "dec": a["m"].get("decoupling_pct"), "id": a["id"]}
          for a in rides if a["m"].get("ef") and a["m"].get("ef_basis") == "power"]
    outdoor = [a for a in rides if not a["indoor"] and a["distance_m"]]
    ytd = [a for a in rides if a["d"].year == today.year]
    best_eff = _best_efforts(rides)
    return {
        "ftp": ftp, "ftp_source": ftp_src, "weight": ath["weight"],
        "curves": curves, "eftp": eftp,
        "climbs_top": sorted(climbs, key=lambda c: -(c.get("vam") or 0))[:25],
        "climbs_recent": sorted(climbs, key=lambda c: c["date"], reverse=True)[:25],
        "climb_count": len(climbs), "vam_trend": vam_trend,
        "power_zones_28d_h": [round(x / 3600, 2) for x in pzones],
        "ef": ef,
        "speed": [{"date": a["date"], "kmh": round(a["avg_speed"] * 3.6, 1), "elev_per_km": round((a["elev_gain"] or 0) / (a["distance_m"] / 1000), 1), "id": a["id"]}
                  for a in outdoor if a["avg_speed"]],
        "ytd": {"km": round(sum((a["distance_m"] or 0) for a in ytd) / 1000), "elev": round(sum(a["elev_gain"] or 0 for a in ytd)),
                "h": round(sum(a["moving_s"] or 0 for a in ytd) / 3600), "n": len(ytd)},
        "best_efforts": best_eff,
        "rides": [_public(a, ftp) for a in reversed(rides[-60:])],
    }


# ------------------------------------------------------------------ running
def _best_efforts(acts):
    best, prog = {}, defaultdict(list)
    for a in acts:  # chronological
        for label, e in (a["m"].get("best_efforts") or {}).items():
            cur = best.get(label)
            if cur is None or e["seconds"] < cur["seconds"]:
                best[label] = {"label": label, "meters": e["meters"], "seconds": e["seconds"], "date": a["date"], "id": a["id"]}
                prog[label].append({"date": a["date"], "seconds": e["seconds"], "id": a["id"]})
    order = sorted(best.values(), key=lambda x: x["meters"])
    return {"best": order, "progression": prog}


def _best_in(acts, since):
    out = {}
    for a in acts:
        if a["d"] < since:
            continue
        for label, e in (a["m"].get("best_efforts") or {}).items():
            if label not in out or e["seconds"] < out[label]["seconds"]:
                out[label] = {"seconds": e["seconds"], "meters": e["meters"], "date": a["date"], "id": a["id"]}
    return out


@cached
def running():
    ath = athlete()
    runs = [a for a in activities() if a["sport"] == "run"]
    today = date.today()
    be = _best_efforts(runs)
    recent = _best_in(runs, today - timedelta(days=90))
    season = _best_in(runs, today - timedelta(days=365))
    # Race predictions (Riegel) from the strongest recent effort ≥ 3 km
    preds, basis = {}, None
    cands = [(v, k) for k, v in recent.items() if v["meters"] >= 3000]
    if cands:
        def eq10k(v):
            return v["seconds"] * (10000 / v["meters"]) ** RIEGEL
        v, k = min(cands, key=lambda c: eq10k(c[0]))
        basis = {"label": k, **v}
        for meters, label in ((5000, "5 km"), (10000, "10 km"), (21097.5, "Half marathon"), (42195, "Marathon")):
            preds[label] = round(v["seconds"] * (meters / v["meters"]) ** RIEGEL)
    z2 = ath["zones"]["run"][2]  # zone 3 floor: below = easy aerobic
    easy = [a for a in runs if a["avg_hr"] and a["avg_hr"] < z2 and a["m"].get("ef")]
    ytd = [a for a in runs if a["d"].year == today.year]
    return {
        "runs": [_public(a) for a in reversed(runs[-80:])],
        "trend": [{"date": a["date"], "pace": round((a["moving_s"] or a["duration_s"]) / (a["distance_m"] / 1000)), "km": round(a["distance_m"] / 1000, 2),
                   "hr": _r(a["avg_hr"], 0), "id": a["id"], "indoor": bool(a["indoor"])}
                  for a in runs if a["distance_m"] and a["distance_m"] > 500 and (a["moving_s"] or a["duration_s"])],
        "form": [{"date": a["date"], "cad": _r(a["avg_cadence"], 0), "stride": _r(a["avg_stride"], 2),
                  "gct": _r(a["avg_gct"], 0), "vo": _r(a["avg_vo"], 1)} for a in runs if a["avg_cadence"] or a["avg_gct"]],
        "vo2max": [{"date": a["date"], "v": a["vo2max"]} for a in runs if a["vo2max"]],
        "easy_ef": [{"date": a["date"], "ef": round(a["m"]["ef"], 3), "id": a["id"]} for a in easy],
        "best": be["best"], "progression": be["progression"], "best_90d": recent, "best_365d": season,
        "predictions": preds, "prediction_basis": basis,
        "ytd": {"km": round(sum((a["distance_m"] or 0) for a in ytd) / 1000), "h": round(sum(a["moving_s"] or 0 for a in ytd) / 3600),
                "n": len(ytd), "elev": round(sum(a["elev_gain"] or 0 for a in ytd))},
    }


# ------------------------------------------------------------------ recovery
@cached
def recovery(days: int = 365):
    con = db.connect()
    since = (date.today() - timedelta(days=days)).isoformat()
    rows = [dict(r) for r in con.execute("SELECT * FROM daily WHERE date>=? ORDER BY date", (since,))]
    ls = load_series()
    load_by_day = dict(zip(ls["days"], ls["load"]))
    for r in rows:
        r["load"] = load_by_day.get(r["date"], 0)

    def avg7(key):
        vals = [r.get(key) for r in rows]
        out = []
        for i in range(len(vals)):
            w = [v for v in vals[max(0, i - 6):i + 1] if v is not None]
            out.append(round(sum(w) / len(w), 1) if w else None)
        return out

    corr = {}

    def pearson(xs, ys):
        pairs = [(x, y) for x, y in zip(xs, ys) if x is not None and y is not None]
        if len(pairs) < 20:
            return None
        mx = sum(p[0] for p in pairs) / len(pairs); my = sum(p[1] for p in pairs) / len(pairs)
        sx = math.sqrt(sum((p[0] - mx) ** 2 for p in pairs)); sy = math.sqrt(sum((p[1] - my) ** 2 for p in pairs))
        return round(sum((p[0] - mx) * (p[1] - my) for p in pairs) / (sx * sy), 2) if sx and sy else None

    by = {r["date"]: r for r in rows}
    prev_load, hrv_next, sleep_h, rhr_next = [], [], [], []
    for r in rows:
        y = (date.fromisoformat(r["date"]) - timedelta(days=1)).isoformat()
        if y in by:
            prev_load.append(by[y]["load"]); hrv_next.append(r["hrv_night"]); rhr_next.append(r["resting_hr"])
            sleep_h.append((r["sleep_s"] or 0) / 3600 if r["sleep_s"] else None)
    corr["load_vs_next_hrv"] = pearson(prev_load, hrv_next)
    corr["load_vs_next_rhr"] = pearson(prev_load, rhr_next)
    corr["sleep_vs_hrv"] = pearson(sleep_h, hrv_next)

    # HRV after hard vs easy days
    hard, easy = [], []
    loads = sorted(l for l in prev_load if l)
    if len(loads) > 20:
        thr = loads[int(len(loads) * 0.75)]
        for l, h in zip(prev_load, hrv_next):
            if h is None:
                continue
            (hard if l >= thr else easy).append(h)
    corr["hrv_after_hard"] = _r(_mean(hard)); corr["hrv_after_easy"] = _r(_mean(easy))
    return {"rows": rows, "rhr7": avg7("resting_hr"), "hrv7": avg7("hrv_night"), "sleep7": avg7("sleep_s"), "corr": corr}


# ------------------------------------------------------------------ summary & insights
@cached
def summary():
    con = db.connect()
    acts = activities()
    today = date.today()
    wk = _week(today)
    ls = load_series()
    ath = athlete()

    def totals(a_list):
        t = {s: {"km": 0.0, "h": 0.0, "elev": 0.0, "n": 0} for s in ("run", "ride", "other")}
        for a in a_list:
            x = t[a["sport"]]
            x["km"] += (a["distance_m"] or 0) / 1000; x["h"] += (a["moving_s"] or a["duration_s"] or 0) / 3600
            x["elev"] += a["elev_gain"] or 0; x["n"] += 1
        return {s: {k: round(v, 1) for k, v in d.items()} for s, d in t.items()}

    this_week = totals([a for a in acts if a["d"] and a["d"] >= wk])
    prev4 = totals([a for a in acts if a["d"] and wk - timedelta(weeks=4) <= a["d"] < wk])
    prev4 = {s: {k: round(v / 4, 1) for k, v in d.items()} for s, d in prev4.items()}
    ytd = totals([a for a in acts if a["d"] and a["d"].year == today.year])

    last = {}
    for col in ("resting_hr", "hrv_night", "sleep_s", "sleep_score", "bb_high", "stress_avg", "steps", "hrv_status"):
        row = con.execute(f"SELECT date, {col} FROM daily WHERE {col} IS NOT NULL ORDER BY date DESC LIMIT 1").fetchone()
        last[col] = {"date": row[0], "value": row[1]} if row else None
    ftp, ftp_src = ftp_now()
    return {
        "today": today.isoformat(), "week_start": wk.isoformat(),
        "this_week": this_week, "avg_prev4": prev4, "ytd": ytd,
        "ctl": ls["ctl"][-1] if ls["ctl"] else None, "atl": ls["atl"][-1] if ls["atl"] else None,
        "tsb": ls["tsb"][-1] if ls["tsb"] else None,
        "ctl_7d_ago": ls["ctl"][-8] if len(ls["ctl"]) > 8 else None,
        "latest": last, "recent": [_public(a, ftp) for a in reversed(acts[-8:])],
        "athlete": {**ath, "ftp": ftp, "ftp_source": ftp_src},
        "last_sync": db.kv_get(con, "last_sync"), "n_activities": len(acts),
        "insights": insights(),
    }


def insights():
    out = []
    ls = load_series()
    acts = activities()
    today = date.today()
    con = db.connect()

    def add(level, title, text):
        out.append({"level": level, "title": title, "text": text})

    if ls["tsb"]:
        tsb, ctl = ls["tsb"][-1], ls["ctl"][-1]
        if tsb < -30:
            add("warn", "High fatigue", f"Form is {tsb:.0f}. Fatigue is well above fitness – plan 2–3 easy days soon.")
        elif tsb < -10:
            add("good", "Productive training", f"Form is {tsb:.0f}: you're building fitness. Keep easy days easy.")
        elif tsb > 15 and ctl > 20:
            add("info", "Fresh", f"Form is +{tsb:.0f}. Good for a race or a hard effort; prolonged rest will cost fitness.")
        if len(ls["ctl"]) > 8:
            ramp = ls["ctl"][-1] - ls["ctl"][-8]
            if ramp > 7:
                add("warn", "Load rising fast", f"Fitness (CTL) rose {ramp:.1f} in 7 days. Ramps above ~5–7 per week raise injury risk.")
            elif ramp < -5:
                add("info", "Load dropping", f"Fitness (CTL) fell {abs(ramp):.1f} in 7 days.")

    rows = [dict(r) for r in con.execute("SELECT date, resting_hr, hrv_night, hrv_low, sleep_s FROM daily WHERE date>=? ORDER BY date",
                                         ((today - timedelta(days=60)).isoformat(),))]
    if len(rows) > 21:
        last7 = rows[-7:]; base = rows[:-7]
        r7, rb = _mean([r["resting_hr"] for r in last7]), _mean([r["resting_hr"] for r in base])
        if r7 and rb and r7 - rb >= 4:
            add("warn", "Resting HR elevated", f"7-day resting HR {r7:.0f} bpm vs. {rb:.0f} baseline. Often a sign of fatigue, illness or stress.")
        elif r7 and rb and rb - r7 >= 2:
            add("good", "Resting HR trending down", f"7-day resting HR {r7:.0f} bpm vs. {rb:.0f} baseline.")
        h7, hb = _mean([r["hrv_night"] for r in last7]), _mean([r["hrv_night"] for r in base])
        if h7 and hb and h7 < hb * 0.9:
            add("warn", "HRV below baseline", f"7-day HRV {h7:.0f} ms vs. {hb:.0f} ms baseline – recovery is lagging.")
        s7 = _mean([r["sleep_s"] for r in last7])
        if s7 and s7 < 7 * 3600:
            add("info", "Short sleep", f"You've averaged {s7 / 3600:.1f} h sleep over the last 7 nights.")

    ath = athlete()
    recent = [a for a in acts if a["d"] and a["d"] >= today - timedelta(days=28) and a["m"].get("hr_hist")]
    if recent:
        z = [0] * 5
        for a in recent:
            z = [x + y for x, y in zip(z, zone_seconds(a["m"]["hr_hist"], ath["zones"][a["sport"]]))]
        tot = sum(z) or 1
        low, mid, high = (z[0] + z[1]) / tot, z[2] / tot, (z[3] + z[4]) / tot
        if mid > 0.3:
            add("info", "Lots of moderate intensity",
                f"{mid:.0%} of the last 4 weeks was in zone 3. Polarised training keeps ~80% easy (Z1–2) and makes hard sessions truly hard.")
        else:
            add("good", "Intensity balance", f"Last 4 weeks: {low:.0%} easy (Z1–2), {mid:.0%} moderate, {high:.0%} hard (Z4–5).")

    # new PRs in the last 14 days
    for sport, fn in (("run", running), ("ride", cycling)):
        try:
            data = fn()
        except Exception:
            continue
        fresh = [b["label"] for b in data["best_efforts"]["best"] if date.fromisoformat(b["date"]) >= today - timedelta(days=14)] \
            if sport == "ride" else [b["label"] for b in data["best"] if date.fromisoformat(b["date"]) >= today - timedelta(days=14)]
        if fresh:
            add("good", "New personal best" + ("s" if len(fresh) > 1 else ""),
                f"{'Running' if sport == 'run' else 'Cycling'}: {', '.join(fresh)}.")
    curve = cycling()["curves"]
    for p in curve["all"]:
        if p["s"] in (5, 60, 300, 1200) and date.fromisoformat(p["date"]) >= today - timedelta(days=14):
            label = {5: "5 s", 60: "1 min", 300: "5 min", 1200: "20 min"}[p["s"]]
            add("good", f"Power PR: {label}", f"{p['w']:.0f} W on {p['date']}.")
    return out


# ------------------------------------------------------------------ detail
def activity_detail(act_id: int):
    con = db.connect()
    r = con.execute("SELECT * FROM activities WHERE id=?", (act_id,)).fetchone()
    if not r:
        return None
    a = next((x for x in activities() if x["id"] == act_id), None)
    det = con.execute("SELECT * FROM activity_detail WHERE id=?", (act_id,)).fetchone()
    ath = athlete()
    ftp, _ = ftp_now()
    out = _public(a, ftp)
    m = a["m"]
    out["metrics"] = {k: v for k, v in m.items() if k not in ("hr_hist", "power_hist", "power_curve_wkg")}
    out["hr_zones_s"] = zone_seconds(m.get("hr_hist"), ath["zones"][a["sport"]]) if m.get("hr_hist") else None
    out["zone_floors"] = ath["zones"][a["sport"]]
    out["power_zones_s"] = power_zone_seconds(m.get("power_hist"), ftp) if m.get("power_hist") and ftp else None
    out["ftp"] = ftp
    out["if"] = round(out["np"] / ftp, 2) if out["np"] and ftp else None
    out["streams"] = db.unpack(det["streams"]) if det else None
    out["laps"] = json.loads(det["laps"]) if det and det["laps"] else []
    out["running_dyn"] = {"cad": _r(a["avg_cadence"], 0), "stride": _r(a["avg_stride"], 2), "gct": _r(a["avg_gct"], 0), "vo": _r(a["avg_vo"], 1)} if a["sport"] == "run" else None
    out["vo2max"] = a["vo2max"]
    out["trimp"] = _r(a["trimp"], 0)
    # how this effort compares to the all-time curve
    if m.get("power_curve"):
        allc = {p["s"]: p["w"] for p in cycling()["curves"]["all"]}
        out["curve_vs_best"] = [{"s": int(k), "w": v, "best": allc.get(int(k))} for k, v in m["power_curve"].items()]
    return out


def activity_list(sport=None, q=None, limit=50, offset=0):
    ftp, _ = ftp_now()
    acts = list(reversed(activities()))
    if sport:
        acts = [a for a in acts if a["sport"] == sport]
    if q:
        ql = q.lower()
        acts = [a for a in acts if ql in (a["name"] or "").lower() or ql in (a["location"] or "").lower() or ql in a["date"]]
    return {"total": len(acts), "items": [_public(a, ftp) for a in acts[offset:offset + limit]]}


def sync_status():
    con = db.connect()
    log = [dict(r) for r in con.execute("SELECT * FROM sync_log ORDER BY rowid DESC LIMIT 30")]
    pending = con.execute("SELECT count(*) FROM activities WHERE fit_status='pending'").fetchone()[0]
    counts = {r[0]: r[1] for r in con.execute("SELECT fit_status, count(*) FROM activities GROUP BY fit_status")}
    days = con.execute("SELECT count(*), min(date), max(date) FROM daily").fetchone()
    coverage = {}
    for col in ("steps", "resting_hr", "stress_avg", "bb_high", "sleep_s", "sleep_score", "hrv_night", "weight_kg"):
        coverage[col] = con.execute(f"SELECT count(*) FROM daily WHERE {col} IS NOT NULL").fetchone()[0]
    return {"last_sync": db.kv_get(con, "last_sync"), "log": log, "files_pending": pending, "file_status": counts,
            "daily_days": days[0], "daily_range": [days[1], days[2]], "coverage": coverage,
            "athlete": athlete()}
