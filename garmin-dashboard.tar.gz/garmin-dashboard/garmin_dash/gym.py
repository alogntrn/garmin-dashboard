"""Gym log: every set you enter on the Gym page, plus per-day notes and the block's settings.

Kept in its own file (data/gym.sqlite) so Garmin syncs and reprocessing never touch it.
The plan itself (exercises, sets, reps) lives in static/gym.js.
"""
from __future__ import annotations

import json
import re
import sqlite3
from datetime import date, datetime, timedelta

from . import config

DB_PATH = config.DATA_DIR / "gym.sqlite"

SCHEMA = """
CREATE TABLE IF NOT EXISTS sets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL, session TEXT, ex TEXT NOT NULL, name TEXT,
    side TEXT DEFAULT '', kg REAL, reps INTEGER, secs INTEGER, rir REAL,
    created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_sets_date ON sets(date);
CREATE INDEX IF NOT EXISTS idx_sets_ex ON sets(ex);
CREATE TABLE IF NOT EXISTS days (
    date TEXT PRIMARY KEY, session TEXT, pain INTEGER, done INTEGER DEFAULT 0, note TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
"""

SESSIONS = {"A", "B", "C", "R", "F"}
DEFAULT_START = "2026-11-19"  # same as static/gym.js; replaced by the date set on the Gym page
_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_EX = re.compile(r"^[a-z0-9][a-z0-9-]{0,59}$")


def connect() -> sqlite3.Connection:
    config.ensure_dirs()
    con = sqlite3.connect(DB_PATH, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.executescript(SCHEMA)
    return con


def _get(con, key, default=None):
    row = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return json.loads(row[0]) if row else default


def _put(con, key, value):
    con.execute("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)", (key, json.dumps(value)))


# ------------------------------------------------------------------ validation
def _date(v) -> str:
    v = str(v or "")
    if not _DATE.match(v):
        raise ValueError("date must be YYYY-MM-DD")
    date.fromisoformat(v)
    return v


def _num(v, lo, hi, integer=False):
    if v in (None, ""):
        return None
    try:
        x = float(str(v).replace(",", "."))
    except ValueError:
        raise ValueError(f"not a number: {v!r}")
    if not lo <= x <= hi:
        raise ValueError(f"{x} is outside {lo}–{hi}")
    return int(round(x)) if integer else round(x, 2)


def _text(v, n):
    return str(v or "").strip()[:n]


# ------------------------------------------------------------------ reads
def _garmin_strength(since: str) -> dict:
    """Strength / gym activities recorded on the watch, by date (read-only, optional)."""
    out: dict = {}
    if not config.DB_PATH.exists():
        return out
    try:
        con = sqlite3.connect(f"file:{config.DB_PATH}?mode=ro", uri=True, timeout=5)
        con.row_factory = sqlite3.Row
        rows = con.execute(
            "SELECT id, date, name, type_key, duration_s, avg_hr, training_load, calories FROM activities "
            "WHERE date >= ? AND (type_key LIKE '%strength%' OR type_key LIKE '%fitness_equipment%' "
            "OR type_key LIKE '%hiit%' OR type_key LIKE '%cardio%') ORDER BY start_local", (since,)).fetchall()
        con.close()
    except sqlite3.Error:
        return out
    for r in rows:
        out.setdefault(r["date"], []).append({
            "id": r["id"], "name": r["name"], "min": round((r["duration_s"] or 0) / 60),
            "hr": round(r["avg_hr"]) if r["avg_hr"] else None,
            "load": round(r["training_load"]) if r["training_load"] else None,
        })
    return out


def state(days_back: int = 420) -> dict:
    since = (date.today() - timedelta(days=days_back)).isoformat()
    with connect() as con:
        start = _get(con, "start")
        tests = _get(con, "tests", {})
        days = {r["date"]: dict(r) for r in con.execute("SELECT * FROM days WHERE date >= ?", (since,))}
        sets = [dict(r) for r in con.execute("SELECT * FROM sets WHERE date >= ? ORDER BY date, id", (since,))]
    return {"start": start, "tests": tests, "days": days, "sets": sets,
            "garmin": _garmin_strength(since), "today": date.today().isoformat()}


# ------------------------------------------------------------------ writes
def add_set(d: dict) -> dict:
    day = _date(d.get("date"))
    session = _text(d.get("session"), 1).upper() or None
    if session and session not in SESSIONS:
        raise ValueError("unknown session")
    ex = _text(d.get("ex"), 60).lower()
    if not _EX.match(ex):
        raise ValueError("bad exercise id")
    side = _text(d.get("side"), 1).upper()
    if side not in ("", "R", "L"):
        raise ValueError("side must be R, L or empty")
    row = {
        "date": day, "session": session, "ex": ex, "name": _text(d.get("name"), 80) or ex,
        "side": side,
        "kg": _num(d.get("kg"), 0, 1000),
        "reps": _num(d.get("reps"), 0, 500, integer=True),
        "secs": _num(d.get("secs"), 0, 7200, integer=True),
        "rir": _num(d.get("rir"), 0, 10),
        "created_at": datetime.now().isoformat(timespec="seconds"),
    }
    if row["reps"] is None and row["secs"] is None:
        raise ValueError("enter reps or seconds")
    with connect() as con:
        cur = con.execute(
            "INSERT INTO sets(date,session,ex,name,side,kg,reps,secs,rir,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
            tuple(row.values()))
        row["id"] = cur.lastrowid
        if session:
            con.execute("INSERT OR IGNORE INTO days(date, session, updated_at) VALUES(?,?,?)",
                        (day, session, row["created_at"]))
    return row


def delete_set(set_id: int) -> bool:
    with connect() as con:
        return con.execute("DELETE FROM sets WHERE id=?", (int(set_id),)).rowcount > 0


def save_day(d: dict) -> dict:
    day = _date(d.get("date"))
    with connect() as con:
        cur = con.execute("SELECT * FROM days WHERE date=?", (day,)).fetchone()
        row = dict(cur) if cur else {"date": day, "session": None, "pain": None, "done": 0, "note": ""}
        if "session" in d:
            s = _text(d.get("session"), 1).upper() or None
            if s and s not in SESSIONS:
                raise ValueError("unknown session")
            row["session"] = s
        if "pain" in d:
            row["pain"] = _num(d.get("pain"), 0, 10, integer=True)
        if "done" in d:
            row["done"] = 1 if d.get("done") else 0
        if "note" in d:
            row["note"] = _text(d.get("note"), 1000)
        row["updated_at"] = datetime.now().isoformat(timespec="seconds")
        con.execute("INSERT OR REPLACE INTO days(date,session,pain,done,note,updated_at) VALUES(?,?,?,?,?,?)",
                    (row["date"], row["session"], row["pain"], row["done"], row["note"], row["updated_at"]))
    return row


def save_settings(d: dict) -> dict:
    with connect() as con:
        if "start" in d:
            _put(con, "start", _date(d["start"]) if d["start"] else None)
        if "tests" in d:
            t = d["tests"] if isinstance(d["tests"], dict) else {}
            clean = {}
            for k, v in list(t.items())[:40]:
                k = _text(k, 20)
                if re.match(r"^[a-z0-9]{1,20}$", k):
                    clean[k] = _num(v, 0, 1000)
            _put(con, "tests", clean)
        return {"start": _get(con, "start"), "tests": _get(con, "tests", {})}


def session_on(day: date) -> str | None:
    """Gym session (A/B/C/R/F) planned or chosen for a day, None outside the block or if unused."""
    if not DB_PATH.exists():
        return None
    with connect() as con:
        row = con.execute("SELECT session FROM days WHERE date=?", (day.isoformat(),)).fetchone()
        if row and row[0]:
            return row[0]
        start = _get(con, "start") or DEFAULT_START
    i = (day - date.fromisoformat(start)).days
    return "ABCR"[i % 4] if 0 <= i < 28 else None
