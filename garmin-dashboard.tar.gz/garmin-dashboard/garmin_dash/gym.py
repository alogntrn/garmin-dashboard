"""Gym log: every set you enter on the Gym page, per-day notes, your own exercises and workouts.

Kept in its own file (data/gym.sqlite) so Garmin syncs and reprocessing never touch it.
The built-in plan and exercise library live in static/gym-lib.js.
Older databases are upgraded in place on first use (columns are only ever added, never dropped).
"""
from __future__ import annotations

import json
import re
import secrets
import sqlite3
from datetime import date, datetime, timedelta

from . import config

DB_PATH = config.DATA_DIR / "gym.sqlite"

SCHEMA = """
CREATE TABLE IF NOT EXISTS sets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL, session TEXT, ex TEXT NOT NULL, name TEXT,
    side TEXT DEFAULT '', kg REAL, reps INTEGER, secs INTEGER, rir REAL,
    created_at TEXT, slot TEXT, mins REAL
);
CREATE INDEX IF NOT EXISTS idx_sets_date ON sets(date);
CREATE INDEX IF NOT EXISTS idx_sets_ex ON sets(ex);
CREATE TABLE IF NOT EXISTS days (
    date TEXT PRIMARY KEY, session TEXT, pain INTEGER, done INTEGER DEFAULT 0, note TEXT, updated_at TEXT,
    swaps TEXT, extras TEXT
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS exercises (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, kind TEXT NOT NULL, uni INTEGER DEFAULT 0, cat TEXT,
    mus TEXT, note TEXT, archived INTEGER DEFAULT 0, created_at TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS workouts (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, color TEXT, items TEXT, note TEXT,
    archived INTEGER DEFAULT 0, created_at TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS ai_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, text TEXT NOT NULL, ctx TEXT,
    status TEXT NOT NULL DEFAULT 'queued', stage TEXT, model TEXT, result TEXT, applied TEXT, message TEXT,
    created_at TEXT, started_at TEXT, finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_ai_date ON ai_jobs(date);
"""
# columns added after the first release; ALTER TABLE adds them to older databases
_ADDED = {"sets": [("slot", "TEXT"), ("mins", "REAL"), ("src", "TEXT")],
          "days": [("swaps", "TEXT"), ("extras", "TEXT"), ("rpe", "REAL")]}

DEFAULT_START = "2026-11-19"  # same as static/gym.js; replaced by the date set on the Gym page
KINDS = {"kg", "reps", "secs", "hold", "min"}
MUSCLES = {"chest", "frontDelt", "sideDelt", "rearDelt", "biceps", "triceps", "forearms", "lats", "upperBack",
           "lowerBack", "abs", "obliques", "glutes", "abductors", "adductors", "quads", "hamstrings", "calves"}
_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9-]{0,59}$")  # library ids are case-sensitive (curlL); your own are x-…
_SESSION = re.compile(r"^(A|B|C|R|F|W\d{1,9})$")
_COLOR = re.compile(r"^#[0-9a-fA-F]{6}$")


def connect() -> sqlite3.Connection:
    config.ensure_dirs()
    con = sqlite3.connect(DB_PATH, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.executescript(SCHEMA)
    for table, cols in _ADDED.items():
        have = {r[1] for r in con.execute(f"PRAGMA table_info({table})")}
        for name, typ in cols:
            if name not in have:
                con.execute(f"ALTER TABLE {table} ADD COLUMN {name} {typ}")
    if not _get(con, "fix_curlL"):
        # v1/v2 lower-cased exercise ids, which turned the library's "curlL" into an unknown "curll"
        con.execute("UPDATE sets SET ex='curlL' WHERE ex='curll'")
        con.execute("UPDATE sets SET slot='curlL' WHERE slot='curll'")
        for table, col, key in (("days", "swaps", "date"), ("days", "extras", "date"), ("workouts", "items", "id")):
            for k, v in con.execute(f"SELECT {key}, {col} FROM {table} WHERE {col} LIKE '%\"curll\"%'").fetchall():
                con.execute(f"UPDATE {table} SET {col}=? WHERE {key}=?", (v.replace('"curll"', '"curlL"'), k))
        _put(con, "fix_curlL", True)
        con.commit()
    return con


def _get(con, key, default=None):
    row = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return json.loads(row[0]) if row else default


def _put(con, key, value):
    con.execute("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)", (key, json.dumps(value)))


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _loads(v, default):
    try:
        return json.loads(v) if v else default
    except (TypeError, ValueError):
        return default


# ------------------------------------------------------------------ validation
def _date(v) -> str:
    v = str(v or "")
    if not _DATE.match(v):
        raise ValueError("date must be YYYY-MM-DD")
    date.fromisoformat(v)
    return v


def _num(v, lo, hi, integer=False):
    if v in (None, ""):
        return None
    try:
        x = float(str(v).replace(",", "."))
    except ValueError:
        raise ValueError(f"not a number: {v!r}")
    if not lo <= x <= hi:
        raise ValueError(f"{x:g} is outside {lo}–{hi}")
    return int(round(x)) if integer else round(x, 2)


def _text(v, n):
    return str(v or "").strip()[:n]


def _id(v, what="exercise"):
    v = _text(v, 60)
    if not _ID.match(v):
        raise ValueError(f"bad {what} id")
    return v


def _session(v):
    v = _text(v, 12).upper()
    if not v:
        return None
    if not _SESSION.match(v):
        raise ValueError("unknown session")
    return v


def _side(v):
    v = _text(v, 1).upper()
    if v not in ("", "R", "L"):
        raise ValueError("side must be R, L or empty")
    return v


def _set_values(d: dict, partial=False) -> dict:
    out = {}
    fields = {"kg": (0, 1000, False), "reps": (0, 500, True), "secs": (0, 7200, True),
              "mins": (0, 600, False), "rir": (0, 10, False)}
    for k, (lo, hi, integer) in fields.items():
        if not partial or k in d:
            out[k] = _num(d.get(k), lo, hi, integer)
    if not partial or "side" in d:
        out["side"] = _side(d.get("side"))
    return out


# ------------------------------------------------------------------ reads
# watch recordings that can be a gym session (Strength, Cardio, HIIT, gym equipment or plain "Other")
_GYM_TYPES = ("(type_key LIKE '%strength%' OR type_key LIKE '%fitness_equipment%' OR type_key LIKE '%hiit%' "
              "OR type_key LIKE '%cardio%' OR type_key IN ('other', 'training', 'indoor_training'))")


def _garmin_strength(since: str) -> dict:
    """Strength / gym activities recorded on the watch, by date (read-only, optional)."""
    out: dict = {}
    if not config.DB_PATH.exists():
        return out
    try:
        con = sqlite3.connect(f"file:{config.DB_PATH}?mode=ro", uri=True, timeout=5)
        con.row_factory = sqlite3.Row
        rows = con.execute(
            "SELECT id, date, name, type_key, duration_s, avg_hr, training_load, calories FROM activities "
            f"WHERE date >= ? AND {_GYM_TYPES} ORDER BY start_local", (since,)).fetchall()
        con.close()
    except sqlite3.Error:
        return out
    for r in rows:
        out.setdefault(r["date"], []).append({
            "id": r["id"], "name": r["name"], "min": round((r["duration_s"] or 0) / 60),
            "hr": round(r["avg_hr"]) if r["avg_hr"] else None,
            "load": round(r["training_load"]) if r["training_load"] else None,
            "kcal": round(r["calories"]) if r["calories"] else None,
        })
    return out


def _day(r) -> dict:
    d = dict(r)
    d["swaps"] = _loads(d.get("swaps"), {})
    d["extras"] = _loads(d.get("extras"), [])
    return d


def _exercise(r) -> dict:
    d = dict(r)
    d["mus"] = _loads(d.get("mus"), {})
    d["uni"] = bool(d.get("uni"))
    d["archived"] = bool(d.get("archived"))
    return d


def _workout(r) -> dict:
    d = dict(r)
    d["items"] = _loads(d.get("items"), [])
    return d


def state(days_back: int = 420) -> dict:
    since = (date.today() - timedelta(days=days_back)).isoformat()
    with connect() as con:
        out = {
            "start": _get(con, "start"),
            "tests": _get(con, "tests", {}),
            "swaps": _get(con, "swaps", {}),
            "days": {r["date"]: _day(r) for r in con.execute("SELECT * FROM days WHERE date >= ?", (since,))},
            "sets": [dict(r) for r in con.execute("SELECT * FROM sets WHERE date >= ? ORDER BY date, id", (since,))],
            "exercises": [_exercise(r) for r in con.execute("SELECT * FROM exercises ORDER BY name")],
            "workouts": [_workout(r) for r in con.execute("SELECT * FROM workouts WHERE archived=0 ORDER BY name")],
        }
    out["garmin"] = _garmin_strength(since)
    out["today"] = date.today().isoformat()
    return out


# ------------------------------------------------------------------ sets
def add_set(d: dict) -> dict:
    row = {"date": _date(d.get("date")), "session": _session(d.get("session")), "ex": _id(d.get("ex")),
           "name": "", "slot": None}
    row["name"] = _text(d.get("name"), 80) or row["ex"]
    row["slot"] = _id(d["slot"], "slot") if d.get("slot") else row["ex"]
    row.update(_set_values(d))
    if row["reps"] is None and row["secs"] is None and row["mins"] is None:
        raise ValueError("enter reps, seconds or minutes")
    row["created_at"] = _now()
    row["src"] = _text(d.get("src"), 20) or None
    cols = ["date", "session", "ex", "name", "slot", "side", "kg", "reps", "secs", "mins", "rir", "created_at", "src"]
    with connect() as con:
        cur = con.execute(f"INSERT INTO sets({','.join(cols)}) VALUES({','.join('?' * len(cols))})",
                          [row[c] for c in cols])
        row["id"] = cur.lastrowid
        if row["session"]:
            con.execute("INSERT OR IGNORE INTO days(date, session, updated_at) VALUES(?,?,?)",
                        (row["date"], row["session"], row["created_at"]))
    return row


def update_set(set_id: int, d: dict) -> dict:
    vals = _set_values(d, partial=True)
    with connect() as con:
        cur = con.execute("SELECT * FROM sets WHERE id=?", (int(set_id),)).fetchone()
        if not cur:
            raise ValueError("set not found")
        row = {**dict(cur), **vals}
        if row["reps"] is None and row["secs"] is None and row["mins"] is None:
            raise ValueError("enter reps, seconds or minutes")
        sets_sql = ", ".join(f"{k}=?" for k in vals)
        if sets_sql:
            con.execute(f"UPDATE sets SET {sets_sql} WHERE id=?", [*vals.values(), int(set_id)])
    return row


def delete_set(set_id: int) -> bool:
    with connect() as con:
        return con.execute("DELETE FROM sets WHERE id=?", (int(set_id),)).rowcount > 0


# ------------------------------------------------------------------ days
def _get_day(con, day):
    cur = con.execute("SELECT * FROM days WHERE date=?", (day,)).fetchone()
    return _day(cur) if cur else {"date": day, "session": None, "pain": None, "done": 0, "note": "",
                                   "swaps": {}, "extras": [], "rpe": None}


def _put_day(con, row):
    row["updated_at"] = _now()
    con.execute("INSERT OR REPLACE INTO days(date,session,pain,done,note,updated_at,swaps,extras,rpe) VALUES(?,?,?,?,?,?,?,?,?)",
                (row["date"], row["session"], row["pain"], row["done"], row["note"], row["updated_at"],
                 json.dumps(row.get("swaps") or {}), json.dumps(row.get("extras") or []), row.get("rpe")))
    return row


def save_day(d: dict) -> dict:
    day = _date(d.get("date"))
    with connect() as con:
        row = _get_day(con, day)
        if "session" in d:
            row["session"] = _session(d.get("session"))
        if "pain" in d:
            row["pain"] = _num(d.get("pain"), 0, 10, integer=True)
        if "rpe" in d:
            row["rpe"] = _num(d.get("rpe"), 0, 10)
        if "done" in d:
            row["done"] = 1 if d.get("done") else 0
        if "note" in d:
            row["note"] = _text(d.get("note"), 1000)
        if "extras" in d:
            ex = d.get("extras") if isinstance(d.get("extras"), list) else []
            row["extras"] = list(dict.fromkeys(_id(x) for x in ex[:30]))
        return _put_day(con, row)


def swap(d: dict) -> dict:
    """Use another exercise for one slot of a day's session; already-logged sets of that slot move with it."""
    day, slot, ex = _date(d.get("date")), _id(d.get("slot"), "slot"), _id(d.get("ex"))
    name = _text(d.get("name"), 80) or ex
    clear = bool(d.get("clear"))
    with connect() as con:
        row = _get_day(con, day)
        if clear:
            row["swaps"].pop(slot, None)
        else:
            row["swaps"][slot] = ex
        if d.get("session"):
            row["session"] = row["session"] or _session(d.get("session"))
        _put_day(con, row)
        moved = con.execute("UPDATE sets SET ex=?, name=?, slot=? WHERE date=? AND (slot=? OR (slot IS NULL AND ex=?))",
                            (ex, name, slot, day, slot, slot)).rowcount
        if "persist" in d:
            g = _get(con, "swaps", {})
            if d.get("persist") and not clear:
                g[slot] = ex
            else:
                g.pop(slot, None)
            _put(con, "swaps", g)
        return {"day": row, "moved": moved, "swaps": _get(con, "swaps", {})}


def move_day(d: dict) -> dict:
    """Move a whole session (sets, notes, pain) to another date, e.g. when it was logged on the wrong day."""
    src, dst = _date(d.get("from")), _date(d.get("to"))
    if src == dst:
        raise ValueError("same date")
    with connect() as con:
        moved = con.execute("UPDATE sets SET date=? WHERE date=?", (dst, src)).rowcount
        a = con.execute("SELECT * FROM days WHERE date=?", (src,)).fetchone()
        if a:
            a = _day(a)
            b = con.execute("SELECT * FROM days WHERE date=?", (dst,)).fetchone()
            row = _day(b) if b else {**a, "date": dst}
            if b:
                for k in ("session", "pain", "note", "rpe"):
                    if row.get(k) in (None, "") and a.get(k) not in (None, ""):
                        row[k] = a[k]
                row["done"] = 1 if (row.get("done") or a.get("done")) else 0
                row["swaps"] = {**a["swaps"], **row["swaps"]}
                row["extras"] = list(dict.fromkeys(row["extras"] + a["extras"]))
            row["date"] = dst
            con.execute("DELETE FROM days WHERE date=?", (src,))
            _put_day(con, row)
        return {"moved": moved, "to": dst}


# ------------------------------------------------------------------ exercises & workouts
def _slug(name: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:40] or "exercise"
    return "x-" + s


def save_exercise(d: dict) -> dict:
    name = _text(d.get("name"), 60)
    if not name:
        raise ValueError("give the exercise a name")
    kind = _text(d.get("kind"), 8)
    if kind not in KINDS:
        raise ValueError("unknown exercise type")
    mus = {}
    for k, w in (d.get("mus") or {}).items():
        if k not in MUSCLES:
            raise ValueError(f"unknown muscle {k!r}")
        w = _num(w, 0, 1)
        if w:
            mus[k] = w
    row = {"name": name, "kind": kind, "uni": 1 if d.get("uni") else 0, "cat": _text(d.get("cat"), 30),
           "mus": json.dumps(mus), "note": _text(d.get("note"), 500), "updated_at": _now()}
    with connect() as con:
        ex_id = _text(d.get("id"), 60).lower()
        if ex_id:
            if not ex_id.startswith("x-") or not _ID.match(ex_id):
                raise ValueError("only your own exercises can be edited")
            exists = con.execute("SELECT 1 FROM exercises WHERE id=?", (ex_id,)).fetchone()
        else:
            base, ex_id, n = _slug(name), _slug(name), 2
            while con.execute("SELECT 1 FROM exercises WHERE id=?", (ex_id,)).fetchone():
                ex_id, n = f"{base}-{n}", n + 1
            exists = False
        if exists:
            con.execute("UPDATE exercises SET name=?, kind=?, uni=?, cat=?, mus=?, note=?, archived=0, updated_at=? WHERE id=?",
                        (*[row[k] for k in ("name", "kind", "uni", "cat", "mus", "note", "updated_at")], ex_id))
        else:
            con.execute("INSERT INTO exercises(id,name,kind,uni,cat,mus,note,archived,created_at,updated_at) VALUES(?,?,?,?,?,?,?,0,?,?)",
                        (ex_id, *[row[k] for k in ("name", "kind", "uni", "cat", "mus", "note")], row["updated_at"], row["updated_at"]))
        if d.get("rename_sets"):
            con.execute("UPDATE sets SET name=? WHERE ex=?", (name, ex_id))
        return _exercise(con.execute("SELECT * FROM exercises WHERE id=?", (ex_id,)).fetchone())


def delete_exercise(ex_id: str) -> bool:
    """Hide one of your exercises. Logged sets keep their name and numbers."""
    ex_id = _id(ex_id)
    with connect() as con:
        return con.execute("UPDATE exercises SET archived=1, updated_at=? WHERE id=?", (_now(), ex_id)).rowcount > 0


def save_workout(d: dict) -> dict:
    name = _text(d.get("name"), 60)
    if not name:
        raise ValueError("give the workout a name")
    color = _text(d.get("color"), 7)
    if color and not _COLOR.match(color):
        raise ValueError("bad colour")
    items = []
    for it in (d.get("items") or [])[:30]:
        if not isinstance(it, dict):
            continue
        k = _text(it.get("k"), 8).lower()
        if not re.match(r"^[a-z0-9]{4,8}$", k):
            k = secrets.token_hex(3)
        items.append({"k": k, "ex": _id(it.get("ex")), "sets": _num(it.get("sets"), 0, 20, integer=True) or 0,
                      "reps": _text(it.get("reps"), 40), "rest": _text(it.get("rest"), 30), "note": _text(it.get("note"), 200)})
    if not items:
        raise ValueError("add at least one exercise")
    now = _now()
    with connect() as con:
        wid = _num(d.get("id"), 1, 10**9, integer=True)
        if wid and con.execute("SELECT 1 FROM workouts WHERE id=?", (wid,)).fetchone():
            con.execute("UPDATE workouts SET name=?, color=?, items=?, note=?, archived=0, updated_at=? WHERE id=?",
                        (name, color, json.dumps(items), _text(d.get("note"), 500), now, wid))
        else:
            wid = con.execute("INSERT INTO workouts(name,color,items,note,archived,created_at,updated_at) VALUES(?,?,?,?,0,?,?)",
                              (name, color, json.dumps(items), _text(d.get("note"), 500), now, now)).lastrowid
        return _workout(con.execute("SELECT * FROM workouts WHERE id=?", (wid,)).fetchone())


def delete_workout(wid: int) -> bool:
    with connect() as con:
        return con.execute("UPDATE workouts SET archived=1, updated_at=? WHERE id=?", (_now(), int(wid))).rowcount > 0


# ------------------------------------------------------------------ settings
def save_settings(d: dict) -> dict:
    with connect() as con:
        if "start" in d:
            _put(con, "start", _date(d["start"]) if d["start"] else None)
        if "tests" in d:
            t = d["tests"] if isinstance(d["tests"], dict) else {}
            clean = {}
            for k, v in list(t.items())[:40]:
                k = _text(k, 20)
                if re.match(r"^[a-z0-9]{1,20}$", k):
                    clean[k] = _num(v, 0, 1000)
            _put(con, "tests", clean)
        return {"start": _get(con, "start"), "tests": _get(con, "tests", {})}


def session_on(day: date) -> str | None:
    """Gym session chosen for a day (A/B/C/F/W<id>, R on older days); None if nothing was chosen.
    Nothing is planned by date any more: a day's workout is what you pick when you train."""
    if not DB_PATH.exists():
        return None
    with connect() as con:
        row = con.execute("SELECT session FROM days WHERE date=?", (day.isoformat(),)).fetchone()
    return row[0] if row and row[0] else None


# ------------------------------------------------------------------ effort check (heart rate part)
def _median(v):
    v = sorted(v)
    n = len(v)
    return None if not n else v[n // 2] if n % 2 else (v[n // 2 - 1] + v[n // 2]) / 2


def _hr_analysis(t, hr, hrmax, floors):
    """Time-weighted HR summary of one gym recording plus a rough set/rest rhythm from the HR peaks."""
    pts = [(float(a), float(b)) for a, b in zip(t or [], hr or []) if a is not None and b is not None and 30 < b < 240]
    if len(pts) < 30:
        return None
    ts = [p[0] for p in pts]
    hs = [p[1] for p in pts]
    gaps = [ts[i + 1] - ts[i] for i in range(len(ts) - 1)]
    step = _median(gaps) or 1
    dts = [min(g, 4 * step) for g in gaps] + [step]          # pauses in the recording don't count as time
    total = sum(dts)
    avg = sum(h * dt for h, dt in zip(hs, dts)) / total
    zones = [0.0] * 6                                          # below zone 1, zones 1-5
    for h, dt in zip(hs, dts):
        zones[sum(1 for f in floors if h >= f)] += dt
    hi = sum(dt for h, dt in zip(hs, dts) if h >= 0.9 * hrmax)
    # smooth over ~±8 s, then peaks that rise >= 6 bpm above the lows on both sides (within 2.5 min)
    half = max(1, int(round(8 / step)))
    sm = []
    for i in range(len(hs)):
        w = hs[max(0, i - half): i + half + 1]
        sm.append(sum(w) / len(w))
    reach, look, peaks = max(1, int(round(40 / step))), max(2, int(round(150 / step))), []
    for i in range(len(sm)):
        lo, hi_i = max(0, i - reach), min(len(sm), i + reach + 1)
        if sm[i] < max(sm[lo:hi_i]) or (peaks and ts[i] - ts[peaks[-1]] < 45):
            continue
        left = min(sm[max(0, i - look): i + 1])
        right = min(sm[i: i + look + 1])
        if sm[i] - max(left, right) >= 6:
            peaks.append(i)
    cycles = [(ts[b] - ts[a]) / 60 for a, b in zip(peaks, peaks[1:]) if ts[b] - ts[a] <= 600]
    troughs = [min(sm[a:b + 1]) for a, b in zip(peaks, peaks[1:])]
    k = max(1, len(pts) // 240)
    t0 = ts[0]
    return {
        "avg": round(avg), "max": round(max(hs)), "pct_avg": round(avg / hrmax, 3),
        "zones_s": [round(z) for z in zones], "zone_floors": floors, "min_hi": round(hi / 60, 1),
        "peaks": len(peaks), "cycle_min": round(_median(cycles), 1) if len(cycles) >= 3 else None,
        "peak_pct": round(sum(sm[i] for i in peaks) / len(peaks) / hrmax, 3) if peaks else None,
        "trough_pct": round(sum(troughs) / len(troughs) / hrmax, 3) if troughs else None,
        "minutes": round(total / 60),
        "series": [[round((ts[i] - t0) / 60, 2), round(hs[i])] for i in range(0, len(ts), k)],
        "peak_pts": [[round((ts[i] - t0) / 60, 2), round(sm[i])] for i in peaks],
    }


def effort(day: str) -> dict:
    """Heart-rate side of the effort check for one day: the watch recording, if there is one.
    The verdict itself (RIR vs target, session rating, knee) is worked out on the page, where the plan lives."""
    day = _date(day)
    out = {"date": day, "activity": None, "hr": None, "others": [], "usual_pct": None}
    if not config.DB_PATH.exists():
        return out
    try:
        con = sqlite3.connect(f"file:{config.DB_PATH}?mode=ro", uri=True, timeout=5)
        con.row_factory = sqlite3.Row
        rows = con.execute(
            "SELECT a.id, a.name, a.type_key, a.start_local, a.duration_s, a.avg_hr, a.max_hr, a.training_load, d.streams "
            f"FROM activities a LEFT JOIN activity_detail d ON d.id = a.id WHERE a.date = ? AND {_GYM_TYPES} "
            "ORDER BY a.duration_s DESC", (day,)).fetchall()
        since = (date.fromisoformat(day) - timedelta(days=180)).isoformat()
        past = [r[0] for r in con.execute(
            f"SELECT avg_hr FROM activities WHERE date >= ? AND date < ? AND avg_hr > 0 AND duration_s >= 1200 AND {_GYM_TYPES}",
            (since, day))]
        con.close()
    except sqlite3.Error:
        return out
    if not rows:
        return out
    from . import analytics, db
    ath = analytics.athlete()
    hrmax, rest = ath["max_hr"] or 190, ath["rest_hr"] or 50
    r = rows[0]
    out["activity"] = {"id": r["id"], "name": r["name"], "type": (r["type_key"] or "").replace("_", " "),
                       "start": (r["start_local"] or "")[11:16], "min": round((r["duration_s"] or 0) / 60),
                       "avg_hr": round(r["avg_hr"]) if r["avg_hr"] else None, "max_hr": round(r["max_hr"]) if r["max_hr"] else None,
                       "load": round(r["training_load"]) if r["training_load"] else None}
    out["others"] = [{"id": x["id"], "name": x["name"]} for x in rows[1:]]
    out["hrmax"], out["hrrest"] = hrmax, rest
    if len(past) >= 3:
        out["usual_pct"] = round(_median(past) / hrmax, 3)
    try:
        st = db.unpack(r["streams"]) if r["streams"] else None
    except Exception:
        st = None
    if st:
        out["hr"] = _hr_analysis(st.get("t"), st.get("hr"), hrmax, ath["zones"]["other"])
    if not out["hr"] and r["avg_hr"]:
        out["hr"] = {"avg": round(r["avg_hr"]), "max": round(r["max_hr"]) if r["max_hr"] else None,
                     "pct_avg": round(r["avg_hr"] / hrmax, 3), "summary_only": True}
    return out
