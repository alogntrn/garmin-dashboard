"""Settings, read from config.ini next to the project (all values optional)."""
from __future__ import annotations

import configparser
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONFIG_FILE = Path(os.environ.get("GARMIN_DASH_CONFIG", ROOT / "config.ini"))

_cp = configparser.ConfigParser()
_cp.read(CONFIG_FILE)


def _get(section: str, key: str, default: str = "") -> str:
    env = os.environ.get(f"GARMIN_DASH_{section}_{key}".upper())
    if env is not None:
        return env
    return _cp.get(section, key, fallback=default).strip()


def _float(section: str, key: str) -> float | None:
    v = _get(section, key)
    try:
        return float(v) if v else None
    except ValueError:
        return None


# Garmin
BASE_URL = os.environ.get("GARMIN_PERSONAL_API_BASE_URL", "https://personal.connectapi.garmin.com").rstrip("/")
API_KEY_FILE = Path(_get("garmin", "api_key_file", "~/.config/garmin/connect-personal-api-key")).expanduser()
WELLNESS_YEARS = float(_get("garmin", "wellness_years", "5") or 5)
REQUEST_INTERVAL = float(_get("garmin", "request_interval", "0.4") or 0.4)

# Storage
DATA_DIR = Path(_get("storage", "data_dir", str(ROOT / "data"))).expanduser()
DB_PATH = DATA_DIR / "garmin.sqlite"
FIT_DIR = DATA_DIR / "fit"
TOKEN_CACHE = DATA_DIR / "token.json"

# Web server
HOST = _get("server", "host", "127.0.0.1")
PORT = int(_get("server", "port", "8050") or 8050)

# Athlete overrides (blank = use Garmin's values or estimate from data)
FTP = _float("athlete", "ftp")
MAX_HR = _float("athlete", "max_hr")
RESTING_HR = _float("athlete", "resting_hr")
WEIGHT_KG = _float("athlete", "weight_kg")


# Local AI (Ollama on the Pi) for "describe your workout" on the Gym page
AI_ENABLED = _get("ai", "enabled", "yes").lower() not in ("no", "false", "0", "off")
AI_URL = _get("ai", "url", "http://127.0.0.1:11434").rstrip("/")
AI_MODEL = _get("ai", "model", "qwen3:4b")
AI_THREADS = int(_float("ai", "threads") or 3)
AI_CTX = int(_float("ai", "context") or 6144)
AI_KEEP_ALIVE = _get("ai", "keep_alive", "2m")
AI_TIMEOUT_MIN = _float("ai", "timeout_minutes") or 25
AI_CAREFUL = _get("ai", "careful_pass", "yes").lower() not in ("no", "false", "0", "off")


def ensure_dirs() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    FIT_DIR.mkdir(parents=True, exist_ok=True)
