"""Per-activity analysis from the 1-second arrays produced by fitfile.parse()."""
from __future__ import annotations

import math

import numpy as np

POWER_DURATIONS = [1, 5, 10, 15, 30, 60, 120, 180, 300, 600, 1200, 1800, 2700, 3600, 5400, 7200]
RUN_EFFORTS = [(400, "400 m"), (1000, "1 km"), (1609.34, "1 mile"), (3000, "3 km"), (5000, "5 km"),
               (10000, "10 km"), (15000, "15 km"), (21097.5, "Half marathon"), (30000, "30 km"), (42195, "Marathon")]
RIDE_EFFORTS = [(5000, "5 km"), (10000, "10 km"), (20000, "20 km"), (40000, "40 km"), (50000, "50 km"),
                (100000, "100 km"), (160934, "100 miles")]


def _nan_to_none(a):
    return [None if (x is None or (isinstance(x, float) and math.isnan(x))) else round(float(x), 5) for x in a]


def _interp_nan(a: np.ndarray) -> np.ndarray:
    a = a.copy()
    ok = ~np.isnan(a)
    if ok.sum() < 2:
        return a
    idx = np.arange(len(a))
    a[~ok] = np.interp(idx[~ok], idx[ok], a[ok])
    return a


def _rolling_mean(a: np.ndarray, w: int) -> np.ndarray:
    if len(a) < w or w <= 1:
        return a.copy()
    cs = np.cumsum(np.insert(a, 0, 0.0))
    out = (cs[w:] - cs[:-w]) / w
    return np.concatenate([np.full(w - 1, out[0]), out])


def histogram(values: np.ndarray, lo: int, hi: int, step: int) -> list:
    v = values[~np.isnan(values)]
    if len(v) == 0:
        return []
    edges = np.arange(lo, hi + 2 * step, step)  # bins [lo, lo+step) ... [hi, hi+step)
    h, _ = np.histogram(np.clip(v, lo, hi), bins=edges)
    return [int(x) for x in h]


def best_efforts(t: np.ndarray, dist: np.ndarray, targets) -> dict:
    d = _interp_nan(dist)
    if np.isnan(d).all():
        return {}
    d = np.maximum.accumulate(np.nan_to_num(d))
    out = {}
    total = d[-1]
    for meters, label in targets:
        if total < meters * 0.999:
            continue
        j = np.searchsorted(d, d + meters, side="left")
        ok = j < len(d)
        if not ok.any():
            continue
        dt = t[j[ok]] - t[np.where(ok)[0]]
        if len(dt):
            i = int(np.argmin(dt))
            out[label] = {"meters": meters, "seconds": float(dt[i]), "start_s": float(t[i])}
    return out


def power_curve(p: np.ndarray) -> dict:
    p = np.nan_to_num(p)
    n = len(p)
    cs = np.cumsum(np.insert(p, 0, 0.0))
    out = {}
    for d in POWER_DURATIONS:
        if d > n:
            break
        out[str(d)] = round(float(np.max(cs[d:] - cs[:-d]) / d), 1)
    return out


def detect_climbs(t, alt, dist, rec, power, hr, drop=15.0) -> list:
    if np.isnan(alt).mean() > 0.5 or np.isnan(dist).mean() > 0.5:
        return []
    a = _rolling_mean(_interp_nan(alt), 20)
    d = np.maximum.accumulate(np.nan_to_num(_interp_nan(dist)))
    climbs = []

    def trim(s, p, win=250.0, min_grade=0.025):
        """Drop flat lead-in/run-out so a climb starts where the road actually tilts up."""
        while s < p:
            j = int(np.searchsorted(d, d[s] + win))
            if j >= p or (a[j] - a[s]) / win >= min_grade:
                break
            s = j
        while p > s:
            j = int(np.searchsorted(d, d[p] - win))
            if j <= s or (a[p] - a[j]) / win >= min_grade:
                break
            p = j
        return s, p

    def evaluate(s, p):
        s, p = trim(s, p)
        gain = a[p] - a[s]
        length = d[p] - d[s]
        if gain >= 50 and length >= 400 and gain / max(length, 1) >= 0.03:
            secs = float(rec[s:p + 1].sum()) or float(t[p] - t[s])
            seg_p = power[s:p + 1]; seg_h = hr[s:p + 1]
            climbs.append({
                "start_s": float(t[s]), "end_s": float(t[p]), "start_km": round(d[s] / 1000, 2),
                "length_m": round(float(length)), "gain_m": round(float(gain)),
                "grade_pct": round(float(gain / length * 100), 1), "duration_s": round(secs),
                "vam": round(float(gain / secs * 3600)) if secs > 0 else None,
                "avg_power": round(float(np.nanmean(seg_p)), 1) if np.isfinite(seg_p).any() else None,
                "avg_hr": round(float(np.nanmean(seg_h)), 1) if np.isfinite(seg_h).any() else None,
                "top_alt": round(float(a[p])),
            })

    s = pk = 0
    for i in range(1, len(a)):
        if a[i] >= a[pk]:
            pk = i
        elif a[pk] - a[i] > drop:
            evaluate(s, pk)
            s = pk = i
        if a[i] < a[s]:
            s = pk = i
    evaluate(s, pk)
    return climbs


def compute(grid: dict, sport: str, weight_kg: float | None = None) -> tuple[dict, dict]:
    """Return (metrics, streams) for one activity."""
    t = grid["t"]
    n = len(t)
    if n == 0:
        return {}, {}
    rec = grid["recording"]
    hr, pw, sp = grid["hr"], grid["power"], grid["speed"]
    m: dict = {"seconds": n, "recording_s": int(rec.sum())}

    has_hr = np.isfinite(hr[rec]).mean() > 0.5 if rec.any() else False
    has_pw = np.isfinite(pw[rec]).mean() > 0.5 if rec.any() else False
    m["has_hr"], m["has_power"] = bool(has_hr), bool(has_pw)

    if has_hr:
        m["hr_hist"] = histogram(hr[rec], 40, 220, 1)  # seconds per bpm, 40..220
    if has_pw:
        p_rec = np.nan_to_num(pw[rec])
        m["power_hist"] = histogram(pw[rec], 0, 1500, 10)
        m["power_curve"] = power_curve(np.where(rec, np.nan_to_num(pw), 0.0))
        if len(p_rec) >= 30:
            m["np"] = round(float(np.mean(_rolling_mean(p_rec, 30) ** 4) ** 0.25), 1)
        m["avg_power"] = round(float(p_rec.mean()), 1)
        m["work_kj"] = round(float(p_rec.sum()) / 1000, 1)
        if weight_kg:
            m["power_curve_wkg"] = {k: round(v / weight_kg, 2) for k, v in m["power_curve"].items()}

    # Efficiency factor and aerobic decoupling (first vs. second half)
    moving = rec & (np.nan_to_num(sp) > (1.0 if sport == "run" else 2.0))
    if has_hr and moving.sum() > 20 * 60:
        out = np.nan_to_num(pw) if has_pw else np.nan_to_num(sp) * 60  # W or m/min
        idx = np.where(moving & np.isfinite(hr))[0]
        if len(idx) > 600:
            ef = float(out[idx].mean() / np.nanmean(hr[idx]))
            m["ef"] = round(ef, 3)
            m["ef_basis"] = "power" if has_pw else "speed"
            half = len(idx) // 2
            a, b = idx[:half], idx[half:]
            ef1 = out[a].mean() / np.nanmean(hr[a])
            ef2 = out[b].mean() / np.nanmean(hr[b])
            if ef1 > 0 and len(idx) > 2400:
                m["decoupling_pct"] = round(float((ef1 - ef2) / ef1 * 100), 1)

    dist = grid["dist"]
    if sport == "run":
        m["best_efforts"] = best_efforts(t, dist, RUN_EFFORTS)
    elif sport == "ride":
        m["best_efforts"] = best_efforts(t, dist, RIDE_EFFORTS)
    m["climbs"] = detect_climbs(t, grid["alt"], dist, rec, pw, hr)

    # Downsampled streams for charts and the map
    k = max(1, math.ceil(n / 1500))
    nb = math.ceil(n / k)

    def bucket(a, how="mean"):
        pad = np.full(nb * k - n, np.nan)
        b = np.concatenate([a, pad]).reshape(nb, k)
        with np.errstate(all="ignore"):
            if how == "first":
                return b[:, 0]
            if how == "max":
                return np.nanmax(b, axis=1)
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", RuntimeWarning)
                return np.nanmean(b, axis=1)

    streams = {"t": [int(x) for x in t[::k]]}
    for key in ("hr", "power", "speed", "cadence", "alt", "temp"):
        arr = grid.get(key)
        if arr is not None and np.isfinite(arr).any():
            streams[key] = _nan_to_none(np.round(bucket(arr), 2))
    if np.isfinite(dist).any():
        streams["dist"] = _nan_to_none(np.round(bucket(_interp_nan(dist), "first") / 1000, 4))
    lat, lon = grid["lat"], grid["lon"]
    if np.isfinite(lat).sum() > 10:
        streams["lat"] = _nan_to_none(np.round(bucket(lat, "first"), 6))
        streams["lon"] = _nan_to_none(np.round(bucket(lon, "first"), 6))
    return m, streams
