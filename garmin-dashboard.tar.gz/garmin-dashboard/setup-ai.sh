#!/usr/bin/env bash
# Sets up the local AI behind "Describe it in words" on the Gym page:
# Ollama plus one small model, limited so the dashboard (and anything else on the Pi) stays responsive.
# Safe to run again: it updates Ollama and re-applies the limits.
# Run from the project folder:  ./setup-ai.sh
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"
[ -f config.ini ] || cp config.example.ini config.ini

ini() { sed -n "/^\[ai\]/,/^\[/{s/^[[:space:]]*$1[[:space:]]*=[[:space:]]*//p}" config.ini | head -1; }
MODEL="$(ini model)"; MODEL="${MODEL:-qwen3:4b}"
THREADS="$(ini threads)"; THREADS="${THREADS:-3}"

echo "==> Checking the Pi"
[ "$(uname -m)" = "aarch64" ] || { echo "Needs a 64-bit OS (uname -m says $(uname -m))."; exit 1; }
MEM_MB=$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)
FREE_GB=$(df -BG --output=avail / | tail -1 | tr -dc '0-9')
echo "   RAM ${MEM_MB} MB, free disk ${FREE_GB} GB, model ${MODEL}, ${THREADS} threads"
[ "$MEM_MB" -ge 6000 ] || echo "   Note: with under 8 GB RAM use a smaller model – set  model = qwen3:1.7b  under [ai] in config.ini."
[ "${FREE_GB:-0}" -ge 5 ] || { echo "Less than 5 GB free disk – free some space first (old models: ollama list / ollama rm <name>)."; exit 1; }

echo "==> Installing or updating Ollama (official installer)"
curl -fsSL https://ollama.com/install.sh | sh

echo "==> Limiting Ollama: one job and one model at a time, low priority, at most ${THREADS} of 4 cores"
sudo mkdir -p /etc/systemd/system/ollama.service.d
sudo tee /etc/systemd/system/ollama.service.d/garmin-dashboard.conf >/dev/null <<EOF
# written by garmin-dashboard/setup-ai.sh
[Service]
Environment="OLLAMA_HOST=127.0.0.1:11434"
Environment="OLLAMA_NUM_PARALLEL=1"
Environment="OLLAMA_MAX_LOADED_MODELS=1"
Environment="OLLAMA_KEEP_ALIVE=2m"
Nice=10
CPUQuota=${THREADS}00%
IOSchedulingClass=idle
MemoryMax=5500M
EOF
sudo systemctl daemon-reload
sudo systemctl enable ollama >/dev/null 2>&1 || true
sudo systemctl restart ollama
for _ in $(seq 1 30); do curl -fsS http://127.0.0.1:11434/api/version >/dev/null 2>&1 && break; sleep 1; done
echo "   Ollama $(curl -fsS http://127.0.0.1:11434/api/version | sed 's/.*"version":"\([^"]*\)".*/\1/')"

echo "==> Downloading ${MODEL} (qwen3:4b is about 2.5 GB)"
ollama pull "$MODEL"

if ! grep -q '^\[ai\]' config.ini; then
  echo "==> Adding an [ai] section to config.ini (all optional)"
  cat >> config.ini <<EOF

[ai]
# "Describe it in words" on the Gym page, using Ollama on this Pi
enabled = yes
model = ${MODEL}
threads = ${THREADS}
EOF
fi

echo "==> Test run (loads the model once – about a minute on a Pi 4)"
START=$(date +%s)
RES=$(curl -fsS http://127.0.0.1:11434/api/generate \
  -d "{\"model\":\"${MODEL}\",\"prompt\":\"Reply with: OK\",\"stream\":false,\"think\":false,\"keep_alive\":\"10s\",\"options\":{\"num_predict\":8,\"num_thread\":${THREADS}}}")
python3 - "$RES" <<'PY'
import json, sys
d = json.loads(sys.argv[1])
sec = lambda k: d.get(k, 0) / 1e9
rate = lambda n, k: d.get(n, 0) / max(sec(k), 1e-9)
print("   answer: %r · load %.0f s · reading %.0f tokens/s · writing %.1f tokens/s"
      % (d.get("response", "").strip()[:30], sec("load_duration"),
         rate("prompt_eval_count", "prompt_eval_duration"), rate("eval_count", "eval_duration")))
PY
echo "   took $(( $(date +%s) - START )) s"

OLD=$(ollama list | awk 'NR>1 {print $1}' | grep -vx "$MODEL" || true)
if [ -n "$OLD" ]; then
  echo "==> Other models on this Pi (not needed for the dashboard):"
  echo "$OLD" | sed 's/^/   /'
  echo "   Free their disk space with:  ollama rm <name>"
fi

echo "==> Restarting the dashboard"
sudo systemctl restart garmin-dashboard.service
echo "Done. Gym page → today's session → \"Describe it in words (AI)\"."
