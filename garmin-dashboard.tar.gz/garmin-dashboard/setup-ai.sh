#!/usr/bin/env bash
# Sets up the local AI behind "Describe it in words" on the Gym page:
# Ollama plus one small model, limited so the dashboard (and anything else on the Pi) stays responsive.
# Safe to run again: it updates Ollama and re-applies the limits.
# Run from the project folder:  ./setup-ai.sh
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"
[ -f config.ini ] || cp config.example.ini config.ini

ini() { sed -n "/^\[ai\]/,/^\[/{s/^[[:space:]]*$1[[:space:]]*=[[:space:]]*//p}" config.ini | head -1; }
# qwen3:4b is now the "thinking" model (always reasons first) - right for the careful pass, too slow for the quick one.
# The first version of this script wrote "model = qwen3:4b"; move that to the pair used now.
if [ "$(ini model)" = "qwen3:4b" ] && [ -z "$(ini careful_model)" ]; then
  sed -i '/^\[ai\]/,/^\[/{s/^model = qwen3:4b$/model = qwen3:4b-instruct-2507-q4_K_M\ncareful_model = qwen3:4b/}' config.ini
  echo "==> config.ini: quick pass -> qwen3:4b-instruct-2507-q4_K_M, careful pass -> qwen3:4b"
fi
MODEL="$(ini model)"; MODEL="${MODEL:-qwen3:4b-instruct-2507-q4_K_M}"
CAREFUL="$(ini careful_model)"; CAREFUL="${CAREFUL:-qwen3:4b}"
THREADS="$(ini threads)"; THREADS="${THREADS:-3}"

echo "==> Checking the Pi"
[ "$(uname -m)" = "aarch64" ] || { echo "Needs a 64-bit OS (uname -m says $(uname -m))."; exit 1; }
MEM_MB=$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)
FREE_GB=$(df -BG --output=avail / | tail -1 | tr -dc '0-9')
echo "   RAM ${MEM_MB} MB, free disk ${FREE_GB} GB, models ${MODEL} + ${CAREFUL}, ${THREADS} threads"
[ "$MEM_MB" -ge 6000 ] || echo "   Note: with under 8 GB RAM use a smaller model – set  model = qwen3:1.7b  under [ai] in config.ini."
[ "${FREE_GB:-0}" -ge 5 ] || { echo "Less than 5 GB free disk – free some space first (old models: ollama list / ollama rm <name>)."; exit 1; }

echo "==> Installing or updating Ollama (official installer)"
curl -fsSL https://ollama.com/install.sh | sh

echo "==> Limiting Ollama: one job and one model at a time, low priority, at most ${THREADS} of 4 cores"
sudo mkdir -p /etc/systemd/system/ollama.service.d
sudo tee /etc/systemd/system/ollama.service.d/garmin-dashboard.conf >/dev/null <<EOF
# written by garmin-dashboard/setup-ai.sh
[Service]
Environment="OLLAMA_HOST=127.0.0.1:11434"
Environment="OLLAMA_NUM_PARALLEL=1"
Environment="OLLAMA_MAX_LOADED_MODELS=1"
Environment="OLLAMA_KEEP_ALIVE=2m"
Nice=10
CPUQuota=${THREADS}00%
IOSchedulingClass=idle
MemoryMax=5500M
EOF
sudo systemctl daemon-reload
sudo systemctl enable ollama >/dev/null 2>&1 || true
sudo systemctl restart ollama
for _ in $(seq 1 30); do curl -fsS http://127.0.0.1:11434/api/version >/dev/null 2>&1 && break; sleep 1; done
echo "   Ollama $(curl -fsS http://127.0.0.1:11434/api/version | sed 's/.*"version":"\([^"]*\)".*/\1/')"

echo "==> Downloading the models (2.5 GB each; already downloaded ones are only checked)"
ollama pull "$MODEL"
[ "$CAREFUL" = "$MODEL" ] || ollama pull "$CAREFUL"

if ! grep -q '^\[ai\]' config.ini; then
  echo "==> Adding an [ai] section to config.ini (all optional)"
  cat >> config.ini <<EOF

[ai]
# "Describe it in words" on the Gym page, using Ollama on this Pi
enabled = yes
model = ${MODEL}
careful_model = ${CAREFUL}
threads = ${THREADS}
EOF
fi

echo "==> Speed test with the quick model and a prompt as long as a real one (1-3 minutes)"
START=$(date +%s)
BODY=$(python3 - "$MODEL" "$THREADS" <<'PY'
import json, sys
text = "bench 3x8 at 60 kg, leg press both legs 3x12 at 120 kg, 10 min abs. " * 45
print(json.dumps({"model": sys.argv[1], "prompt": text + "\nReply with just: OK", "stream": False, "think": False,
                  "keep_alive": "10s", "options": {"num_predict": 12, "num_thread": int(sys.argv[2]), "num_ctx": 6144}}))
PY
)
RES=$(curl -fsS http://127.0.0.1:11434/api/generate -d "$BODY")
python3 - "$RES" <<'PY'
import json, sys
d = json.loads(sys.argv[1])
sec = lambda k: d.get(k, 0) / 1e9
read = d.get("prompt_eval_count", 0) / max(sec("prompt_eval_duration"), 1e-9)
write = d.get("eval_count", 0) / max(sec("eval_duration"), 1e-9)
print("   answer: %r · load %.0f s · reading %.0f tokens/s · writing %.1f tokens/s"
      % (d.get("response", "").strip()[:30], sec("load_duration"), read, write))
if read and write:
    quick = 1100 / read + 250 / write
    print("   -> a typical description: about %.0f min for the quick pass" % max(1, round(quick / 60)))
PY
echo "   took $(( $(date +%s) - START )) s"

OLD=$(ollama list | awk 'NR>1 {print $1}' | grep -vx -e "$MODEL" -e "$CAREFUL" -e "${CAREFUL}:latest" || true)
if [ -n "$OLD" ]; then
  echo "==> Other models on this Pi (not needed for the dashboard):"
  echo "$OLD" | sed 's/^/   /'
  echo "   Free their disk space with:  ollama rm <name>"
fi

echo "==> Restarting the dashboard"
sudo systemctl restart garmin-dashboard.service
echo "Done. Gym page → today's session → \"Describe it in words (AI)\"."
